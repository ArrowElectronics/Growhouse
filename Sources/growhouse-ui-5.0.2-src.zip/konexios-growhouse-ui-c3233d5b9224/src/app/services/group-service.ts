import { Injectable, EventEmitter } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { environment, appConfig } from '../../environments/environment';
import { Device, channelConfig, DeviceType } from '../models/device.model';
import { String } from 'typescript-string-operations';
import { Group } from '../models/group.model';


@Injectable({
    providedIn: 'root',
})
export class GroupService {
    private url: string = environment.appServerURL;
    selectedGroup = new EventEmitter<Group>();
    editedGroup = new EventEmitter<Group>();
    constructor(private http: HttpClient) {
    }

    getGroupsByGrowarea(growareaId: number) {
        return this.http.get(this.url + String.Format(appConfig.getGroups, growareaId));
    }
    createGroup(group) {
        return this.http.post(this.url + appConfig.createGroup, group);
    }
    updateGroup(group) {
        return this.http.put(this.url + appConfig.createGroup, group);
    }
    deleteGroup(groupId) {
        return this.http.delete(String.Format(this.url + appConfig.deleteGroup, groupId));
    }
    getGroupByGroupId(groupId){
        return this.http.get(this.url + appConfig.getGroupByGroupId + '/' + groupId);
    }
    getDevicesByGroup(obj, gatewayId) {
        return this.http.put(this.url + String.Format(appConfig.getDevicesByGroup, gatewayId), obj);
    }
    getEventsByGroupId(groupId) {
        return this.http.get(this.url + String.Format(appConfig.getEventsByGroupId, groupId));
    }
    deleteEvent(name) {
        return this.http.delete(String.Format(this.url + appConfig.deleteEvent, name));
    }
}
