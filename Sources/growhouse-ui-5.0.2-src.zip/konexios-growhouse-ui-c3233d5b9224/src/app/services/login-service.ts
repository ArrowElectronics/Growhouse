import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { environment, appConfig } from "src/environments/environment";
import { UserLogin, UserChangePassword } from "../models/user.model";
import { String } from "typescript-string-operations";

@Injectable({
  providedIn: "root",
})
export class LoginService {
  private url: string = environment.appServerURL;
  private token: string;
  constructor(private http: HttpClient) {}

  signIn(userLogin: UserLogin) {
    return this.http.post(this.url + appConfig.signIn, userLogin);
  }

  signOut() {
    return this.http.post(this.url + appConfig.signOut, null);
  }

  resetStorage() {
    localStorage.removeItem("userDetails");
    localStorage.removeItem("loggedInUser");
    this.token = null;
  }

  resetPassword(username: string) {
    console.log("resetPassword: " + username);
    return this.http.post(
      this.url + String.Format(appConfig.resetPassword, username),
      null
    );
  }

  changePassword(payload: UserChangePassword) {
    console.log("username: " + payload.login);
    return this.http.post(
      this.url + String.Format(appConfig.changePassword, payload.login),
      payload
    );
  }

  getToken() {
    this.token = "";
    if (localStorage.getItem("userDetails")) {
      this.token = JSON.parse(localStorage.getItem("userDetails")).token;
    }
    return this.token;
  }
}
