import { Injectable, EventEmitter } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { environment, appConfig } from '../../environments/environment';

import { User } from '../models/user.model';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class GlobalService {
  private url: string = environment.appServerURL;
  selectedProfile = new EventEmitter<any>();
  private router: Router
  constructor(private http: HttpClient, ) { }

  // refresh(){

  // }


  getCounts() {
    return this.http.get(this.url + appConfig.countByUser);
  }

  getAlertsByProfile(profileId) {
    return this.http.get(
      this.url + appConfig.profileAlerts + '/' + profileId + '/lasthours'
    );
  }

  getProfileAlertsByGrowSectionId(sectionId) {
    return this.http.get(
      this.url + appConfig.profileAlertsByGrowsection + '/' + sectionId
    );
  }

  getNormalUserDashboardCount() {
    return this.http.get(this.url + appConfig.normalUserDashboardCount);
  }

  getProfileAlerts() {
    return this.http.get(this.url + appConfig.profileAlerts + '/user');
  }

  getProfileAlertByProfileId(profileId) {
    return this.http.get(this.url + appConfig.profiles + '/' + profileId);
  }

  getProfileHistoryForGrowAreas(profileId, fromTimestamp, toTimestamp) {
    console.log('fromTimestamp' + fromTimestamp);
    return this.http.get(this.url + appConfig.profileAlerts + '/' + profileId + '/history?fromTimestamp=' + fromTimestamp + '&toTimestamp=' + toTimestamp);
  }

  getProfileAlertsByContainerId(containerId) {
    return this.http.get(
      this.url + appConfig.profileAlertsByContainer + '/' + containerId
    );
  }

  getProfileAlertsByFacilityId(facilityId) {
    return this.http.get(
      this.url + appConfig.profileAlertsByFacility + '/' + facilityId
    );
  }

  getProfileAlertsByGrowareaId(growareaId) {
    return this.http.get(
      this.url + appConfig.profileAlertsByGrowarea + '/' + growareaId
    );
  }

  createProfile(sectionId, profileObj) {
    return this.http.post(
      this.url + appConfig.createProfile + '/' + sectionId + '/create',
      profileObj
    );
  }

  updateProfile(profileId, growsectionId, profileObj) {
    return this.http.put(
      this.url + appConfig.updateGrowsectionProfileById + '/' + profileId + '/growsection/' + growsectionId + '/update', profileObj
    );
  }

  getProfilesByGrowSectionId(sectionId) {
    return this.http.get(
      this.url + appConfig.profilesByGrowsection + '/' + sectionId
    );
  }

  getPropertiesByProfileId(profileId) {
    return this.http.get(
      this.url + appConfig.propertiesByprofileId + '/' + profileId
    );
  }

  getProfiles() {
    return this.http.get(this.url + appConfig.profiles + '/user');
  }

  getProfilesByContainerId(containerId) {
    return this.http.get(
      this.url + appConfig.profilesByContainer + '/' + containerId
    );
  }

  getProfilesByFacilityId(facilityId) {
    return this.http.get(
      this.url + appConfig.profilesByFacility + '/' + facilityId
    );
  }

  getProfilesByGrowareaId(growareaId) {
    return this.http.get(
      this.url + appConfig.profilesByGrowarea + '/' + growareaId
    );
  }

  deleteProfile(profileId) {
    return this.http.delete(this.url + appConfig.profiles + '/' + profileId);
  }

  getOutOfNetworkCount() {
    return this.http.get(this.url + appConfig.growAreaOutOfNetworkCount);
  }

  getOutOfNetworkCountByContainer(containerId) {
    return this.http.get(
      this.url +
      appConfig.growAreaOutOfNetworkCountByContainer +
      '/' +
      containerId
    );
  }

  getOutOfNetworkCountByFacility(facilityId) {
    return this.http.get(
      this.url +
      appConfig.growAreaOutOfNetworkCountByFacility +
      '/' +
      facilityId
    );
  }

  getSuperAdminDashboardCount() {
    return this.http.get(this.url + appConfig.superAdminDashboardCount);
  }
  handleClick() {
    console.log(window.location.href);
    const eafwec = window.location.href.split('/');
    console.log(eafwec);
    if (eafwec.length % 2 === 0) {
      location.reload();
    }
  }
}
