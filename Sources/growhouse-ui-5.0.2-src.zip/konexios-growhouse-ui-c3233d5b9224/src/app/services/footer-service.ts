import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { environment, appConfig } from "../../environments/environment";

@Injectable({
  providedIn: "root",
})
export class FooterService {
  constructor(private http: HttpClient) {}
  private url: string = environment.appServerURL;

  getReleaseVersion() {
    return this.http.get(this.url + appConfig.releaseVersion);
  }
}
