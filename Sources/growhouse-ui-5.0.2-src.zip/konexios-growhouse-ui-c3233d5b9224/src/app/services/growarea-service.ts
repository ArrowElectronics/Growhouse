import { Injectable, EventEmitter } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment, appConfig } from '../../environments/environment';
import { Facility } from '../models/facility.model';
import { Container } from '../models/container.model';
import { GrowArea } from '../models/growarea.model';
import { DeviceType } from '../models/device.model';
import { String } from 'typescript-string-operations';

@Injectable({
  providedIn: 'root',
})

export class GrowAreaService {
  private url: string = environment.appServerURL;
  selectedGrowArea = new EventEmitter<GrowArea>();
  constructor(private http: HttpClient) {
  }

  getGrowAreaList() {
    return this.http.get(this.url + appConfig.dashboardCount);
  }

  getGrowAreas() {
    return this.http.get(this.url + appConfig.growareas);
  }

  getGrowAreaTypes() {
    return this.http.get(this.url + appConfig.growareatypes);
  }

  getCountByGrowAreaId(growareaId: number) {
    return this.http.get(this.url + appConfig.countByGrowArea + '/' + growareaId);
  }

  createGrowArea(growArea: GrowArea) {
    return this.http.post(this.url + appConfig.growareas, growArea);
  }

  editGrowArea(growArea: GrowArea, growAreaId: number) {
    return this.http.put(this.url + appConfig.growareas + '/' + growAreaId, growArea);
  }

  deleteGrowAreaByLedProfile(growAreaId: number) {
    return this.http.delete(this.url + appConfig.deletGrowAreaByProfileLedNode + '/' + growAreaId);
  }

  deletGrowAreaByDesireValues(growAreaId: number) {
    return this.http.delete(this.url + appConfig.deletGrowAreaByDesireValueLedNode + '/' + growAreaId);
  }

  deletGrowAreaByChannelConfiguration(growAreaId: number) {
    return this.http.delete(this.url + appConfig.deletGrowAreaBychannelConfigurationLedNode + '/' + growAreaId);
  }

  deletGrowAreaByPropertyMapping(growAreaId: number) {
    return this.http.delete(this.url + appConfig.deletGrowAreaBypropertyMapping + '/' + growAreaId);
  }

  deletGrowAreaBySection(growAreaId: number) {
    return this.http.delete(this.url + appConfig.deletGrowAreaBySection + '/' + growAreaId);
  }

  deletGrowDevicesFromGateway(growAreaId: number) {
    return this.http.delete(this.url + appConfig.deletGrowDevicesFromGateway + '/' + growAreaId);
  }

  deletProfileAlertsFromGateway(growAreaId: number) {
    return this.http.delete(this.url + appConfig.deletProfileAlertsFromGateway + '/' + growAreaId);
  }

  deletProfiles(growAreaId: number) {
    return this.http.delete(this.url + appConfig.deletProfile + '/' + growAreaId);
  }

  deletGrowSections(growAreaId: number) {
    return this.http.delete(this.url + appConfig.deletGrowSections + '/' + growAreaId);
  }

  deletGroups(growAreaId: number) {
    return this.http.delete(this.url + String.Format(appConfig.deletGroups, growAreaId));
  }

  deletGrowAreaAsignee(growAreaId: number) {
    return this.http.delete(this.url + appConfig.deletGrowAreaAsignee + '/' + growAreaId);
  }

  deletGrowArea(growAreaId: number) {
    return this.http.delete(this.url + appConfig.deletGrowArea + '/' + growAreaId);
  }

  getGrowAreasByFacility(facilityId: number) {
    return this.http.get(this.url + appConfig.growareasByFacility + '/' + facilityId);
  }

  getGrowAreasByContainer(containerId: number) {
    return this.http.get(this.url + appConfig.growareasByContainer + '/' + containerId);
  }

  getGrowAreaById(growareaId: number) {
    return this.http.get(this.url + appConfig.growareas + '/' + growareaId);
  }

  getNoNetworkGrowarea() {
    return this.http.get(this.url + appConfig.growAreaOutOfNetwork);
  }

}
