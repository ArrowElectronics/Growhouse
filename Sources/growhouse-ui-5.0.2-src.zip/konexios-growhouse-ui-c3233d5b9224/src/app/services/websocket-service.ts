import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root',
})
export class WebSocketService {
  private url: string = environment.websocketServerURL;
  private websocketConnection;
  constructor() {
  }

  connect() {
    console.log(this.url);
    this.websocketConnection = new WebSocket(this.url);
    return this.websocketConnection;
  }

  disconnect(wsObj) {
    wsObj.close();
  }

  send(topic, wsObj) {
    wsObj.send(topic);
  }


}
