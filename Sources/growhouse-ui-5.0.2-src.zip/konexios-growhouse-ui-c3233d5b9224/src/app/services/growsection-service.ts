import { Injectable, EventEmitter } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment, appConfig } from '../../environments/environment';
import { GrowSection } from '../models/growsection.model';
import { String } from 'typescript-string-operations';

@Injectable({
  providedIn: 'root',
})
export class GrowSectionService {
  private url: string = environment.appServerURL;
  selectedGrowSection = new EventEmitter<GrowSection>();
  constructor(private http: HttpClient) {
  }

  getGrowSections() {
    return this.http.get(this.url + appConfig.growsections);
  }

  getGridConfig() {
    return this.http.get('assets/jsons/gridLayoutConfig.json');
  }

  getGrowSectionById(id: number) {
    console.log(this.url + appConfig.growsections + '/' + id);
    return this.http.get(this.url + appConfig.growsections + '/' + id);
  }
  deleteGrowSectionById(sectionID) {
    return this.http.delete(this.url + String.Format(appConfig.deleteGrowSection, sectionID));

  }

  getGrowSectionsByFacility(facilityId) {
    return this.http.get(this.url + appConfig.growsectionsByFacility + '/' + facilityId);
  }

  getGrowSectionsByContainer(containerId) {
    return this.http.get(this.url + appConfig.growsectionsByContainer + '/' + containerId);
  }

  getGrowSectionsByGrowarea(growareaId) {
    return this.http.get(this.url + appConfig.growsectionsByGrowarea + '/' + growareaId);
  }

  createGrowSection(growsections) {
    return this.http.post(this.url + appConfig.growsections, growsections);
  }

  editGrowSection(growsections) {
    return this.http.put(this.url + appConfig.growsections, growsections);
  }

  getCountForDevicesInGrowsection(growsectionId) {
    return this.http.get(this.url + appConfig.countDevicesforGrowsection + '/' + growsectionId + '/devices/count');
  }

  getConditionsForDevicesInGrowSections(growsectionId) {
    return this.http.get(this.url + appConfig.profileConditionsGrowSection + '/' + growsectionId);
  }

}
