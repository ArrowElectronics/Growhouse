import { Component, OnInit, ViewChild } from "@angular/core";
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from "@angular/forms";
import { DataTableDirective } from "angular-datatables";
import { BreadcrumbsService } from "ng6-breadcrumbs/lib/breadcrumbs.service";
import { NgxSpinnerService } from "ngx-spinner";
import { ToastrService } from "ngx-toastr";
import { Subject } from "rxjs";
import { ValidationPatterns } from "src/environments/environment";
import { AccountService } from "../services/account-service";
import { GlobalService } from "../services/global-service";
import { Account } from "./../models/global.model";

@Component({
  selector: "app-accounts",
  templateUrl: "./accounts.component.html",
  styleUrls: ["./accounts.component.css"],
})
export class AccountsComponent implements OnInit {
  dtOptions: any = {};
  dtTrigger: Subject<any> = new Subject();
  @ViewChild(DataTableDirective)
  private datatableElement: DataTableDirective;
  activeAccountCount: number;
  accounts: Account[] = [];
  accountForm: FormGroup;
  isEditAccount = false;
  selectedAccount: Account;
  deleteAccountId: number;
  apiLoading = false;
  isAccountLoad = false;
  constructor(
    private accountService: AccountService,
    private spinner: NgxSpinnerService,
    private toastrService: ToastrService,
    private formBuilder: FormBuilder,
    private breadcrumbService: BreadcrumbsService,
    private globalService: GlobalService
  ) {}

  ngOnInit() {
    this.breadcrumbService.store([
      { label: "Accounts", url: "/accounts", params: [] },
    ]);
    this.dtOptions = {
      pagingType: "full_numbers",
      pageLength: 10,
      destroy: true,
      info: false,
      order: [],
      lengthChange: false,
      select: true,
      language: {
        zeroRecords: "No Accounts to display",
        paginate: {
          next: ">", // or '→'
          previous: "<", // or '←',
        },
      },
    };
    const elem = document.getElementById("headerMenuCollapse");
    if (elem) {
      elem.classList.remove("show");
    }
    this.accountForm = new FormGroup({
      account_name: new FormControl("", [
        Validators.required,
        Validators.maxLength(40),
        Validators.pattern(ValidationPatterns.username),
      ]),
      admin: new FormGroup({
        email_id: new FormControl("", [
          Validators.required,
          Validators.pattern(ValidationPatterns.emailPattern),
          this.noDoubleDotValidator,
          this.noIntegerValidator,
        ]),
        username: new FormControl("", [
          Validators.required,
          Validators.maxLength(40),
          Validators.pattern(ValidationPatterns.username),
        ]),
        first_name: new FormControl("", [
          Validators.required,
          Validators.maxLength(40),
          Validators.pattern(ValidationPatterns.name),
        ]),
        last_name: new FormControl("", [
          Validators.required,
          Validators.maxLength(40),
          Validators.pattern(ValidationPatterns.name),
        ]),
      }),
    });
    this.getAccounts();
    this.addReloadEventToBreadcrumb();
  }

  public noDoubleDotValidator(control: FormControl) {
    return (control.value || "").includes("..") ? { doubleDot: true } : null;
  }

  public noIntegerValidator(control: FormControl) {
    if (control.value && control.value.includes("@")) {
      return isNaN(control.value.split("@")[0]) ? null : { onlyNumbers: true };
    }
    return null;
  }

  getAccounts() {
    this.isAccountLoad = true;

    this.accounts = [];
    this.accountService.getAccounts().subscribe(
      (response: Account[]) => {
        this.accounts = response;
        if (this.accounts) {
          this.activeAccountCount = this.accounts.length;
        } else {
          this.activeAccountCount = 0;
        }
        this.dtTrigger.next();
        this.isAccountLoad = false;
      },
      (error) => {
        console.log("Error" + JSON.stringify(error));
        this.isAccountLoad = false;
      }
    );
  }

  onNewAccount() {
    this.isEditAccount = false;
    this.selectedAccount = undefined;
    this.accountForm.reset();
    this.accountForm.get("admin").get("username").enable();
  }

  onAddAccountSubmit() {
    this.apiLoading = true;
    this.accountService.createAccount(this.accountForm.value).subscribe(
      (response) => {
        this.datatableElement.dtInstance.then((dtInstance: DataTables.Api) => {
          // Destroy the table first
          dtInstance.destroy();
        });
        this.getAccounts();
        this.toastrService.success(
          "Account Created Successfully",
          "Create Account"
        );
        this.apiLoading = false;
      },
      (error) => {
        this.apiLoading = false;
      }
    );
  }

  onEditAccount(account) {
    this.accountForm.reset();
    this.accountForm.patchValue({
      account_name: account.account_name,
      admin: {
        email_id: account.admin.email_id,
        username: account.admin.username,
        first_name: account.admin.first_name,
        last_name: account.admin.last_name,
      },
    });
    this.accountForm.get("admin").get("username").disable();
    this.selectedAccount = account;
    this.isEditAccount = true;
  }

  onEditAccountSubmit() {
    this.apiLoading = true;
    this.accountForm.value.id = this.selectedAccount.id;
    this.accountService
      .updateAccount(this.accountForm.value, this.accountForm.value.id)
      .subscribe(
        (response) => {
          this.datatableElement.dtInstance.then(
            (dtInstance: DataTables.Api) => {
              // Destroy the table first
              dtInstance.destroy();
            }
          );
          this.isEditAccount = false;
          this.getAccounts();
          this.selectedAccount = undefined;
          this.toastrService.success(
            "Account updated Successfully",
            "Update Account"
          );
          this.apiLoading = false;
        },
        (error) => {
          this.apiLoading = false;
        }
      );
  }
  onDeleteAccountChange(accountId: number) {
    this.deleteAccountId = accountId;
  }
  onDeleteAccount() {
    this.apiLoading = true;

    this.accountService.deleteAccount(this.deleteAccountId).subscribe(
      (response) => {
        this.datatableElement.dtInstance.then((dtInstance: DataTables.Api) => {
          // Destroy the table first
          dtInstance.destroy();
        });
        this.isEditAccount = false;
        this.getAccounts();
        this.selectedAccount = undefined;
        this.apiLoading = false;

        this.toastrService.success(
          "Account deleted Successfully",
          "Delete Account"
        );
      },
      (error) => {
        this.apiLoading = false;
      }
    );
  }
  addReloadEventToBreadcrumb() {
    setTimeout(() => {
      const elems = document.querySelectorAll(".breadcrumb-item a");
      console.log(elems);
      console.log("length     ", elems.length);
      for (let i = 0; i < elems.length; i++) {
        elems[i].addEventListener("click", this.globalService.handleClick);
      }
    }, 100);
  }
}
