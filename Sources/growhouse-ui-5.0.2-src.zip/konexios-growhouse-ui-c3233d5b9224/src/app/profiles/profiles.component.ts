import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { DataTableDirective } from 'angular-datatables';
import { HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { NgxSpinnerService } from 'ngx-spinner';
import { FormGroup, FormArray, FormControl, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { Subject } from 'rxjs';
import { Location } from '@angular/common';
import { Container } from '../models/container.model';
import { ContainerService } from 'src/app/services/container-service';
import { Country, State } from '../models/global.model';
import { Facility } from '../models/facility.model';
import { FacilityService } from '../services/facility-service';
import { ActivatedRoute, Params, Router, ActivatedRouteSnapshot } from '@angular/router';
import { BreadcrumbsService } from 'ng6-breadcrumbs';
import { User } from '../models/user.model';
import { GlobalService } from '../services/global-service';
import { GrowArea } from '../models/growarea.model';
import { GrowAreaService } from '../services/growarea-service';
import { ProfileMessage } from '../../environments/environment';
import { DeviceService } from '../services/device-service';

@Component({
  selector: 'app-profiles',
  templateUrl: './profiles.component.html',
  styleUrls: ['./profiles.component.css']
})

export class ProfilesComponent implements OnInit, OnDestroy {

  dtOptions: any = {};
  dtTrigger: Subject<any> = new Subject();
  @ViewChild(DataTableDirective)
  private datatableElement: DataTableDirective;
  selectedProfile;
  profiles: any = [];
  selectedFacility: Facility;
  selectedContainer: Container;
  selectedGrowArea: GrowArea;
  activeProfilesCount = 0;
  deviceList: any[] = [];
  propertyList: any[] = [];
  loggedInUser: User;
  isProfileLoad = false;
  addProfileForm: FormGroup;
  addConditionForm: FormGroup;
  deleteProfileId;
  apiLoading = false;
  ngOnInit() {
    // this.breadcrumbService.store([
    //   { label: 'Rules', url: '/profiles', params: [] }
    // ]);
    // window.location.reload();
    console.log('in compoent');
    // datatable options for facility table
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 10,
      info: false,
      order: [],
      lengthChange: false,
      select: true,
      destroy: true,
      language: {
        zeroRecords: 'No Rules to display',
        paginate: {
          next: '>', // or '→'
          previous: '<', // or '←',
        }
      }
    };
    this.loggedInUser = JSON.parse(localStorage.getItem('loggedInUser'));
    this.globalServices.selectedProfile.subscribe(
      (profile: any) => {
        console.log(profile);
        this.selectedProfile = profile;
      }
    );

    this.route.params.subscribe(
      (params: Params) => {
        console.log('params:' + JSON.stringify(params));
        if (params.facilityId && params.containerId && params.growareaId) {
          this.getFacilityById(
            params.facilityId,
            params.containerId,
            params.growareaId
          );
          this.getProfileByGrowareaId(params.growareaId, params.deviceTypeId);
        } else if (params.facilityId && params.containerId) {
          this.getFacilityById(params.facilityId, params.containerId, undefined);
          this.getProfileByContainerId(params.containerId);
        } else if (params.facilityId && params.growareaId) {
          this.getFacilityById(params.facilityId, undefined, params.growareaId);
          this.getProfileByGrowareaId(params.growareaId, params.deviceTypeId);
        } else if (params.containerId && params.growareaId) {
          this.getContainerById(params.containerId, params.growareaId);
          this.getProfileByGrowareaId(params.growareaId, params.deviceTypeId);
        } else if (params.growareaId) {
          this.getGrowareaById(params.growareaId);
          this.getDevicesBySectionId(params.growareaId);
          // this.getProfilesBySectionId(params.growareaId); 
          //http://23.96.18.150:4200/api/growareas/57
          this.getProfileByGrowareaId(params.growareaId, params.deviceTypeId);
        } else if (params.containerId) {
          this.getContainerById(params.containerId, undefined);
          this.getProfileByContainerId(params.containerId);
        } else if (params.facilityId) {
          this.getFacilityById(params.facilityId, undefined, undefined);
          this.getProfileByFacilityId(params.facilityId);
        } else {
          // this.getProfiles();  
          this.getProfileByGrowareaId(params.growareaId, params.deviceTypeId);
        }

        // if (params.facilityId) {
        //   this.getProfileByFacilityId(params.facilityId);
        // } else if (params.containerId) {
        //   this.getProfileByContainerId(params.containerId);
        // } else if (params.growareaId) {
        //   this.getProfileByGrowareaId(params.growareaId);
        // } else {
        //   this.getProfiles();
        // }

        // console.log(this.selectedGrowArea);
        //  this.addProfileForm = new FormGroup({
        //   conditions: new FormArray([
        //     new FormGroup({
        //       actions: new FormArray([
        //         new FormGroup({
        //           alertMessage: new FormControl(ProfileMessage.ALL_OK),
        //           type: new FormControl('send_alarm')
        //         })
        //       ]),
        //       expression: new FormControl('')
        //     }),
        //     new FormGroup({
        //       actions: new FormArray([
        //         new FormGroup({
        //           alertMessage: new FormControl(ProfileMessage.NEED_WATER),
        //           type: new FormControl('send_alarm')
        //         })
        //       ]),
        //       expression: new FormControl('')
        //     }),
        //     new FormGroup({
        //       actions: new FormArray([
        //         new FormGroup({
        //           alertMessage: new FormControl(ProfileMessage.NEED_SUN),
        //           type: new FormControl('send_alarm')
        //         })
        //       ]),
        //       expression: new FormControl('')
        //     }),
        //     new FormGroup({
        //       actions: new FormArray([
        //         new FormGroup({
        //           alertMessage: new FormControl(ProfileMessage.MORE_SUN),
        //           type: new FormControl('send_alarm')
        //         })
        //       ]),
        //       expression: new FormControl('')
        //     })
        //   ]),
        //   monitors: new FormArray([
        //     new FormGroup({
        //       deviceHids: new FormArray([
        //         new FormControl('', Validators.required)
        //       ]),
        //       // gatewayHid: new FormControl(this.selectedGrowArea.grow_area_hid)
        //     })
        //   ]),
        //   type: new FormControl('CREATE'),
        //   timeInterval: new FormControl(60),
        //   // globalResponsePayload: new FormGroup({
        //   //   containerId: new FormControl(JSON.stringify(this.selectedGrowArea.container.id)),
        //   //   containerName: new FormControl(this.selectedGrowArea.container.container_name),
        //   //   facilityId: new FormControl(JSON.stringify(this.selectedGrowArea.container.facility.id)),
        //   //   facilityName: new FormControl(this.selectedGrowArea.container.facility.facility_name),
        //   //   gatewayId: new FormControl(JSON.stringify(this.selectedGrowArea.id)),
        //   //   gatewayName: new FormControl(this.selectedGrowArea.grow_area_name),
        //   //   // growSectionId: new FormControl(JSON.stringify(this.selectedGrowSection.id)),
        //   //   // growSectionName: new FormControl(this.selectedGrowSection.grow_section_name)
        //   // })
        // });
        // this.addConditionForm = new FormGroup({
        //   condition1: new FormArray([
        //     new FormGroup({
        //       property: new FormControl('', Validators.required),
        //       value: new FormControl('', Validators.required),
        //       operator: new FormControl('==', Validators.required),
        //       combinationOperator: new FormControl('')
        //     })
        //   ]),
        //   condition2: new FormArray([
        //     new FormGroup({
        //       property: new FormControl('', Validators.required),
        //       value: new FormControl('', Validators.required),
        //       operator: new FormControl('==', Validators.required),
        //       combinationOperator: new FormControl('')
        //     })
        //   ]),
        //   condition3: new FormArray([
        //     new FormGroup({
        //       property: new FormControl('', Validators.required),
        //       value: new FormControl('', Validators.required),
        //       operator: new FormControl('==', Validators.required),
        //       combinationOperator: new FormControl('')
        //     })
        //   ]),
        //   condition4: new FormArray([
        //     new FormGroup({
        //       property: new FormControl('', Validators.required),
        //       value: new FormControl('', Validators.required),
        //       operator: new FormControl('==', Validators.required),
        //       combinationOperator: new FormControl('')
        //     })
        //   ])
        // });
        // console.log(JSON.stringify(this.addConditionForm.value));
        // console.log(JSON.stringify(this.addProfileForm.value));
      }
    );
  }

  constructor(private globalServices: GlobalService,
    private spinner: NgxSpinnerService,
    private toastrService: ToastrService,
    private router: Router,
    private route: ActivatedRoute,
    private breadcrumbService: BreadcrumbsService,
    private growareaService: GrowAreaService,
    private facilityService: FacilityService,
    private deviceService: DeviceService,
    private containerService: ContainerService,
    private globalService: GlobalService
  ) {


  }


  // addConditionOperator(condition, index, value) {
  //   index = index - 1;
  //   const controls = <FormArray>this.addConditionForm.controls[condition];
  //   const innerControl = <FormGroup>controls.controls[index];
  //   innerControl.value.combinationOperator = value;
  //   console.log(controls.controls[index]);
  // }

  // refresh(){
  //   this.router.routeReuseStrategy.shouldReuseRoute = function (future: ActivatedRouteSnapshot, curr: ActivatedRouteSnapshot) {
  //     return false;
  //   };
  // }

  getFacilityById(id, containerId, growareaId) {

    this.facilityService.getFacilityById(id).subscribe((response: Facility) => {
      this.selectedFacility = response;

      if (growareaId === undefined && containerId === undefined) {
        this.breadcrumbService.store([
          { label: 'Facilities', url: '/facilities', params: [] },
          {
            label: this.selectedFacility.facility_name + '',
            url: '/facilities/' + this.selectedFacility.id,
            params: []
          },
          { label: 'Rules', url: '', params: [] }
        ]);
        this.addReloadEventToBreadcrumb();
      } else {
        if (containerId && growareaId) {
          this.getContainerById(containerId, growareaId);
        } else if (containerId) {
          this.getContainerById(containerId, undefined);
        } else {
          this.getGrowareaById(growareaId);
        }
      }
    });
  }
  addReloadEventToBreadcrumb() {
    setTimeout(() => {
      const elems = document.querySelectorAll('.breadcrumb-item a');
      console.log(elems);
      console.log('length     ', elems.length);
      for (let i = 0; i < elems.length; i++) {
        elems[i].addEventListener('click', this.globalService.handleClick);
      }
    }, 100);
  }

  getContainerById(containerId, growareaId) {

    this.containerService
      .getContainerById(containerId)
      .subscribe((response: Container) => {
        this.selectedContainer = response;

        if (this.selectedFacility === undefined && growareaId === undefined) {
          this.breadcrumbService.store([
            { label: 'Container', url: '/containers', params: [] },
            { label: this.selectedContainer.container_name + '', url: '/containers/' + this.selectedContainer.id, params: [] },
            { label: 'Rules', url: '', params: [] },
          ]);
          this.addReloadEventToBreadcrumb();
        } else if (this.selectedFacility && growareaId === undefined) {
          this.breadcrumbService.store([
            { label: 'Facilities', url: '/facilities', params: [] },
            { label: this.selectedFacility.facility_name + '', url: '/facilities/' + this.selectedFacility.id, params: [] },
            { label: 'Containers', url: 'facilities/' + this.selectedFacility.id + '/containers', params: [] },
            {
              label: this.selectedContainer.container_name + '',
              url: 'facilities/' + this.selectedFacility.id + '/containers/' + this.selectedContainer.id, params: []
            },
            { label: 'Rules', url: '', params: [] },
          ]);
          this.addReloadEventToBreadcrumb();
        } else {
          this.getGrowareaById(growareaId);
        }
      });
  }

  getGrowareaById(growareaId) {

    this.growareaService
      .getGrowAreaById(growareaId)
      .subscribe((response: GrowArea) => {
        this.selectedGrowArea = response;

        if (this.selectedFacility === undefined && this.selectedContainer === undefined) {
          this.breadcrumbService.store([
            { label: 'Grow Areas', url: '/grow-areas', params: [] },
            { label: this.selectedGrowArea.grow_area_name + '', url: '/grow-areas/' + this.selectedGrowArea.id, params: [] },
            { label: 'Rules', url: '', params: [] },
          ]);
        } else if (this.selectedFacility && this.selectedContainer === undefined) {
          this.breadcrumbService.store([
            { label: 'Facilities', url: '/facilities', params: [] },
            { label: this.selectedFacility.facility_name + '', url: '/facilities/' + this.selectedFacility.id, params: [] },
            { label: 'Grow Areas', url: '/facilities/' + this.selectedFacility.id + '/grow-areas', params: [] },
            {
              label: this.selectedGrowArea.grow_area_name + '',
              url: 'facilities/' + this.selectedFacility.id + '/grow-areas/' + this.selectedGrowArea.id, params: []
            },
            { label: 'Rules', url: '', params: [] },
          ]);
        } else if (this.selectedFacility === undefined && this.selectedContainer) {
          this.breadcrumbService.store([
            { label: 'Containers', url: '/containers', params: [] },
            { label: this.selectedContainer.container_name + '', url: '/containers/' + this.selectedContainer.id, params: [] },
            { label: 'Grow Areas', url: '/containers/' + this.selectedContainer.id + '/grow-areas', params: [] },
            {
              label: this.selectedGrowArea.grow_area_name + '',
              url: '/containers/' + this.selectedContainer.id + '/grow-areas/' + this.selectedGrowArea.id, params: []
            },
            { label: 'Rules', url: '', params: [] },
          ]);
        } else {
          this.breadcrumbService.store([
            { label: 'Facilities', url: '/facilities', params: [] },
            { label: this.selectedFacility.facility_name + '', url: '/facilities/' + this.selectedFacility.id, params: [] },
            { label: 'Containers', url: '/facilities/' + this.selectedFacility.id + '/containers', params: [] },
            {
              label: this.selectedContainer.container_name + '',
              url: '/facilities/' + this.selectedFacility.id + '/containers/' + this.selectedContainer.id, params: []
            },
            {
              label: 'Grow Areas',
              url: '/facilities/' + this.selectedFacility.id + '/containers/' + this.selectedContainer.id + '/grow-areas', params: []
            },
            {
              label: this.selectedGrowArea.grow_area_name + '',
              url: '/facilities/' + this.selectedFacility.id + '/containers/' + this.selectedContainer.id
                + '/grow-areas/' + this.selectedGrowArea.id,
              params: []
            },
            { label: 'Rules', url: '', params: [] },
          ]);
        }
        this.addReloadEventToBreadcrumb();
      });
  }

  getProfiles() {
    this.profiles = [];
    this.isProfileLoad = true;
    this.globalServices.getProfilesByGrowareaId(this.selectedGrowArea.id).
      subscribe((response) => {
        setTimeout(
          () => {
            this.profiles = response;
            if (this.profiles) {
              this.activeProfilesCount = this.profiles.length;
            } else {
              this.activeProfilesCount = 0;
            }
            this.dtTrigger.next();
          }, 500
        );
        this.isProfileLoad = false;
      }
      , (error) => {
        console.log('Error' + JSON.stringify(error));
        this.isProfileLoad = false;
      });
  }

  getProfileByFacilityId(facilityId) {
    this.profiles = [];
    this.dtTrigger.next();
    this.isProfileLoad = true;
    this.globalServices.getProfilesByFacilityId(facilityId).
      subscribe((response) => {
        setTimeout(
          () => {
            this.profiles = response;
            if (this.profiles) {
              this.activeProfilesCount = this.profiles.length;
            } else {
              this.activeProfilesCount = 0;
            }
            this.dtTrigger.next();
            this.isProfileLoad = false;
          }, 500
        );
      });
  }

  getProfileByContainerId(containerId) {
    this.profiles = [];
    this.dtTrigger.next();
    this.globalServices.getProfilesByContainerId(containerId).
      subscribe((response) => {
        this.profiles = response;
        if (this.profiles) {
          this.activeProfilesCount = this.profiles.length;
        } else {
          this.activeProfilesCount = 0;
        }
        this.dtTrigger.next();
      });
  }

  getProfileByGrowareaId(growareaId, deviceTypeId) {
    this.profiles = [];
    this.isProfileLoad = true;
    this.dtTrigger.next();
    this.globalServices.getProfilesByGrowareaId(growareaId).
      subscribe((response) => {
        setTimeout(
          () => {
            this.profiles = response;
            if (this.profiles) {
              this.activeProfilesCount = this.profiles.length;
            } else {
              this.activeProfilesCount = 0;
            }
            this.dtTrigger.next();
          }, 500
        );
        this.isProfileLoad = false;
      });
  }

  onAddProfiles() {

    // // console.log(this.selectedGrowArea);
    // this.addProfileForm = new FormGroup({
    //   conditions: new FormArray([
    //     new FormGroup({
    //       actions: new FormArray([
    //         new FormGroup({
    //           alertMessage: new FormControl(ProfileMessage.ALL_OK),
    //           type: new FormControl('send_alarm')
    //         })
    //       ]),
    //       expression: new FormControl('')
    //     }),
    //     new FormGroup({
    //       actions: new FormArray([
    //         new FormGroup({
    //           alertMessage: new FormControl(ProfileMessage.NEED_WATER),
    //           type: new FormControl('send_alarm')
    //         })
    //       ]),
    //       expression: new FormControl('')
    //     }),
    //     new FormGroup({
    //       actions: new FormArray([
    //         new FormGroup({
    //           alertMessage: new FormControl(ProfileMessage.NEED_SUN),
    //           type: new FormControl('send_alarm')
    //         })
    //       ]),
    //       expression: new FormControl('')
    //     }),
    //     new FormGroup({
    //       actions: new FormArray([
    //         new FormGroup({
    //           alertMessage: new FormControl(ProfileMessage.MORE_SUN),
    //           type: new FormControl('send_alarm')
    //         })
    //       ]),
    //       expression: new FormControl('')
    //     })
    //   ]),
    //   monitors: new FormArray([
    //     new FormGroup({
    //       deviceHids: new FormArray([
    //         new FormControl('', Validators.required)
    //       ]),
    //       gatewayHid: new FormControl(this.selectedGrowArea.grow_area_hid)
    //     })
    //   ]),
    //   type: new FormControl('CREATE'),
    //   timeInterval: new FormControl(60),
    //   // globalResponsePayload: new FormGroup({
    //   //   containerId: new FormControl(JSON.stringify(this.selectedGrowArea.container.id)),
    //   //   containerName: new FormControl(this.selectedGrowArea.container.container_name),
    //   //   facilityId: new FormControl(JSON.stringify(this.selectedGrowArea.container.facility.id)),
    //   //   facilityName: new FormControl(this.selectedGrowArea.container.facility.facility_name),
    //   //   gatewayId: new FormControl(JSON.stringify(this.selectedGrowArea.id)),
    //   //   gatewayName: new FormControl(this.selectedGrowArea.grow_area_name),
    //   //   // growSectionId: new FormControl(JSON.stringify(this.selectedGrowSection.id)),
    //   //   // growSectionName: new FormControl(this.selectedGrowSection.grow_section_name)
    //   // })
    // });
    // this.addConditionForm = new FormGroup({
    //   condition1: new FormArray([
    //     new FormGroup({
    //       property: new FormControl('', Validators.required),
    //       value: new FormControl('', Validators.required),
    //       operator: new FormControl('==', Validators.required),
    //       combinationOperator: new FormControl('')
    //     })
    //   ]),
    //   condition2: new FormArray([
    //     new FormGroup({
    //       property: new FormControl('', Validators.required),
    //       value: new FormControl('', Validators.required),
    //       operator: new FormControl('==', Validators.required),
    //       combinationOperator: new FormControl('')
    //     })
    //   ]),
    //   condition3: new FormArray([
    //     new FormGroup({
    //       property: new FormControl('', Validators.required),
    //       value: new FormControl('', Validators.required),
    //       operator: new FormControl('==', Validators.required),
    //       combinationOperator: new FormControl('')
    //     })
    //   ]),
    //   condition4: new FormArray([
    //     new FormGroup({
    //       property: new FormControl('', Validators.required),
    //       value: new FormControl('', Validators.required),
    //       operator: new FormControl('==', Validators.required),
    //       combinationOperator: new FormControl('')
    //     })
    //   ])
    // });
    // console.log(JSON.stringify(this.addConditionForm.value));
    // console.log(JSON.stringify(this.addProfileForm.value));
  }

  get condition1() {
    return this.addConditionForm.get('condition1') as FormArray;
  }

  get condition2() {
    return this.addConditionForm.get('condition2') as FormArray;
  }

  get condition3() {
    return this.addConditionForm.get('condition3') as FormArray;
  }

  get condition4() {
    return this.addConditionForm.get('condition4') as FormArray;
  }

  // onCreateProfile() {
  //   console.log(JSON.stringify(this.addConditionForm.value));
  //   let validFlag = true;

  //   for (let i = 0; i < this.addConditionForm.value.condition1.length; i++) {
  //     const obj = this.addConditionForm.value.condition1;

  //     if (obj[i + 1]) {
  //       if (obj[i].combinationOperator !== '') {
  //         if (!validFlag) {
  //           validFlag = true;
  //         }
  //       } else {
  //         validFlag = false;
  //       }
  //     }
  //   }
  //   if (validFlag) {
  //     for (let i = 0; i < this.addConditionForm.value.condition2.length; i++) {
  //       const obj = this.addConditionForm.value.condition2;
  //       if (obj[i + 1]) {
  //         if (obj[i].combinationOperator !== '') {
  //           if (!validFlag) {
  //             validFlag = true;
  //           }
  //         } else {
  //           validFlag = false;
  //         }
  //       }
  //     }
  //   }
  //   if (validFlag) {
  //     for (let i = 0; i < this.addConditionForm.value.condition3.length; i++) {
  //       const obj = this.addConditionForm.value.condition3;
  //       if (obj[i + 1]) {
  //         if (obj[i].combinationOperator !== '') {
  //           if (!validFlag) {
  //             validFlag = true;
  //           }
  //         } else {
  //           validFlag = false;
  //         }
  //       }
  //     }
  //   }
  //   if (validFlag) {
  //     for (let i = 0; i < this.addConditionForm.value.condition4.length; i++) {
  //       const obj = this.addConditionForm.value.condition4;
  //       if (obj[i + 1]) {
  //         if (obj[i].combinationOperator !== '') {
  //           if (!validFlag) {
  //             validFlag = true;
  //           }
  //         } else {
  //           validFlag = false;
  //         }
  //       }
  //     }
  //   }
  //   console.log(validFlag);
  //   if (!validFlag) {
  //     this.toastrService.error('Please provide all details', 'Create Profile');
  //   } else {

  //     let deviceHids = [];
  //     this.addConditionForm.value.condition1 = this.sortObjByOperator(this.addConditionForm.value.condition1);
  //     this.addConditionForm.value.condition2 = this.sortObjByOperator(this.addConditionForm.value.condition2);
  //     this.addConditionForm.value.condition3 = this.sortObjByOperator(this.addConditionForm.value.condition3);
  //     this.addConditionForm.value.condition4 = this.sortObjByOperator(this.addConditionForm.value.condition4);

  //     this.addProfileForm.value.conditions[0].expression = this.createExressionStringFromObj(this.addConditionForm.value.condition1);
  //     this.addProfileForm.value.conditions[1].expression = this.createExressionStringFromObj(this.addConditionForm.value.condition2);
  //     this.addProfileForm.value.conditions[2].expression = this.createExressionStringFromObj(this.addConditionForm.value.condition3);
  //     this.addProfileForm.value.conditions[3].expression = this.createExressionStringFromObj(this.addConditionForm.value.condition4);

  //     deviceHids = this.createDeviceHidsFromObj(this.addConditionForm.value.condition1);
  //     this.addProfileForm.value.monitors[0].deviceHids = deviceHids;
  //     deviceHids = this.createDeviceHidsFromObj(this.addConditionForm.value.condition2);
  //     this.addProfileForm.value.monitors[0].deviceHids = this.addProfileForm.value.monitors[0].deviceHids.concat(deviceHids);
  //     deviceHids = this.createDeviceHidsFromObj(this.addConditionForm.value.condition3);
  //     this.addProfileForm.value.monitors[0].deviceHids = this.addProfileForm.value.monitors[0].deviceHids.concat(deviceHids);
  //     deviceHids = this.createDeviceHidsFromObj(this.addConditionForm.value.condition4);
  //     this.addProfileForm.value.monitors[0].deviceHids = this.addProfileForm.value.monitors[0].deviceHids.concat(deviceHids);
  //     this.addProfileForm.value.monitors[0].deviceHids = this.unique(this.addProfileForm.value.monitors[0].deviceHids);
  //     //    this.addProfileForm.value.conditions = JSON.stringify(this.addProfileForm.value.conditions);
  //     //  this.addProfileForm.value.monitors = JSON.stringify(this.addProfileForm.value.monitors);
  //     console.log(JSON.stringify(this.addProfileForm.value));
  //     // this.globalServices.createProfile(this.selectedGrowSection.id, this.addProfileForm.value).subscribe(
  //     //   response => {
  //     //     this.toastrService.success('Profile creation request sent successfully.', 'Create Profile');
  //     //   }
  //     // );
  //   }
  // }

  getProfilesBySectionId(sectionId) {
    this.globalServices.getProfilesByGrowSectionId(sectionId).subscribe(
      (response: any[]) => {
        this.profiles = response;
        console.log('profiles:' + this.profiles);
      }
    );
  }

  getDevicesBySectionId(sectionId) {
    this.deviceService.getDevicePropertiesByGrowSectionId(sectionId).subscribe(
      (response: any[]) => {
        this.deviceList = response;
        console.log('devices:' + this.deviceList);
      }
    );
  }

  getPropertyList(deviceId, index) {
    console.log(typeof deviceId);
    console.log(deviceId);
    let device;
    for (let i = 0; i < this.deviceList.length; i++) {
      console.log(this.deviceList[i].device_hid, '===', deviceId, 10);
      if (this.deviceList[i].device_hid === deviceId) {
        device = this.deviceList[i];
        console.log(device);

        this.propertyList[index] = device.properties;
      }
    }
  }

  // onAddConditionBlock(condition) {
  //   console.log(this.addConditionForm.controls[condition]);
  //   const controls = <FormArray>this.addConditionForm.controls[condition];
  //   controls.push(new FormGroup({
  //     property: new FormControl('', Validators.required),
  //     value: new FormControl('', Validators.required),
  //     operator: new FormControl('==', Validators.required),
  //     combinationOperator: new FormControl('')
  //   }));
  //   console.log(this.addConditionForm.get(condition));
  // }

  // onRemoveConditionBlock(condition, index) {
  //   const controls = <FormArray>this.addConditionForm.controls[condition];
  //   controls.removeAt(index);
  //   console.log(this.addConditionForm.get(condition));
  // }

  // unique(arr) {
  //   const u = {}, a = [];
  //   for (let i = 0, l = arr.length; i < l; ++i) {
  //     if (!u.hasOwnProperty(arr[i])) {
  //       a.push(arr[i]);
  //       u[arr[i]] = 1;
  //     }
  //   }
  //   return a;
  // }


  // createDeviceHidsFromObj(conditionArr) {
  //   const deviceHids: string[] = [];
  //   for (let i = 0; i < conditionArr.length; i++) {
  //     let proplist = [];
  //     proplist = conditionArr[i].property.split('.');
  //     proplist = proplist[0].split('_');
  //     if (deviceHids.indexOf(proplist[1]) === -1) {
  //       deviceHids.push(proplist[1]);
  //     } else {
  //       const index = deviceHids.indexOf(proplist[1]);
  //       deviceHids.splice(index, 1);
  //     }
  //   }
  //   console.log('from fun 616      ', deviceHids);
  //   return deviceHids;
  // }

  // sortObjByOperator(obj) {
  //   obj.sort(function (a, b) {
  //     const operator1 = a.combinationOperator;
  //     const operator2 = b.combinationOperator;
  //     if (operator1 < operator2) {
  //       return 1;
  //     }
  //     if (operator1 > operator2) {
  //       return -1;
  //     }
  //     return 0;
  //   });
  //   console.log('584', obj);
  //   return obj;
  // }

  // createExressionStringFromObj(conditionArr) {
  //   let expression = '';
  //   for (let i = 0; i < conditionArr.length; i++) {
  //     if (conditionArr[i].combinationOperator !== '') {
  //       expression = expression + conditionArr[i].property +
  //         conditionArr[i].operator + conditionArr[i].value + ' ' + conditionArr[i].combinationOperator + ' ';
  //     } else {
  //       expression = expression + conditionArr[i].property + conditionArr[i].operator + conditionArr[i].value;
  //     }
  //   }
  //   console.log('598', expression);
  //   return expression;
  // }


  onProfileRowSelected(profiles) {
    this.selectedProfile = profiles;
    this.router.navigate([this.selectedProfile.id], { relativeTo: this.route });
  }

  onDeleteProfileChange(profileId) {
    this.deleteProfileId = profileId;
    // console.log('Devang test: ' + this.deleteProfileId);
  }

  onDeleteProfile() {
    this.apiLoading = true;
    this.globalServices.deleteProfile(this.deleteProfileId).subscribe(
      response => {
        this.toastrService.success('Rule deleted successfully', 'Delete Rule');
        this.datatableElement.dtInstance.then((dtInstance: DataTables.Api) => {
          // Destroy the table first
          dtInstance.destroy();
        });
        if (this.selectedProfile) {
          this.selectedProfile = null;

          if (this.selectedFacility && this.selectedContainer && this.selectedGrowArea) {
            this.router.navigate(['/facilities/' + this.selectedFacility.id + '/containers/' + this.selectedContainer.id
             + '/grow-areas/' + this.selectedGrowArea.id + '/profiles' ]);
             this.getFacilityById(this.selectedFacility.id, this.selectedContainer.id, this.selectedGrowArea.id);
          } else if (this.selectedFacility && this.selectedGrowArea) {

            this.router.navigate(['/facilities/' + this.selectedFacility.id + '/grow-areas/' + this.selectedGrowArea.id + '/profiles' ]);
            this.getFacilityById(this.selectedFacility.id, undefined, this.selectedGrowArea.id);
          } else if (this.selectedContainer && this.selectedGrowArea) {
            this.router.navigate(['/containers/' + this.selectedContainer.id + '/grow-areas/' + this.selectedGrowArea.id + '/profiles' ]);
            this.getContainerById(this.selectedContainer.id, this.selectedGrowArea.id);
          } else {
          this.router.navigate(['/grow-areas/' + this.selectedGrowArea.id + '/profiles']);
          this.getGrowareaById(this.selectedGrowArea.id);
          }
        }
        this.getProfiles();
        this.apiLoading = false;

      } , (error) => {
        console.log('Error' + JSON.stringify(error));
        this.apiLoading = false;
      }
    );
  }

  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }


}
