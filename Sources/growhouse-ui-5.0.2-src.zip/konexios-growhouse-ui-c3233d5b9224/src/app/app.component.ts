import {
  Component,
  OnInit,
  ViewChild,
  AfterViewInit,
  ElementRef,
  ViewEncapsulation,
  HostListener,
  Host,
  OnDestroy,
} from "@angular/core";
import { Router, RouterOutlet, ActivatedRoute } from "@angular/router";
import { User } from "./models/user.model";
import { BreadcrumbsService } from "ng6-breadcrumbs";
import { FacilityService } from "../app/services/facility-service";
import { ContainerService } from "../app/services/container-service";
// import { Facility } from '../models/facility.model';

declare var $: any;
@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.css"],
})
export class AppComponent implements OnInit {
  title = "Growhouse";
  loginFlag = false;
  url: String = "";

  userDetails: { name: string; email: string; image: string; token: string };
  loggedInUser: User;
  logoutFlag = true;
  // selectedFacility: Facility;
  @ViewChild("bodytag") body;
  constructor(
    private router: Router,
    private el: ElementRef,
    private breadcrumService: BreadcrumbsService,
    private containerService: ContainerService,
    private facilityService: FacilityService,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    // Load google maps script after view init
    const DSLScript = document.createElement("script");
    DSLScript.src =
      "https://maps.googleapis.com/maps/api/js?key=AIzaSyAjvsSiWGGFt0g7TQFWqbecMXQ438ZEqog&libraries=drawing";
    DSLScript.type = "text/javascript";
    DSLScript.async = false;
    DSLScript.charset = "utf-8";
    document.getElementsByTagName("body")[0].appendChild(DSLScript);
    document.body.removeChild(DSLScript);

    this.router.events.subscribe((e: any) => {
      this.url = this.router.url;
      if (this.url === "/" || this.url === "/change-password") {
        this.loginFlag = false;
        this.el.nativeElement.closest("body").className = "login-page-bg";
      } else {
        this.loginFlag = true;
        this.el.nativeElement.closest("body").className = "";
      }
    });
    console.log($("breadcrumb"));
    console.log(window.performance.navigation.type);
  }

  prepareRoute(outlet: RouterOutlet) {
    return (
      outlet && outlet.activatedRouteData && outlet.activatedRouteData["title"]
    );
  }

  // @HostListener('window:beforeunload', ['$event'])
  // beforeunloadHandler(event) {
  //   console.log('in before unload');
  //   if (window.opener && !window.opener.closed) {
  //     window.opener.location.href = 'localhost:4200';
  //   }
  // if (window.performance.navigation.type == 1) {
  //   // debugger;
  //   console.log('debugger');
  // } else {
  //   localStorage.removeItem('userDetails');
  //   localStorage.removeItem('loggedInUser');
  //   window.location.assign('https://www.google.com/accounts/Logout?continue=https:' +
  //   '//appengine.google.com/_ah/logout?continue='+environment.redirectURL);
  //   console.log("This page is reloaded");
  // }
  // }
  handleClick(event) {
    console.log(this.url);
    const eafwec = this.url.split("/");
    console.log(eafwec);
    if (eafwec.length % 2 === 0) {
      location.reload();
    }
  }
}
