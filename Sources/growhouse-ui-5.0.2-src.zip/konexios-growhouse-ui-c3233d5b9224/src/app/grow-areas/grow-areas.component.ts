import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { Subject } from 'rxjs';
import { DataTableDirective } from 'angular-datatables';
import { GrowArea, GrowAreaType } from '../models/growarea.model';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { ContainerService } from '../services/container-service';

import { GrowAreaService } from '../services/growarea-service';
import { HttpErrorResponse } from '@angular/common/http';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Container } from '../models/container.model';
import { FacilityService } from '../services/facility-service';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { Facility } from '../models/facility.model';
import { BreadcrumbsService } from 'ng6-breadcrumbs';
import { User } from '../models/user.model';
import { GlobalService } from '../services/global-service';
import * as moment from 'moment';
import { Moment } from 'moment';
import { environment, ValidationPatterns, } from '../../environments/environment';
@Component({
  selector: 'app-grow-areas',
  templateUrl: './grow-areas.component.html',
  styleUrls: ['./grow-areas.component.css']
})
export class GrowAreasComponent implements OnInit, OnDestroy {

  dtOptions: any = {};
  dtTrigger: Subject<any> = new Subject();
  @ViewChild(DataTableDirective)
  private datatableElement: DataTableDirective;
  selectedGrowArea: GrowArea;
  selectedGrowAreaFlag = true;
  growAreaId: GrowArea;
  device = true;
  delet = false;
  deletGrowAreaId: number;
  growAreas: GrowArea[] = [];
  growAreaTypes: GrowAreaType[] = [];
  containers: Container[] = [];
  growAreaForm: FormGroup;
  selectedFacility: Facility;
  selectedContainer: Container;
  activeGrowAreaCount = 0;
  outOfNetworkGrowAreaCount = 0;
  loggedInUser: User;
  growAreaLoad = false;
  outofnetwork = false;
  active = false;
  diff = [];
  // Flags of Delete Grow Area
  deletedProfile = false;
  deletedLedDesiredValue = false;
  deletedLEDChannelConfiguration = false;
  deletedDevicesPropertyMapping = false;
  deletedSectionDevices = false;
  deletedDevices = false;
  deletedProfileAlertsFromClouds = false;
  deletedGrowSectionProfile = false;
  deletedGrowSection = false;
  deletedGroups = false;
  deletedGatewayAssignee = false;
  deletedGateway = false;
  gatewayToDelete = null;
  isGrowAreaVisible = true;
  apiLoading = false;

  constructor(
    private growareaService: GrowAreaService,
    private spinner: NgxSpinnerService,
    private toastrService: ToastrService,
    private globalService: GlobalService,
    private containerService: ContainerService,
    private facilityService: FacilityService,
    private route: ActivatedRoute,
    private breadcrumbService: BreadcrumbsService,
    private router: Router,

  ) {
  }

  ngOnInit() {
    this.breadcrumbService.store([
      { label: 'Grow Areas', url: '/grow-areas', params: [] }
    ]);
    const elem = document.getElementById('headerMenuCollapse');
    if (elem) {
      elem.classList.remove('show');
    }
    // datatable options for facility table
    this.loggedInUser = JSON.parse(localStorage.getItem('loggedInUser'));
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 10,
      info: false,
      order: [],
      lengthChange: false,
      select: true,
      language: {
        zeroRecords: 'No Grow Areas to display',
        paginate: {
          next: '>', // or '→'
          previous: '<', // or '←',
        }
      }
    };
    this.route.params.subscribe(
      (params: Params) => {
        console.log(params);
        if (params.facilityId && params.containerId) {
          this.getFacilityById(params.facilityId, params.containerId);
          this.getGrowAreasByContainerId(params.containerId);
          this.getGrowAreaTypes();
          this.getOutOfNetworkCount('container', params.containerId);
        } else if (params.facilityId) {
          this.getFacilityById(params.facilityId, undefined);
          this.getGrowAreasByFacilityId(params.facilityId);
          this.getContainersByFacilityId(params.facilityId);
          this.getGrowAreaTypes();
          this.getOutOfNetworkCount('facility', params.facilityId);
        } else if (params.containerId) {
          this.getContainerById(params.containerId);
          this.getGrowAreasByContainerId(params.containerId);
          this.getGrowAreaTypes();
          this.getOutOfNetworkCount('container', params.containerId);
        } else {
          this.getGrowAreas();
          this.getGrowAreaTypes();
          this.getContainers();
          this.getOutOfNetworkCount(null, null);
        }
      }
    );

    this.growareaService.selectedGrowArea.subscribe(
      (growarea: GrowArea) => {
        this.selectedGrowArea = growarea;
        if (!growarea) {
          this.isGrowAreaVisible = false;
        } else {
          this.isGrowAreaVisible = true;
        }
      }
    );
    this.onNewGrowArea();
  }

  refresh() {
    this.router.routeReuseStrategy.shouldReuseRoute = function () {
      return false;
    };
  }

  getGrowAreas() {
    this.growAreas = [];
    this.growAreaLoad = true;
    this.growareaService.getGrowAreas().subscribe(
      (response: GrowArea[]) => {
        setTimeout(
          () => {
            this.growAreas = response;
            if (this.growAreas) {
              this.activeGrowAreaCount = this.growAreas.length;
            } else {
              this.activeGrowAreaCount = 0;
            }
            this.dtTrigger.next();
          }, 500
        );
        this.growAreaLoad = false;
      } , (error) => {
        console.log('Error' + JSON.stringify(error));
        this.growAreaLoad = false;
      }
    );
  }


  onNewGrowArea() {
    this.growAreaForm = new FormGroup({
      grow_area_name: new FormControl(null, [Validators.required]),
      grow_area_type: new FormControl(this.growAreaTypes[0], [Validators.required]),
      mac_id: new FormControl('', [Validators.required]),
      container: new FormControl('', [Validators.required]),
      description: new FormControl(''),
      layout: new FormControl('3')
    });
  }


  getContainers() {
    this.containers = [];
    this.containerService.getContainers().subscribe(
      (response: Container[]) => {
        this.containers = response;
      }
    );
  }

  getOutOfNetworkCount(type, id) {
    if (type === 'facility') {
      this.globalService.getOutOfNetworkCountByFacility(id).subscribe(
        (response: any) => {
          this.outOfNetworkGrowAreaCount = response.count;
        }
      );
    } else if (type === 'container') {
      this.globalService.getOutOfNetworkCountByContainer(id).subscribe(
        (response: any) => {
          this.outOfNetworkGrowAreaCount = response.count;
        }
      );
    } else {
      this.globalService.getOutOfNetworkCount().subscribe(
        (response: any) => {
          this.outOfNetworkGrowAreaCount = response.count;
        }
      );
    }
  }

  getGrowAreaTypes() {
    this.growAreaTypes = [];
    this.growareaService.getGrowAreaTypes().subscribe(
      (response: { id: number, grow_area_type_name: string }[]) => {
        this.growAreaTypes = response;
      }
    );
  }

  onGrowAreaRowSelected(growArea: GrowArea) {
    this.isGrowAreaVisible = true;
    this.selectedGrowAreaFlag = true;
    if (!this.growAreaLoad) {
      this.selectedGrowArea = growArea;
      this.router.navigate([this.selectedGrowArea.id], { relativeTo: this.route });
    }
  }

  onCreateGrowAreaSubmit() {

    console.log(JSON.stringify(this.growAreaForm.value));
    delete this.growAreaForm.value.container;
    this.growareaService.createGrowArea(this.growAreaForm.value).subscribe(
      (response: Response) => {
        this.datatableElement.dtInstance.then((dtInstance: DataTables.Api) => {
          // Destroy the table first
          dtInstance.destroy();
        });
        this.toastrService.success('GrowArea created successfully', 'Create Grow Area');
        if (this.selectedContainer && this.selectedFacility) {
          this.getGrowAreasByContainerId(this.selectedContainer.id);
        } else if (this.selectedContainer) {
          this.getGrowAreasByContainerId(this.selectedContainer.id);
        } else if (this.selectedFacility) {
          this.getGrowAreasByFacilityId(this.selectedFacility.id);
        } else {
          this.getGrowAreas();
        }
      }
    );
  }

  // Delet GrowArea By Id

  onDeletChanges(growArea) {
    console.log('OnDeletChanges called ', growArea);
    this.gatewayToDelete = growArea;
    console.log('GrowAreaID' + growArea.id);
    this.deletGrowAreaId = growArea.id;
  }

  onDeleteGrowArea() {
    this.apiLoading = true;
    this.isGrowAreaVisible = false;
    this.delet = true;
    this.selectedGrowAreaFlag = false;
    this.deletedProfile = false;
    this.deletedLedDesiredValue = false;
    this.deletedLEDChannelConfiguration = false;
    this.deletedDevicesPropertyMapping = false;
    this.deletedSectionDevices = false;
    this.deletedDevices = false;
    this.deletedProfileAlertsFromClouds = false;
    this.deletedGrowSectionProfile = false;
    this.deletedGrowSection = false;
    this.deletedGatewayAssignee = false;
    this.deletedGateway = false;
    this.deletedGroups = false;
    this.selectedGrowArea = undefined;

    this.growareaService.deleteGrowAreaByLedProfile(this.deletGrowAreaId).subscribe((response) => {
      console.log('first service called');
      console.log('response:' + JSON.stringify(response));
      this.deletedProfile = true;
      this.growareaService.deletGrowAreaByDesireValues(this.deletGrowAreaId).subscribe((response) => {
        console.log('second service called');
        console.log('response:' + JSON.stringify(response));
        this.deletedLedDesiredValue = true;
        this.deleteGrowAreaForchannelConfiguration(this.deletGrowAreaId);
      });
      this.apiLoading = false;
    }, (error) => {
      console.log('Error' + JSON.stringify(error));
      this.apiLoading = false;

    });
  }

  deleteGrowAreaForchannelConfiguration(growAreaIdValue) {
    this.growareaService.deletGrowAreaByChannelConfiguration(growAreaIdValue).subscribe((response) => {
      console.log('third method');
      console.log('response:' + JSON.stringify(response));
      this.deletedLEDChannelConfiguration = true;
      this.deleteGrowAreaForPropertyMapping(growAreaIdValue);
    }, (error) => {
      console.log('error' + JSON.stringify(error));
    });
  }

  deleteGrowAreaForPropertyMapping(growAreaIdValue) {
    this.growareaService.deletGrowAreaByPropertyMapping(growAreaIdValue).subscribe((response) => {
      console.log('fourth method');
      console.log('response:' + JSON.stringify(response));
      this.deletedDevicesPropertyMapping = true;
      this.deleteGrowAreaForSection(growAreaIdValue);
    }, (error) => {
      console.log('Error' + JSON.stringify(error));
    });
  }

  deleteGrowAreaForSection(growAreaIdValue) {
    this.growareaService.deletGrowAreaBySection(growAreaIdValue).subscribe((response) => {
      console.log('fifth method');
      console.log('response:' + JSON.stringify(response));
      this.deletedSectionDevices = true;
      this.deleteDevicesFromGateway(growAreaIdValue);
    });
  }

  deleteDevicesFromGateway(growAreaIdValue) {
    this.growareaService.deletGrowDevicesFromGateway(growAreaIdValue).subscribe((response) => {
      console.log('sixth method');
      this.deletedDevices = true;
      this.deleteProfilesAlertsFromGateway(growAreaIdValue);
    }, (error) => {
      console.log('error' + JSON.stringify(error));
    });
  }

  deleteProfilesAlertsFromGateway(growAreaIdValue) {
    this.growareaService.deletProfileAlertsFromGateway(growAreaIdValue).subscribe((response) => {
      console.log('seventh method');
      this.deletedProfileAlertsFromClouds = true;
      this.deleteGrowProfile(growAreaIdValue);
      // this.deleteGrowSection(growAreaIdValue);
    }, (error) => {
      console.log('error' + JSON.stringify(error));
    });
  }

  deleteGrowProfile(growAreaIdValue) {
    this.growareaService.deletProfiles(growAreaIdValue).subscribe((response) => {
      console.log('Eight Method');
      this.deletedGrowSectionProfile = true;
      this.deleteGrowSection(growAreaIdValue);
    }, (error) => {
      console.log('error' + JSON.stringify(error));
    });
  }

  deleteGrowSection(growAreaIdValue) {
    this.growareaService.deletGrowSections(growAreaIdValue).subscribe((response) => {
      console.log('Nine Method');
      this.deletedGrowSection = true;
      this.deleteGroups(growAreaIdValue);
    }, (error) => {
      console.log('error' + JSON.stringify(error));
    });
  }

  deleteGroups(growAreaIdValue) {
    this.growareaService.deletGroups(growAreaIdValue).subscribe((response) => {
      console.log('Ten Method');
      this.deletedGroups = true;
      this.deleteGrowAreaAsignee(growAreaIdValue);
    }, (error) => {
      console.log('error' + JSON.stringify(error));
    });
  }
  deleteGrowAreaAsignee(growAreaIdValue) {
    this.growareaService.deletGrowAreaAsignee(growAreaIdValue).subscribe((response) => {
      console.log('Eleven Methods');
      this.deletedGatewayAssignee = true;
      this.deleteGrowArea(growAreaIdValue);
    }, (error) => {
      console.log('error' + JSON.stringify(error));
    });
  }

  deleteGrowArea(growAreaIdValue) {
    this.growareaService.deletGrowArea(growAreaIdValue).subscribe((response) => {
      console.log('Twelve method');
      this.deletedGateway = true;
      this.selectedGrowAreaFlag = true;
      this.datatableElement.dtInstance.then((dtInstance: DataTables.Api) => {
        // Destroy the table first
        dtInstance.destroy();
      });

      this.route.params.subscribe((params: Params) => {
        console.log(params);
        if (params.growareaId) {
          params.remove(params.growareaId);
        }
        console.log(params);
      });
      if (this.selectedFacility && this.selectedContainer) {
        this.router.navigate(['facilities', this.selectedFacility.id, 'containers', this.selectedContainer.id, 'grow-areas']);
        this.getFacilityById(this.selectedFacility.id, this.selectedContainer.id);
      } else if (this.selectedFacility) {
        this.router.navigate(['facilities', this.selectedFacility.id, 'grow-areas']);
        this.getFacilityById(this.selectedFacility.id, undefined);
      } else if (this.selectedContainer) {
        this.router.navigate(['containers', this.selectedContainer.id, 'grow-areas']);
        this.getContainerById(this.selectedContainer.id);
      } else {
        this.router.navigate(['grow-areas']);
        this.selectedGrowArea = undefined;
        this.breadcrumbService.store([
          { label: 'Grow Areas', url: '/grow-areas', params: [] }
        ]);
      }
      this.toastrService.success('Grow Area deleted successfully', 'Delete Grow Area');
      if (this.selectedContainer && this.selectedFacility) {
        this.getGrowAreasByContainerId(this.selectedContainer.id);
      } else if (this.selectedContainer) {
        this.getGrowAreasByContainerId(this.selectedContainer.id);
      } else if (this.selectedFacility) {
        this.getGrowAreasByFacilityId(this.selectedFacility.id);
      } else {
        this.getGrowAreas();
      }
      this.selectedGrowAreaFlag = true;
      this.delet = false;

    }, (error) => {
      console.log('error' + JSON.stringify(error));
      this.delet = false;

    });
  }



  // onDeleteGrowArea() {

  //   this.growareaService.deleteGrowArea(this.deletGrowAreaId.id).subscribe(
  //     (response: Response) => { savanmnayak@gmail.com

  //       this.datatableElement.dtInstance.then((dtInstance: DataTables.Api) => {
  //         // Destroy the table first
  //         dtInstance.destroy();
  //       });
  //       if (this.selectedFacility && this.selectedContainer && this.selectedGrowArea) {
  //         this.router.navigate(['facilities', this.selectedFacility.id, 'containers', this.selectedContainer.id, 'grow-areas']);
  //         this.getFacilityById(this.selectedFacility.id, this.selectedContainer.id);
  //       } else if (this.selectedFacility) {
  //         this.router.navigate(['facilities', this.selectedFacility.id, 'grow-areas']);
  //         this.getFacilityById(this.selectedFacility.id, undefined);
  //       } else if (this.selectedContainer) {
  //         this.router.navigate(['containers', this.selectedContainer.id, 'grow-areas']);
  //         this.getContainerById(this.selectedContainer.id);
  //       } else if (this.selectedGrowArea) {
  //         this.router.navigate(['grow-areas']);
  //       }
  //       this.toastrService.success('Grow Area deleted successfully', 'Delete Grow Area');
  //       if (this.selectedContainer && this.selectedFacility) {
  //         this.getGrowAreasByContainerId(this.selectedContainer.id);
  //       } else if (this.selectedContainer) {
  //         this.getGrowAreasByContainerId(this.selectedContainer.id);
  //       } else if (this.selectedFacility) {
  //         this.getGrowAreasByFacilityId(this.selectedFacility.id);
  //       } else {
  //         this.getGrowAreas();
  //       }
  //     }
  //   );
  //   // }else{
  //   //   console.log('Nothing is changing..');
  //   // }
  // }

  onEditGrowArea(growAreaObj: GrowArea) {
    this.growAreaForm.setValue({
      grow_area_name: growAreaObj.grow_area_name,
      grow_area_type: growAreaObj.grow_area_type,
      mac_id: growAreaObj.mac_id,
      container: growAreaObj.container,
      description: growAreaObj.description,
      layout: 'abcs'
    });
    this.selectedGrowArea = growAreaObj;
  }
  addReloadEventToBreadcrumb() {
    setTimeout(() => {
      const elems = document.querySelectorAll('.breadcrumb-item a');
      console.log(elems);
      console.log('length     ', elems.length);
      for (let i = 0; i < elems.length; i++) {
        elems[i].addEventListener('click', this.globalService.handleClick);
      }
    }, 100);
  }
  // functions when we go to grow areas from facilities

  getFacilityById(id, containerId) {

    this.facilityService.getFacilityById(id).subscribe(
      (response: Facility) => {
        this.selectedFacility = response;

        if (containerId === undefined) {
          this.breadcrumbService.store([
            { label: 'Facilities', url: '/facilities', params: [] },
            { label: this.selectedFacility.facility_name + '', url: '/facilities/' + this.selectedFacility.id, params: [] },
            { label: 'Grow Areas', url: '', params: [] }
          ]);
          this.addReloadEventToBreadcrumb();
        } else {
          this.getContainerById(containerId);
        }
      }
    );
  }

  getGrowAreasByFacilityId(facilityId) {
    this.growareaService.getGrowAreasByFacility(facilityId).subscribe(
      (response: GrowArea[]) => {
        console.log(response);
        this.growAreas = response;
        if (this.growAreas) {
          this.activeGrowAreaCount = this.growAreas.length;
        } else {
          this.activeGrowAreaCount = 0;
        }
        this.dtTrigger.next();
      },
      (errorResponse: HttpErrorResponse) => {

      }
    );
  }

  getContainersByFacilityId(facilityId) {
    this.containerService.getContainersByFacilityId(facilityId).subscribe(
      (response: Container[]) => {
        this.containers = response;
      }
    );
  }

  // functions when we go to grow areas from containers

  getContainerById(containerId) {

    this.containerService.getContainerById(containerId).subscribe(
      (response: Container) => {
        this.selectedContainer = response;
        if (this.selectedFacility) {
          this.breadcrumbService.store([
            { label: 'Facilities', url: '/facilities', params: [] },
            { label: this.selectedFacility.facility_name + '', url: '/facilities/' + this.selectedFacility.id, params: [] },
            { label: 'Containers', url: '/facilities/' + this.selectedFacility.id + '/containers', params: [] },
            {
              label: this.selectedContainer.container_name + '',
              url: '/facilities/' + this.selectedFacility.id + '/containers/' + this.selectedContainer.id, params: []
            },
            { label: 'Grow Areas', url: '', params: [] },
          ]);
        } else {
          this.breadcrumbService.store([
            { label: 'Containers', url: '/containers', params: [] },
            { label: this.selectedContainer.container_name + '', url: '/containers/' + this.selectedContainer.id, params: [] },
            { label: 'Grow Areas', url: '', params: [] },
          ]);
        }
        this.addReloadEventToBreadcrumb();
      }
    );
  }

  getGrowAreasByContainerId(containerId) {
    this.growareaService.getGrowAreasByContainer(containerId).subscribe(
      (response: GrowArea[]) => {
        this.growAreas = response;
        if (this.growAreas) {
          this.activeGrowAreaCount = this.growAreas.length;
        } else {
          this.activeGrowAreaCount = 0;
        }
        this.dtTrigger.next();
      }
    );
  }

  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }

}
