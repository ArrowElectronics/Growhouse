import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GrowAreasComponent } from './grow-areas.component';

describe('GrowAreasComponent', () => {
  let component: GrowAreasComponent;
  let fixture: ComponentFixture<GrowAreasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GrowAreasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GrowAreasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
