export class User {
  public id: number;
  public username: string;
  public first_name: string;
  public last_name: string;
  public token: string;
  public user_role: UserRole;
  public email_id: string;
  public account: Account;
  constructor(
    id: number,
    username: string,
    first_name: string,
    last_name: string,
    token: string,
    user_role: UserRole,
    email_id: string,
    account: Account
  ) {
    this.id = id;
    this.username = username;
    this.first_name = first_name;
    this.last_name = last_name;
    this.token = token;
    this.email_id = email_id;
    this.account = account;
    this.user_role = user_role;
  }
}

export class UserRole {
  public virtual_role_name: string;
  public role_name: string;
  public id: number;
  constructor(virtual_role_name: string, role_name: string, id: number) {
    this.virtual_role_name = virtual_role_name;
    this.role_name = role_name;
    this.id = id;
  }
}

export class UserLogin {
  public login: string;
  public password: string;
  constructor(login: string, password: string) {
    this.login = login;
    this.password = password;
  }
}

export class UserChangePassword {
  public login: string;
  public currentPassword: string;
  public newPassword: string;
  public confirmNewPassword: string;
  constructor(
    login: string,
    currentPassword: string,
    newPassword: string,
    confirmNewPassword: string
  ) {
    this.login = login;
    this.currentPassword = currentPassword;
    this.newPassword = newPassword;
    this.confirmNewPassword = confirmNewPassword;
  }
}

export class UserSession {
  public userDTO: User;
  public sessionId: string;
}
