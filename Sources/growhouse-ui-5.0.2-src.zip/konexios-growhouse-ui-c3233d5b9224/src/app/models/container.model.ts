import { Facility } from './facility.model';
import { User } from './user.model';



export class Container {

  public id: number;
  public container_name: string;
  public container_type: ContainerType;
  public admin: User;
  public facility: Facility;
  public description: string;


  constructor( id: number,
            container_name: string,
            facility: Facility,
            admin: User,
            description: string
            ) {
      this.id = id;
      this.container_name = container_name;
      this.facility = facility;
      this.admin = admin;
      this.description = description;
  }
}

export class ContainerType {
  public id: number;
  public container_type_name: string;

  constructor(
    id: number,
    container_type_name: string
  ) {
    this.id = id;
    this.container_type_name = container_type_name;
  }
}
