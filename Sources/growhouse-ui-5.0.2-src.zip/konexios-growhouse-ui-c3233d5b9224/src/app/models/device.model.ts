import { Facility } from './facility.model';
import { User } from './user.model';
import { GrowArea } from './growarea.model';
import { GrowSection } from './growsection.model';



export class Device {

  public id: number;
  public device_name: string;
  public device_type: DeviceType;
  public grow_area: GrowArea;
  public description: string;
  public deviceHId: string;
  public deviceUId: string;
  public prefix_keyword: string;
  public status: boolean;

  constructor(id: number,
    device_name: string,
    device_type: DeviceType,
    grow_area: GrowArea,
    description: string,
    deviceHId: string,
    deviceUId: string,
    prefix_keyword: string,
    status: boolean
  ) {
    this.id = id;
    this.device_name = device_name;
    this.device_type = device_type;
    this.grow_area = grow_area;
    this.description = description;
    this.deviceHId = deviceHId;
    this.deviceUId = deviceUId;
    this.prefix_keyword = prefix_keyword;
    this.status = status;
  }
}

export class DeviceType {
  public id: number;
  public device_type_name: string;
  public virtual_device_type_name: string;
  constructor(
    id: number,
    device_type_name: string,
    virtual_device_type_name: string
  ) {
    this.id = id;
    this.device_type_name = device_type_name;
    this.virtual_device_type_name = virtual_device_type_name;

  }
}

export class channelConfig {
  public device_id: any;
  public device_type: string;
  public ch1: number;
  public ch2: number;
  public ch3: number;
  public ch4: number;
  public ch5: number;
  public ch6: number;

  constructor(
    device_id: any,
    device_type: string,
    ch1: number,
    ch2: number,
    ch3: number,
    ch4: number,
    ch5: number,
    ch6: number,
  ) {
    this.device_id = device_id;
    this.device_type = device_type;
    this.ch1 = ch1;
    this.ch2 = ch2;
    this.ch3 = ch3;
    this.ch4 = ch4;
    this.ch5 = ch5;
    this.ch6 = ch6;
  }

}

export class profileConfig {
  public device: any;
  public device_type: string;
  profile_name: string;
  description: string;
  public channel_configuration: any;
  constructor(device: any, device_type: string, profile_name: string, description: string, channel_configuration: any) {
    this.device = device;
    this.device_type = device_type;
    this.profile_name = profile_name;
    this.description = description;
    this.channel_configuration = channel_configuration;
  }
}
