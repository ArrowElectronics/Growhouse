import { PlatformLocation } from "@angular/common";
import { Component, OnDestroy, OnInit, ViewChild } from "@angular/core";
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from "@angular/forms";
import { Router } from "@angular/router";
import { DataTableDirective } from "angular-datatables";
import { BreadcrumbsService } from "ng6-breadcrumbs";
import { NgxSpinnerService } from "ngx-spinner";
import { ToastrService } from "ngx-toastr";
import { Subject } from "rxjs";
import { ValidationPatterns } from "../../environments/environment";
import { User, UserRole } from "../models/user.model";
import { GlobalService } from "../services/global-service";
import { UserService } from "../services/user-service";

@Component({
  selector: "app-users",
  templateUrl: "./users.component.html",
  styleUrls: ["./users.component.css"],
})
export class UsersComponent implements OnInit, OnDestroy {
  dtOptions: any = {};
  dtTrigger: Subject<any> = new Subject();
  @ViewChild(DataTableDirective)
  private datatableElement: DataTableDirective;
  users: User[] = [];
  deletUserId: User;
  delet = true;
  userRoles: UserRole[] = [];
  userForm: FormGroup;
  isEditUser = false;
  selectedUser: User;
  isUserLoad = false;
  apiLoading = false;
  totalUsersCount = 0;
  obj1 = { key: "value" };
  obj2 = { key: "value" };
  loggedInUser: User;
  constructor(
    private userService: UserService,
    private spinner: NgxSpinnerService,
    private toastrService: ToastrService,
    private formBuilder: FormBuilder,
    private router: Router,
    private breadcrumService: BreadcrumbsService,
    private location: PlatformLocation,
    private globalService: GlobalService
  ) {
    // location.onPopState(()=>{
    //   $('#userModal').modal('hide');
    //   $('myDeletModal').modal('hide');
    // });
  }

  ngOnInit() {
    this.breadcrumService.store([
      { label: "Users", url: "/users", params: [] },
    ]);
    const elem = document.getElementById("headerMenuCollapse");
    if (elem) {
      elem.classList.remove("show");
    }
    this.loggedInUser = JSON.parse(localStorage.getItem("loggedInUser"));
    // datatable options for facility table
    this.dtOptions = {
      pagingType: "full_numbers",
      pageLength: 10,
      destroy: true,
      info: false,
      order: [],
      lengthChange: false,
      select: true,
      language: {
        zeroRecords: "No Users to display",
        paginate: {
          next: ">", // or '→'
          previous: "<", // or '←',
        },
      },
    };

    // initializing the add user form group
    this.userForm = new FormGroup({
      username: new FormControl(null, [
        Validators.required,
        Validators.maxLength(40),
        Validators.pattern(ValidationPatterns.username),
      ]),
      email_id: new FormControl(null, [
        Validators.required,
        Validators.pattern(ValidationPatterns.emailPattern),
        this.noDoubleDotValidator,
        this.noIntegerValidator,
      ]),
      first_name: new FormControl(null, [
        Validators.required,
        Validators.maxLength(40),
        Validators.pattern(ValidationPatterns.name),
      ]),
      last_name: new FormControl(null, [
        Validators.required,
        Validators.maxLength(40),
        Validators.pattern(ValidationPatterns.name),
      ]),
      user_role: new FormControl({ value: null, disabled: true }),
      account: new FormControl(this.loggedInUser.account),
    });

    this.getUsers();
    this.getUserRoles();
    this.addReloadEventToBreadcrumb();
  }
  addReloadEventToBreadcrumb() {
    setTimeout(() => {
      const elems = document.querySelectorAll(".breadcrumb-item a");
      console.log(elems);
      console.log("length     ", elems.length);
      for (let i = 0; i < elems.length; i++) {
        elems[i].addEventListener("click", this.globalService.handleClick);
      }
    }, 100);
  }
  public noDoubleDotValidator(control: FormControl) {
    return (control.value || "").includes("..") ? { doubleDot: true } : null;
  }

  public noIntegerValidator(control: FormControl) {
    if (control.value && control.value.includes("@")) {
      return isNaN(control.value.split("@")[0]) ? null : { onlyNumbers: true };
    }
    return null;
  }

  getUsers() {
    this.isUserLoad = true;
    this.users = [];
    this.userService.getUsers().subscribe(
      (response: User[]) => {
        setTimeout(() => {
          this.users = response;
          this.totalUsersCount = this.users.length;
          this.dtTrigger.next();
          this.isUserLoad = false;
        }, 500);
      },
      (error) => {
        console.log("error" + error);
        this.isUserLoad = false;
      }
    );
  }

  removeDetails() {
    this.userForm.reset();
  }

  // ^[a-z0-9](\.?[a-z0-9]){5,}@g(oogle)?mail\.com$
  // ^([A-Za-z](\.|_){0,1})+[A-Z|a-z|0-9|\._]+@gmail.com

  onNewUser() {
    this.isEditUser = false;
    this.userForm.reset();
    this.userForm
      .get("user_role")
      .setValue(this.userRoles[0].virtual_role_name);
    this.userForm.get("username").enable();
  }

  getUserRoles() {
    this.userRoles = [];
    this.userService.getUserRoles().subscribe(
      (response: UserRole[]) => {
        this.userRoles = response;
        let index = 0;
        for (let i = 0; i < this.userRoles.length; i++) {
          if (this.userRoles[i].role_name === "Admin") {
            index = i;
          }
        }
        this.userRoles.splice(index, 1);
      },
      (error) => {
        console.log("error", error);
      }
    );
  }

  onAddUserSubmit() {
    this.apiLoading = true;
    let payload = this.userForm.value;
    payload["user_role"] = this.userRoles[0];

    this.userService.createUser(this.userForm.value).subscribe(
      (response) => {
        this.datatableElement.dtInstance.then((dtInstance: DataTables.Api) => {
          // Destroy the table first
          dtInstance.destroy();
        });
        this.getUsers();
        this.toastrService.success(
          "User was created successfully",
          "Create User"
        );
        this.apiLoading = false;
      },
      (error) => {
        console.log("error", error);
        this.apiLoading = false;
      }
    );
  }

  onEditUser(user: User) {
    console.log(user);
    this.selectedUser = user;
    this.isEditUser = true;
    this.userForm.patchValue({
      username: user.username,
      email_id: user.email_id,
      first_name: user.first_name,
      last_name: user.last_name,
      user_role: user.user_role.virtual_role_name,
    });
    this.userForm.get("username").disable();
  }

  onEditUserSubmit() {
    this.apiLoading = true;
    this.userForm.get("user_role").setValue(this.selectedUser.user_role);
    this.userForm.value.id = this.selectedUser.id;
    this.userService
      .updateUser(this.userForm.value, this.userForm.value.id)
      .subscribe(
        (response) => {
          this.datatableElement.dtInstance.then(
            (dtInstance: DataTables.Api) => {
              // Destroy the table first
              dtInstance.destroy();
            }
          );
          this.isEditUser = false;
          this.getUsers();
          this.selectedUser = undefined;
          this.toastrService.success(
            "User Updated Successfully",
            "Update User"
          );
          this.apiLoading = false;
        },
        (error) => {
          console.log("error", error);
          this.apiLoading = false;
        }
      );
  }

  onFieldMissing(name: string) {
    let field = this.userForm.get(name);
    return !field.value && field.touched;
  }

  onFieldInvalid(name: string) {
    let field = this.userForm.get(name);
    return field.value && !field.valid && field.touched;
  }

  compareFn(obj1: any, obj2: any): boolean {
    return obj1 && obj2 ? obj1.id === obj2.id : obj1 === obj2;
  }

  // Delet User Detail
  onDeletChanges(userId: User) {
    this.delet = true;
    console.log("OnDeletChanges called");
    this.deletUserId = userId;
  }

  onDeleteUser() {
    this.apiLoading = true;

    this.userService.deleteUser(this.deletUserId.id).subscribe(
      (response) => {
        this.datatableElement.dtInstance.then((dtInstance: DataTables.Api) => {
          // Destroy the table first
          dtInstance.destroy();
        });
        this.apiLoading = false;

        this.getUsers();
        this.toastrService.success("User deleted Successfully", "Delete User");
      },
      (error) => {
        console.log("error", error);
        this.apiLoading = false;
      }
    );
  }

  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }
}
