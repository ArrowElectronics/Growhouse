import {
  HttpErrorResponse,
  HttpEvent,
  HttpHandler,
  HttpHeaders,
  HttpInterceptor,
  HttpRequest,
} from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Router } from "@angular/router";
import { NgxSpinnerService } from "ngx-spinner";
import { ToastrService } from "ngx-toastr";
import { Observable, throwError } from "rxjs";
import { catchError } from "rxjs/operators";
import { error } from "util";
import { LoginService } from "../services/login-service";

@Injectable()
export class AuthInterceptor implements HttpInterceptor {
  constructor(
    private loginService: LoginService,
    private router: Router,
    private toasterService: ToastrService,
    private spinnerService: NgxSpinnerService
  ) {}

  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    const request = req.clone({
      headers: new HttpHeaders({
        Authorization: this.loginService.getToken(),
      }),
    });
    return next.handle(request).pipe(
      catchError((event: HttpErrorResponse) => {
        console.log(event.status + ": " + JSON.stringify(event));
        if (event.status === 401 || event.status === 403) {
          this.loginService.resetStorage();
          if (!event.url.endsWith("login")) {
            window.location.href = "/";
          }
        } else if (event.status === 409) {
          this.loginService.resetStorage();
          if (!event.url.endsWith("login")) {
            window.location.href = "/change-password";
          }
        } else {
          if (event.error && event.error.message) {
            this.toasterService.error(event.error.message);
          }
        }
        return throwError(event);
      })
    );
  }

  private handleAuthError(err: HttpErrorResponse): Observable<any> {
    // handle your auth error or rethrow
    throw error;
  }
}
