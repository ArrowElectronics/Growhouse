import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { GlobalService } from '../services/global-service';
import { ProfileMessage } from 'src/environments/environment';
import * as _ from 'underscore';
import { PagerService } from '../services/pager.service';
import { BreadcrumbsService } from 'ng6-breadcrumbs';
import { FacilityService } from '../services/facility-service';
import { GrowArea } from '../models/growarea.model';
import { Container } from '../models/container.model';
import { Facility } from '../models/facility.model';
import { ContainerService } from '../services/container-service';
import { GrowAreaService } from '../services/growarea-service';
import { Moment } from 'moment';
import * as moment from 'moment';
import { NgxDaterangepickerMd } from 'ngx-daterangepicker-material';


@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})

export class ProfileComponent implements OnInit, OnDestroy {

  selectedGrowArea: GrowArea;
  selectedContainer: Container;
  selectedFacility: Facility;
  p1 = 1;
  p2 = 1;
  startDate: any;
  endDate: any;
  alertsOfProfileLoad = false;
  // selected: { start: Moment, end: Moment };

  selectedProfile;
  ALL_OK = ProfileMessage.ALL_OK;
  NEED_WATER = ProfileMessage.NEED_WATER;
  NEED_SUN = ProfileMessage.NEED_SUN;
  MORE_SUN = ProfileMessage.MORE_SUN;
  // array of all items to be paged
  //  pagedItem: any[];
  device_id: { id: number };

  // pager object
  pager: any = {};
  // paged items
  allItems: any[] = [];
  properties: any[] = [];
  profileHistoryNotSelected = false;
  profileHistoryData: any = [];
  selected: string;

  pagedItem: any[];
  selectedDateObject = Object.keys;

  ranges: any = {
    'Today': [moment().startOf('day').add(1, 'second'), moment()],
    'Yesterday': [moment().subtract(1, 'days').startOf('day').add(1, 'second'), moment().subtract(1, 'days').endOf('day')],
    'Last 7 Days': [moment().subtract(7, 'days').startOf('day').add(1, 'second'), moment()],
    'Last 30 Days': [moment().subtract(30, 'days').startOf('day'), moment()],
    'This Month': [moment().startOf('month'), moment().endOf('month')],
  };

  constructor(
    private globalService: GlobalService,
    private router: Router,
    private route: ActivatedRoute,
    private pagerService: PagerService,
    private facilityService: FacilityService,
    private containerService: ContainerService,
    private growareaService: GrowAreaService,
    private breadcrumService: BreadcrumbsService
  ) {

  }

  ngOnInit() {
    let containerId, facilityId, growareaId, profileId;
    this.route.params.subscribe((parentParams: Params) => {
      console.log(parentParams);
      this.route.parent.params.subscribe(
        (params: Params) => {
          console.log(params);
          if (parentParams.facilityId) {
            facilityId = parentParams.facilityId;
          }
          if (parentParams.containerId) {
            containerId = parentParams.containerId;
          }
          if (parentParams.growareaId) {
            growareaId = parentParams.growareaId;
          }

          if (params.facilityId) {
            facilityId = params.facilityId;
          }
          if (params.containerId) {
            containerId = params.containerId;
          }
          if (params.growareaId) {
            growareaId = params.growareaId;
          }
          if (parentParams.profileId) {
            profileId = parentParams.profileId;
          }
          if (facilityId) {
            this.getFacilityById(facilityId, containerId, growareaId, profileId);
            this.getAlertsByProfileId(parentParams.profileId);
          } else if (containerId) {
            this.getContainerById(containerId, growareaId, profileId);
          } else if (growareaId) {
            this.getGrowAreaById(growareaId, profileId);
          } else {
            this.getProfilesByProfileId(profileId);
            this.getAlertsByProfileId(parentParams.profileId);
          }
        });
      if (parentParams.profileId) {
        this.getProfilesByProfileId(parentParams.profileId);
        this.getAlertsByProfileId(parentParams.profileId);
        // this.getGrowAreaProfileHistory(parentParams.profileId);
      }
    });
  }

  getFacilityById(id, containerId, growareaId, profileId) {
    this.facilityService.getFacilityById(id).subscribe((response: Facility) => {
      this.selectedFacility = response;
      console.log(this.selectedFacility);
      this.facilityService.selectedFacility.emit(this.selectedFacility);
      if (containerId) {
        this.getContainerById(containerId, growareaId, profileId);
      } else if (growareaId) {
        this.getGrowAreaById(growareaId, profileId);
      } else {
        this.getProfilesByProfileId(profileId);
        this.getAlertsByProfileId(profileId);
      }
    });
  }

  getContainerById(id, growareaId, profileId) {
    this.containerService
      .getContainerById(id)
      .subscribe((response: Container) => {
        this.selectedContainer = response;
        if (growareaId) {
          this.getGrowAreaById(growareaId, profileId);
        } else {
          this.getProfilesByProfileId(profileId);
          this.getAlertsByProfileId(profileId);
        }
      });
  }

  getGrowAreaById(id, deviceId) {
    this.growareaService
      .getGrowAreaById(id)
      .subscribe((response: GrowArea) => {
        this.selectedGrowArea = response;
        console.log(this.selectedGrowArea);
        if (deviceId) {
          this.getProfilesByProfileId(deviceId);
          // this.getAlertsByProfileId(deviceId);
        }
      });
  }

  getProfilesByProfileId(profileId) {
    let properties;
    const prop_arr = [];
    this.getAlertsByProfileId(profileId);
    return this.globalService.getProfileAlertByProfileId(profileId).subscribe(
      response => {
        this.selectedProfile = response;
        properties = this.selectedProfile.properties ? JSON.parse(this.selectedProfile.properties) : {};
        console.log(properties);
        // tslint:disable-next-line:forin
        for (const key in properties) {
          prop_arr.push({ name: key, value: properties[key] });
        }
        this.selectedProfile.properties = prop_arr;
        this.globalService.selectedProfile.emit(this.selectedProfile);
        if (this.selectedFacility && this.selectedContainer && this.selectedGrowArea) {
          this.breadcrumService.store([
            { label: 'Facilities', url: '/facilities', params: [] },
            {
              label: this.selectedFacility.facility_name,
              url: '/facilities/' + this.selectedFacility.id,
              params: []
            },
            { label: 'Containers', url: '/facilities/' + this.selectedFacility.id + '/containers', params: [] },
            {
              label: this.selectedContainer.container_name + '',
              url: '/facilities/' + this.selectedFacility.id + '/containers/' + this.selectedContainer.id,
              params: []
            },
            {
              label: 'Grow Areas',
              url: '/facilities/' + this.selectedFacility.id + '/containers/' + this.selectedContainer.id + '/grow-areas',
              params: []
            },
            {
              label: this.selectedGrowArea.grow_area_name + '',
              url: '/facilities/' + this.selectedFacility.id + '/containers/' + this.selectedContainer.id
                + '/grow-areas/' + this.selectedGrowArea.id,
              params: []
            },
            {
              label: 'Rules',
              url: '/facilities/' + this.selectedFacility.id + '/containers/' + this.selectedContainer.id
                + '/grow-areas/' + this.selectedGrowArea.id + '/profiles/',
              params: []
            },
            {
              label: this.selectedProfile.profileVirtualName + '',
              url: '/facilities/' + this.selectedFacility.id + '/containers/' + this.selectedContainer.id +
                '/grow-areas/' + this.selectedGrowArea.id + '/profiles/' + this.selectedProfile.profileId,
              params: []
            }
          ]);
        }  else if (this.selectedFacility && this.selectedGrowArea) {
          this.breadcrumService.store([
            { label: 'Facilities', url: '/facilities', params: [] },
            {
              label: this.selectedFacility.facility_name,
              url: '/facilities/' + this.selectedFacility.id,
              params: []
            },
            {
              label: 'Grow Areas',
              url: '/facilities/' + this.selectedFacility.id + '/grow-areas',
              params: []
            },
            {
              label: this.selectedGrowArea.grow_area_name + '',
              url: '/facilities/' + this.selectedFacility.id + '/grow-areas/' + this.selectedGrowArea.id,
              params: []
            },
            {
              label: 'Rules',
              url: '/facilities/' + this.selectedFacility.id + '/grow-areas/' + this.selectedGrowArea.id + '/profiles',
              params: []
            },
            {
              label: this.selectedProfile.profileVirtualName + '',
              url: '/facilities/' + this.selectedFacility.id +
                '/grow-areas/' + this.selectedGrowArea.id + '/profiles/' + this.selectedProfile.profileId,
              params: []
            }
          ]);
        } else if (this.selectedContainer && this.selectedGrowArea) {
          this.breadcrumService.store([
            { label: 'Containers', url: '/containers', params: [] },
            {
              label: this.selectedContainer.container_name + '',
              url: '/containers/' + this.selectedContainer.id,
              params: []
            },
            {
              label: 'Grow Areas',
              url: '/containers/' + this.selectedContainer.id + '/grow-areas',
              params: []
            },
            {
              label: this.selectedGrowArea.grow_area_name + '',
              url: '/containers/' + this.selectedContainer.id + '/grow-areas/' + this.selectedGrowArea.id,
              params: []
            },
            {
              label: 'Rules',
              url: '/containers/' + this.selectedContainer.id + '/grow-areas/' + this.selectedGrowArea.id + '/profiles/',
              params: []
            },
            {
              label: this.selectedProfile.profileVirtualName + '',
              url: '/containers/' + this.selectedContainer.id + '/grow-areas/' +
                this.selectedGrowArea.id + '/profiles/' + this.selectedProfile.profileId,
              params: []
            }
          ]);
        } else if (this.selectedGrowArea) {
          this.breadcrumService.store([
            {
              label: 'Grow Areas',
              url: '/grow-areas',
              params: []
            },
            {
              label: this.selectedGrowArea.grow_area_name + '',
              url: '/grow-areas/' + this.selectedGrowArea.id,
              params: []
            },
            {
              label: 'Rules',
              url: '/grow-areas/' + this.selectedGrowArea.id + '/profiles',
              params: []
            },
            {
              label: this.selectedProfile.profileVirtualName + '',
              url: '/grow-areas/' + this.selectedGrowArea.id + '/profiles/' + this.selectedProfile.profileId,
              params: []
            }
          ]);
        } else {
          this.breadcrumService.store([
            {
              label: 'Rules',
              url: '/profiles',
              params: []
            },
            {
              label: this.selectedProfile.profileVirtualName + '',
              url: '/profiles/' + this.selectedProfile.profileId,
              params: []
            }
          ]);
        }
        this.addReloadEventToBreadcrumb();
      });
  }
  addReloadEventToBreadcrumb() {
    setTimeout(() => {
      const elems = document.querySelectorAll('.breadcrumb-item a');
      console.log(elems);
      console.log('length     ', elems.length);
      for (let i = 0; i < elems.length; i++) {
        elems[i].addEventListener('click', this.globalService.handleClick);
      }
    }, 100);
  }
  getAlertsByProfileId(profileId) {
    // this.getProfilesByProfileId(profileId);
    this.globalService.getAlertsByProfile(profileId).subscribe(
      (response: any[]) => {
        this.allItems = response;
        console.log('alerts' + JSON.stringify(this.allItems));
      });
  }


  closeLiveHistoryModal() {
    this.selected = '';
    this.profileHistoryData = [];
  }

  setData(event) {
    this.profileHistoryData = [];
    console.log('data' + JSON.stringify(event));
    // this.startDate = new Date(event.start).getTime();
    // this.endDate = new Date(event.end).getTime();
    this.startDate = event.start;
    this.endDate = event.end;
    console.log('start' + this.startDate);
    console.log('end' + this.endDate);
    if (this.startDate && this.endDate) {
      this.alertsOfProfileLoad = true;
      this.globalService.getProfileHistoryForGrowAreas(this.selectedProfile.profileId, this.startDate, this.endDate).subscribe((data) => {
        // this.profileHistoryData = [];
        this.profileHistoryData = data;
        if (this.profileHistoryData.length === 0) {
          this.profileHistoryNotSelected = true;
        } else {
          this.profileHistoryNotSelected = false;
        }
        console.log('profileHistoryData' + JSON.stringify(this.profileHistoryData));
        this.alertsOfProfileLoad = false;
      }, (error) => {
        console.log('error' + JSON.stringify(error));
      });
    }
  }

  ngOnDestroy() {
    this.globalService.selectedProfile.emit(undefined);
  }
}
