import { Component, OnInit } from "@angular/core";
import { LoginService } from "../services/login-service";
import { environment } from "../../environments/environment";
import { Location } from "@angular/common";
import { User } from "../models/user.model";
import { Router } from "@angular/router";

@Component({
  selector: "app-header",
  templateUrl: "./header.component.html",
  styleUrls: ["./header.component.css"],
})
export class HeaderComponent implements OnInit {
  userDetails: { name: string; email: string; image: string; token: string };
  loggedInUser: User;
  isLoader: boolean = false;

  constructor(
    private loginService: LoginService,
    private location: Location,
    private router: Router
  ) {}

  ngOnInit() {
    this.userDetails = JSON.parse(localStorage.getItem("userDetails"));
    this.loggedInUser = JSON.parse(localStorage.getItem("loggedInUser"));
  }

  onSignOut() {
    this.loginService.signOut().subscribe(
      () => {},
      (error) => {
        console.log(error);
      }
    );
    this.loginService.resetStorage();
    window.location.href = "/";
    this.isLoader = true;
  }
}
