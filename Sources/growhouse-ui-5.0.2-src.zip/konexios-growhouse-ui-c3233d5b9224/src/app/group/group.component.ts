import { Component, OnInit } from '@angular/core';
import { GrowArea } from '../models/growarea.model';
import { Facility } from '../models/facility.model';
import { Group } from '../models/group.model';
import { GrowAreaService } from '../services/growarea-service';
import { ToastrService } from 'ngx-toastr';
import { GroupService } from '../services/group-service';
import { ContainerService } from '../services/container-service';
import { FacilityService } from '../services/facility-service';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { BreadcrumbsService } from 'ng6-breadcrumbs';
import { Container } from '../models/container.model';
import { GlobalService } from '../services/global-service';
import { throwMatDialogContentAlreadyAttachedError } from '@angular/material';

@Component({
  selector: 'app-group',
  templateUrl: './group.component.html',
  styleUrls: ['./group.component.css']
})
export class GroupComponent implements OnInit {
  selectedGrowArea: GrowArea;
  selectedContainer: Container;
  selectedFacility: Facility;
  selectedGroup;
  isViewDevices = false;
  constructor(
    private growareaService: GrowAreaService,
    private toastrService: ToastrService,
    private groupService: GroupService,
    private containerService: ContainerService,
    private facilityService: FacilityService,
    private route: ActivatedRoute,
    private breadcrumbService: BreadcrumbsService,
    private router: Router,
    private globalService: GlobalService
  ) { }

  ngOnInit() {
    let containerId, facilityId, growareaId, groupId;
    this.route.params.subscribe((parentParams: Params) => {
      console.log(parentParams);
      this.route.parent.params.subscribe(
        (params: Params) => {
          console.log(params);
          if (parentParams.facilityId) {
            facilityId = parentParams.facilityId;
          }
          if (parentParams.containerId) {
            containerId = parentParams.containerId;
          }
          if (parentParams.growareaId) {
            growareaId = parentParams.growareaId;
          }

          if (params.facilityId) {
            facilityId = params.facilityId;
          }
          if (params.containerId) {
            containerId = params.containerId;
          }
          if (params.growareaId) {
            growareaId = params.growareaId;
          }
          if (parentParams.groupId) {
            groupId = parentParams.groupId;
          }
          if (facilityId) {
            this.getFacilityById(facilityId, containerId, growareaId, groupId);
          } else if (containerId) {
            this.getContainerById(containerId, growareaId, groupId);
          } else if (growareaId) {
            this.getGrowAreaById(growareaId, groupId);
          } else {
            this.getGroupByGroupId(groupId);
          }
        });
      if (parentParams.groupId) {
        this.getGroupByGroupId(parentParams.groupId);
      }
    });

    this.groupService.editedGroup.subscribe(
      (response) => {
        console.log(response);
        this.getGroupByGroupId(response);
      }
    );
  }
  getFacilityById(id, containerId, growareaId, groupId) {
    this.facilityService.getFacilityById(id).subscribe((response: Facility) => {
      this.selectedFacility = response;
      console.log(this.selectedFacility);
      this.facilityService.selectedFacility.emit(this.selectedFacility);
      if (containerId) {
        this.getContainerById(containerId, growareaId, groupId);
      } else if (growareaId) {
        this.getGrowAreaById(growareaId, groupId);
      } else {
        this.getGroupByGroupId(groupId);
      }
    });
  }
  getContainerById(id, growareaId, groupId) {
    this.containerService
      .getContainerById(id)
      .subscribe((response: Container) => {
        this.selectedContainer = response;
        if (growareaId) {
          this.getGrowAreaById(growareaId, groupId);
        } else {
          this.getGroupByGroupId(groupId);
        }
      });
  }
  getGrowAreaById(id, groupId) {
    this.growareaService
      .getGrowAreaById(id)
      .subscribe((response: GrowArea) => {
        this.selectedGrowArea = response;
        console.log(this.selectedGrowArea);
        if (groupId) {
          this.getGroupByGroupId(groupId);
        }
      });
  }
  getGroupByGroupId(groupId) {
    this.isViewDevices  = false;
    this.groupService
      .getGroupByGroupId(groupId)
      .subscribe((response: Group) => {
        this.selectedGroup = response;
        // const group = {
        //   'id': 1,
        //   'group_name': 'abc1',
        //   'generated_group_name': 'A-B-UV A-UV B-UV C-NC',
        //   'channel_configuration': {
        //     'CH1': 'A',
        //     'CH2': 'B',
        //     'CH3': 'UV A',
        //     'CH4': 'UV B',
        //     'CH5': 'UV C',
        //     'CH6': 'NC'
        //   },
        //   'device_details': [
        //   {
        //       device_name: 'Rose Led',
        //       deviceUId: '000D6FFFFE659F50',
        //       id: 2
        //   },
        //   {
        //     device_name: 'Rose Led 1',
        //     deviceUId: '000D6FFFFE659F51',
        //     id: 2
        // }
        //   ]
        // };
        // this.selectedGroup = group;
        console.log(this.selectedGroup);
        console.log(this.selectedGrowArea);
        this.groupService.selectedGroup.emit(this.selectedGroup);
        if (this.selectedFacility && this.selectedContainer && this.selectedGrowArea) {
          this.breadcrumbService.store([
            { label: 'Facilities', url: '/facilities', params: [] },
            {
              label: this.selectedFacility.facility_name,
              url: '/facilities/' + this.selectedFacility.id,
              params: []
            },
            { label: 'Containers', url: '/facilities/' + this.selectedFacility.id + '/containers', params: [] },
            {
              label: this.selectedContainer.container_name + '',
              url: '/facilities/' + this.selectedFacility.id + '/containers/' + this.selectedContainer.id,
              params: []
            },
            {
              label: 'Grow Areas',
              url: '/facilities/' + this.selectedFacility.id + '/containers/' + this.selectedContainer.id + '/grow-areas',
              params: []
            },
            {
              label: this.selectedGrowArea.grow_area_name + '',
              url: '/facilities/' + this.selectedFacility.id + '/containers/' + this.selectedContainer.id
                + '/grow-areas/' + this.selectedGrowArea.id,
              params: []
            },
            {
              label: 'Groups',
              url: '/facilities/' + this.selectedFacility.id + '/containers/' + this.selectedContainer.id +
                '/grow-areas/' + this.selectedGrowArea.id + '/groups',
              params: []
            },
            {
              label: this.selectedGroup.group_name + '',
              url: '/facilities/' + this.selectedFacility.id + '/containers/' + this.selectedContainer.id +
                '/grow-areas/' + this.selectedGrowArea.id + '/groups/' + this.selectedGroup.id,
              params: []
            }
          ]);
        } else if (this.selectedFacility && this.selectedGrowArea) {
          this.breadcrumbService.store([
            { label: 'Facilities', url: '/facilities', params: [] },
            {
              label: this.selectedFacility.facility_name,
              url: '/facilities/' + this.selectedFacility.id,
              params: []
            },
            {
              label: 'Grow Areas',
              url: '/facilities/' + this.selectedFacility.id + '/grow-areas',
              params: []
            },
            {
              label: this.selectedGrowArea.grow_area_name + '',
              url: '/facilities/' + this.selectedFacility.id + '/grow-areas/' + this.selectedGrowArea.id,
              params: []
            },
            {
              label: 'Groups',
              url: '/facilities/' + this.selectedFacility.id + '/grow-areas/' + this.selectedGrowArea.id + '/groups',
              params: []
            },
            {
              label: this.selectedGroup.group_name + '',
              url: '/facilities/' + this.selectedFacility.id +
                '/grow-areas/' + this.selectedGrowArea.id + '/groups/' + this.selectedGroup.id,
              params: []
            }
          ]);
        } else if (this.selectedContainer && this.selectedGrowArea) {
          this.breadcrumbService.store([
            { label: 'Containers', url: '/containers', params: [] },
            {
              label: this.selectedContainer.container_name + '',
              url: '/containers/' + this.selectedContainer.id,
              params: []
            },
            {
              label: 'Grow Areas',
              url: '/containers/' + this.selectedContainer.id + '/grow-areas',
              params: []
            },
            {
              label: this.selectedGrowArea.grow_area_name + '',
              url: '/containers/' + this.selectedContainer.id + '/grow-areas/' + this.selectedGrowArea.id,
              params: []
            },
            {
              label: 'Groups',
              url: '/containers/' + this.selectedContainer.id + '/grow-areas/' + this.selectedGrowArea.id + '/groups',
              params: []
            },
            {
              label: this.selectedGroup.group_name + '',
              url: '/containers/' + this.selectedContainer.id + '/grow-areas/' +
                this.selectedGrowArea.id + '/groups/' + this.selectedGroup.id,
              params: []
            }
          ]);
        } else if (this.selectedGrowArea) {
          this.breadcrumbService.store([
            {
              label: 'Grow Areas',
              url: '/grow-areas',
              params: []
            },
            {
              label: this.selectedGrowArea.grow_area_name + '',
              url: '/grow-areas/' + this.selectedGrowArea.id,
              params: []
            },
            {
              label: 'Groups',
              url: '/grow-areas/' + this.selectedGrowArea.id + '/groups',
              params: []
            },
            {
              label: this.selectedGroup.group_name + '',
              url: '/grow-areas/' + this.selectedGrowArea.id + '/groups/' + this.selectedGroup.id,
              params: []
            }
          ]);
        } else if (this.selectedGroup) {
          this.breadcrumbService.store([
            {
              label: 'Groups',
              url: '',
              params: []
            },
            {
              label: this.selectedGroup.group_name + '',
              url: '/groups/' + this.selectedGroup.id,
              params: []
            }
          ]);
        }
        this.addReloadEventToBreadcrumb();
      });
  }
  addReloadEventToBreadcrumb() {
    setTimeout(() => {
      const elems = document.querySelectorAll('.breadcrumb-item a');
      console.log(elems);
      console.log('length     ', elems.length);
      for (let i = 0; i < elems.length; i++) {
        elems[i].addEventListener('click', this.globalService.handleClick);
      }
    }, 100);
  }
  onClickOfViewProfiles(){
    this.router.navigate(['profiles'], { relativeTo: this.route });
  }
  onClickOfViewEvents(){
    this.router.navigate(['events'], { relativeTo: this.route });

  }
  onClickOfViewDevices(){
    this.isViewDevices = !this.isViewDevices;
    console.log(this.selectedGroup);
  }
}
