import { Component, OnInit, ViewChild, OnDestroy } from "@angular/core";
import { DataTableDirective } from "angular-datatables";
import { HttpErrorResponse, HttpResponse } from "@angular/common/http";
import { NgxSpinnerService } from "ngx-spinner";
import {
  FormGroup,
  FormControl,
  Validators,
  FormBuilder,
} from "@angular/forms";
import { ToastrService } from "ngx-toastr";
import { Subject } from "rxjs";
import { Location, PlatformLocation } from "@angular/common";
import { Container } from "../models/container.model";
import { ContainerService } from "src/app/services/container-service";
import { Country, State } from "../models/global.model";
import { Facility } from "../models/facility.model";
import { FacilityService } from "../services/facility-service";
import { ActivatedRoute, Params, Router } from "@angular/router";
import { BreadcrumbsService } from "ng6-breadcrumbs";
import { User } from "../models/user.model";
import {
  environment,
  ValidationPatterns,
} from "../../environments/environment";
import { GlobalService } from "../services/global-service";
@Component({
  selector: "app-containers",
  templateUrl: "./containers.component.html",
  styleUrls: ["./containers.component.css"],
})
export class ContainersComponent implements OnInit, OnDestroy {
  dtOptions: any = {};
  dtTrigger: Subject<any> = new Subject();
  @ViewChild(DataTableDirective)
  private datatableElement: DataTableDirective;
  selectedContainer: Container;
  editContainer: Container;
  deletContainer: Container;
  delet = false;
  containers: Container[] = [];
  conatinerTypes: { id: number; container_type_name: string }[] = [];
  facilities: Facility[] = [];
  containerForm: FormGroup;
  countryList: Country[] = [];
  stateList: State[] = [];
  localityList: string[] = [];
  selectedFacility: Facility;
  totalContainersCount = 0;
  activeContainersCount = 0;
  isEditContainer = false;
  addGrowAreaFlag;
  getContainersLoading = false;
  isContainerLoad = false;
  apiLoading = false;

  loggedInUser: User;
  constructor(
    private containerService: ContainerService,
    private spinner: NgxSpinnerService,
    private toastrService: ToastrService,
    private facilityService: FacilityService,
    private router: Router,
    private route: ActivatedRoute,
    private breadcrumService: BreadcrumbsService,
    private formBuilder: FormBuilder,
    location: PlatformLocation,
    private globalService: GlobalService
  ) {
    // location.onPopState(()=>{
    //   $('#containerModal').hide("fast");
    // });
    // location.onPopState(()=>{
    //   $('#containerModal').modal('hide');
    //   $('#myModal').modal('hide');
    // });
  }

  ngOnInit() {
    this.breadcrumService.store([
      { label: "Containers", url: "/containers", params: [] },
    ]);
    console.log("in compoent");
    // datatable options for facility table
    this.dtOptions = {
      pagingType: "full_numbers",
      pageLength: 10,
      destroy: true,
      order: [],
      info: false,
      lengthChange: false,
      select: true,
      language: {
        zeroRecords: "No Containers to display",
        paginate: {
          next: ">", // or '→'
          previous: "<", // or '←',
        },
      },
    };
    const elem = document.getElementById("headerMenuCollapse");
    if (elem) {
      elem.classList.remove("show");
    }
    this.getContainerTypes();

    this.loggedInUser = JSON.parse(localStorage.getItem("loggedInUser"));

    this.containerService.selectedContainer.subscribe(
      (container: Container) => {
        this.selectedContainer = container;
      }
    );
    let facilityId;
    this.route.params.subscribe((params: Params) => {
      console.log(params);
      if (params.facilityId) {
        facilityId = params.facilityId;
        this.getFacilityById(params.facilityId);
        this.getContainersByFacilityId(params.facilityId);
        this.getCountrys();
        // this.getContainers();
        this.getContainerTypes();
      } else {
        this.getContainers();
      }
    });

    this.containerForm = new FormGroup({
      container_name: new FormControl(null, [
        Validators.required,
        Validators.maxLength(25),
        Validators.pattern(ValidationPatterns.username),
      ]),
      container_type: new FormControl(this.conatinerTypes[0], [
        Validators.required,
      ]),
      facility: new FormControl("", [Validators.required]),
      description: new FormControl(null, [Validators.maxLength(200)]),
    });
    if (this.selectedFacility) {
      this.containerForm.patchValue({
        facility: this.selectedFacility,
      });
    }
  }

  compareFn(obj1: any, obj2: any): boolean {
    return obj1 && obj2 ? obj1.id === obj2.id : obj1 === obj2;
  }

  onNewContainer() {
    this.containerForm.reset();
  }

  onContainerRowSelected(container) {
    this.selectedContainer = container;
    this.router.navigate([this.selectedContainer.id], {
      relativeTo: this.route,
    });
  }

  getContainers() {
    this.containers = [];
    this.isContainerLoad = true;
    // this.dtTrigger.next();
    this.containerService.getContainers().subscribe(
      (response: Container[]) => {
        setTimeout(() => {
          this.containers = response;
          console.log("asfdghjkl", response);
          if (this.containers) {
            this.activeContainersCount = this.containers.length;
          } else {
            this.activeContainersCount = 0;
          }
          this.dtTrigger.next();
        }, 500);
        this.getCountrys();
        this.isContainerLoad = false;
      },
      (errorResponse: HttpErrorResponse) => {
        this.getCountrys();
        this.isContainerLoad = false;
      }
    );
  }

  getCountrys() {
    this.countryList = [];
    this.facilityService.getCountrys().subscribe(
      (response: Country[]) => {
        this.countryList = response;
        this.getFacilities();
      },
      (errorResponse: HttpErrorResponse) => {
        this.getFacilities();
      }
    );
  }

  getFacilities() {
    this.facilities = [];
    this.facilityService.getFacility().subscribe(
      (response: Facility[]) => {
        this.facilities = response;
        this.getContainerTypes();
      },
      (errorResponse: HttpErrorResponse) => {
        this.getContainerTypes();
      }
    );
  }

  getContainerTypes() {
    this.conatinerTypes = [];
    this.containerService
      .getContainerTypes()
      .subscribe((response: { id: number; container_type_name: string }[]) => {
        this.conatinerTypes = response;
      });
  }

  onCreateContainerSubmit() {
    this.apiLoading = true;

    this.containerService.createContainer(this.containerForm.value).subscribe(
      (response: Response) => {
        this.datatableElement.dtInstance.then((dtInstance: DataTables.Api) => {
          // Destroy the table first
          dtInstance.destroy();
        });
        this.toastrService.success(
          "Container created successfully",
          "Create Container"
        );
        console.log(this.selectedFacility);
        if (this.selectedFacility) {
          this.getContainersByFacilityId(this.selectedFacility.id);
        } else {
          this.getContainers();
        }
        this.apiLoading = false;
      },
      (error) => {
        this.containerForm.reset();
        this.apiLoading = false;
      }
    );
  }

  onEditContainer(containerObj: Container) {
    this.isEditContainer = true;
    this.containerForm.patchValue({
      container_name: containerObj.container_name,
      container_type: containerObj.container_type,
      facility: containerObj.facility,
      description: containerObj.description,
    });
    this.editContainer = containerObj;
  }

  onEditContainerSubmit() {
    this.apiLoading = true;

    this.containerForm.value.id = this.editContainer.id;
    console.log(this.containerForm.value);
    this.containerService
      .editContainer(this.containerForm.value, this.containerForm.value.id)
      .subscribe(
        (response: Response) => {
          this.isEditContainer = false;
          this.toastrService.success(
            "Container updated successfully",
            "Update Container"
          );
          this.datatableElement.dtInstance.then(
            (dtInstance: DataTables.Api) => {
              // Destroy the table first
              dtInstance.destroy();
            }
          );
          this.containerService.ediContainer.emit(this.containerForm.value.id);

          if (this.selectedFacility) {
            this.getContainersByFacilityId(this.selectedFacility.id);
          } else {
            this.getContainers();
          }
          // this.getContainerById(this.editContainer.id);
          this.apiLoading = false;
        },
        (error) => {
          this.containerForm.reset();
          this.apiLoading = false;
        }
      );
  }

  getContainerById(id) {
    this.containerService
      .getContainerById(id)
      .subscribe((response: Container) => {
        this.selectedContainer = response;
        console.log(this.selectedContainer);
        this.containerService.selectedContainer.emit(this.selectedContainer);
        if (this.selectedFacility) {
          this.breadcrumService.store([
            { label: "Facilities", url: "/facilities", params: [] },
            {
              label: this.selectedFacility.facility_name + "",
              url: "/facilities/" + this.selectedFacility.id,
              params: [],
            },
            {
              label: "Containers",
              url: "/facilities/" + this.selectedFacility.id + "/containers",
              params: [],
            },
            {
              label: this.selectedContainer.container_name + "",
              url:
                "/facilities/" +
                this.selectedFacility.id +
                "/conatiners/" +
                this.selectedContainer.id,
              params: [],
            },
          ]);
        } else {
          // console.log('container called');
          this.breadcrumService.store([
            { label: "Containers", url: "/containers", params: [] },
            {
              label: this.selectedContainer.container_name + "",
              url: "/conatiners/" + this.selectedContainer.id,
              params: [],
            },
          ]);
        }
        this.addReloadEventToBreadcrumb();
      });
  }

  addReloadEventToBreadcrumb() {
    setTimeout(() => {
      const elems = document.querySelectorAll(".breadcrumb-item a");
      console.log(elems);
      console.log("length     ", elems.length);
      for (let i = 0; i < elems.length; i++) {
        elems[i].addEventListener("click", this.globalService.handleClick);
      }
    }, 100);
  }

  onDeletChanges(container: Container) {
    this.delet = true;
    console.log("OnDeletChanges called");
    this.deletContainer = container;
  }

  onDeleteContainer() {
    this.apiLoading = true;

    this.containerService.deleteConatiner(this.deletContainer.id).subscribe(
      (response: Response) => {
        this.datatableElement.dtInstance.then((dtInstance: DataTables.Api) => {
          // Destroy the table first
          dtInstance.destroy();
        });
        this.toastrService.success(
          "Container deleted successfully",
          "Delete Container"
        );
        if (this.selectedFacility) {
          this.getContainersByFacilityId(this.selectedFacility.id);
          this.router.navigate([
            "/facilities/" + this.selectedFacility.id + "/containers",
          ]);
          this.getFacilityById(this.selectedFacility.id);
        } else {
          this.getContainers();
          this.router.navigate(["/containers"]);
        }
        this.apiLoading = false;
      },
      (error) => {
        this.apiLoading = false;
      }
    );
  }

  removeData() {
    if (this.isEditContainer === false) {
    } else {
      this.containerForm.reset();
    }
  }

  refresh() {
    this.router.routeReuseStrategy.shouldReuseRoute = function () {
      return false;
    };
  }

  getFacilityById(id) {
    this.facilityService.getFacilityById(id).subscribe((response: Facility) => {
      this.selectedFacility = response;
      this.breadcrumService.store([
        { label: "Facilities", url: "/facilities", params: [] },
        {
          label: this.selectedFacility.facility_name + "",
          url: "/facilities/" + this.selectedFacility.id,
          params: [],
        },
        { label: "Containers", url: "", params: [] },
      ]);
    });
    this.addReloadEventToBreadcrumb();
  }

  getContainersByFacilityId(facilityId) {
    this.containers = [];

    this.containerService
      .getContainersByFacilityId(facilityId)
      .subscribe((response: Container[]) => {
        this.containers = response;
        if (this.containers) {
          this.activeContainersCount = this.containers.length;
        } else {
          this.activeContainersCount = 0;
        }
        this.dtTrigger.next();
      });
  }

  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }
}
