import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GrowSectionsComponent } from './grow-sections.component';

describe('GrowSectionsComponent', () => {
  let component: GrowSectionsComponent;
  let fixture: ComponentFixture<GrowSectionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GrowSectionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GrowSectionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
