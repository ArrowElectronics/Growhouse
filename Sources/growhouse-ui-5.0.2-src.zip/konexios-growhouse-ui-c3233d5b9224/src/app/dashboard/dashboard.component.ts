import { GrowAreaService } from './../services/growarea-service';
import { ProfileMessage } from './../../environments/environment';
import { Component, OnInit, ViewChild } from '@angular/core';
import { LoginService } from '../services/login-service';
import { GlobalService } from '../services/global-service';
import { User } from '../models/user.model';
import { BreadcrumbsService } from 'ng6-breadcrumbs';
import { Router, Route, ActivatedRoute } from '@angular/router';
import { GrowArea, GrowAreaType } from '../models/growarea.model';
import { environment, ValidationPatterns, } from '../../environments/environment';
import { AlertsService } from '../services/alerts-service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  @ViewChild('mapWorld')
  gmapElement: any;
  mapProp: any;
  map: google.maps.Map;
  marker;
  dashboardCountObj;
  loggedInUser: User;
  profileAlerts = [];
  toArray = [];
  growareaCountObj;

  // plants URL
  everyThingIsOK = '';
  growAreas: any[] = [];
  alerts: any[] = [];
  profiles: any[] = [];
  propertyName: string[] = [];
  ALL_OK = ProfileMessage.ALL_OK;
  NEED_WATER = ProfileMessage.NEED_WATER;
  NEED_SUN = ProfileMessage.NEED_SUN;
  MORE_SUN = ProfileMessage.MORE_SUN;
  noNetworkGrowareas: any[] = [];
  breadcrumbList: Array<any> = [];
  imageUrl: string;
  alertsOfProfileLoad = false;
  constructor(
    private loginService: LoginService,
    private globalService: GlobalService,
    private growareaService: GrowAreaService,
    private breadcrumService: BreadcrumbsService,
    private router: Router,
    private route: ActivatedRoute,
    private alertsService: AlertsService,


  ) { }

  ngOnInit() {
    this.breadcrumService.store([
      { label: 'Dashboard', url: '/dashboard', params: [] }
    ]);
    const elem = document.getElementById('headerMenuCollapse');
    if (elem) {
      elem.classList.remove('show');
    }
    this.loggedInUser = JSON.parse(localStorage.getItem('loggedInUser'));
    if (this.loggedInUser.user_role.role_name.toLowerCase() === 'admin') {
      // let intervalId = setInterval(() => {
      //   console.log('in interval');
      //   console.log(typeof google);
      //   if (typeof google === 'object' && typeof google.maps === 'object') {
      //     clearInterval(intervalId);
      //     intervalId = null;
      //     this.mapProp = {
      //       center: new google.maps.LatLng(0, 0),
      //       zoom: 1.2,
      //       mapTypeId: google.maps.MapTypeId.ROADMAP
      //     };
      //     this.map = new google.maps.Map(
      //       this.gmapElement.nativeElement,
      //       this.mapProp
      //     );
      //   }
      // }, 50);
      this.getGrowAreaList();
      this.getProfiles();
      this.getNoNetworkGrowareas();
    }

    if (this.loggedInUser.user_role.role_name.toLowerCase() === 'normaluser') {
      this.getProfiles();
      this.getNoNetworkGrowareas();
    }
    this.getCounts();
  }

  getGrowAreaList() {
    this.growAreas = [];
    this.growareaService.getGrowAreaList().subscribe(
      (response: any) => {
        setTimeout(
          () => {
            this.growAreas = response;
            if (this.growAreas) {

            } else {
              this.growAreas = [];
            }
          }, 500
        );
      }
    );
  }

  getCountsById(id) {
    this.growareaService.getCountByGrowAreaId(id).subscribe(
      (response) => {
        this.growareaCountObj = response;
        console.log(this.growareaCountObj);
      }
    );
    return true;

  }
  getProfileName(alertMessage) {
    console.log(alertMessage);
    const asc = alertMessage.split('@#$');
    console.log(asc);
    return alertMessage.split('@#$');
  }
  getSuperAdminCounts() {
    this.globalService.getSuperAdminDashboardCount().subscribe(response => {
      this.dashboardCountObj = {};
      this.dashboardCountObj = response;
    });
  }

  getAdminCounts() {
    this.globalService.getCounts().subscribe(response => {
      this.dashboardCountObj = {};
      this.dashboardCountObj = response;
    });
  }

  getNormalAdminCounts() {
    this.globalService.getNormalUserDashboardCount().subscribe(response => {
      this.dashboardCountObj = {};

      this.dashboardCountObj = response;

      console.log('normal user' + this.dashboardCountObj);
    });
  }

  getCounts() {
    if (this.loggedInUser.user_role.role_name.toLowerCase() === 'superadmin') {
      this.getSuperAdminCounts();
    } else if (
      this.loggedInUser.user_role.role_name.toLowerCase() === 'admin'
    ) {
      this.getAdminCounts();
    } else if (
      this.loggedInUser.user_role.role_name.toLowerCase() === 'normaluser'
    ) {
      this.getNormalAdminCounts();
    }
  }

  getNoNetworkGrowareas() {
    this.growareaService.getNoNetworkGrowarea().subscribe((response: any[]) => {
      this.noNetworkGrowareas = response;
    });
  }


  // getImageUrls(profilesResponse){
  //   let profiles;
  //   this.profileAlerts=[];
  //   console.log('adfda',profilesResponse[0].alertMessage.slice(1,-1));
  //   for(let i=0;i<profilesResponse.length;i++){
  //     this.profileAlerts.push(profilesResponse[i].alertMessage.slice(1,-1));
  //     console.log(this.profileAlerts[i]);
  //   }
  // }

  getProfiles() {
    this.globalService.getProfileAlerts().subscribe((response: any[]) => {
      this.profiles = response;
      console.log('profilesss', this.profiles.length);
      for (let i = 0; i < this.profiles.length; i++) {
        let properties;
        const properties_arr = [];
        properties = JSON.parse(this.profiles[i].properties);
        // tslint:disable-next-line:forin
        for (const key in properties) {
          properties_arr.push({ name: key, value: properties[key] });
        }
        this.profiles[i].properties = properties_arr.sort((a, b) => a.name > b.name ? 1 : -1);

      }
      console.log('profile:' + JSON.stringify(this.profiles));
      // this.getImageUrls(this.profiles);
    });
  }

  getPropertyKeys(profile) {
    console.log('in fun');
    return (this.propertyName = Object.keys(profile.properties));
  }

  onLoadMoreProfile() {
    this.router.navigate(['profiles'], { relativeTo: this.route });
  }
  onClickViewAllAlerts() {
    this.alerts = [];
    this.alertsOfProfileLoad = true;
    let prop_arr = [];
    let properties;
    this.alertsService.getAllProfileAlerts().subscribe(
      (response: any) => {
        console.log(response);
        if (response) {
          this.alerts = response;
          for (let i = 0; i < this.alerts.length; i++) {
            properties = this.alerts[i].properties ? JSON.parse(this.alerts[i].properties) : {};
            console.log(properties);
            // tslint:disable-next-line:forin
            prop_arr = [];
            for (const key in properties) {
              prop_arr.push({ name: key, value: properties[key] });
            }
            this.alerts[i].properties = prop_arr;
          }
          // this.alerts.sort((val1, val2) => {
          //   const date1 = parseInt(val2.created_date, 10);
          //   const date2 = parseInt(val1.created_date, 10);
          //   return date1 - date2;
          // });
        }
        console.log(this.alerts);
        this.alertsOfProfileLoad = false;
      },
      error => {
        this.alertsOfProfileLoad = false;
      }
    );
  }
}
