import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { Device, channelConfig, profileConfig, DeviceType } from '../models/device.model';
import { GrowArea } from '../models/growarea.model';
import { Chart } from 'chart.js';
import { HostListener } from '@angular/core';
import { Facility } from '../models/facility.model';
import { Container } from '../models/container.model';
import { DeviceService } from '../services/device-service';
import { GrowAreaService } from '../services/growarea-service';
import { ContainerService } from '../services/container-service';
import { FacilityService } from '../services/facility-service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { BreadcrumbsService } from 'ng6-breadcrumbs';
import { WebSocketService } from '../services/websocket-service';
import { environment } from '../../environments/environment.prod';
import { CONTEXT } from '@angular/core/src/render3/interfaces/view';
import * as moment from 'moment';
import { DatePipe } from '@angular/common';
import * as bootstrap from 'bootstrap';
import { Moment } from 'moment';
import { GlobalService } from '../services/global-service';
declare var $: any;
import * as Stomp from 'stompjs';
import * as SockJS from 'sockjs-client';
import { UUID } from 'angular2-uuid';

@Component({
  selector: 'app-device-type',
  templateUrl: './device-type.component.html',
  styleUrls: ['./device-type.component.css']
})
export class DeviceTypeComponent implements OnInit {
  @ViewChild('myForm') formValues; // Added this
  selectedGrowArea: GrowArea;
  selectedContainer: Container;
  selectedFacility: Facility;
  selectedDevice: Device;
  ctx;
  message;
  ws: any = {};
  value_channel_1 = 0;
  valueProfile: number;
  value_channel_2 = 0;
  value_channel_3 = 0;
  value_channel_4 = 0;
  value_channel_5 = 0;
  value_channel_6 = 0;
  title = 'googleChartDemo';
  chart;
  startDate: any = null;
  endDate: any = null;
  connectionFlag = false;
  @ViewChild('profileForm')
  profileForm: any;
  alwaysShowCalendars: boolean;
  gatewayhid = 'a3a51548d24e1bb3c658c080c015c0970945b8f7';
  devicehid = '56ab1118f1c2c6e0ddac06b594026b1d96ff58fd';
  dates = [];
  valueList = [];
  selected: { start: Moment, end: Moment };
  tempHistoryData = [];
  selectedDate = true;
  historyList = [];
  selectedProperty = '';
  data = [];
  tempData = [];
  selectedHistoryProperty: string;
  propertyNameList = [];
  ioConnection: any;
  selectedProfile;
  profileValues: any = [];
  liveChartEnable: boolean;
  // liveChartHistoryEnable:boolean;
  isTimePickerEnabled = true;
  topic: string;
  zero = 0;
  preset = 100;
  ledNodeValue: any = [];
  history: any = [];
  ledProfileValue: any = [];
  value: any;
  device_id: { id: number };
  scmNode = false;
  channels: any = ['1', '2', '3'];
  channelConfigData: channelConfig;
  profileData: profileConfig;
  profile_name: string;
  description: string;
  value_profile_1 = 0;
  value_profile_2 = 0;
  value_profile_3 = 0;
  lightNode: boolean;
  value_profile_4 = 0;
  value_profile_5 = 0;
  value_profile_6 = 0;
  telemetry: any[] = [];
  device_time: string;
  maxDate = new Date();
  dateRangeMinDate = moment().subtract(4, 'months');
  dateRangeMaxDate = moment();
  historyData: any[] = [];
  historyTimeStamps: any[] = [];
  isHistoryChartVisible = false;
  isHistoryDataAvailable = true;
  isLiveChartVisible = true;
  loader = false;
  deleteProfile = null;
  url = environment.websocketServerURL;
  sessionId;

  val1 = 0 ;
 val2 = 0;
 val3 = 0;
 val4 = 0;
 val5 = 0 ;
 val6 = 0;
  // routingFlag:boolean = false;
  enableButton = false;
  telemetrySectionWidth = 100;
  selectedDeviceType: DeviceType;
  isProfileApply = false;
  options: any = {
    type: 'line',
    data: {
      labels: [],
      datasets: [
        {
          data: [],
          borderColor: '#3cba9f',
          fill: false
        }
      ]
    },
    options: {
      responsive: true,
      legend: {
        display: false
      },
      scales: {
        xAxes: [
          {
            display: true
          }
        ],
        yAxes: [
          {
            display: true
          }
        ]
      }
    }
  };

  ranges: any = {
    'Today': [moment().startOf('day').add(1, 'second'), moment()],
    'Yesterday': [moment().subtract(1, 'days').startOf('day').add(1, 'second'), moment().subtract(1, 'days').endOf('day')],
    'Last 7 Days': [moment().subtract(7, 'days').startOf('day').add(1, 'second'), moment()],
    'Last 30 Days': [moment().subtract(30, 'days').startOf('day'), moment()],
    'This Month': [moment().startOf('month'), moment().endOf('month')],
  };
  constructor(
    private deviceService: DeviceService,
    private growareaService: GrowAreaService,
    private containerService: ContainerService,
    private facilityService: FacilityService,
    private spinner: NgxSpinnerService,
    private toastrService: ToastrService,
    private router: Router,
    private route: ActivatedRoute,
    private breadcrumService: BreadcrumbsService,
    private datePipe: DatePipe,
    private globalService: GlobalService
  ) { }
  ngOnInit() {
    this.selectedProfile = null;
    this.isProfileApply = false;
    let containerId, facilityId, growareaId, deviceId;
    this.route.params.subscribe((parentParams: Params) => {
      console.log(parentParams);
      this.route.parent.params.subscribe(
        async (params: Params) => {
          console.log(params);
          if (parentParams.facilityId) {
            facilityId = parentParams.facilityId;
          }
          if (parentParams.containerId) {
            containerId = parentParams.containerId;
          }
          if (parentParams.growareaId) {
            growareaId = parentParams.growareaId;
          }
          if (parentParams.deviceId) {
            deviceId = parentParams.deviceId;
            this.device_id = deviceId;
          }
          if (params.facilityId) {
            facilityId = params.facilityId;
          }
          if (params.containerId) {
            containerId = params.containerId;
          }
          if (params.growareaId) {
            growareaId = params.growareaId;
          }
          if (params.deviceId) {
            deviceId = params.deviceId;
          }
          await this.getDeviceTypes(params.deviceType);

          this.getLedNodeData(deviceId);
          this.setProfileName(deviceId);

          if (facilityId) {
            this.getFacilityById(facilityId, containerId, growareaId, deviceId);
          } else if (containerId) {
            this.getContainerById(containerId, growareaId, deviceId);
          } else if (growareaId) {
            this.getGrowAreaById(growareaId, deviceId);
          } else {
            this.getDeviceById(deviceId);
          }
        });
    });
  }
  getDeviceTypes(deviceTypeName) {
    this.deviceService.getDeviceTypes().subscribe(
      (response: DeviceType[]) => {
        const devicetypes = response;
        this.selectedDeviceType = devicetypes.filter(devicetypeObj => devicetypeObj.device_type_name === deviceTypeName)[0];
      }
    );
  }
  rangeSelected(data) {
    if (data.start == null || data.end == null) {
      this.selectedDate = true;
    } else {
      this.selectedDate = false;
      this.startDate = JSON.stringify(data.start).slice(1, -1);
      this.endDate = JSON.stringify(data.end).slice(1, -1);
    }
  }

  onClickOfHistoryFilter() {

    this.loader = true;
    this.isHistoryChartVisible = true;

    this.deviceService.getPropertiesHistoryByDate(this.selectedDevice.deviceHId, this.startDate,
      this.endDate, this.selectedHistoryProperty).subscribe((res: any[]) => {

        console.log('res' + JSON.stringify(res));
        this.historyData = [];
        this.historyTimeStamps = [];
        this.isHistoryDataAvailable = true;

        if (res) {
          if (res.length !== 0) {
            this.isHistoryDataAvailable = true;
            for (let i = 0; i < res.length; i++) {
              const date = this.datePipe.transform(new Date(res[i].timestamp), 'MM/dd/yyyy h:mm:ss a');

              if (res[i].type.toLowerCase() === 'float') {
                this.historyData.push(parseFloat(res[i].value));
                // this.historyTimeStamps.push(new Date(res[i].timestamp).toLocaleString());
                this.historyTimeStamps.push((date).toLocaleString());

              } else if (res[i].type.toLowerCase() === 'int') {
                this.historyData.push(parseInt(res[i].value));
                // this.historyTimeStamps.push(new Date(res[i].timestamp).toLocaleString());
                this.historyTimeStamps.push((date).toLocaleString());

              }
            }

            if (this.chart) {
              this.chart.destroy();
            }

            this.ctx = document.getElementById('historycanvas');
            this.chart = new Chart(this.ctx, this.options);
            console.log('data:' + this.chart);
            this.chart.data.labels = this.historyTimeStamps;
            this.chart.data.datasets[0].data = this.historyData;
            this.chart.update();
            this.loader = false;
          } else {
            this.loader = false;
            this.isHistoryChartVisible = false;
            this.isHistoryDataAvailable = false;
          }
        } else {
          this.loader = false;
          this.isHistoryChartVisible = false;
          this.isHistoryDataAvailable = false;
        }
      }, (error) => {
        console.log('error', error);
        this.loader = false;
        this.isHistoryChartVisible = false;
        this.isHistoryDataAvailable = false;
      });
  }
  setProfileName(id) {
    this.deviceService.getProfileData(id).subscribe((res) => {
      // console.log('Profile Data:' + JSON.stringify(res));
      this.profileValues = [];
      this.profileValues = res;
      console.log('profile Data:' + JSON.stringify(this.profileValues));
    });
    // this.saveProfile();
  }

  setLedNodeData() {
    console.log(this.selectedGrowArea);
    if(!this.selectedDevice.status || this.selectedGrowArea.latest_heartbeat_timestamp === 'false'){
      this.toastrService.error(
        'Selected Device or Grow Area is currently out of network. Please try later.',
        'Device set'
      );
      this.isProfileApply =false;
      this.selectedProfile = null;
      this.getLastTelemetry(this.selectedDevice.deviceHId);

      return;
    }
    // console.log('device Id:'+JSON.parse(JSON.stringify('''+JSON.stringify({'id':this.selectedDevice.id})+''')));
    this.channelConfigData = new channelConfig(
      { id: this.selectedDevice.id },
      this.selectedDevice.device_type.device_type_name,
      this.value_channel_1,
      this.value_channel_2,
      this.value_channel_3,
      this.value_channel_4,
      this.value_channel_5,
      this.value_channel_6
    );
    console.log('channel config:' + JSON.stringify(this.channelConfigData));
    this.deviceService
    .setRGBLightNodeValue(JSON.parse(JSON.stringify(this.channelConfigData)))
    .subscribe((response: Response) => {
      this.toastrService.success(
        'Set Channel Configuration values successfully.',
        'Devices set'
      );
      // this.getLastTelemetry(this.selectedDevice.deviceHId);
      this.isProfileApply =false;
      this.selectedProfile = null;
    }, error =>{
      this.getLastTelemetry(this.selectedDevice.deviceHId);
      this.isProfileApply =false;
      this.selectedProfile = null;
    });
  }

  getLedNodeData(deviceId) {
    console.log('Device Id' + deviceId);
    this.deviceService.getRGBLightNode(deviceId).subscribe((data) => {
      this.ledNodeValue = [];
      // if(this.ledNodeValue.length == 0 ){
      //   this.ledNodeValue.push({'led1':'R','led2':'G','led3':'B','led4':'R','led5':'G','led6':'NC'});
      // }else{
      this.ledNodeValue.push(data);
      this.preset = 100;
      this.isProfileApply = false;
      if (this.formValues) {
        this.formValues.resetForm();
      }
      this.selectedProfile = null;
      // }
    });
  }

  saveProfile() {
    this.profileData = new profileConfig({ 'id': this.selectedDevice.id },
      this.selectedDevice.device_type.device_type_name, this.profile_name,
      this.description, JSON.stringify({
        'ch1': this.value_profile_1,
        'ch2': this.value_profile_2, 'ch3': this.value_profile_3,
        'ch4': this.value_profile_4, 'ch5': this.value_profile_5,
        'ch6': this.value_profile_6
      }));
    console.log('Profile config:' + JSON.stringify(this.profileData));
    console.log(this.profile_name);

    this.deviceService.setLedNodeProfile(this.profileData).subscribe((response: Response) => {
      this.toastrService.success('Profile Created Successfully', 'Create Profile');
      $('#profileModal').modal('hide');
      this.setProfileName(this.selectedDevice.id);
      this.profile_name = '';
      this.description = '';
      this.value_profile_1 = 0;
      this.value_profile_2 = 0;
      this.value_profile_3 = 0;
      this.value_profile_4 = 0;
      this.value_profile_5 = 0;
      this.value_profile_6 = 0;
      this.profileForm.reset();
    }, (error) => {
      this.profile_name = '';
      this.description = '';
      this.value_profile_1 = 0;
      this.value_profile_2 = 0;
      this.value_profile_3 = 0;
      this.value_profile_4 = 0;
      this.value_profile_5 = 0;
      this.value_profile_6 = 0;
      this.profileForm.reset();
      $('#profileModal').modal('hide');
      this.toastrService.error('something went wrong');
    });

  }
  closeProfileCreateModal() {
    this.profileForm.reset();
    this.profile_name = '';
    this.description = '';
    this.value_profile_1 = 0;
    this.value_profile_2 = 0;
    this.value_profile_3 = 0;
    this.value_profile_4 = 0;
    this.value_profile_5 = 0;
    this.value_profile_6 = 0;
    $('#profileModal').modal('hide');

  }

  clear() {
    this.selectedProfile = null;
    this.value_channel_1 = 0;
    this.value_channel_2 = 0;
    this.value_channel_3 = 0;
    this.value_channel_4 = 0;
    this.value_channel_5 = 0;
    this.value_channel_6 = 0;
    this.isProfileApply = false;
    // this.getLastTelemetry(this.selectedDevice.deviceHId);
  }
 
  getProfile() {
    console.log(this.profileValues);
    console.log(this.selectedProfile);

    if(this.profileValues && this.selectedProfile !== null){
      this.isProfileApply = true;
    this.preset = 100;
    this.value_channel_1 = JSON.parse(
      this.profileValues[this.selectedProfile].channel_configuration
    ).ch1;
    this.value_channel_2 = JSON.parse(
      this.profileValues[this.selectedProfile].channel_configuration
    ).ch2;
    this.value_channel_3 = JSON.parse(
      this.profileValues[this.selectedProfile].channel_configuration
    ).ch3;
    this.value_channel_4 = JSON.parse(
      this.profileValues[this.selectedProfile].channel_configuration
    ).ch4;
    this.value_channel_5 = JSON.parse(
      this.profileValues[this.selectedProfile].channel_configuration
    ).ch5;
    this.value_channel_6 = JSON.parse(
      this.profileValues[this.selectedProfile].channel_configuration
    ).ch6;
    this.val1 = JSON.parse(JSON.stringify(this.value_channel_1));
    this.val2 = JSON.parse(JSON.stringify(this.value_channel_2));
    this.val3 = JSON.parse(JSON.stringify(this.value_channel_3));
    this.val4 = JSON.parse(JSON.stringify(this.value_channel_4));
    this.val5 = JSON.parse(JSON.stringify(this.value_channel_5));
    this.val6 = JSON.parse(JSON.stringify(this.value_channel_6));
    }
  }
  onDeleteProfile(){
    this.deviceService.deleteIndividualProfile(this.deleteProfile.id).subscribe(
      response => {
        console.log(response);
        this.toastrService.success(
          'Profile Deleted Successfully',
          'Delete Profile'
        );
        this.preset = 100;
        this.isProfileApply = false;
        if (this.formValues) {
          this.formValues.resetForm();
        }
        this.selectedProfile = null;
        this.setProfileName(this.selectedDevice.id);
        this.deleteProfile = null;

      }, error => {
        this.toastrService.error(
          error,
          'Delete Profile'
        );
        this.preset = 100;
        this.isProfileApply = false;
        if (this.formValues) {
          this.formValues.resetForm();
        }
        this.selectedProfile = null;
        this.deleteProfile = null;
      }
      );
  }
  onDeletChanges() {
    console.log('OnDeletChanges called');
    if(this.profileValues && this.selectedProfile !== null){
    this.deleteProfile = this.profileValues[this.selectedProfile];
    }
  }
  getFacilityById(id, containerId, growareaId, deviceId) {
    this.facilityService.getFacilityById(id).subscribe((response: Facility) => {
      this.selectedFacility = response;
      console.log(this.selectedFacility);
      this.facilityService.selectedFacility.emit(this.selectedFacility);
      if (containerId) {
        this.getContainerById(containerId, growareaId, deviceId);
      } else if (growareaId) {
        this.getGrowAreaById(growareaId, deviceId);
      } else {
        this.getDeviceById(deviceId);
      }
    });
  }

  getContainerById(id, growareaId, deviceId) {
    this.containerService
      .getContainerById(id)
      .subscribe((response: Container) => {
        this.selectedContainer = response;
        if (growareaId) {
          this.getGrowAreaById(growareaId, deviceId);
        } else {
          this.getDeviceById(deviceId);
        }
      });
  }

  getGrowAreaById(id, deviceId) {
    this.growareaService
      .getGrowAreaById(id)
      .subscribe((response: GrowArea) => {
        this.selectedGrowArea = response;
        console.log(this.selectedGrowArea);
        if (deviceId) {
          this.getDeviceById(deviceId);
        }
      });
  }

  // refresh() {
  //   this.router.routeReuseStrategy.shouldReuseRoute = function () {
  //     return false;
  //   };
  // }

  getDeviceById(id) {
    this.deviceService
      .getDeviceById(id)
      .subscribe((response: Device) => {
        this.selectedDevice = response;
        this.getLastTelemetry(this.selectedDevice.deviceHId);
        console.log(this.selectedGrowArea);
        this.deviceService.selectedDevice.emit(this.selectedDevice);
        if (this.selectedFacility && this.selectedContainer && this.selectedGrowArea && this.selectedDeviceType) {
          this.breadcrumService.store([
            { label: 'Facilities', url: '/facilities', params: [] },
            {
              label: this.selectedFacility.facility_name,
              url: '/facilities/' + this.selectedFacility.id,
              params: []
            },
            { label: 'Containers', url: '/facilities/' + this.selectedFacility.id + '/containers', params: [] },
            {
              label: this.selectedContainer.container_name + '',
              url: '/facilities/' + this.selectedFacility.id + '/containers/' + this.selectedContainer.id,
              params: []
            },
            {
              label: 'Grow Areas',
              url: '/facilities/' + this.selectedFacility.id + '/containers/' + this.selectedContainer.id + '/grow-areas',
              params: []
            },
            {
              label: this.selectedGrowArea.grow_area_name + '',
              url: '/facilities/' + this.selectedFacility.id + '/containers/' + this.selectedContainer.id
                + '/grow-areas/' + this.selectedGrowArea.id,
              params: []
            },
            {
              label: this.selectedDeviceType.virtual_device_type_name + 's',
              url: '/facilities/' + this.selectedFacility.id + '/containers/' + this.selectedContainer.id +
                '/grow-areas/' + this.selectedGrowArea.id + '/' + this.selectedDeviceType.device_type_name,
              params: []
            },
            {
              label: this.selectedDevice.device_name + '',
              url: '/facilities/' + this.selectedFacility.id + '/containers/' + this.selectedContainer.id +
                '/grow-areas/' + this.selectedGrowArea.id + '/' + this.selectedDeviceType.device_type_name + this.selectedDevice.id,
              params: []
            }
          ]);
        }  else if (this.selectedFacility && this.selectedGrowArea && this.selectedDeviceType) {
          this.breadcrumService.store([
            { label: 'Facilities', url: '/facilities', params: [] },
            {
              label: this.selectedFacility.facility_name,
              url: '/facilities/' + this.selectedFacility.id,
              params: []
            },
            {
              label: 'Grow Areas',
              url: '/facilities/' + this.selectedFacility.id + '/grow-areas',
              params: []
            },
            {
              label: this.selectedGrowArea.grow_area_name + '',
              url: '/facilities/' + this.selectedFacility.id + '/grow-areas/' + this.selectedGrowArea.id,
              params: []
            },
            {
              label: this.selectedDeviceType.virtual_device_type_name + 's',
              url: '/facilities/' + this.selectedFacility.id + '/grow-areas/' + this.selectedGrowArea.id + '/' +
                this.selectedDeviceType.device_type_name,
              params: []
            },
            {
              label: this.selectedDevice.device_name + '',
              url: '/facilities/' + this.selectedFacility.id +
                '/grow-areas/' + this.selectedGrowArea.id + '/' + this.selectedDeviceType.device_type_name + this.selectedDevice.id,
              params: []
            }
          ]);
        } else if (this.selectedContainer && this.selectedGrowArea && this.selectedDeviceType) {
          this.breadcrumService.store([
            { label: 'Containers', url: '/containers', params: [] },
            {
              label: this.selectedContainer.container_name + '',
              url: '/containers/' + this.selectedContainer.id,
              params: []
            },
            {
              label: 'Grow Areas',
              url: '/containers/' + this.selectedContainer.id + '/grow-areas',
              params: []
            },
            {
              label: this.selectedGrowArea.grow_area_name + '',
              url: '/containers/' + this.selectedContainer.id + '/grow-areas/' + this.selectedGrowArea.id,
              params: []
            },
            {
              label: this.selectedDeviceType.virtual_device_type_name + 's',
              url: '/containers/' + this.selectedContainer.id + '/grow-areas/' + this.selectedGrowArea.id + '/' +
                this.selectedDeviceType.device_type_name,
              params: []
            },
            {
              label: this.selectedDevice.device_name + '',
              url: '/containers/' + this.selectedContainer.id + '/grow-areas/' +
                this.selectedGrowArea.id + '/' + this.selectedDeviceType.device_type_name + this.selectedDevice.id,
              params: []
            }
          ]);
        }  else if (this.selectedGrowArea && this.selectedDeviceType) {
          this.breadcrumService.store([
            {
              label: 'Grow Areas',
              url: '/grow-areas',
              params: []
            },
            {
              label: this.selectedGrowArea.grow_area_name + '',
              url: '/grow-areas/' + this.selectedGrowArea.id,
              params: []
            },
            {
              label: this.selectedDeviceType.virtual_device_type_name + 's',
              url: '/grow-areas/' + this.selectedGrowArea.id + '/' + this.selectedDeviceType.device_type_name,
              params: []
            },
            {
              label: this.selectedDevice.device_name + '',
              url: '/grow-areas/' + this.selectedGrowArea.id + '/' + this.selectedDeviceType.device_type_name + this.selectedDevice.id,
              params: []
            }
          ]);
        } else if(this.selectedDeviceType){
          this.breadcrumService.store([
            {
              label: this.selectedDeviceType.device_type_name + 's',
              url: '',
              params: []
            },
            {
              label: this.selectedDevice.device_name + '',
              url: this.selectedDeviceType.device_type_name + this.selectedDevice.id,
              params: []
            }
          ]);
        }
        this.addReloadEventToBreadcrumb();
      });
  }

  addReloadEventToBreadcrumb() {
    setTimeout(() => {
      const elems = document.querySelectorAll('.breadcrumb-item a');
      console.log(elems);
      console.log('length     ', elems.length);
      for (let i = 0; i < elems.length; i++) {
        elems[i].addEventListener('click', this.globalService.handleClick);
      }
    }, 500);
  }

  getLastTelemetry(deviceHid) {
    this.telemetrySectionWidth = 100;
    this.deviceService.getLastTelemetry(deviceHid).subscribe(
      (response: any[]) => {
        this.telemetry = response;

        for (let i = 0; i < this.telemetry.length; i++) {
          if (this.telemetry[i].name === 'led1') {
            this.value_channel_1 = parseInt(this.telemetry[i].value, 10);
          }

          if (this.telemetry[i].name === 'led2') {
            this.value_channel_2 = parseInt(this.telemetry[i].value, 10);
          }

          if (this.telemetry[i].name === 'led3') {
            this.value_channel_3 = parseInt(this.telemetry[i].value, 10);
          }

          if (this.telemetry[i].name === 'led4') {
            this.value_channel_4 = parseInt(this.telemetry[i].value, 10);
          }

          if (this.telemetry[i].name === 'led5') {
            this.value_channel_5 = parseInt(this.telemetry[i].value, 10);
          }

          if (this.telemetry[i].name === 'led6') {
            this.value_channel_6 = parseInt(this.telemetry[i].value, 10);
          }

          if (this.telemetry[i].type === 'Float') {
            this.telemetry[i].value = parseFloat(this.telemetry[i].value).toFixed(2);
          }
        }
      }, error => {
        this.value_channel_1 = 0;
        this.value_channel_2 = 0;
        this.value_channel_3 = 0;
        this.value_channel_4 = 0;
        this.value_channel_5 = 0;
        this.value_channel_6 = 0;

      }
      );
  }

  closeLiveHistoryModal() {
    if(this.chart){
    this.chart.data.labels = [];
    this.chart.data.datasets[0].data = [];
    this.chart.destroy();
    }
    this.loader = false;
    this.historyData = [];
    this.isHistoryChartVisible = false;
    this.historyTimeStamps = [];
  }

  onClickOfLiveChart() {
    console.log('Chart Clear');
    // this.chart.clear();
    this.ctx = document.getElementById('canvas');
    this.chart = new Chart(this.ctx, this.options);

    this.isHistoryChartVisible = false;
    // this.loader = false;
    console.log('historyChart' + this.isHistoryChartVisible);

    this.propertyNameList = [];
    this.historyData = [];
    this.historyTimeStamps = [];
    this.selectedProfile = null;

    this.deviceService.getPropertiesByDeviceId(this.selectedDevice.id).subscribe(
      (response: any[]) => {
        this.propertyNameList = response;
      }
    );
    this.topic = this.selectedDevice.deviceHId;
    // this.topic = 'a3a51548d24e1bb3c658c080c015c0970945b8f7-56ab1118f1c2c6e0ddac06b594026b1d96ff58fd';
    this.connect();
    if (this.chart) {
      this.chart.destroy();
      // this.isLiveChartVisible=true;
    }
    this.ctx = document.getElementById('canvas');
    this.chart = new Chart(this.ctx, this.options);
    // this.liveChartEnable = true;
  }

  onChartModalClose() {
    this.send(JSON.stringify(
      { topic: this.topic , status: 'unsubscribe', sessionId : this.sessionId }
    ));
    console.log('message sent');
    this.disconnect(this.ws);
    this.chart.destroy();
    this.tempData = [];
    this.dates = [];
    this.selectedProperty = undefined;
    this.chart.data.labels = [];
    this.chart.data.datasets[0].data = [];
    this.sessionId = undefined;
  }
  onChange(value){
    if(this.isProfileApply){
      this.getLastTelemetry(this.selectedDevice.deviceHId);
      }
      this.isProfileApply = false;
  }
  connect(){
    this.sessionId = undefined;
    console.log(this.url);
    const socket = new SockJS(this.url);
    this.ws = Stomp.over(socket);
    const _this = this;
    this.ws.connect({}, function (frame) {
      console.log('Connected: ' + frame);
      _this.sessionId = UUID.UUID();
      _this.ws.subscribe('/topic/' + _this.topic + '/' + _this.sessionId, function (message) {
      _this.onMessage(message);
      });
      _this.send(JSON.stringify(
        { topic: _this.topic, status: 'subscribe', sessionId : _this.sessionId }
      ));
    });
  }

  disconnect(wsoObj) {
    if (wsoObj != null) {
      wsoObj.disconnect();
    }
    this.sessionId = undefined;
    console.log('Disconnected!');
  }

  send(message) {
      this.ws.send('/growhouse/listen', {}, message);
  }
  onMessage(message) {
    let received_msg = message.body;
    console.log('Message is received...', JSON.parse(received_msg));
    received_msg = JSON.parse(received_msg);
    this.message = received_msg;
    this.parseMessage(received_msg);
  }
  onHistoryChartClose() {
    this.historyData = [];
    this.historyTimeStamps = [];
    this.selectedProperty = undefined;
    this.chart.data.labels = [];
    this.chart.data.datasets[0].data = [];
    this.chart.destroy();
    this.isHistoryChartVisible = false;
    // this.loader = false;
    console.log(this.chart);
    console.log('Destroy Chart');
  }


  onClickOfLiveChartHistory(historyData) {
    // this.isLiveChartVisible=false;
    // this.isHistoryChartVisible = true;
    this.selected = null;
    // this.chart.destroy();
    this.historyData = [];
    this.selectedProperty = undefined;
    this.selectedHistoryProperty = undefined;
    // this.chart.destroy();

    this.propertyNameList = [];
    this.deviceService.getPropertiesByDeviceId(this.selectedDevice.id).subscribe(
      (response: any[]) => {
        this.propertyNameList = response;
      });
  }

  parseMessage(messages) {
    messages.forEach(message => {
      console.log(this.selectedProperty);
      if (message['name'] === this.selectedProperty) {
        if (message['type'] === 'Float') {
          if (Object.keys(message).indexOf('timestamp') !== -1) {
            const currentDate = this.datePipe.transform(new Date(parseInt(message['timestamp'], 10)), 'MM/dd/yyyy h:mm:ss a');
            this.chart.data.labels.push(currentDate.toLocaleString());
          }
          this.chart.data.datasets.forEach(dataset => {
            dataset.data.push(parseFloat(message['floatValue']));
          });
          this.chart.update();
        } else if (message['type'] === 'Integer') {
          if (Object.keys(message).indexOf('timestamp') !== -1) {
            const currentDate = this.datePipe.transform(new Date(parseInt(message['timestamp'], 10)), 'MM/dd/yyyy h:mm:ss a');
            this.chart.data.labels.push(currentDate.toLocaleString());
          }
          this.chart.data.datasets.forEach(dataset => {
            dataset.data.push(parseInt(message['integerValue'], 10));
          });
          this.chart.update();
        }
      }
    });
  }
  changeProperty() {
    console.log('change property called..');
    console.log(this.selectedProperty);
    this.valueList = [];
    console.log(this.chart);
    this.tempData = [];
    this.chart.data.datasets[0].data = [];
    this.chart.data.labels = [];
    // tslint:disable-next-line:no-shadowed-variable
    this.tempData.forEach(datakey => {
      this.chart.data.datasets.forEach(dataset => {
        dataset.data.push(datakey[this.selectedProperty]);
      });
    });
    console.log(this.chart.data.datasets);
    this.chart.update();
  }

  ngOnDestroy(): void {
    this.deviceService.selectedDevice.emit(undefined);
    if (this.ws.readyState === 3) {
      this.send(JSON.stringify(
        { topic: this.topic , status: 'unsubscribe', sessionId : this.sessionId}
        ));
      this.disconnect(this.ws);
    }
  }

  @HostListener('window:beforeunload', ['$event'])
  beforeunloadHandler(event) {
    console.log('in before unload');
    if (this.ws.readyState === 3) {
      this.send(JSON.stringify(
        { topic: this.topic , status: 'unsubscribe', sessionId : this.sessionId }
        ));
      this.disconnect(this.ws);
    }
  }
  formatLabel(value: number | null) {
    if (!value) {
      return 0;
    }

    // if (value >= 10) {
    //   return Math.round(value / 1000) + 'k';
    // }

    return value;
  }
  formatLabelpreset(value: number | null){
    // if (!value) {
    //   return 0;
    // }
    console.log(this.value_channel_1);
    console.log(this.value_channel_2);
    console.log(this.value_channel_3);
    console.log(this.value_channel_4);
    console.log(this.value_channel_5);
    console.log(this.value_channel_6);
    console.log(this.preset);

    this.value_channel_1  = this.takeRound((this.val1 * this.preset) / 100, 'CH1');
    this.value_channel_2  = this.takeRound((this.val2 * this.preset) / 100, 'CH2');
    this.value_channel_3  = this.takeRound((this.val3 * this.preset) / 100, 'CH3');
    this.value_channel_4  = this.takeRound((this.val4 * this.preset) / 100, 'CH4');
    this.value_channel_5  = this.takeRound((this.val5 * this.preset) / 100, 'CH5');
    this.value_channel_6  = this.takeRound((this.val6 * this.preset) / 100, 'CH6');
    return value;

  }
  takeRound(value, config) {
    return config === 'NC' ? 0 : Math.round(value);
  }

}
