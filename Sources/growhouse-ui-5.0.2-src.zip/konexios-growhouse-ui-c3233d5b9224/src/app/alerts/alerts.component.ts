import { Component, OnInit } from '@angular/core';
import { AlertsService } from '../services/alerts-service';
import { ProfileMessage } from 'src/environments/environment';
import * as moment from 'moment';
import { Moment } from 'moment';
import { BreadcrumbsService } from 'ng6-breadcrumbs/lib/breadcrumbs.service';
import { GlobalService } from '../services/global-service';

@Component({
  selector: 'app-alerts',
  templateUrl: './alerts.component.html',
  styleUrls: ['./alerts.component.css']
})
export class AlertsComponent implements OnInit {
  dtOptions: any = {};
  alerts: any = [];
  isGetListApiLoading = false;
  selectedMessage: string;
  selectedDate = true;
  startDate: any = null;
  endDate: any = null;
  selected: { start: Moment, end: Moment };
  filterted = false;
  ALL_OK = ProfileMessage.ALL_OK;
  NEED_WATER = ProfileMessage.NEED_WATER;
  NEED_SUN = ProfileMessage.NEED_SUN;
  MORE_SUN = ProfileMessage.MORE_SUN;
  messageList = [this.ALL_OK, this.NEED_WATER, this.NEED_SUN];
  ranges: any = {
    'Today': [moment().startOf('day').add(1, 'second'), moment()],
    'Yesterday': [moment().subtract(1, 'days').startOf('day').add(1, 'second'), moment().subtract(1, 'days').endOf('day')],
    'Last 7 Days': [moment().subtract(7, 'days').startOf('day').add(1, 'second'), moment()],
    'Last 30 Days': [moment().subtract(30, 'days').startOf('day'), moment()],
    'This Month': [moment().startOf('month'), moment().endOf('month')],
  };
  constructor(
    private alertsService: AlertsService,
    private breadcrumbService: BreadcrumbsService,
    private globalService: GlobalService
  ) { }

  ngOnInit() {
    this.breadcrumbService.store([
      { label: 'Alerts', url: '/alerts', params: [] }
    ]);
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 10,
      info: false,
      order: [],
      lengthChange: false,
      select: true,
      destroy: true,
      language: {
        zeroRecords: 'No Profiles to display',
        paginate: {
          next: '>', // or '→'
          previous: '<', // or '←',
        }
      }
    };
    const elem = document.getElementById('headerMenuCollapse');
    if (elem) {
      elem.classList.remove('show');
    }
    this.getAllProfileAlerts();
    this.addReloadEventToBreadcrumb();
  }

  getAllProfileAlerts() {
    this.alerts = [];
    this.isGetListApiLoading = true;
    let prop_arr = [];
    let properties;

    this.alertsService.getAllProfileAlerts().subscribe(
      (response: any) => {
        console.log(response);
        if (response) {
          this.alerts = response;
          for (let i = 0; i < this.alerts.length; i++) {
            properties = this.alerts[i].properties ? JSON.parse(this.alerts[i].properties) : {};
            console.log(properties);
            // tslint:disable-next-line:forin
            prop_arr = [];
            for (const key in properties) {
              prop_arr.push({ name: key, value: properties[key] });
            }
            this.alerts[i].properties = prop_arr;
          }
          // this.alerts.sort((val1, val2) => {
          //   const date1 = parseInt(val2.created_date, 10);
          //   const date2 = parseInt(val1.created_date, 10);
          //   return date1 - date2;
          // });
        }
        this.filterted = false;
        console.log(this.alerts);
        this.isGetListApiLoading = false;
        this.selectedMessage = null;
        this.startDate = null;
        this.endDate = null;
        this.selected = null;

      },
      error => {
        this.isGetListApiLoading = false;
      }
    );
  }
  rangeSelected(data) {
    if (data.start == null || data.end == null) {
      this.selectedDate = true;
    } else {
      this.selectedDate = false;
      this.startDate = JSON.stringify(data.start).slice(1, -1);
      this.endDate = JSON.stringify(data.end).slice(1, -1);
    }
  }
  addReloadEventToBreadcrumb() {
    setTimeout(() => {
      const elems = document.querySelectorAll('.breadcrumb-item a');
      console.log(elems);
      console.log('length     ', elems.length);
      for (let i = 0; i < elems.length; i++) {
        elems[i].addEventListener('click', this.globalService.handleClick);
      }
    }, 100);
  }
  onClickOfAlertFilter() {

    this.alerts = [];
    this.isGetListApiLoading = true;
    let prop_arr = [];
    let properties;
    let startDt = 0;
    let endDt = 0;
    let msg = null;
    if (this.startDate) {
      startDt = Date.parse(this.startDate);
    }
    if (this.endDate) {
      endDt = Date.parse(this.endDate);
    }

    if (this.selectedMessage) {
      msg = this.selectedMessage;
    }
    console.log(msg);

    this.alertsService.getAllAlertsByFilter(startDt,
      endDt, msg).subscribe((response: any) => {
        console.log(response);
        if (response) {
          this.alerts = response;
          for (let i = 0; i < this.alerts.length; i++) {
            properties = this.alerts[i].properties ? JSON.parse(this.alerts[i].properties) : {};
            console.log(properties);
            // tslint:disable-next-line:forin
            prop_arr = [];
            for (const key in properties) {
              prop_arr.push({ name: key, value: properties[key] });
            }
            this.alerts[i].properties = prop_arr;
          }
          // this.alerts.sort((val1, val2) => {
          //   const date1 = parseInt(val2.created_date, 10);
          //   const date2 = parseInt(val1.created_date, 10);
          //   return date1 - date2;
          // });
        }
        this.filterted = true;
        console.log(this.alerts);
        if (startDt === 0 && endDt === 0) {
          this.startDate = null;
          this.endDate = null;
          this.selected = null;
        }
        this.isGetListApiLoading = false;
      },
        error => {
          this.isGetListApiLoading = false;
        });
  }
  checkDisabled(){
    const falg = true;
    if(  this.selectedMessage || (this.selected && this.endDate)){
      return false;
    }
    return falg;
  }
  onChange(event){
console.log(event);
  }
}
