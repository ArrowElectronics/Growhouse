// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  appServerURL: "https://growhouse-api-dev1.konexios.io/api/",
  websocketServerURL:
    "https://growhouse-ws-dev1.konexios.io/growhouse-websocket",
};

export const appConfig = {
  signIn: "users/login",
  signOut: "users/logout",
  resetPassword: "users/{0}/reset-password",
  changePassword: "users/{0}/change-password",
  countByUser: "count",
  releaseVersion: "release/version",
  facilities: "facilities",
  countByFacility: "count/byfacility",
  containers: "containers",
  containertypes: "containertypes",
  countByContainer: "count/bycontainer",
  conatinersByFacility: "containers/facilities",
  dashboardCount: "count/dashboard",
  growareas: "growareas",
  growareatypes: "growareatypes",
  countByGrowArea: "count/bygrowarea",
  deletGrowAreaByProfileLedNode: "devices/ledNode/Profile/gateway",
  deletGrowAreaByDesireValueLedNode: "devices/ledNode/desiredValue/gateway",
  deletGrowAreaBychannelConfigurationLedNode:
    "devices/ledNode/channelConfig/gateway",
  deletGrowAreaBypropertyMapping: "devices/propertyMapping/gateway",
  deletGrowAreaBySection: "devices/section/gateway",
  deletGrowDevicesFromGateway: "devices/gateway",
  deletProfileAlertsFromGateway: "profilealert/gateway",
  deletProfile: "profile/growarea",
  deletGrowSections: "growsections/growSection",
  deletGroups: "lednode/gateway/{0}/groups",
  deletGrowAreaAsignee: "growareas/assignee",
  deletGrowArea: "growareas",
  deleteGrowSection: "growsections/{0}",
  growareasByFacility: "growareas/facilities",
  growareasByContainer: "growareas/containers",
  growsections: "growsections",
  updateGrowsectionProfileById: "profile",
  growsectionsByFacility: "growsections/facilities",
  growsectionsByContainer: "growsections/containers",
  growsectionsByGrowarea: "growsections/growareas",
  users: "users",
  verifyUser: "users/token",
  userRoles: "userroles",
  devices: "devices",
  devicesByGrowareaIDNDeviceType: "devices/growareas/{0}/devicetype/{1}",
  devicesByFacility: "devices/facilities",
  devicesByContainer: "devices/containers",
  devicesByGrowarea: "devices/growareas",
  ledNodeSetRGBValue: "devices/lednodevalue/history",
  ledNodeRGBValue: "devices/lednode",
  outOfNetworkAllDevices: "devices/count/outofnetwork/{0}",
  outOfNetworkDevicesByType: "devices/count/outofnetwork/{0}/{1}",
  accounts: "accounts",
  countries: "countries",
  states: "states",
  localities: "localities",
  devicetypes: "devicetypes",
  profilesByFacilityId: "rules/growareas/byfacility",
  profilesByContainerId: "rules/growareas/bycontainer",
  profilesByGrowareaId: "rules/growareas/bygrowarea",
  propertiesByGrowsection: "devices/properties/growarea",
  propertiesBySectionId: "devices/properties/growSection",
  propertiesByprofileId: "profile/alert",
  createProfile: "profile/growsection",
  countDevicesforGrowsection: "growsections",
  profileConditionsGrowSection: "profile/alerts/growsection",
  profileAlerts: "profilealert",
  profileAlertsByFacility: "profilealert/facility",
  profileAlertsByContainer: "profilealert/container",
  profileAlertsByGrowarea: "profilealert/growarea",
  profileAlertsByGrowsection: "profilealert/growsection",
  profiles: "profile",
  profilesByFacility: "profile/facility",
  profilesByContainer: "profile/container",
  profilesByGrowarea: "profile/growarea",
  profilesByGrowsection: "profile/growsection",
  getAdminUsers: "users/account/admin",
  propertiesByDevice: "devices/properties/device",
  propertiesHistory: "telemetry/device",
  growAreaOutOfNetwork: "growareas/outofnetwork",
  growAreaOutOfNetworkCount: "growareas/count/outofnetwork",
  growAreaOutOfNetworkCountByFacility: "growareas/count/outofnetwork/facility",
  growAreaOutOfNetworkCountByContainer:
    "growareas/count/outofnetwork/container",
  superAdminDashboardCount: "superadmin/dashboard/count",
  normalUserDashboardCount: "normaluser/dashboard/count",
  allAlerts: "profilealert/all/user",
  allAlertsByFacilityId: "profilealert/all/facility/",
  allAlertsByContainerId: "profilealert/all/container/",
  allAlertsByGrowareaId: "profilealert/all/growarea/",
  allAlertsByFilter: "profilealert/all/filter",
  getGroups: "lednode/group/growarea/{0}",
  createGroup: "lednode/group",
  deleteGroup: "lednode/group/{0}",
  getGroupByGroupId: "lednode/group",
  getProfiles: "lednode/group/{0}/profiles",
  createLedProfile: "lednode/group/profile",
  deleteLedProfile: "lednode/group/profile/{0}",
  getProfileByProfileId: "lednode/group/profile/{0}",
  getDevicesByGroup: "lednode/group/devices/gateway/{0}",
  applyProfile: "lednode/group/profile/event",
  applyNow: "lednode/group/profile/now",
  getEventsByGroupId: "lednode/group/{0}/event",
  deleteEvent: "lednode/group/profile/event/{0}",
  deleteIndividualProfile: "devices/lednode/profile/{0}",
};

export enum ProfileMessage {
  ALL_OK = "OK",
  NEED_WATER = "Soil needs attention",
  NEED_SUN = "Battery needs attention",
  MORE_SUN = "Temperature needs attention",
}

export const ValidationPatterns = {
  gmailPattern2: "^[a-zA-Z0-9][a-zA-Z0-9.]{4,30}[a-zA-Z0-9]@gmail.com$",
  passwordPattern: "^(?=.*[A-Z])(?=.*[!@#$&*])(?=.*[0-9]).{8,16}$",
  emailPattern:
    "^([A-Z|a-z|0-9](.|_){0,1})+[A-Z|a-z|0-9]@([A-Z|a-z|0-9])+((\\.){0,1}[A-Z|a-z|0-9]){2}\\.[a-z]{2,3}$",
  emailPattern2:
    "^[a-zA-Z0-9][a-zA-Z0-9.]{4,30}[a-zA-Z0-9]@([A-Z|a-z|0-9])+((\\.){0,1}[A-Z|a-z|0-9]){2}\\.[a-z]{2,3}$",
  username: "^[a-zA-Z][a-zA-Z_.]{0,1}[ a-z|A-Z|0-9|_.]*$",
  name: "^[a-zA-Z][a-zA-Z_.]{0,1}[ a-z|A-Z|0-9|_.]*$",
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
