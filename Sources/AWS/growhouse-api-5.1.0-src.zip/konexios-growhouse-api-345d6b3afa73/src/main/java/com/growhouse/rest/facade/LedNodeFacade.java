package com.growhouse.rest.facade;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.modelmapper.ModelMapper;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SchedulerFactory;
import org.quartz.SimpleScheduleBuilder;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.growhouse.rest.dto.DeviceGroupDTO;
import com.growhouse.rest.dto.DeviceLedNodeDTO;
import com.growhouse.rest.dto.GroupChannelConfigurationDTO;
import com.growhouse.rest.dto.GroupChannelValuesDTO;
import com.growhouse.rest.dto.LedNodeGroupChannelConfigurationDTO;
import com.growhouse.rest.dto.LedNodeGroupProfileDTO;
import com.growhouse.rest.dto.LedNodeProfileEventDTO;
import com.growhouse.rest.dto.LedNodeProfileEventNowDTO;
import com.growhouse.rest.entity.Device;
import com.growhouse.rest.entity.GroupDevice;
import com.growhouse.rest.entity.LedNodeGroupChannelConfiguration;
import com.growhouse.rest.entity.LedNodeGroupProfile;
import com.growhouse.rest.entity.LedNodeProfileEvent;
import com.growhouse.rest.repository.GroupDeviceRepository;
import com.growhouse.rest.repository.LedNodeProfileEventRepository;
import com.growhouse.rest.services.IDeviceService;
import com.growhouse.rest.services.ILedNodeService;
import com.growhouse.rest.utils.Constants;
import com.growhouse.rest.utils.LedNodeChannelMapping;

@Component
public class LedNodeFacade {

	@Autowired
	private IDeviceService deviceService;

	@Autowired
	private DeviceFacade devicefacade;

	@Autowired
	private ILedNodeService ledNodeService;

	@Autowired
	private LedNodeFacade ledNodeFacade;

	@Autowired
	private LedNodeProfileEventRepository ledNodeProfileEventRepository;

	@Autowired
	private GroupDeviceRepository groupDeviceRepo;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private ObjectMapper objectMapper;

	private static final Logger LOGGER = LogManager.getLogger(LedNodeFacade.class);

	public Map<String, Object> getLedNodeStateProperties(Integer deviceId) {
		Map<String, Object> map = null;
		Device device = deviceService.getDeviceById(deviceId);
		if (device != null) {
			map = ledNodeService.getLedNodeStateProperties(device.getDeviceHId());
		}
		return map;
	}

	public LedNodeGroupChannelConfigurationDTO createLedGroup(
			LedNodeGroupChannelConfigurationDTO ledNodeGroupChannelConfigurationDTO) {
		ledNodeGroupChannelConfigurationDTO.setGroupName(ledNodeGroupChannelConfigurationDTO.getGroupName().trim());
		LedNodeGroupChannelConfiguration group = ledNodeService.getGroupByGroupNameAndGateway(
				ledNodeGroupChannelConfigurationDTO.getGroupName(), ledNodeGroupChannelConfigurationDTO.getGrowArea());
		if (group == null) {
			List<DeviceGroupDTO> devices = ledNodeGroupChannelConfigurationDTO.getDevices();
			LedNodeGroupChannelConfiguration ledNodeGroupChannelConfiguration = convertDTOToEntity(
					ledNodeGroupChannelConfigurationDTO);
			LedNodeGroupChannelConfiguration createdledGroupChannelConfi = ledNodeService
					.createLedGroup(ledNodeGroupChannelConfiguration);
			if (!devices.isEmpty()) {
				List<GroupDevice> groupdevices = devicesForGroup(devices, createdledGroupChannelConfi);
				groupDeviceRepo.saveAll(groupdevices);
			}
			LedNodeGroupChannelConfigurationDTO conledGroupCongi = convertEntityTODTO(createdledGroupChannelConfi);
			conledGroupCongi.setDevices(devices);
			return conledGroupCongi;
		} else {
			throw new HttpClientErrorException(HttpStatus.BAD_REQUEST,
					"Group name already exist in selected Grow Area.");
		}
	}

	public List<GroupDevice> devicesForGroup(List<DeviceGroupDTO> devices,
			LedNodeGroupChannelConfiguration createdledGroupChannelConfi) {
		List<GroupDevice> groupdevices = new ArrayList<>();
		for (DeviceGroupDTO deviceDTO : devices) {
			GroupDevice groupdevice = new GroupDevice();
			groupdevice.setGroup(createdledGroupChannelConfi);
			groupdevice.setDevice(modelMapper.map(deviceDTO, Device.class));
			groupdevices.add(groupdevice);
		}
		return groupdevices;
	}

	public List<LedNodeGroupChannelConfigurationDTO> getLedGroupByGrowareaId(Integer growareaId) {
		List<LedNodeGroupChannelConfigurationDTO> ledGroupDTO = new ArrayList<>();
		List<LedNodeGroupChannelConfiguration> ledGroup = ledNodeService.getLedGroupByGrowareaId(growareaId);
		if (ledGroup != null && !ledGroup.isEmpty()) {
			ledGroupDTO = ledGroup.stream().map(this::convertEntityTODTOForGroup).collect(Collectors.toList());
		}
		return ledGroupDTO;

	}

	public LedNodeGroupChannelConfigurationDTO getLedGroupById(Integer groupId) {
		LedNodeGroupChannelConfigurationDTO ledGroupDTO = null;
		Optional<LedNodeGroupChannelConfiguration> ledGroup = ledNodeService.getLedGroupById(groupId);
		if (ledGroup.isPresent() && ledGroup.get().isActive()) {
			LedNodeGroupChannelConfiguration dbLedGroup = ledGroup.get();
			ledGroupDTO = convertEntityTODTOForGroup(dbLedGroup);

		}
		return ledGroupDTO;
	}

	public LedNodeGroupChannelConfigurationDTO updateLedGroup(
			LedNodeGroupChannelConfigurationDTO ledNodeGroupChannelConfigurationDTO) {
		LedNodeGroupChannelConfiguration createdledGroupChannelConfi = null;
		List<GroupDevice> requestedGroupDevices;
		ledNodeGroupChannelConfigurationDTO.setGroupName(ledNodeGroupChannelConfigurationDTO.getGroupName().trim());
		LedNodeGroupChannelConfiguration group = ledNodeService.getGroupByGroupNameAndGateway(
				ledNodeGroupChannelConfigurationDTO.getGroupName(), ledNodeGroupChannelConfigurationDTO.getGrowArea());
		if (group == null) {
			LedNodeGroupChannelConfiguration ledNodeGroupChannelConfiguration = convertDTOToEntity(
					ledNodeGroupChannelConfigurationDTO);
			createdledGroupChannelConfi = ledNodeService.updateLedGroup(ledNodeGroupChannelConfiguration);
		} else {
			if (group.getId().equals(ledNodeGroupChannelConfigurationDTO.getId()) == Constants.TRUE) {
				LedNodeGroupChannelConfiguration ledNodeGroupChannelConfiguration = convertDTOToEntity(
						ledNodeGroupChannelConfigurationDTO);
				createdledGroupChannelConfi = ledNodeService.updateLedGroup(ledNodeGroupChannelConfiguration);

			} else {
				throw new HttpClientErrorException(HttpStatus.BAD_REQUEST,
						"Group name already exist in selected Grow Area.");
			}
		}
		List<DeviceGroupDTO> devices = ledNodeGroupChannelConfigurationDTO.getDevices();
		if (!devices.isEmpty()) {
			requestedGroupDevices = devicesForGroup(devices, createdledGroupChannelConfi);
			groupDeviceRepo.deleteGroupDevicesByGroupId(createdledGroupChannelConfi.getId());
			groupDeviceRepo.saveAll(requestedGroupDevices);
		} else {
			groupDeviceRepo.deleteGroupDevicesByGroupId(createdledGroupChannelConfi.getId());
		}
		LedNodeGroupChannelConfigurationDTO updatedledGroupConfi = convertEntityTODTO(createdledGroupChannelConfi);
		updatedledGroupConfi.setDevices(devices);
		return updatedledGroupConfi;
	}

	public LedNodeGroupChannelConfigurationDTO deleteLedGroup(Integer groupId) {

		LedNodeGroupChannelConfiguration createdledGroupChannelConfi = ledNodeService.deleteLedGroup(groupId);
		return convertEntityTODTO(createdledGroupChannelConfi);
	}

	public LedNodeGroupProfileDTO createLedGroupProfile(LedNodeGroupProfileDTO ledNodeGroupProfileDTO)
			throws IOException {
		LedNodeGroupProfile createdLedProfile = null;
		ledNodeGroupProfileDTO.setLedProfileName(ledNodeGroupProfileDTO.getLedProfileName().trim());
		LedNodeGroupProfile profile = ledNodeService.getProfileByProfileNameAndGroupId(
				ledNodeGroupProfileDTO.getLedProfileName(), ledNodeGroupProfileDTO.getGroupId());
		if (profile == null) {
			LedNodeGroupProfile ledProfile = convertProfileDTOToEntity(ledNodeGroupProfileDTO);
			ledProfile.setChannelConfiguration(
					objectMapper.writeValueAsString(ledNodeGroupProfileDTO.getChannelConfiguration()));
			ledProfile.setChannelValues(objectMapper.writeValueAsString(ledNodeGroupProfileDTO.getChannelValues()));
			createdLedProfile = ledNodeService.createLedNodeGroupProfile(ledProfile);
			return convertProfileEntityToDTO(createdLedProfile);
		} else {
			throw new HttpClientErrorException(HttpStatus.BAD_REQUEST, "Profile name already exist in selected Group.");
		}

	}

	public LedNodeGroupProfileDTO updateLedGroupProfile(LedNodeGroupProfileDTO ledNodeGroupProfileDTO)
			throws IOException {
		LedNodeGroupProfile updatedLedProfile = null;
		ledNodeGroupProfileDTO.setLedProfileName(ledNodeGroupProfileDTO.getLedProfileName().trim());
		LedNodeGroupProfile profile = ledNodeService.getProfileByProfileNameAndGroupId(
				ledNodeGroupProfileDTO.getLedProfileName(), ledNodeGroupProfileDTO.getGroupId());
		if (profile == null) {
			LedNodeGroupProfile ledProfile = convertProfileDTOToEntity(ledNodeGroupProfileDTO);
			ledProfile.setChannelConfiguration(
					objectMapper.writeValueAsString(ledNodeGroupProfileDTO.getChannelConfiguration()));
			ledProfile.setChannelValues(objectMapper.writeValueAsString(ledNodeGroupProfileDTO.getChannelValues()));
			updatedLedProfile = ledNodeService.updateLedNodeGroupProfile(ledProfile);
			ledNodeService.updateEventProfileNameByProfileId(ledNodeGroupProfileDTO.getLedProfileName(),
					ledNodeGroupProfileDTO.getId());

		} else {
			if (profile.getId().equals(ledNodeGroupProfileDTO.getId()) == Constants.TRUE) {
				LedNodeGroupProfile ledProfile = convertProfileDTOToEntity(ledNodeGroupProfileDTO);
				ledProfile.setChannelConfiguration(
						objectMapper.writeValueAsString(ledNodeGroupProfileDTO.getChannelConfiguration()));
				ledProfile.setChannelValues(objectMapper.writeValueAsString(ledNodeGroupProfileDTO.getChannelValues()));
				updatedLedProfile = ledNodeService.updateLedNodeGroupProfile(ledProfile);
			} else {
				throw new HttpClientErrorException(HttpStatus.BAD_REQUEST,
						"Profile name already exist in selected Group.");
			}
		}
		return convertProfileEntityToDTO(updatedLedProfile);
	}

	public List<LedNodeGroupProfileDTO> getLedGroupProfileByGroupId(Integer groupId) {
		List<LedNodeGroupProfileDTO> lednodeProfileDTO = null;
		List<LedNodeGroupProfile> ledNodeGroupProfiles = ledNodeService.getLedNodeGrupProfilesByGroupId(groupId);
		if (ledNodeGroupProfiles != null && !ledNodeGroupProfiles.isEmpty()) {
			lednodeProfileDTO = ledNodeGroupProfiles.stream().map(this::convertProfileEntityToDTO)
					.collect(Collectors.toList());
		}
		return lednodeProfileDTO;
	}

	public LedNodeGroupProfileDTO getLedProfileByProfileId(Integer profileId) {
		LedNodeGroupProfileDTO ledNodeGroupProfileDTO = null;
		LedNodeGroupProfile profile = ledNodeService.getGroupProfileByProfileId(profileId);
		if (profile != null) {
			ledNodeGroupProfileDTO = convertProfileEntityToDTO(profile);
		}
		return ledNodeGroupProfileDTO;
	}

	public void deleteLedProfileByGroupId(Integer groupId) {

		ledNodeService.deleteLedNodeGroupProfilesByGroupId(groupId);

	}

	public void deleteLedGroupsBygatewayId(Integer gatewayId) {

		ledNodeService.deleteGroupsByGatewayId(gatewayId);

	}

	public void deleteProfileByProfileId(Integer profileId) {
		ledNodeService.deleteLedNodeProfileByProfileId(profileId);
	}

	public List<DeviceLedNodeDTO> getDevicesByChannelConfi(GroupChannelConfigurationDTO channelConfigurationDTO,
			int gatewayId) {
		return devicefacade.getDeviceBychannelConfi(channelConfigurationDTO, gatewayId);

	}

	private LedNodeGroupProfile convertProfileDTOToEntity(LedNodeGroupProfileDTO ledNodeGroupProfileDTO) {
		return modelMapper.map(ledNodeGroupProfileDTO, LedNodeGroupProfile.class);
	}

	private LedNodeGroupProfileDTO convertProfileEntityToDTO(LedNodeGroupProfile ledNodeGroupProfile) {
		GroupChannelConfigurationDTO groupChannelConfiDTO;
		GroupChannelValuesDTO groupChanelValuesDTO;
		LedNodeGroupProfileDTO ledGroupProfileDTO = modelMapper.map(ledNodeGroupProfile, LedNodeGroupProfileDTO.class);
		try {
			groupChannelConfiDTO = objectMapper.readValue(ledNodeGroupProfile.getChannelConfiguration(),
					GroupChannelConfigurationDTO.class);
			ledGroupProfileDTO.setChannelConfiguration(groupChannelConfiDTO);
			groupChanelValuesDTO = objectMapper.readValue(ledNodeGroupProfile.getChannelValues(),
					GroupChannelValuesDTO.class);
			ledGroupProfileDTO.setChannelValues(groupChanelValuesDTO);
		} catch (JsonParseException e) {
			LOGGER.info("JSon parser exception");
		} catch (JsonMappingException e) {
			LOGGER.info("JsonMapping exception");
		} catch (IOException e) {
			LOGGER.info("IOException exception");
		}

		return ledGroupProfileDTO;
	}

	public String applyLedNodeEvent(LedNodeProfileEventDTO eventPayload) throws SchedulerException, ParseException {

		List<GroupDevice> devices = groupDeviceRepo
				.findByGroupIdAndIsActiveTrue(eventPayload.getProfileDeatils().getGroupId());
		if (!devices.isEmpty()) {
			LedNodeProfileEvent profileEvent = convertProfileDTOToEvent(eventPayload);
			profileEvent.setProfileId(eventPayload.getProfileDeatils().getId());
			profileEvent.setProfileName(eventPayload.getProfileDeatils().getLedProfileName());
			profileEvent.setGroupId(eventPayload.getProfileDeatils().getGroupId());

			SchedulerFactory schedFact = new StdSchedulerFactory();
			Scheduler sched = schedFact.getScheduler();

			String startdate = eventPayload.getStartDate();
			SimpleDateFormat endformatter = new SimpleDateFormat("MM/dd/yyyy HH:mm");
			SimpleDateFormat todayformater = new SimpleDateFormat("MM/dd/yyyy");
			String todayDate = todayformater.format(new Date());
			String todayComparetime = endformatter.format(new Date());
			Date todayCompareDate = endformatter.parse(todayComparetime);
			String startTime = eventPayload.getStartTime();
			List<String> days = eventPayload.getRepeatTime();
			String todayDay = getDayOfToday();
			String finalstartdate = startdate + " " + startTime;
			Date startforonce = endformatter.parse(finalstartdate);

			if (startforonce.compareTo(todayCompareDate) > 0) {
				if (days.isEmpty()) {
					if (todayDate.equals(startdate) == Constants.TRUE) {
						LedNodeProfileEvent event = ledNodeProfileEventRepository.getEventByStartDateAndTime(startdate,
								startTime, eventPayload.getProfileDeatils().getGroupId());
						if (event != null) {
							sched.deleteJob(new JobKey(event.getJobName(), event.getJobName()));
							LOGGER.info("deleted job---" + event.getJobName());
						}

						LedNodeProfileEvent createdProfileEvent = ledNodeProfileEventRepository.save(profileEvent);
						String jobName = "Job_" + createdProfileEvent.getId();
						createdProfileEvent.setJobName(jobName);
						ledNodeProfileEventRepository.save(createdProfileEvent);

						JobDetail job = JobBuilder.newJob(SimpleJob.class).withIdentity(jobName, jobName).build();
						job.getJobDataMap().put("groupId", eventPayload.getProfileDeatils().getGroupId());
						job.getJobDataMap().put("profileId", eventPayload.getProfileDeatils().getId());
						job.getJobDataMap().put("obj", ledNodeService);
						job.getJobDataMap().put("lednodeFacade", ledNodeFacade);
						job.getJobDataMap().put("preset", eventPayload.getPreset());

						Trigger trigger = TriggerBuilder.newTrigger().withIdentity("myTrigger", jobName)
								.startAt(startforonce).withSchedule(SimpleScheduleBuilder.simpleSchedule()).build();
						sched.scheduleJob(job, trigger);
						LOGGER.info("Start date is Today so schedule job---." + jobName);
					} else {
						profileEventSave(profileEvent);

					}
				} else {
					if (todayDate.equals(startdate) && days.contains(todayDay)) {
						LedNodeProfileEvent event = ledNodeProfileEventRepository.getEventByStartDateAndTimeAndDay(
								startdate, startTime, todayDay, eventPayload.getProfileDeatils().getGroupId());
						if (event != null) {
							sched.deleteJob(new JobKey(event.getJobName(), event.getJobName()));
							LOGGER.info("deleted job---" + event.getJobName());
						}

						LedNodeProfileEvent createdProfileEvent = ledNodeProfileEventRepository.save(profileEvent);
						String jobName = "Job_" + createdProfileEvent.getId();
						createdProfileEvent.setJobName(jobName);
						ledNodeProfileEventRepository.save(createdProfileEvent);

						JobDetail job = JobBuilder.newJob(SimpleJob.class).withIdentity(jobName, jobName).build();
						job.getJobDataMap().put("groupId", eventPayload.getProfileDeatils().getGroupId());
						job.getJobDataMap().put("profileId", eventPayload.getProfileDeatils().getId());
						job.getJobDataMap().put("obj", ledNodeService);
						job.getJobDataMap().put("lednodeFacade", ledNodeFacade);
						job.getJobDataMap().put("preset", eventPayload.getPreset());

						Trigger trigger = TriggerBuilder.newTrigger().withIdentity("myTrigger", jobName)
								.startAt(startforonce).withSchedule(SimpleScheduleBuilder.simpleSchedule()).build();
						sched.scheduleJob(job, trigger);
						LOGGER.info("Start date is Today so schedule job---." + jobName);
					} else {
						profileEventSave(profileEvent);
					}
				}

				final Thread first = new Thread(new Runnable() {
					@Override
					public void run() {
						try {
							sched.start();
						} catch (SchedulerException e) {
							LOGGER.info("Exception occured in Scheduling event");
						}
					}
				});
				first.start();
				return "Event Scheduled Successfully";
			} else {
				throw new HttpClientErrorException(HttpStatus.BAD_REQUEST,
						"Please select start date and time greater than current date time.");
			}
		} else {
			throw new HttpClientErrorException(HttpStatus.BAD_REQUEST,
					"Currently no device present in selected Group.");
		}
	}

	public void profileEventSave(LedNodeProfileEvent profileEvent) {
		LedNodeProfileEvent createdProfileEvent = ledNodeProfileEventRepository.save(profileEvent);
		String jobName = "Job_" + createdProfileEvent.getId();
		createdProfileEvent.setJobName(jobName);
		ledNodeProfileEventRepository.save(createdProfileEvent);
	}

	public String getDayOfToday() {
		HashMap<Integer, String> map = new HashMap<>();
		map.put(1, "Every Sunday");
		map.put(2, "Every Monday");
		map.put(3, "Every Tuesday");
		map.put(4, "Every Wednesday");
		map.put(5, "Every Thursday");
		map.put(6, "Every Friday");
		map.put(7, "Every Saturday");
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(new Date());
		int d = calendar.get(Calendar.DAY_OF_WEEK);
		return map.get(d);
	}

	public void deleteEventById(String eventName) throws SchedulerException {
		ledNodeProfileEventRepository.deleteLedNodeProfileEventByEventName(eventName);
		SchedulerFactory schedFact = new StdSchedulerFactory();
		Scheduler sched = schedFact.getScheduler();
		sched.deleteJob(new JobKey(eventName, eventName));
	}

	public void applyLedNodeGroupProfile(LedNodeProfileEventNowDTO eventPayload) {
		List<GroupDevice> devicesList = groupDeviceRepo
				.findByGroupIdAndIsActiveTrue(eventPayload.getProfileDeatils().getGroupId());
		if (!devicesList.isEmpty()) {
			Map<String, Object> deviceStates = setLedGroupDeviceState(eventPayload);
			int groupId = eventPayload.getProfileDeatils().getGroupId();
			LedNodeGroupChannelConfigurationDTO group = getLedGroupById(groupId);
			if (group != null) {
				List<DeviceGroupDTO> devices = group.getDevices();
				for (DeviceGroupDTO device : devices) {
					deviceService.setStateToArrowConnect(device.getDeviceHId(), deviceStates);
				}
			} else {
				throw new HttpClientErrorException(HttpStatus.NOT_FOUND, "Group does not exist.");
			}
		} else {
			throw new HttpClientErrorException(HttpStatus.BAD_REQUEST,
					"Currently no device present in selected Group.");
		}
	}

	public List<LedNodeProfileEventDTO> getProfileEventsByGroupId(Integer groupId) {
		List<LedNodeProfileEvent> profileEvents = ledNodeProfileEventRepository
				.findByGroupIdAndIsActiveTrueOrderByCreatedTimestampDesc(groupId);
		return profileEvents.stream().map(this::convertProfileEventToDTO).collect(Collectors.toList());

	}

	private LedNodeProfileEvent convertProfileDTOToEvent(LedNodeProfileEventDTO eventPayload) {
		LedNodeProfileEvent profileEvent = modelMapper.map(eventPayload, LedNodeProfileEvent.class);
		try {
			profileEvent.setProfileDetails(objectMapper.writeValueAsString(eventPayload.getProfileDeatils()));
			profileEvent.setRepeatTime(objectMapper.writeValueAsString(eventPayload.getRepeatTime()));
		} catch (JsonProcessingException e) {
			LOGGER.info("exception occured in convert profile DTO to event-", e);
		}

		return profileEvent;
	}

	private LedNodeProfileEventDTO convertProfileEventToDTO(LedNodeProfileEvent eventPayload) {
		LedNodeProfileEventDTO profileEvent = modelMapper.map(eventPayload, LedNodeProfileEventDTO.class);
		try {
			profileEvent.setProfileDeatils(
					objectMapper.readValue(eventPayload.getProfileDetails(), LedNodeGroupProfileDTO.class));
			profileEvent.setRepeatTime(
					objectMapper.readValue(eventPayload.getRepeatTime(), new TypeReference<List<String>>() {
					}));
		} catch (IOException e) {
			LOGGER.info("Exception occured in convert profile event to DTO-", e);
		}
		return profileEvent;
	}

	private LedNodeGroupChannelConfiguration convertDTOToEntity(
			LedNodeGroupChannelConfigurationDTO ledNodeGroupChannelConfigurationDTO) {
		LedNodeGroupChannelConfiguration ledChannelConfiguration = modelMapper.map(ledNodeGroupChannelConfigurationDTO,
				LedNodeGroupChannelConfiguration.class);
		ledChannelConfiguration
				.setLed1(ledNodeGroupChannelConfigurationDTO.getGroupChannelConfigurationDTO().getLed1());
		ledChannelConfiguration
				.setLed2(ledNodeGroupChannelConfigurationDTO.getGroupChannelConfigurationDTO().getLed2());
		ledChannelConfiguration
				.setLed3(ledNodeGroupChannelConfigurationDTO.getGroupChannelConfigurationDTO().getLed3());
		ledChannelConfiguration
				.setLed4(ledNodeGroupChannelConfigurationDTO.getGroupChannelConfigurationDTO().getLed4());
		ledChannelConfiguration
				.setLed5(ledNodeGroupChannelConfigurationDTO.getGroupChannelConfigurationDTO().getLed5());
		ledChannelConfiguration
				.setLed6(ledNodeGroupChannelConfigurationDTO.getGroupChannelConfigurationDTO().getLed6());
		String generatedGroupName = ledChannelConfiguration.getLed1() + "-" + ledChannelConfiguration.getLed2() + "-"
				+ ledChannelConfiguration.getLed3() + "-" + ledChannelConfiguration.getLed4() + "-"
				+ ledChannelConfiguration.getLed5() + "-" + ledChannelConfiguration.getLed6();
		ledChannelConfiguration.setGeneratedGroupName(generatedGroupName);
		ledChannelConfiguration.setDevices(null);
		return ledChannelConfiguration;
	}

	private LedNodeGroupChannelConfigurationDTO convertEntityTODTO(
			LedNodeGroupChannelConfiguration ledNodeGroupChannelConfi) {
		GroupChannelConfigurationDTO groupChannelConfigurationDTO = new GroupChannelConfigurationDTO();
		LedNodeGroupChannelConfigurationDTO ledChannelConfiguration = modelMapper.map(ledNodeGroupChannelConfi,
				LedNodeGroupChannelConfigurationDTO.class);
		groupChannelConfigurationDTO.setLed1(ledNodeGroupChannelConfi.getLed1());
		groupChannelConfigurationDTO.setLed2(ledNodeGroupChannelConfi.getLed2());
		groupChannelConfigurationDTO.setLed3(ledNodeGroupChannelConfi.getLed3());
		groupChannelConfigurationDTO.setLed4(ledNodeGroupChannelConfi.getLed4());
		groupChannelConfigurationDTO.setLed5(ledNodeGroupChannelConfi.getLed5());
		groupChannelConfigurationDTO.setLed6(ledNodeGroupChannelConfi.getLed6());
		ledChannelConfiguration.setGroupChannelConfigurationDTO(groupChannelConfigurationDTO);

		return ledChannelConfiguration;
	}

	private LedNodeGroupChannelConfigurationDTO convertEntityTODTOForGroup(
			LedNodeGroupChannelConfiguration ledNodeGroupChannelConfi) {
		List<DeviceGroupDTO> groupDevices = new ArrayList<>();
		GroupChannelConfigurationDTO groupChannelConfigurationDTO = new GroupChannelConfigurationDTO();
		LedNodeGroupChannelConfigurationDTO ledChannelConfiguration = modelMapper.map(ledNodeGroupChannelConfi,
				LedNodeGroupChannelConfigurationDTO.class);
		groupChannelConfigurationDTO.setLed1(ledNodeGroupChannelConfi.getLed1());
		groupChannelConfigurationDTO.setLed2(ledNodeGroupChannelConfi.getLed2());
		groupChannelConfigurationDTO.setLed3(ledNodeGroupChannelConfi.getLed3());
		groupChannelConfigurationDTO.setLed4(ledNodeGroupChannelConfi.getLed4());
		groupChannelConfigurationDTO.setLed5(ledNodeGroupChannelConfi.getLed5());
		groupChannelConfigurationDTO.setLed6(ledNodeGroupChannelConfi.getLed6());
		ledChannelConfiguration.setGroupChannelConfigurationDTO(groupChannelConfigurationDTO);
		List<GroupDevice> devices = groupDeviceRepo.findByGroupIdAndIsActiveTrue(ledNodeGroupChannelConfi.getId());
		if (devices != null && !devices.isEmpty()) {
			for (GroupDevice groupDevice : devices) {
				DeviceGroupDTO deviceGroup = new DeviceGroupDTO();
				deviceGroup.setDeviceHId(groupDevice.getDevice().getDeviceHId());
				deviceGroup.setDeviceName(groupDevice.getDevice().getDeviceName());
				deviceGroup.setDeviceUId(groupDevice.getDevice().getDeviceUId());
				deviceGroup.setId(groupDevice.getDevice().getId());
				boolean status = groupDevice.getDevice().isStatus();
				String deviceStatus = (status == Constants.TRUE) ? "true" : "false";
				deviceGroup.setStatus(deviceStatus);
				groupDevices.add(deviceGroup);
			}
		}
		ledChannelConfiguration.setDevices(groupDevices);
		return ledChannelConfiguration;
	}

	public Map<String, Object> setLedGroupDeviceState(LedNodeProfileEventNowDTO eventPayload) {
		Map<String, String> states = new HashMap<>();
		states.put(LedNodeChannelMapping.valueOf(Constants.CHANNEL1).showLedNodeChannelMappingValue(),
				eventPayload.getCh1().toString());
		states.put(LedNodeChannelMapping.valueOf(Constants.CHANNEL2).showLedNodeChannelMappingValue(),
				eventPayload.getCh2().toString());
		states.put(LedNodeChannelMapping.valueOf(Constants.CHANNEL3).showLedNodeChannelMappingValue(),
				eventPayload.getCh3().toString());
		states.put(LedNodeChannelMapping.valueOf(Constants.CHANNEL4).showLedNodeChannelMappingValue(),
				eventPayload.getCh4().toString());
		states.put(LedNodeChannelMapping.valueOf(Constants.CHANNEL5).showLedNodeChannelMappingValue(),
				eventPayload.getCh5().toString());
		states.put(LedNodeChannelMapping.valueOf(Constants.CHANNEL6).showLedNodeChannelMappingValue(),
				eventPayload.getCh6().toString());
		Map<String, Object> deviceState = new HashMap<>();
		String isoDatePattern = "yyyy-MM-dd'T'HH:mm:dd'Z'";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(isoDatePattern);
		deviceState.put("timestamp", simpleDateFormat.format(new Date()));

		try {
			deviceState.put("states", objectMapper.readValue(objectMapper.writeValueAsString(states), Map.class));
		} catch (IOException exception) {
			LOGGER.error("Error occurred while manipulating Json {}", exception);
		}

		return deviceState;
	}

}
