package com.growhouse.rest.dto;

import java.util.List;

public class PayloadDTO {
	private Integer id;

	private List<Condition> conditions;

	private List<Monitor> monitors;

	private String name;

	private String ruleHid;
	
	private String type;

	private String timeInterval;
	
	private String profileName;

	private GlobalResponsePayloadDTO globalResponsePayload;

	/**
	 * @return the conditions
	 */
	
	


	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}





	public List<Condition> getConditions() {
		return conditions;
	}

	public void setConditions(List<Condition> conditions) {
		this.conditions = conditions;
	}

	public List<Monitor> getMonitors() {
		return monitors;
	}

	public void setMonitors(List<Monitor> monitors) {
		this.monitors = monitors;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the ruleHid
	 */
	public String getRuleHid() {
		return ruleHid;
	}

	/**
	 * @param ruleHid the ruleHid to set
	 */
	public void setRuleHid(String ruleHid) {
		this.ruleHid = ruleHid;
	}

	/**
	 * @return the timeInterval
	 */
	public String getTimeInterval() {
		return timeInterval;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @param timeInterval the timeInterval to set
	 */
	public void setTimeInterval(String timeInterval) {
		this.timeInterval = timeInterval;
	}

	/**
	 * @return the globalResponsePayloadDTO
	 */
	public GlobalResponsePayloadDTO getGlobalResponsePayload() {
		return globalResponsePayload;
	}

	/**
	 * @param globalResponsePayloadDTO the globalResponsePayloadDTO to set
	 */
	public void setGlobalResponsePayload(GlobalResponsePayloadDTO globalResponsePayloadDTO) {
		this.globalResponsePayload = globalResponsePayloadDTO;
	}

	public String getProfileName() {
		return profileName;
	}

	public void setProfileName(String profileName) {
		this.profileName = profileName;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */


}







