package com.growhouse.rest.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GroupChannelValuesDTO {

	@JsonProperty("CH1")
	private Integer led1;
	
	@JsonProperty("CH2")
	private Integer led2;
	
	@JsonProperty("CH3")
	private Integer led3;
	
	@JsonProperty("CH4")
	private Integer led4;
	
	@JsonProperty("CH5")
	private Integer led5;
	
	@JsonProperty("CH6")
	private Integer led6;

	public Integer getLed1() {
		return led1;
	}

	public void setLed1(Integer led1) {
		this.led1 = led1;
	}

	public Integer getLed2() {
		return led2;
	}

	public void setLed2(Integer led2) {
		this.led2 = led2;
	}

	public Integer getLed3() {
		return led3;
	}

	public void setLed3(Integer led3) {
		this.led3 = led3;
	}

	public Integer getLed4() {
		return led4;
	}

	public void setLed4(Integer led4) {
		this.led4 = led4;
	}

	public Integer getLed5() {
		return led5;
	}

	public void setLed5(Integer led5) {
		this.led5 = led5;
	}

	public Integer getLed6() {
		return led6;
	}

	public void setLed6(Integer led6) {
		this.led6 = led6;
	}

	@Override
	public String toString() {
		return "GroupChannelValuesDTO [led1=" + led1 + ", led2=" + led2 + ", led3=" + led3 + ", led4=" + led4
				+ ", led5=" + led5 + ", led6=" + led6 + "]";
	}

	
}
