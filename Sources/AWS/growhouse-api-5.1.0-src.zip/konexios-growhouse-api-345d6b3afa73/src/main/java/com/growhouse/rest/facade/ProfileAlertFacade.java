package com.growhouse.rest.facade;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.Collectors;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.growhouse.rest.dto.ProfileAlertTimestampDTO;
import com.growhouse.rest.dto.ProfileResponseDTO;
import com.growhouse.rest.entity.GrowAreaAssignee;
import com.growhouse.rest.entity.ProfileAlert;
import com.growhouse.rest.entity.User;
import com.growhouse.rest.entity.ProfileAlertsUI;
import com.growhouse.rest.services.impl.GrowAreaAssigneeService;
import com.growhouse.rest.services.impl.ProfileAlertService;
import com.growhouse.rest.utils.Constants;

@Component
public class ProfileAlertFacade {

	public static final Logger LOGGER = LoggerFactory.getLogger(ProfileAlertFacade.class);
	
	@Autowired
	private ProfileAlertService profileAlertService;
	
	@Autowired
	private GrowAreaAssigneeService growAreaAssigneeService;
	
	@Autowired
	private ObjectMapper mapper;

	public List<ProfileResponseDTO> getProfileAlertByUser() {
		List<ProfileResponseDTO> profileResponseDTOs=new ArrayList<>(); 
		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		List<GrowAreaAssignee> growAreaAssignees = growAreaAssigneeService
		        .getAllGrowAreaAssigneesByUserId(user.getId());
		if (growAreaAssignees != null && !growAreaAssignees.isEmpty())
		{
		List<String> growAreaIds = growAreaAssignees.stream()
		        .map(growAreaAssignee -> growAreaAssignee.getGrowArea().getId().toString())
		        .collect(Collectors.toList());
		List<Integer> profileIds = getRandomFromList(profileIdFromGatewayId(growAreaIds));
		List<ProfileAlertsUI> profileAlerts = profileIds.stream().map(
		        profileId -> profileAlertService.getProfileAlertByProfileId(profileId))
		        .collect(Collectors.toList());
		        profileResponseDTOs=convertToProfileAlertDTO(profileAlerts);
		}
		return profileResponseDTOs;
		
	}

	public List<ProfileResponseDTO> getAllProfileAlertByUser() {
		List<ProfileResponseDTO> profileResponseDTOs=new ArrayList<>(); 
		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		List<GrowAreaAssignee> growAreaAssignees = growAreaAssigneeService
		        .getAllGrowAreaAssigneesByUserId(user.getId());
		if (growAreaAssignees != null && !growAreaAssignees.isEmpty())
		{
		List<String> growAreaIds = growAreaAssignees.stream()
		        .map(growAreaAssignee -> growAreaAssignee.getGrowArea().getId().toString())
		        .collect(Collectors.toList());
		List<Integer> profileIds = profileIdFromGatewayId(growAreaIds);
		List<ProfileAlertsUI> profileAlerts = profileIds.stream().map(
		        profileId -> profileAlertService.getProfileAlertByProfileId(profileId))
		        .collect(Collectors.toList());
		        profileResponseDTOs=convertToProfileAlertDTO(profileAlerts);
		}
		return profileResponseDTOs;
		
	}
	
	public List<ProfileResponseDTO> getAllProfileAlertByFilter(long from,long to,String alertMessage) {
		List<ProfileResponseDTO> profileResponseDTOs=new ArrayList<>(); 
		List<List<ProfileAlertsUI>> profileAlerts=null;
	
		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		List<GrowAreaAssignee> growAreaAssignees = growAreaAssigneeService
		        .getAllGrowAreaAssigneesByUserId(user.getId());
		if (growAreaAssignees != null && !growAreaAssignees.isEmpty())
		{
		List<String> growAreaIds = growAreaAssignees.stream()
		        .map(growAreaAssignee -> growAreaAssignee.getGrowArea().getId().toString())
		        .collect(Collectors.toList());
		if(alertMessage.equals("null"))
		{
			List<Integer> profileIds = profileIdFromGatewayId(growAreaIds);
			profileAlerts = profileIds.stream().map(
			        profileId -> profileAlertService.getAllProfileAlertByProfileIdAndDateRange(profileId,from,to))
			        .collect(Collectors.toList());
		}
		else
		{
		List<Integer> profileIds = profileIdFromGatewayIdAndAlertMessage(growAreaIds,alertMessage);
		if(from != 0L && to != 0L)
		{
			profileAlerts = profileIds.stream().map(
			        profileId -> profileAlertService.getAllProfileAlertByProfileIdAndDateRange(profileId,from,to))
			        .collect(Collectors.toList());
		
		}else
		{
			profileAlerts = profileIds.stream().map(
			        profileId -> profileAlertService.getAllProfileAlertByProfileId(profileId))
			        .collect(Collectors.toList());
		}}
		
		List<ProfileAlertsUI> flat = profileAlerts.stream().flatMap(List::stream).collect(Collectors.toList());
		        profileResponseDTOs=convertToProfileAlertDTO(flat);
		}
		
		return profileResponseDTOs;
		
	}
	
	
	
	public List<ProfileResponseDTO> getProfileAlertByFacilityId(String facilityId) {
		List<ProfileResponseDTO> profileResponseDTOs=null;
		List<Integer> profileIds = profileAlertService.getProfileAlertRepository()
		        .findUniqueProfileIdByFacilityId(facilityId);
		if (profileIds == null || profileIds.isEmpty())
			return Arrays.asList();
		profileIds = getRandomFromList(profileIds);
		List<ProfileAlertsUI> profileAlerts = profileIds.stream().map(
		        profileId -> profileAlertService.getProfileAlertByProfileId(profileId))
		        .collect(Collectors.toList());
		 profileResponseDTOs=convertToProfileAlertDTO(profileAlerts);
		 return profileResponseDTOs;
	}

	public List<ProfileResponseDTO> getAllProfileAlertByFacilityId(String facilityId) {
		List<ProfileResponseDTO> profileResponseDTOs=null;
		List<Integer> profileIds = profileAlertService.getProfileAlertRepository()
		        .findUniqueProfileIdByFacilityId(facilityId);
		if (profileIds == null || profileIds.isEmpty())
			return Arrays.asList();
		List<ProfileAlertsUI> profileAlerts = profileIds.stream().map(
		        profileId -> profileAlertService.getProfileAlertByProfileId(profileId))
		        .collect(Collectors.toList());
		 profileResponseDTOs=convertToProfileAlertDTO(profileAlerts);
		 return profileResponseDTOs;
	}
	
	public List<ProfileResponseDTO> getProfileAlertByContainerId(String containerId) {
		List<ProfileResponseDTO> profileResponseDTOs=null;
		List<Integer> profileIds = profileAlertService.getProfileAlertRepository()
		        .findUniqueProfileIdByContainerId(containerId);
		if (profileIds == null || profileIds.isEmpty())
			return Arrays.asList();
		profileIds = getRandomFromList(profileIds);
		List<ProfileAlertsUI> profileAlerts = profileIds.stream().map(
		        profileId -> profileAlertService.getProfileAlertByProfileId(profileId))
		        .collect(Collectors.toList());
		profileResponseDTOs=convertToProfileAlertDTO(profileAlerts);
		return profileResponseDTOs;
	}
	
	public List<ProfileResponseDTO> getAllProfileAlertByContainerId(String containerId) {
		List<ProfileResponseDTO> profileResponseDTOs=null;
		List<Integer> profileIds = profileAlertService.getProfileAlertRepository()
		        .findUniqueProfileIdByContainerId(containerId);
		if (profileIds == null || profileIds.isEmpty())
			return Arrays.asList();
		List<ProfileAlertsUI> profileAlerts = profileIds.stream().map(
		        profileId -> profileAlertService.getProfileAlertByProfileId(profileId))
		        .collect(Collectors.toList());
		profileResponseDTOs=convertToProfileAlertDTO(profileAlerts);
		return profileResponseDTOs;
	}

	public List<ProfileAlertTimestampDTO> getProfileAlertByProfileId(Integer profileId) {

		long threeHoursAgo = System.currentTimeMillis() - Constants.THREE_HOURS;
		List<ProfileAlert> profileAlerts = profileAlertService.getProfileAlertRepository()
		        .findByProfileIdAndTimestampGreaterThan(profileId, threeHoursAgo);
		if (profileAlerts == null || profileAlerts.isEmpty())
			return Arrays.asList();
		return profileAlerts.stream().map(profileAlert -> new ProfileAlertTimestampDTO(profileAlert.getAlertMessage(),
		        profileAlert.getProperties(), profileAlert.getTimestamp())).collect(Collectors.toList());
	}
	
	public List<ProfileAlertTimestampDTO> getProfileAlertHistoryByProfileId(Integer profileId,long fromTimestamp,long toTimestamp) {

		List<ProfileAlert> profileAlerts = profileAlertService.getProfileAlertRepository()
		        .findProfileAlertsHistory(profileId, fromTimestamp, toTimestamp);
		if (profileAlerts == null || profileAlerts.isEmpty())
			return Arrays.asList();
		return profileAlerts.stream().map(profileAlert -> new ProfileAlertTimestampDTO(profileAlert.getAlertMessage(),
		        profileAlert.getProperties(), profileAlert.getTimestamp())).collect(Collectors.toList());
	}
	

	public ProfileResponseDTO getSpecificProfileAlertByProfileId(Integer profileId) {

		ProfileAlert profileAlert = profileAlertService.getProfileAlertRepository()
		        .findProfileAlertUsingProfileId(profileId);
		List<ProfileResponseDTO> profileResponseDTOs = convertToDTO(Arrays.asList(profileAlert));
		return profileResponseDTOs.get(0);
	}

	public List<ProfileResponseDTO> getProfileAlertByGrowAreaId(String growAreaId) {
		List<ProfileResponseDTO> profileResponseDTOs=null;
		List<Integer> profileIds = profileAlertService.getProfileAlertRepository()
		        .findUniqueProfileIdByGrowAreaId(growAreaId);
		if (profileIds == null || profileIds.isEmpty())
			return Arrays.asList();
		profileIds = getRandomFromList(profileIds);
		List<ProfileAlertsUI> profileAlerts = profileIds.stream().map(
		        profileId -> profileAlertService.getProfileAlertByProfileId(profileId))
		        .collect(Collectors.toList());
		profileResponseDTOs=convertToProfileAlertDTO(profileAlerts);
		return profileResponseDTOs;
	}

	public List<ProfileResponseDTO> getAllProfileAlertByGrowAreaId(String growAreaId) {
		List<ProfileResponseDTO> profileResponseDTOs=null;
		List<Integer> profileIds = profileAlertService.getProfileAlertRepository()
		        .findUniqueProfileIdByGrowAreaId(growAreaId);
		if (profileIds == null || profileIds.isEmpty())
			return Arrays.asList();
		List<ProfileAlertsUI> profileAlerts = profileIds.stream().map(
		        profileId -> profileAlertService.getProfileAlertByProfileId(profileId))
		        .collect(Collectors.toList());
		profileResponseDTOs=convertToProfileAlertDTO(profileAlerts);
		return profileResponseDTOs;
	}
	public List<ProfileResponseDTO> getProfileAlertByGrowSectionId(String growSectionId) {
		List<ProfileResponseDTO> profileResponseDTOs=null;
		List<Integer> profileIds = profileAlertService.getProfileAlertRepository()
		        .findUniqueProfileIdByGrowSectionId(growSectionId);
		if (profileIds == null || profileIds.isEmpty())
			return Arrays.asList();
		profileIds = getRandomFromList(profileIds);
		List<ProfileAlertsUI> profileAlerts = profileIds.stream().map(
		        profileId -> profileAlertService.getProfileAlertByProfileId(profileId))
		        .collect(Collectors.toList());
		profileResponseDTOs=convertToProfileAlertDTO(profileAlerts);
		return profileResponseDTOs;
		
	}

	private List<ProfileResponseDTO> convertToDTO(List<ProfileAlert> profileAlerts) {
		return profileAlerts.stream().map(profileAlert -> {
			ProfileResponseDTO profileByUserDTO = new ProfileResponseDTO();
			profileByUserDTO.setFacilityName(profileAlert.getFacilityName());
			profileByUserDTO.setContainerName(profileAlert.getContainerName());
			profileByUserDTO.setGrowAreaName(profileAlert.getGatewayName());
			profileByUserDTO.setGrowSectionName(profileAlert.getGrowSectionName());
			profileByUserDTO.setProfileId(profileAlert.getProfileId().toString());
			profileByUserDTO.setProfileName(profileAlert.getProfileName());
			profileByUserDTO.setAlertMessage(profileAlert.getAlertMessage());
			profileByUserDTO.setProperties(profileAlert.getProperties());
			profileByUserDTO.setTimestamp(profileAlert.getTimestamp());
			return profileByUserDTO;
		}).collect(Collectors.toList());
	}
	
	private List<ProfileResponseDTO> convertToProfileAlertDTO(List<ProfileAlertsUI> profileAlerts) {
		return profileAlerts.stream().map(profileAlert -> {
			Map<String, String> propertyMap=new HashMap<>();
			propertyMap.put(Constants.SOILPH_KEY, Constants.SOILPH_VALUE);
			propertyMap.put(Constants.BATTERYVOLTAGE_KEY,Constants.BATTERYVOLTAGE_VALUE);
			propertyMap.put(Constants.SOILMOISTURE_KEY,Constants.SOILMOISTURE_VALUE);
			propertyMap.put(Constants.LED1_KEY,Constants.LED1_VALUE);
			propertyMap.put(Constants.LED2_KEY,Constants.LED2_VALUE);
			propertyMap.put(Constants.LED3_KEY,Constants.LED3_VALUE);
			propertyMap.put(Constants.LED4_KEY,Constants.LED4_VALUE);
			propertyMap.put(Constants.LED5_KEY,Constants.LED5_VALUE);
			propertyMap.put(Constants.LED6_KEY,Constants.LED6_VALUE);
			ProfileResponseDTO profileByUserDTO = new ProfileResponseDTO();
			profileByUserDTO.setFacilityName(profileAlert.getFacilityName());
			profileByUserDTO.setContainerName(profileAlert.getContainerName());
			profileByUserDTO.setGrowAreaName(profileAlert.getGatewayName());
			profileByUserDTO.setGrowSectionName(profileAlert.getGrowSectionName());
			profileByUserDTO.setProfileId(profileAlert.getProfileId().toString());
			profileByUserDTO.setProfileName(profileAlert.getProfileName());
			profileByUserDTO.setAlertMessage(profileAlert.getAlertMessage());
			String property=profileAlert.getProperties();
			JSONObject jsonObj = new JSONObject(property);
			Iterator<String> keysItr=jsonObj.keys();
			Map<String, Object> map = new HashMap<>();
			while (keysItr.hasNext()) {
				String key = keysItr.next();
				String putkey=propertyMap.get(key);
		        Object value = jsonObj.get(key); 	
		        map.put(putkey,value);
			}
			try {
				profileByUserDTO.setProperties(mapper.writeValueAsString(map));
			} catch (JsonProcessingException e) {
				LOGGER.error("Exception occured while convert map into string");
			}
			profileByUserDTO.setTimestamp(profileAlert.getTimestamp());
			profileByUserDTO.setProfileVirtualName(profileAlert.getProfileVirtualName());
			return profileByUserDTO;
		}).collect(Collectors.toList());
	}
	
		
	private List<Integer> profileIdFromGatewayId(List<String> gatewayIds) {
		return profileAlertService.getProfileAlertRepository()
		        .findUniqueProfileIdByGatewayId(new ArrayList<String>(new HashSet<String>(gatewayIds)));
}

	private List<Integer> profileIdFromGatewayIdAndAlertMessage(List<String> gatewayIds,String alertMessage) {
		return profileAlertService.getProfileAlertRepository()
		        .findUniqueProfileIdByGatewayIdAndAlertMessage(gatewayIds,alertMessage);
}
	private List<Integer> getRandomFromList(List<Integer> profileIds) {
		List<Integer> randomProfileIds;
		if (profileIds == null || profileIds.isEmpty()) {
			return Arrays.asList();
		} else {
			if(profileIds.size()<=5)
			{
				randomProfileIds=getrandid(profileIds);
			}
			else {
				randomProfileIds=getrandfiveid(profileIds);
			}
			return new ArrayList<>(new HashSet<Integer>(randomProfileIds));
		}
	}
	private List<Integer> getrandfiveid(List<Integer> profileIds)
	{   List<Integer> randomProfileIds = new ArrayList<>();
		for (int i = 0; i < 5; i++) 	{
			int randnum=new Random().nextInt(profileIds.size());
			int listnum=profileIds.get(randnum);
			while(randomProfileIds.contains(listnum))
			{
				randnum=new Random().nextInt(profileIds.size());
				listnum=profileIds.get(randnum);
			}
			randomProfileIds.add(listnum);
			LOGGER.info("i value={} and List={}", i,randomProfileIds);
		}
		return randomProfileIds;
	}
	
	private List<Integer> getrandid(List<Integer> profileIds)
	{
		List<Integer> randomProfileIds = new ArrayList<>();
		for (int i = 0; i < profileIds.size(); i++) 	{
			int randnum=new Random().nextInt(profileIds.size());
			int listnum=profileIds.get(randnum);
			while(randomProfileIds.contains(listnum))
			{
				randnum=new Random().nextInt(profileIds.size());
				listnum=profileIds.get(randnum);
			}
			randomProfileIds.add(listnum);
			LOGGER.info("i value={} and List={}", i,randomProfileIds);
		}
		return randomProfileIds;
	}
	
	public void deleteProfileAlertsByGatewayId(int gatewayId)
	{
		String gatewayId1=Integer.toString(gatewayId); 
		profileAlertService.getProfileAlertRepository().deleteProfileAlertsByGatewayId(gatewayId1);
	}

	public void deleteProfileAlertsByProfileId(int profileId)
	{
		profileAlertService.getProfileAlertRepository().deleteProfileAlertsByProfileId(profileId);
	}
	
}
