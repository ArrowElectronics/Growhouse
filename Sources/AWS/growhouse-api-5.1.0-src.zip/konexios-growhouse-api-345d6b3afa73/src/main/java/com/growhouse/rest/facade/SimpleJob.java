package com.growhouse.rest.facade;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.growhouse.rest.KonexiosConfig;
import com.growhouse.rest.dto.DeviceGroupDTO;
import com.growhouse.rest.dto.GroupChannelValuesDTO;
import com.growhouse.rest.dto.LedNodeGroupChannelConfigurationDTO;
import com.growhouse.rest.entity.LedNodeGroupProfile;
import com.growhouse.rest.services.impl.LedNodeService;
import com.growhouse.rest.utils.Constants;
import com.growhouse.rest.utils.LedNodeChannelMapping;

@Component
public class SimpleJob implements Job {

	@Autowired
	private KonexiosConfig config;

	private static final Logger LOGGER = LogManager.getLogger(SimpleJob.class);

	public void execute(JobExecutionContext context) throws JobExecutionException {
		JobDataMap dataMap = context.getJobDetail().getJobDataMap();
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			Integer groupId = (Integer) dataMap.get("groupId");
			Integer profileId = (Integer) dataMap.get("profileId");
			Integer preset = (Integer) dataMap.get("preset");
			LedNodeService lednodeService = (LedNodeService) dataMap.get("obj");
			LedNodeFacade lednodeFacade = (LedNodeFacade) dataMap.get("lednodeFacade");
			LedNodeGroupChannelConfigurationDTO dbLedGroup = lednodeFacade.getLedGroupById(groupId);
			if (dbLedGroup != null) {

				List<DeviceGroupDTO> devices = dbLedGroup.getDevices();
				LOGGER.info("scheduled devices list -:" + devices);
				if (!devices.isEmpty()) {
					LedNodeGroupProfile profile = lednodeService.getGroupProfileByProfileId(profileId);
					GroupChannelValuesDTO groupChanelValuesDTO = objectMapper.readValue(profile.getChannelValues(),
							GroupChannelValuesDTO.class);
					GroupChannelValuesDTO presetGroupChannel = calculatePresetValues(groupChanelValuesDTO, preset);
					LOGGER.info("Preset channel configuration---:" + presetGroupChannel);
					Map<String, Object> deviceStates = setLedGroupDeviceState(presetGroupChannel);
					for (DeviceGroupDTO device : devices) {
						String url = config.buildSetDeviceStateUrl(device.getDeviceHId());
						LOGGER.info("URL for arrow:-" + url);
						try {
							HttpHeaders headers = new HttpHeaders();
							headers.setContentType(MediaType.APPLICATION_JSON);
							headers.set(config.getAuthTokenKey(), config.getAuthToken());
							LOGGER.info("LED channel confi payload for arrow connect----" + deviceStates);
							HttpEntity<Map> entity = new HttpEntity<>(deviceStates, headers);
							RestTemplate restTemplate = new RestTemplate();
							ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.POST, entity,
									String.class);
							if (response.getStatusCode() != HttpStatus.OK) {
								LOGGER.info("exception occured when called Arrow api---" + response);
							} else {
								LOGGER.info("Set device state request sent successfully---" + device.getDeviceHId()
										+ "time---" + new Date());
							}
						} catch (HttpStatusCodeException httpStatusCodeException) {
							LOGGER.info(
									"This device hid device does not exist on arrow portal--" + device.getDeviceHId());
						} catch (Exception exception) {
							LOGGER.info("Internal server error--" + exception.getMessage());
						}
					}
				}

			}
		} catch (NullPointerException exception) {
			LOGGER.info("Null pointer exception" + exception);
		} catch (IOException e) {
			LOGGER.info("parse error");
		}
	}

	public Map<String, Object> setLedGroupDeviceState(GroupChannelValuesDTO eventPayload) {
		ObjectMapper objectMapper = new ObjectMapper();
		Map<String, String> states = new HashMap<>();
		states.put(LedNodeChannelMapping.valueOf(Constants.CHANNEL1).showLedNodeChannelMappingValue(),
				eventPayload.getLed1().toString());
		states.put(LedNodeChannelMapping.valueOf(Constants.CHANNEL2).showLedNodeChannelMappingValue(),
				eventPayload.getLed2().toString());
		states.put(LedNodeChannelMapping.valueOf(Constants.CHANNEL3).showLedNodeChannelMappingValue(),
				eventPayload.getLed3().toString());
		states.put(LedNodeChannelMapping.valueOf(Constants.CHANNEL4).showLedNodeChannelMappingValue(),
				eventPayload.getLed4().toString());
		states.put(LedNodeChannelMapping.valueOf(Constants.CHANNEL5).showLedNodeChannelMappingValue(),
				eventPayload.getLed5().toString());
		states.put(LedNodeChannelMapping.valueOf(Constants.CHANNEL6).showLedNodeChannelMappingValue(),
				eventPayload.getLed6().toString());
		Map<String, Object> deviceState = new HashMap<>();
		String isoDatePattern = "yyyy-MM-dd'T'HH:mm:dd'Z'";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(isoDatePattern);
		deviceState.put("timestamp", simpleDateFormat.format(new Date()));

		try {
			deviceState.put("states", objectMapper.readValue(objectMapper.writeValueAsString(states), Map.class));
		} catch (IOException exception) {
			LOGGER.error("Error occurred while manipulating Json {}", exception);
		}

		return deviceState;
	}

	public GroupChannelValuesDTO calculatePresetValues(GroupChannelValuesDTO channel, int preset) {
		int ch1 = Math.round(((preset / 100.0f) * channel.getLed1()));
		int ch2 = Math.round(((preset / 100.0f) * channel.getLed2()));
		int ch3 = Math.round(((preset / 100.0f) * channel.getLed3()));
		int ch4 = Math.round(((preset / 100.0f) * channel.getLed4()));
		int ch5 = Math.round(((preset / 100.0f) * channel.getLed5()));
		int ch6 = Math.round(((preset / 100.0f) * channel.getLed6()));
		channel.setLed1(ch1);
		channel.setLed2(ch2);
		channel.setLed3(ch3);
		channel.setLed4(ch4);
		channel.setLed5(ch5);
		channel.setLed6(ch6);
		return channel;
	}
}