/**
 * 
 */
package com.growhouse.rest.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author dharita.chokshi
 *
 */
public class DeviceTypeDTO {

	private Integer id;
	@JsonProperty("device_type_name")
	private String deviceTypeName;
	
	@JsonProperty("virtual_device_type_name")
	private String virtualDeviceTypeName;

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the deviceTypeName
	 */
	public String getDeviceTypeName() {
		return deviceTypeName;
	}

	/**
	 * @param deviceTypeName
	 *            the deviceTypeName to set
	 */
	public void setDeviceTypeName(String deviceTypeName) {
		this.deviceTypeName = deviceTypeName;
	}

	public String getVirtualDeviceTypeName() {
		return virtualDeviceTypeName;
	}

	public void setVirtualDeviceTypeName(String virtualDeviceTypeName) {
		this.virtualDeviceTypeName = virtualDeviceTypeName;
	}

	@Override
	public String toString() {
		return "DeviceTypeDTO [id=" + id + ", deviceTypeName=" + deviceTypeName + ", virtualDeviceTypeName="
				+ virtualDeviceTypeName + "]";
	}

	
	
}
