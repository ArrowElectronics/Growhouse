package com.growhouse.rest.facade;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import org.springframework.web.util.UriComponents;

import com.growhouse.rest.KonexiosConfig;
import com.growhouse.rest.dto.CreateProfileActionDTO;
import com.growhouse.rest.dto.ProfileActionParametersDTO;
import com.growhouse.rest.entity.Profile;
import com.growhouse.rest.entity.kronos.KronosData;
import com.growhouse.rest.entity.kronos.KronosResponse;
import com.growhouse.rest.services.impl.ProfileService;
import com.growhouse.rest.utils.Constants;

@Component
public class ProfileAsyncFacade {

	@Autowired
	private ProfileService profileService;

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private KonexiosConfig config;

	public static final Logger LOGGER = LoggerFactory.getLogger(ProfileAsyncFacade.class);

	@Async
	public void createRuleToArrowConnect(Profile profile) {
		try {
			Thread.sleep(50000);
			String deviceHid = getDeviceHIdByDeviceUId(profile.getName());
			setActionOnProfile(profile.getGrowSection().getId().toString(), deviceHid);
		} catch (Exception exception) {
			LOGGER.error("Error Occured {}", exception.getMessage());
			profileService.getProfileRepository().delete(profile);
		}

	}

	private String getDeviceHIdByDeviceUId(String deviceUId) {
		String url = config.buildDeviceHidByUidUrl(deviceUId);
		String hid = null;
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set(config.getAuthTokenKey(), config.getAuthToken());

			HttpEntity<String> entity = new HttpEntity<>(headers);
			ResponseEntity<KronosResponse> response = restTemplate.exchange(url, HttpMethod.GET, entity,
					KronosResponse.class);
			if (response.getStatusCode() == HttpStatus.OK) {
				List<KronosData> data = response.getBody().getData();
				hid = data.get(0).getHid();
			}

		} catch (Exception exception) {
			throw new HttpClientErrorException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to fetch Device HId");
		}
		return hid;
	}

	private void setActionOnProfile(String growSectionId, String deviceHid) {
		String url = config.buildCreateActionDeviceUrl(deviceHid);
		try {
			UriComponents uri = ServletUriComponentsBuilder.fromCurrentRequest().build();
			String alertPostBackUrl = uri.getScheme() + "://" + uri.getHost() + ":" + uri.getPort()
					+ Constants.ALERT_POSTBACK_API_PATH;
			LOGGER.info("alertPostBackUrl: " + alertPostBackUrl);

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set(config.getAuthTokenKey(), config.getAuthToken());
			CreateProfileActionDTO createProfileActionDTO = new CreateProfileActionDTO();
			createProfileActionDTO.setCriteria(Constants.GROWSECTION_ID + " == " + growSectionId);
			createProfileActionDTO.setEnabled(true);
			createProfileActionDTO.setExpiration(10);
			createProfileActionDTO.setNoTelemetry(false);
			createProfileActionDTO.setNoTelemetrySeconds(0);
			createProfileActionDTO.setSystemName(Constants.POSTBACK_URL);
			createProfileActionDTO.setParameters(new ProfileActionParametersDTO(alertPostBackUrl,
					Constants.ALERT_REQUEST_BODY_VALUE, Constants.CONTENT_TYPE_VALUE));

			HttpEntity<CreateProfileActionDTO> entity = new HttpEntity<>(createProfileActionDTO, headers);
			ResponseEntity<KronosResponse> response = restTemplate.exchange(url, HttpMethod.POST, entity,
					KronosResponse.class);
			if (response.getStatusCode() != HttpStatus.OK) {
				throw new HttpClientErrorException(HttpStatus.INTERNAL_SERVER_ERROR,
						"Unable to create action on Profile Device");
			} else {
				LOGGER.info("Successfully created action on profile device");
			}

		} catch (Exception exception) {
			throw new HttpClientErrorException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to fetch Device HId");
		}
	}
}
