package com.growhouse.rest.dto;



public class DeviceStatusDTO {

	private String deviceUid;

	private boolean status;

	public String getDeviceUid() {
		return deviceUid;
	}

	public void setDeviceUid(String deviceUid) {
		this.deviceUid = deviceUid;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "DeviceStatusDTO [deviceUid=" + deviceUid + ", status=" + status + "]";
	}

	
	
	
	
}