/**
 * 
 */
package com.growhouse.rest.facade;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Component;

import com.growhouse.rest.dto.GrowAreaTypeDTO;
import com.growhouse.rest.entity.GrowAreaType;
import com.growhouse.rest.services.IGrowAreaTypeService;

/**
 * @author dharita.chokshi
 *
 */
@Component
public class GrowAreaTypeFacade {

	public static final Logger LOGGER = LoggerFactory.getLogger(GrowAreaTypeFacade.class);

	@Autowired
	private IGrowAreaTypeService growAreaTypeService;

	@Autowired
	private ModelMapper modelMapper;

	public List<GrowAreaTypeDTO> getGrowAreaTypes() {
		List<GrowAreaTypeDTO> growAreaTypeDTOs = new ArrayList<>();
		List<GrowAreaType> growAreaTypes = growAreaTypeService.getAllGrowAreaTypes();
		if (growAreaTypes != null && !growAreaTypes.isEmpty()) {
			growAreaTypeDTOs = growAreaTypes.stream().map(this::convertEntityToDTO)
					.collect(Collectors.toList());
		}
		return growAreaTypeDTOs;
	}

	public GrowAreaTypeDTO getGrowAreaTypeById(int growAreaTypeId) {
		GrowAreaTypeDTO growAreaTypeDTO = null;
		GrowAreaType growAreaType = growAreaTypeService.getGrowAreaTypeById(growAreaTypeId);
		if (growAreaType != null) {
			growAreaTypeDTO = convertEntityToDTO(growAreaType);
		}
		return growAreaTypeDTO;
	}

	private GrowAreaTypeDTO convertEntityToDTO(GrowAreaType growAreaType) {
		return modelMapper.map(growAreaType, GrowAreaTypeDTO.class);
	}

}
