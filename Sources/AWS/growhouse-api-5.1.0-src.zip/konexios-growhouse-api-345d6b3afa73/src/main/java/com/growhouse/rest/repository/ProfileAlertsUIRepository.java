/**
 * 
 */
package com.growhouse.rest.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.growhouse.rest.entity.ProfileAlertsUI;

/**
 * @author einfochips
 *
 */
@Repository
public interface ProfileAlertsUIRepository extends JpaRepository<ProfileAlertsUI, Integer> {

	@Query(value = "SELECT pa.*, p.profile_name as profile_virtual_name FROM profile_alerts as pa \r\n"
			+ "join profile as p on pa.profile_id = p.id and pa.profile_id = ?1 ORDER BY timestamp DESC Limit 1", nativeQuery = true)
	public ProfileAlertsUI getProfileAlertByProfileId(Integer profileId);
	
	
	@Query(value = "SELECT pa.*, p.profile_name as profile_virtual_name FROM profile_alerts as pa \r\n"
			+ "join profile as p on pa.profile_id = p.id and pa.profile_id = ?1 ORDER BY timestamp DESC Limit 1", nativeQuery = true)
	public List<ProfileAlertsUI> getAllProfileAlertByProfileId(Integer profileId);
	
	@Query(value = "SELECT pa.*, p.profile_name as profile_virtual_name FROM profile_alerts as pa \r\n"
			+ "join profile as p on pa.profile_id = p.id and pa.profile_id = ?1 and timestamp >= ?2 and timestamp <= ?3 ORDER BY timestamp DESC Limit 1", nativeQuery = true)
	public List<ProfileAlertsUI> getAllProfileAlertByProfileIdDateRange(Integer profileId,long from,long to);
	
}
