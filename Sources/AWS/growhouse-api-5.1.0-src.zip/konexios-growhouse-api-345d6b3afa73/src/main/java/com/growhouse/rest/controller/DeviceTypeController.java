/**
 * 
 */
package com.growhouse.rest.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpServerErrorException;

import com.growhouse.rest.dto.DeviceTypeDTO;
import com.growhouse.rest.facade.DeviceTypeFacade;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author dharita.chokshi
 *
 */

@RestController
@RequestMapping("/api/devicetypes")
@Transactional
public class DeviceTypeController {

	public static final Logger LOGGER = LoggerFactory.getLogger(DeviceTypeController.class);

	@Autowired
	private DeviceTypeFacade deviceTypeFacade;

	/* Query-- select * from device_types where is_active=true */
	@GetMapping(value = "")
	@ApiOperation(value = "View a list of active device types")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "List retrieved successfully"),
			@ApiResponse(code = 204, message = "Empty list") })
	public ResponseEntity<List<DeviceTypeDTO>> getDeviceTypes() {
		ResponseEntity<List<DeviceTypeDTO>> responseEntity;
		try {
			List<DeviceTypeDTO> deviceTypeDTOs = deviceTypeFacade.getDeviceTypes();
			if (deviceTypeDTOs == null || deviceTypeDTOs.isEmpty())
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(deviceTypeDTOs, HttpStatus.OK);
		} catch (Exception exception) {
			throw new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/*
	 * Query-- select * from device_types where device_type_id=? and is_active=true
	 */
	@GetMapping(value = "/{deviceTypeId}")
	@ApiOperation(value = "View device type based on deviceTypeId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Device type retrieved successfully"),
			@ApiResponse(code = 403, message = "Device type is inactive") })
	public ResponseEntity<DeviceTypeDTO> getDeviceTypeByDeviceTypeId(
			@PathVariable("deviceTypeId") Integer deviceTypeId) {
		ResponseEntity<DeviceTypeDTO> responseEntity;
		try {
			DeviceTypeDTO deviceTypeDTO = deviceTypeFacade.getDeviceTypeById(deviceTypeId);
			if (deviceTypeDTO == null)
				responseEntity = new ResponseEntity<>(HttpStatus.NOT_FOUND);
			else
				responseEntity = new ResponseEntity<>(deviceTypeDTO, HttpStatus.OK);
		} catch (Exception exception) {
			throw new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}
}
