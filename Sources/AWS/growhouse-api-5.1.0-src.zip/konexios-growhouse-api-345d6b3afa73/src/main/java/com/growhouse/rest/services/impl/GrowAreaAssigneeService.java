/**
 * 
 */
package com.growhouse.rest.services.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;

import com.growhouse.rest.entity.GrowAreaAssignee;
import com.growhouse.rest.repository.GrowAreaAssigneeRepository;
import com.growhouse.rest.services.IGrowAreaAssigneeService;


/**
 * @author dharita.chokshi
 *
 */
@Service
public class GrowAreaAssigneeService implements IGrowAreaAssigneeService {

	@Autowired
	private GrowAreaAssigneeRepository growAreaAssigneeRepository;

	
	public List<GrowAreaAssignee> getActiveGrowAreaAssignees() {
		return growAreaAssigneeRepository.findByIsActiveTrue();
	}

	
	public List<GrowAreaAssignee> getAllGrowAreaAssignees() {
		return growAreaAssigneeRepository.findAll();
	}

	
	public List<GrowAreaAssignee> createGrowAreaAssigneesInBatch(List<GrowAreaAssignee> growAreaAssignees) {
		return growAreaAssigneeRepository.saveAll(growAreaAssignees);
	}

	
	public GrowAreaAssignee deleteGrowAreaAssignee(int growAreaId, int userId) {
		GrowAreaAssignee deletedGrowAreaAssignee=null;
		Optional<GrowAreaAssignee> optional = growAreaAssigneeRepository.findByGrowAreaIdAndUserId(growAreaId, userId);
		if (optional.isPresent() && optional.get().isActive()) {
			GrowAreaAssignee growAreaAssignee = optional.get();
			growAreaAssignee.setActive(false);
			deletedGrowAreaAssignee = growAreaAssigneeRepository.save(growAreaAssignee);
		} else {
			throw new HttpClientErrorException(HttpStatus.NOT_FOUND, "Requested growAreaAssignee not found");
		}
		return deletedGrowAreaAssignee;
	}

	public void deleteGrowAreaAssigneeByGatewayId(int gatewayId)
	{
		growAreaAssigneeRepository.deleteGrowAreaAssigneeByGatewayId(gatewayId);
	}
	
	@Override
	public List<GrowAreaAssignee> getAllGrowAreaAssigneesByGrowAreaId(int growAreaId) {
		return growAreaAssigneeRepository.findByGrowAreaIdAndIsActiveTrue(growAreaId);
	}

	@Override
	public List<GrowAreaAssignee> getAllGrowAreaAssigneesByUserId(int userId) {
		return growAreaAssigneeRepository.findByUserIdAndIsActiveTrue(userId);
	}

	@Override
    public List<GrowAreaAssignee> getAllGrowAreaAssigneesByContainerId(int userId,int containerId) {
        return growAreaAssigneeRepository.findByUserIdAndContainerIdAndGrowAreaIsActiveTrueAndIsActiveTrue(userId, containerId);
    }
    
	//@Override
    public int countOfAllGrowAreaByContainerId(int userId,int containerId) {
        return growAreaAssigneeRepository.countByUserIdAndContainerIdAndGrowAreaIsActiveTrueAndIsActiveTrue(userId, containerId);
    }
	
    @Override
    public List<GrowAreaAssignee> getAllGrowAreaAssigneesByFacilityId(int userId,int facilityId) {
        return growAreaAssigneeRepository.findByUserIdAndFacilityIdAndGrowAreaIsActiveTrueAndIsActiveTrue(userId, facilityId);
    }

    public int countOfAllGrowAreaAssigneesByFacilityId(int userId,int facilityId) {
        return growAreaAssigneeRepository.countByUserIdAndFacilityIdAndGrowAreaIsActiveTrueAndIsActiveTrue(userId, facilityId);
    }
    
	@Override
	public List<GrowAreaAssignee> getAllGrowAreaAssigneesByUserIdAndGrowAreaIsActive(int userId) {
		return growAreaAssigneeRepository.findByUserIdAndIsActiveTrueAndGrowAreaIsActiveTrue(userId);
	}
	
}
