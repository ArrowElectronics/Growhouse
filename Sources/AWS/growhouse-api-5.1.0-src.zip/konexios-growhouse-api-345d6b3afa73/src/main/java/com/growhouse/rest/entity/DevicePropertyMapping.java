package com.growhouse.rest.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="device_property_mapping")
public class DevicePropertyMapping implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1137737702431823233L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="device_id")
	private Device device;
	

	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name = "device_property_id")
	private DevicePropertyDetails devicePropertyDetails;


	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public Device getDevice() {
		return device;
	}


	public void setDevice(Device device) {
		this.device = device;
	}


	public DevicePropertyDetails getDevicePropertyDetails() {
		return devicePropertyDetails;
	}


	public void setDevicePropertyDetails(DevicePropertyDetails devicePropertyDetails) {
		this.devicePropertyDetails = devicePropertyDetails;
	}


	@Override
	public String toString() {
		return "DevicePropertyMapping [id=" + id + ", device=" + device + ", devicePropertyDetails="
				+ devicePropertyDetails + "]";
	}


	
	
	
}
