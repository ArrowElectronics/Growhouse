package com.growhouse.rest.services;
import com.growhouse.rest.entity.Profile;
import com.growhouse.rest.repository.ProfileRepository;

public interface IProfileService {

	public Profile createProfile(Profile profile);
	
	public ProfileRepository getProfileRepository();
	
	public Profile updateProfile(Profile profile);
}
