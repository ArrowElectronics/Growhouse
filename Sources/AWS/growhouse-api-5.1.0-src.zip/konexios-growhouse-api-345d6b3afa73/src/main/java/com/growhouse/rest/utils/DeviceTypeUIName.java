package com.growhouse.rest.utils;

public enum DeviceTypeUIName {

	SoilNode("soil_nodes_count"),LedNode("light_nodes_count"), LightShield("light_shields_count"), HumidityNode("humidity_nodes_count"),SCMNode("scms_count");
	
	 String devicePrefixName;
	 DeviceTypeUIName(String devicePrefixName) {
		   this.devicePrefixName = devicePrefixName;
	   }
	 public String showDevicePrefixValue() {
		   return devicePrefixName;
	   }
}
