package com.growhouse.rest.services;

import com.growhouse.rest.repository.ProfileAlertRepository;

public interface IProfileAlertService {

	public ProfileAlertRepository getProfileAlertRepository();
}
