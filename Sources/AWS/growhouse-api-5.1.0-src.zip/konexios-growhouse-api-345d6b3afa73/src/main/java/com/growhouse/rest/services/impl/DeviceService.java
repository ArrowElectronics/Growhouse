/**
 * 
 */
package com.growhouse.rest.services.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.growhouse.rest.KonexiosConfig;
import com.growhouse.rest.dto.GroupChannelConfigurationDTO;
import com.growhouse.rest.entity.Device;
import com.growhouse.rest.entity.DeviceProperties;
import com.growhouse.rest.entity.DevicePropertyDetails;
import com.growhouse.rest.entity.DevicePropertyMapping;
import com.growhouse.rest.entity.GrowAreaAssignee;
import com.growhouse.rest.entity.GrowSectionDevice;
import com.growhouse.rest.entity.LedNodeChannelConfiguration;
import com.growhouse.rest.entity.LedNodeHistory;
import com.growhouse.rest.entity.LedNodeProfile;
import com.growhouse.rest.entity.User;
import com.growhouse.rest.entity.kronos.KronosData;
import com.growhouse.rest.entity.kronos.KronosResponse;
import com.growhouse.rest.entity.kronos.TelemetryItem;
import com.growhouse.rest.repository.DevicePropertyDetailsRepository;
import com.growhouse.rest.repository.DevicePropertyMappingRepository;
import com.growhouse.rest.repository.DeviceRepository;
import com.growhouse.rest.repository.GrowSectionDeviceRepository;
import com.growhouse.rest.repository.LedNodeChannelConfigRepository;
import com.growhouse.rest.repository.LedNodeDesiredValueRepository;
import com.growhouse.rest.repository.LedNodeProfileRepository;
import com.growhouse.rest.services.IDeviceService;
import com.growhouse.rest.services.IGrowAreaAssigneeService;
import com.growhouse.rest.utils.Command;
import com.growhouse.rest.utils.Constants;
import com.growhouse.rest.utils.DeviceTypePrefix;

/**
 * @author dharita.chokshi
 *
 */
@Service
public class DeviceService implements IDeviceService {

	private static final Logger LOGGER = LogManager.getLogger(DeviceService.class);

	@Autowired
	private DeviceRepository deviceRepository;

	@Autowired
	private DevicePropertyDetailsRepository devicePropertyDetailsRepository;

	@Autowired
	private LedNodeChannelConfigRepository ledNodeChannelConfigRepository;

	@Autowired
	private DevicePropertyMappingRepository devicePropertyMappingRepository;

	@Autowired
	private LedNodeProfileRepository ledNodeProfileRepository;

	@Autowired
	private IGrowAreaAssigneeService growAreaAssigneeService;

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private ObjectMapper mapper;

	@Autowired
	private LedNodeDesiredValueRepository ledNodeDesiredValueRepository;

	@Autowired
	private GrowSectionDeviceRepository growSectionDeviceRepository;

	@Autowired
	private KonexiosConfig config;

	public List<Device> getActiveDevices() {
		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		List<GrowAreaAssignee> growAreaAssignees = growAreaAssigneeService
				.getAllGrowAreaAssigneesByUserId(user.getId());
		List<Integer> growAreaIdList = growAreaAssignees.stream()
				.map(growAreaAssinee -> growAreaAssinee.getGrowArea().getId()).collect(Collectors.toList());
		if (growAreaIdList != null && !growAreaIdList.isEmpty()) {
			return deviceRepository.findByIsActiveTrueAndGrowAreaIdIn(growAreaIdList);
		} else {
			throw new HttpClientErrorException(HttpStatus.NO_CONTENT, "this user have not access of any devices");
		}
	}

	public List<Device> getAllDevices() {
		return deviceRepository.findAll();
	}

	public void updateDeviceStatus(boolean status, String uid) {
		deviceRepository.updateDeviceLatestStatus(status, uid);
	}

	public List<Device> getDevicesByGrowSectionId(int growSectionId) {
		return deviceRepository.findByGrowSectionIdAndIsActiveTrue(growSectionId);
	}

	public List<Device> getDevicesByGrowAreaId(int growAreaId) {
		return deviceRepository
				.findByIsActiveTrueAndGrowAreaIsActiveTrueAndGrowAreaIdOrderByCreatedTimestampDesc(growAreaId);
	}

	public List<Device> getDevicesByGrowAreaIdAndDeviceTypeId(int growAreaId, int deviceTypeId) {
		return deviceRepository.findByGrowAreaIdAndDeviceTypeIdAndIsActiveTrueOrderByCreatedTimestampDesc(growAreaId,
				deviceTypeId);
	}

	public List<Device> getDevicesByContainerId(int containerId) {

		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		List<GrowAreaAssignee> growAreaAssignees = growAreaAssigneeService
				.getAllGrowAreaAssigneesByContainerId(user.getId(), containerId);
		List<Integer> growAreaIdList = growAreaAssignees.stream()
				.map(growAreaAssinee -> growAreaAssinee.getGrowArea().getId()).collect(Collectors.toList());
		if (growAreaIdList != null && !growAreaIdList.isEmpty()) {
			return deviceRepository.findByIsActiveTrueAndGrowAreaIdIn(growAreaIdList);
		} else {
			throw new HttpClientErrorException(HttpStatus.NO_CONTENT, "this user have not access of any devices");
		}
	}

	public int getDevicesCountByContainerId(int containerId) {

		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		List<GrowAreaAssignee> growAreaAssignees = growAreaAssigneeService
				.getAllGrowAreaAssigneesByContainerId(user.getId(), containerId);
		List<Integer> growAreaIdList = growAreaAssignees.stream()
				.map(growAreaAssinee -> growAreaAssinee.getGrowArea().getId()).collect(Collectors.toList());
		if (growAreaIdList != null && !growAreaIdList.isEmpty()) {
			return deviceRepository.countByIsActiveTrueAndGrowAreaIdIn(growAreaIdList);
		} else {
			throw new HttpClientErrorException(HttpStatus.NO_CONTENT, Constants.DEVICE_NOT_ACCESSIBLE);
		}
	}

	public List<Device> getDevicesByFacilityId(int facilityId) {
		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		List<GrowAreaAssignee> growAreaAssignees = growAreaAssigneeService
				.getAllGrowAreaAssigneesByFacilityId(user.getId(), facilityId);
		List<Integer> growAreaIdList = growAreaAssignees.stream()
				.map(growAreaAssinee -> growAreaAssinee.getGrowArea().getId()).collect(Collectors.toList());
		if (growAreaIdList != null && !growAreaIdList.isEmpty()) {
			return deviceRepository.findByIsActiveTrueAndGrowAreaIdIn(growAreaIdList);
		} else {
			throw new HttpClientErrorException(HttpStatus.NO_CONTENT, Constants.DEVICE_NOT_ACCESSIBLE);
		}

	}

	public List<Device> getDevicesByDeviceTypeId(int deviceTypeId) {
		return deviceRepository.findByDeviceTypeIdAndIsActiveTrue(deviceTypeId);
	}

	public Device getDeviceById(int id) {
		Optional<Device> optional = deviceRepository.findByIdAndIsActiveTrue(id);
		return optional.isPresent() ? optional.get() : null;
	}

	public Device createDevice(Device device) {
		if (device.getDeviceHId() == null) {
			String hid = getDeviceHIdByDeviceUId(device.getDeviceUId());
			device.setDeviceHId(hid);
		}
		device = deviceRepository.save(device);
		if (device.getPrefixKeyword() == null)
			device.setPrefixKeyword(
					DeviceTypePrefix.valueOf(device.getDeviceType().getDeviceTypeName()) + "_" + device.getId());
		device = deviceRepository.save(device);
		return device;
	}

	public Device updateDevice(Device device) {
		if (device.getDeviceHId() == null) {
			String hid = getDeviceHIdByDeviceUId(device.getDeviceUId());
			device.setDeviceHId(hid);
		}
		return deviceRepository.save(device);
	}

	public Device deleteDevice(int id) {
		Device deletedDevice = null;
		Optional<Device> optional = deviceRepository.findById(id);
		if (optional.isPresent() && optional.get().isActive()) {
			String deviceHId = null;
			String gatewayDeviceHid = null;
			String gatewayHid = null;
			Device device = optional.get();
			if (device != null) {
				deviceHId = device.getDeviceHId();
				gatewayDeviceHid = device.getGrowArea().getGatewayDeviceHId();
				gatewayHid = device.getGrowArea().getGrowAreaHId();
				if (gatewayDeviceHid == null)
					gatewayDeviceHid = fetchgatewayDefaultDevice(device.getGrowArea().getGrowAreaHId());

				try {
					deletedDevice = deleteDeviceSubFunction(gatewayHid, gatewayDeviceHid, deviceHId, device);

				} catch (HttpStatusCodeException httpStatusCodeException) {
					throw new HttpClientErrorException(httpStatusCodeException.getStatusCode(),
							httpStatusCodeException.getStatusText());
				} catch (Exception exception) {
					throw new HttpClientErrorException(HttpStatus.INTERNAL_SERVER_ERROR, exception.getMessage());
				}
			}
		}
		return deletedDevice;
	}

	public Device deleteDeviceSubFunction(String gatewayHid, String gatewayDeviceHid, String deviceHId, Device device)
			throws JsonProcessingException {
		Device deletedDevice = null;
		String url1 = config.buildDeviceCommandUrl(gatewayHid, gatewayDeviceHid);
		HttpHeaders headers1 = new HttpHeaders();
		headers1.setContentType(MediaType.APPLICATION_JSON);
		headers1.set(config.getAuthTokenKey(), config.getAuthToken());
		Map<String, Object> map = new HashMap<>();
		map.put(Constants.COMMAND, Command.deleteDevice);
		map.put(Constants.DEVICE_HID, gatewayDeviceHid);
		map.put(Constants.MESSAGE_EXPIRATION, 10);
		Map<String, String> payloadMap = new HashMap<>();
		payloadMap.put(Constants.DEVICE_HID, deviceHId);
		map.put(Constants.PAYLOAD, String.valueOf(mapper.writeValueAsString(payloadMap)));
		HttpEntity<Map<?, ?>> entity1 = new HttpEntity<>(map, headers1);
		try {
			restTemplate.exchange(url1, HttpMethod.POST, entity1, String.class);
			LOGGER.info("Request send to saleni.");
		} catch (HttpClientErrorException httpClientErrorException) {
			LOGGER.info("Device does not exist on Arrow Portal");
		}
		device.setActive(false);
		device.setStatus(false);
		deletedDevice = deviceRepository.save(device);
		return deletedDevice;
	}

	public void deleteAllGrowAreaDevices(int gatewayId) {
		try {
			List<Device> devices = getDevicesByGrowAreaId(gatewayId);
			if (devices != null && !devices.isEmpty()) {
				for (Device device : devices) {
					try {
						deleteDevice(device.getId());
						Thread.sleep(4000);
					} catch (HttpClientErrorException httpClientErrorException) {
						LOGGER.info("Device does not exist on Arrow Portal", httpClientErrorException);
					}
				}
			}
		} catch (Exception exception) {
			LOGGER.info(exception.getMessage());
		}

	}

	private String getDeviceHIdByDeviceUId(String deviceUId) {
		String url = config.buildDeviceHidByUidUrl(deviceUId);
		String hid = null;
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set(config.getAuthTokenKey(), config.getAuthToken());

			HttpEntity<String> entity = new HttpEntity<>(headers);
			ResponseEntity<KronosResponse> response = restTemplate.exchange(url, HttpMethod.GET, entity,
					KronosResponse.class);
			if (response.getStatusCode() == HttpStatus.OK) {
				List<KronosData> data = response.getBody().getData();
				hid = data.get(0).getHid();
			}

		} catch (Exception exception) {
			throw new HttpClientErrorException(HttpStatus.INTERNAL_SERVER_ERROR,
					Constants.FETCH_DEVICE_ID_ERROR_MESSAGE);
		}
		return hid;
	}

	public List<DevicePropertyMapping> getDevicePropertiesByDeviceId(int deviceId) {

		List<DevicePropertyMapping> devicePropertyMappings = devicePropertyMappingRepository.findByDeviceId(deviceId);
		if (devicePropertyMappings == null || devicePropertyMappings.isEmpty()) {
			Device device = getDeviceById(deviceId);
			if (device != null) {
				devicePropertyMappings = getDevicePropertiesByDeviceIdSubFun(device);
			} else {
				throw new HttpClientErrorException(HttpStatus.NO_CONTENT, Constants.DEVICE_NOT_FOUND_MESSAGE);
			}
		}
		return devicePropertyMappings;
	}

	public List<DevicePropertyMapping> getDevicePropertiesByDeviceIdSubFun(Device device) {
		List<DevicePropertyMapping> devicePropertyMappings;
		List<String> properties = new ArrayList<>();
		String deviceHid = device.getDeviceHId();
		List<DevicePropertyDetails> devicePropertyDetails = getDevicePropertiesFromKronos(deviceHid);
		List<DevicePropertyMapping> devicePropertyMappingList = new ArrayList<>();
		for (DevicePropertyDetails devicePropertyDetail : devicePropertyDetails) {
			DevicePropertyDetails deviceProperty = devicePropertyDetailsRepository
					.findByNameAndTypeAndIsActiveTrue(devicePropertyDetail.getName(), devicePropertyDetail.getType());
			if (deviceProperty == null)
				deviceProperty = devicePropertyDetailsRepository.save(devicePropertyDetail);
			if (!properties.contains(deviceProperty.getName())) {
				DevicePropertyMapping devicePropertyMapping = new DevicePropertyMapping();
				devicePropertyMapping.setDevice(device);
				devicePropertyMapping.setDevicePropertyDetails(deviceProperty);
				devicePropertyMappingList.add(devicePropertyMapping);
				properties.add(deviceProperty.getName());
			}
		}
		devicePropertyMappings = devicePropertyMappingRepository.saveAll(devicePropertyMappingList);
		return devicePropertyMappings;
	}

	private List<DevicePropertyDetails> getDevicePropertiesFromKronos(String deviceHId) {
		String url = config.buildDevicePropertyUrl(deviceHId);
		List<DevicePropertyDetails> devicePropertyDetails = null;
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set(config.getAuthTokenKey(), config.getAuthToken());

			HttpEntity<String> entity = new HttpEntity<>(headers);
			ResponseEntity<DeviceProperties> response = restTemplate.exchange(url, HttpMethod.GET, entity,
					DeviceProperties.class);
			if (response.getStatusCode() == HttpStatus.OK) {
				devicePropertyDetails = response.getBody().getData();
			}

		} catch (Exception exception) {
			throw new HttpClientErrorException(HttpStatus.INTERNAL_SERVER_ERROR,
					Constants.FETCH_DEVICE_ID_ERROR_MESSAGE);
		}
		return devicePropertyDetails;

	}

	public List<DevicePropertyMapping> getDevicePropertiesByGrowSectionId(int growSectionId,
			List<GrowSectionDevice> growSectionDevices) {
		List<DevicePropertyMapping> alldevicePropertyMappings = new ArrayList<>();
		for (GrowSectionDevice device : growSectionDevices) {
			List<DevicePropertyMapping> devicePropertyMappings = getDevicePropertiesByDeviceId(
					device.getDevice().getId());
			if (devicePropertyMappings != null && !devicePropertyMappings.isEmpty())
				alldevicePropertyMappings.addAll(devicePropertyMappings);
		}
		return alldevicePropertyMappings;

	}

	public List<DevicePropertyMapping> getDevicePropertiesByGrowAreaId(List<Device> devices) {

		List<DevicePropertyMapping> alldevicePropertyMappings = new ArrayList<>();
		for (Device device : devices) {
			List<DevicePropertyMapping> devicePropertyMappings = getDevicePropertiesByDeviceId(device.getId());
			if (devicePropertyMappings != null && !devicePropertyMappings.isEmpty())
				alldevicePropertyMappings.addAll(devicePropertyMappings);
		}
		return alldevicePropertyMappings;

	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<TelemetryItem> getDeviceLastTelemetry(String deviceHId) {
		List<TelemetryItem> telemetry = null;
		String url = config.buildDeviceLastTelemetryUrl(deviceHId);
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set(config.getAuthTokenKey(), config.getAuthToken());

			HttpEntity<String> entity = new HttpEntity<>(headers);
			ResponseEntity<Map> response = restTemplate.exchange(url, HttpMethod.GET, entity, Map.class);
			if (response.getStatusCode() == HttpStatus.OK) {
				telemetry = (List<TelemetryItem>) response.getBody().get("data");
			}
		} catch (HttpStatusCodeException httpStatusCodeException) {
			throw new HttpClientErrorException(HttpStatus.NOT_FOUND, "Device does not exist in Arrow Portal.");
		} catch (Exception exception) {
			throw new HttpClientErrorException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Unable to fetch last telemetry of device");
		}
		return telemetry;
	}

	@Override
	public LedNodeHistory setLedNodedesiredValue(LedNodeHistory ledNodeHistory, Map<String, Object> map,
			String deviceHId) {
		setStateToArrowConnect(deviceHId, map);
		return ledNodeDesiredValueRepository.save(ledNodeHistory);
	}

	public LedNodeChannelConfiguration getLedNodeChannelConfiguration(Integer deviceId) {
		return ledNodeChannelConfigRepository.findByDeviceId(deviceId);
	}

	public LedNodeChannelConfiguration setLedNodeChannelConfiguration(
			LedNodeChannelConfiguration ledNodeChannelConfiguration) {
		return ledNodeChannelConfigRepository.save(ledNodeChannelConfiguration);
	}

	public LedNodeProfile setLedNodeProfile(LedNodeProfile requestedLedNodeProfile) {
		return ledNodeProfileRepository.save(requestedLedNodeProfile);
	}

	public List<LedNodeProfile> getLedNodeProfile(int deviceId) {
		return ledNodeProfileRepository.findByDeviceIdAndIsActiveTrue(deviceId);
	}

	public void deleteLedNodeProfileById(int id) {
		ledNodeProfileRepository.deleteProfileById(id);
	}

	@Override
	public DeviceRepository getDeviceRepository() {
		return deviceRepository;
	}

	@SuppressWarnings("rawtypes")
	public void setStateToArrowConnect(String deviceHId, Map<String, Object> deviceStatePayload) {
		String url = config.buildSetDeviceStateUrl(deviceHId);

		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set(config.getAuthTokenKey(), config.getAuthToken());
			LOGGER.info("LED channel confi payload for arrow connect----" + deviceStatePayload);
			HttpEntity<Map> entity = new HttpEntity<>(deviceStatePayload, headers);
			ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);

			if (response.getStatusCode() != HttpStatus.OK) {
				throw new HttpClientErrorException(response.getStatusCode(), response.getBody());
			} else {
				LOGGER.info("Set device state request sent successfully");
			}
		} catch (HttpStatusCodeException httpStatusCodeException) {

			throw new HttpClientErrorException(httpStatusCodeException.getStatusCode(),
					"This device does not exist on arrow portal.");
		} catch (Exception exception) {

			throw new HttpClientErrorException(HttpStatus.INTERNAL_SERVER_ERROR, exception.getMessage());
		}
	}

	@Override
	public Device getDeviceByUID(String uId) {
		return deviceRepository.findByDeviceUIdAndIsActiveTrue(uId);
	}

	public void deleteDevicePropertyMapping(int deviceId) {
		devicePropertyMappingRepository.deleteByDeviceId(deviceId);
	}

	public void deleteDevicePropertyMappingByGatewayId(int gatewayId) {
		devicePropertyMappingRepository.deleteByDeviceGrowAreaId(gatewayId);
	}

	public void deleteLedNodeProfile(int deviceId) {
		ledNodeProfileRepository.deleteProfileByDeviceId(deviceId);
	}

	public void deleteLedNodeDesiredValue(int deviceId) {
		ledNodeDesiredValueRepository.deleteLedNodeDesiredValueByDeviceId(deviceId);
	}

	public void deleteLedNodeDesiredValueByGatewayId(int gatewayId) {
		ledNodeDesiredValueRepository.deleteByDeviceGrowAreaId(gatewayId);
	}

	public void deleteLedNodeChannelConfigurationValue(int deviceId) {
		ledNodeChannelConfigRepository.deleteByDeviceId(deviceId);
	}

	public void deleteLedNodeChannelConfigurationValueByGatewayId(int gatewayId) {
		ledNodeChannelConfigRepository.deleteByDeviceGrowAreaId(gatewayId);
	}

	public void deleteSectionDevices(int deviceId) {

		growSectionDeviceRepository.deleteDeviceSectionByDeviceId(deviceId);
	}

	public void deleteSectionDevicesList(int gatewayId) {
		List<Device> devices = getDevicesByGrowAreaId(gatewayId);
		if (devices != null && !devices.isEmpty()) {
			List<Integer> devicesList = devices.stream().map(device -> device.getId()).collect(Collectors.toList());
			growSectionDeviceRepository.deleteDeviceSectionByDeviceIdList(devicesList);
		}
	}

	public void deleteLedNodeProfileByGatewayId(int gatewayId) {
		ledNodeProfileRepository.deleteByDeviceGrowAreaId(gatewayId);
	}

	public Device getDeviceByDeviceHID(String deviceHID) {
		return deviceRepository.findByDeviceHIdAndIsActiveTrue(deviceHID);
	}

	private String fetchgatewayDefaultDevice(String gatewayHId) {
		UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(config.buildGatewayDevicesUrl())
				.queryParam("gatewayHid", gatewayHId);
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set(config.getAuthTokenKey(), config.getAuthToken());

			HttpEntity<String> entity = new HttpEntity<>(headers);
			ResponseEntity<KronosResponse> response = restTemplate.exchange(builder.toUriString(), HttpMethod.GET,
					entity, KronosResponse.class);
			if (response.getStatusCode() == HttpStatus.OK) {
				KronosResponse kronosResponse = response.getBody();
				return kronosResponse.getData().get(0).getHid();
			}
		} catch (HttpStatusCodeException httpStatusCodeException) {
			throw new HttpClientErrorException(httpStatusCodeException.getStatusCode(),
					httpStatusCodeException.getStatusText());
		} catch (Exception exception) {
			throw new HttpClientErrorException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to fetch gateway device HID");
		}
		return null;

	}

	public List<LedNodeChannelConfiguration> getDevicesBasedonConfiguration(GroupChannelConfigurationDTO confi,
			int gatewayId) {
		return ledNodeChannelConfigRepository
				.findByDeviceGrowAreaIdAndLed1AndLed2AndLed3AndLed4AndLed5AndLed6AndDeviceIsActiveTrue(gatewayId,
						confi.getLed1(), confi.getLed2(), confi.getLed3(), confi.getLed4(), confi.getLed5(),
						confi.getLed6());
	}
}
