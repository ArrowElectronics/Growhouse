/**
 * 
 */
package com.growhouse.rest.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * @author dharita.chokshi
 *
 */
@Entity
@Table(name = "led_group_device")
public class GroupDevice extends DefaultModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -759953882250808825L;

	@OneToOne(fetch = FetchType.EAGER, cascade = { CascadeType.MERGE })
	@JoinColumn(name = "group_id")
	private LedNodeGroupChannelConfiguration group;

	@OneToOne(fetch = FetchType.EAGER, cascade = { CascadeType.MERGE })
	@JoinColumn(name = "device_id")
	private Device device;

	public LedNodeGroupChannelConfiguration getGroup() {
		return group;
	}

	public void setGroup(LedNodeGroupChannelConfiguration group) {
		this.group = group;
	}

	public Device getDevice() {
		return device;
	}

	public void setDevice(Device device) {
		this.device = device;
	}

	@Override
	public String toString() {
		return "GroupDevice [group=" + group + ", device=" + device + "]";
	}

	
	

}