package com.growhouse.rest.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;


public class LedNodeGroupChannelConfigurationDTO {

	private Integer id;
	
	@JsonProperty("growarea_id")
	private Integer growArea;
	
	@JsonProperty("group_name")
	private String groupName;
	
	@JsonProperty("generated_group_name")
	private String generatedGroupName;
	
	@JsonProperty("channel_configuration")
	private GroupChannelConfigurationDTO groupChannelConfigurationDTO;

	@JsonProperty("added_devices")
	private List<DeviceGroupDTO> devices;
	
	@JsonProperty("description")
	private String description;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getGrowArea() {
		return growArea;
	}

	public void setGrowArea(Integer growArea) {
		this.growArea = growArea;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getGeneratedGroupName() {
		return generatedGroupName;
	}

	public void setGeneratedGroupName(String generatedGroupName) {
		this.generatedGroupName = generatedGroupName;
	}

	public GroupChannelConfigurationDTO getGroupChannelConfigurationDTO() {
		return groupChannelConfigurationDTO;
	}

	public void setGroupChannelConfigurationDTO(GroupChannelConfigurationDTO groupChannelConfigurationDTO) {
		this.groupChannelConfigurationDTO = groupChannelConfigurationDTO;
	}

	public List<DeviceGroupDTO> getDevices() {
		return devices;
	}

	public void setDevices(List<DeviceGroupDTO> devices) {
		this.devices = devices;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "LedNodeGroupChannelConfigurationDTO [id=" + id + ", growArea=" + growArea + ", groupName=" + groupName
				+ ", generatedGroupName=" + generatedGroupName + ", groupChannelConfigurationDTO="
				+ groupChannelConfigurationDTO + ", devices=" + devices + ", description=" + description + "]";
	}

	
	
}
