/**
 * 
 */
package com.growhouse.rest.services;

import java.util.List;

import com.growhouse.rest.entity.DeviceType;

/**
 * @author dharita.chokshi
 *
 */
public interface IDeviceTypeService {

	public List<DeviceType> getAllDeviceTypes();

	public DeviceType getDeviceTypeById(int deviceTypeId);
	
	public DeviceType getDeviceTypeByDeviceTypeName(String deviceTypeName);

}
