/**
 * 
 */
package com.growhouse.rest.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * @author dharita.chokshi
 *
 */
@Entity
@Table(name = "container_types")
public class ContainerType extends DefaultModel implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -7926722805853226753L;

	@Column(name = "container_type_name")
	private String containerTypeName;

	/**
	 * @return the containerTypeName
	 */
	public String getContainerTypeName() {
		return containerTypeName;
	}

	/**
	 * @param containerTypeName
	 *            the containerTypeName to set
	 */
	public void setContainerTypeName(String containerTypeName) {
		this.containerTypeName = containerTypeName;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ContainerType [containerTypeName=" + containerTypeName + "]";
	}

}
