/**
 * 
 */
package com.growhouse.rest.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.growhouse.rest.entity.GrowAreaAssignee;

/**
 * @author dharita.chokshi
 *
 */
@Repository
public interface GrowAreaAssigneeRepository extends JpaRepository<GrowAreaAssignee, Integer> {

	public List<GrowAreaAssignee> findByIsActiveTrue();

	public List<GrowAreaAssignee> findByGrowAreaIdAndIsActiveTrue(int growAreaId);

	public List<GrowAreaAssignee> findByUserIdAndIsActiveTrue(int userId);
	
	public List<GrowAreaAssignee> findByUserIdAndIsActiveTrueAndGrowAreaIsActiveTrue(int userId);

	public Optional<GrowAreaAssignee> findByGrowAreaIdAndUserId(int growAreaId, int userId);
	
	public List<GrowAreaAssignee> findByUserIdAndContainerIdAndGrowAreaIsActiveTrueAndIsActiveTrue(int userId,int containerId);
	
	public int countByUserIdAndContainerIdAndGrowAreaIsActiveTrueAndIsActiveTrue(int userId,int containerId);
	
    public List<GrowAreaAssignee> findByUserIdAndFacilityIdAndGrowAreaIsActiveTrueAndIsActiveTrue(int userId,int facilityId);

    public int countByUserIdAndFacilityIdAndGrowAreaIsActiveTrueAndIsActiveTrue(int userId,int facilityId);
    
    @Transactional
    @Modifying
    @Query(value="Update grow_area_assignee p SET p.is_active=0 where p.grow_area_id=?1 and p.is_active=1",nativeQuery = true)
    public void deleteGrowAreaAssigneeByGatewayId(int gatewayId);
}