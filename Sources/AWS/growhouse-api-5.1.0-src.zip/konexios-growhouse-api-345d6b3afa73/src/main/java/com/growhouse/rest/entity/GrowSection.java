/**
 * 
 */
package com.growhouse.rest.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

/**
 * @author dharita.chokshi
 *
 */
@Entity
@Table(name = "grow_sections")
public class GrowSection extends DefaultModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -759953882250808825L;

	@Column(name = "grow_section_name")
	@NotBlank
	private String growSectionName;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "grow_area_id")
	private GrowArea growArea;

	private String size;

	private String description;

	/**
	 * @return the growSectionName
	 */
	public String getGrowSectionName() {
		return growSectionName;
	}

	/**
	 * @param growSectionName
	 *            the growSectionName to set
	 */
	public void setGrowSectionName(String growSectionName) {
		this.growSectionName = growSectionName;
	}

	/**
	 * @return the growArea
	 */
	public GrowArea getGrowArea() {
		return growArea;
	}

	/**
	 * @param growArea
	 *            the growArea to set
	 */
	public void setGrowArea(GrowArea growArea) {
		this.growArea = growArea;
	}

	/**
	 * @return the size
	 */
	public String getSize() {
		return size;
	}

	/**
	 * @param size
	 *            the size to set
	 */
	public void setSize(String size) {
		this.size = size;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description
	 *            the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "GrowSection [growSectionName=" + growSectionName + ", growArea=" + growArea + ", size=" + size
				+ ", description=" + description + "]";
	}

}