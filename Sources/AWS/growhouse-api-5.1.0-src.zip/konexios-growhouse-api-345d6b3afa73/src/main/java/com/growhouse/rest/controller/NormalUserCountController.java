package com.growhouse.rest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.growhouse.rest.dto.NormalUserDashboardCountDTO;
import com.growhouse.rest.facade.NormalUserFacade;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/api/normaluser")
@Transactional
public class NormalUserCountController {

	@Autowired
	private NormalUserFacade normalUserFacade;

	@GetMapping("/dashboard/count")
	@ApiOperation(value = "View Count of NormalUser dashboard")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Data retrieved successfully") })
	public ResponseEntity<?> getSuperAdminDashboardCount() {
		ResponseEntity<?> responseEntity;
		try {
			NormalUserDashboardCountDTO userDashboardCountDTO = normalUserFacade.getNormalUserCount();
			responseEntity = new ResponseEntity<>(userDashboardCountDTO, HttpStatus.OK);
		} catch (Exception exception) {
			responseEntity = new ResponseEntity<>(exception.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

}
