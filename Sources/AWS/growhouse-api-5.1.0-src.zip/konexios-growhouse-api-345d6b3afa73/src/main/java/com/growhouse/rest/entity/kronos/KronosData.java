/**
 * 
 */
package com.growhouse.rest.entity.kronos;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * @author dharita.chokshi
 *
 */
public class KronosData {
	private String hid;
	private String uid;
	private String gatewayHid;
	private String deviceHid;
	private String name;
	private String type;
	private long timestamp;
	private String strValue;
	private Long intValue;
	private Double floatValue;
	private Boolean boolValue;
	private LocalDate dateValue;
	private LocalDateTime datetimeValue;
	private String intSqrValue;
	private String floatSqrValue;
	private String intCubeValue;
	private String floatCubeValue;
	private String binaryValue;

	/**
	 * @return the hid
	 */
	public String getHid() {
		return hid;
	}

	/**
	 * @param hid
	 *            the hid to set
	 */
	public void setHid(String hid) {
		this.hid = hid;
	}

	/**
	 * @return the uid
	 */
	public String getUid() {
		return uid;
	}

	/**
	 * @param uid
	 *            the uid to set
	 */
	public void setUid(String uid) {
		this.uid = uid;
	}

	/**
	 * @return the gatewayHid
	 */
	public String getGatewayHid() {
		return gatewayHid;
	}

	/**
	 * @param gatewayHid
	 *            the gatewayHid to set
	 */
	public void setGatewayHid(String gatewayHid) {
		this.gatewayHid = gatewayHid;
	}

	/**
	 * @return the deviceHid
	 */
	public String getDeviceHid() {
		return deviceHid;
	}

	/**
	 * @param deviceHid
	 *            the deviceHid to set
	 */
	public void setDeviceHid(String deviceHid) {
		this.deviceHid = deviceHid;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type
	 *            the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the timestamp
	 */
	public long getTimestamp() {
		return timestamp;
	}

	/**
	 * @param timestamp
	 *            the timestamp to set
	 */
	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}

	/**
	 * @return the strValue
	 */
	public String getStrValue() {
		return strValue;
	}

	/**
	 * @param strValue
	 *            the strValue to set
	 */
	public void setStrValue(String strValue) {
		this.strValue = strValue;
	}

	/**
	 * @return the intValue
	 */
	public Long getIntValue() {
		return intValue;
	}

	/**
	 * @param intValue
	 *            the intValue to set
	 */
	public void setIntValue(Long intValue) {
		this.intValue = intValue;
	}

	/**
	 * @return the floatValue
	 */
	public Double getFloatValue() {
		return floatValue;
	}

	/**
	 * @param floatValue
	 *            the floatValue to set
	 */
	public void setFloatValue(Double floatValue) {
		this.floatValue = floatValue;
	}

	/**
	 * @return the boolValue
	 */
	public Boolean getBoolValue() {
		return boolValue;
	}

	/**
	 * @param boolValue
	 *            the boolValue to set
	 */
	public void setBoolValue(Boolean boolValue) {
		this.boolValue = boolValue;
	}

	/**
	 * @return the dateValue
	 */
	public LocalDate getDateValue() {
		return dateValue;
	}

	/**
	 * @param dateValue
	 *            the dateValue to set
	 */
	public void setDateValue(LocalDate dateValue) {
		this.dateValue = dateValue;
	}

	/**
	 * @return the datetimeValue
	 */
	public LocalDateTime getDatetimeValue() {
		return datetimeValue;
	}

	/**
	 * @param datetimeValue
	 *            the datetimeValue to set
	 */
	public void setDatetimeValue(LocalDateTime datetimeValue) {
		this.datetimeValue = datetimeValue;
	}

	/**
	 * @return the intSqrValue
	 */
	public String getIntSqrValue() {
		return intSqrValue;
	}

	/**
	 * @param intSqrValue
	 *            the intSqrValue to set
	 */
	public void setIntSqrValue(String intSqrValue) {
		this.intSqrValue = intSqrValue;
	}

	/**
	 * @return the floatSqrValue
	 */
	public String getFloatSqrValue() {
		return floatSqrValue;
	}

	/**
	 * @param floatSqrValue
	 *            the floatSqrValue to set
	 */
	public void setFloatSqrValue(String floatSqrValue) {
		this.floatSqrValue = floatSqrValue;
	}

	/**
	 * @return the intCubeValue
	 */
	public String getIntCubeValue() {
		return intCubeValue;
	}

	/**
	 * @param intCubeValue
	 *            the intCubeValue to set
	 */
	public void setIntCubeValue(String intCubeValue) {
		this.intCubeValue = intCubeValue;
	}

	/**
	 * @return the floatCubeValue
	 */
	public String getFloatCubeValue() {
		return floatCubeValue;
	}

	/**
	 * @param floatCubeValue
	 *            the floatCubeValue to set
	 */
	public void setFloatCubeValue(String floatCubeValue) {
		this.floatCubeValue = floatCubeValue;
	}

	/**
	 * @return the binaryValue
	 */
	public String getBinaryValue() {
		return binaryValue;
	}

	/**
	 * @param binaryValue
	 *            the binaryValue to set
	 */
	public void setBinaryValue(String binaryValue) {
		this.binaryValue = binaryValue;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "KronosData [hid=" + hid + ", uid=" + uid + ", gatewayHid=" + gatewayHid + ", deviceHid=" + deviceHid
				+ ", name=" + name + ", type=" + type + ", timestamp=" + timestamp + ", strValue=" + strValue
				+ ", intValue=" + intValue + ", floatValue=" + floatValue + ", boolValue=" + boolValue + ", dateValue="
				+ dateValue + ", datetimeValue=" + datetimeValue + ", intSqrValue=" + intSqrValue + ", floatSqrValue="
				+ floatSqrValue + ", intCubeValue=" + intCubeValue + ", floatCubeValue=" + floatCubeValue
				+ ", binaryValue=" + binaryValue + "]";
	}

}
