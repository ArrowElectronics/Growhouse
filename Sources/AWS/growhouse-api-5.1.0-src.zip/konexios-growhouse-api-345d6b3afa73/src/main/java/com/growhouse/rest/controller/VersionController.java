package com.growhouse.rest.controller;

/**
 * 
 */

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;

import com.growhouse.rest.entity.Version;
import com.growhouse.rest.response.ResponseMessage;
import com.growhouse.rest.utils.Constants;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/api/release/version")
@Transactional
public class VersionController {

	@GetMapping(value = "")
	@ApiOperation(value = "Retrive Release Version.")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully fetch Release version"),
			@ApiResponse(code = 404, message = "Release version not found"), })
	public ResponseEntity<?> getReleaseVersion() {
		ResponseEntity<?> responseEntity;
		try {
			String version = Constants.RELEASE_VERSION;
			Version releaseVersion = new Version();
			releaseVersion.setReleaseVersion(version);
			responseEntity = new ResponseEntity<>(releaseVersion, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			ResponseMessage responseMessage = new ResponseMessage();
			responseMessage.setMessage(httpClientErrorException.getStatusText());
			responseEntity = new ResponseEntity<>(responseMessage, httpClientErrorException.getStatusCode());
		} catch (Exception exception) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

}
