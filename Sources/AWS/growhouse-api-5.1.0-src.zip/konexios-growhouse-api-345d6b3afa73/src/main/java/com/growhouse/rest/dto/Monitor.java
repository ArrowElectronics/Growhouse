package com.growhouse.rest.dto;

import java.util.List;

public class Monitor {
	private List<String> deviceHids;
	private String gatewayHid;

	public List<String> getDeviceHids() {
		return deviceHids;
	}

	public void setDeviceHids(List<String> deviceHids) {
		this.deviceHids = deviceHids;
	}

	public String getGatewayHid() {
		return gatewayHid;
	}

	public void setGatewayHid(String gatewayHid) {
		this.gatewayHid = gatewayHid;
	}

	@Override
	public String toString() {
		return "Monitor [deviceHids=" + deviceHids + ", gatewayHid=" + gatewayHid + "]";
	}

}
