package com.growhouse.rest.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;

import com.growhouse.rest.dto.TelemetryItemDTO;
import com.growhouse.rest.dto.TelemetryItemWithPagesDTO;
import com.growhouse.rest.entity.Device;
import com.growhouse.rest.facade.TelemetryFacade;
import com.growhouse.rest.response.ResponseMessage;
import com.growhouse.rest.services.impl.DeviceService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/api/telemetry")
@Transactional
public class TelemetryController {

	@Autowired
	private TelemetryFacade telemetryFacade;

	@Autowired
	private DeviceService deviceServiceObj;

	private static final Logger LOGGER = LogManager.getLogger(TelemetryController.class);

	@GetMapping(value = "/device/{deviceHId}")
	@ApiOperation(value = "Retrive telemetry based on deviceHId")
	@ApiResponses(value = { @ApiResponse(code = 204, message = "Telemetry not found"), })
	public ResponseEntity<?> getTelemetryByDeviceHId(@PathVariable("deviceHId") String deviceHId,
			@RequestParam("fromTimestamp") String fromTimestamp, @RequestParam("toTimestamp") String toTimestamp,
			@RequestParam("propertyName") String propertyName) {

		ResponseEntity<?> responseEntity;
		ResponseMessage responseMessage = new ResponseMessage();
		try {
			Device device = deviceServiceObj.getDeviceByDeviceHID(deviceHId);
			if (device != null) {
				String isoDatePattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat(isoDatePattern);
				simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
				String fromTimestampDB = simpleDateFormat.format(device.getCreatedTimestamp());
				SimpleDateFormat formatter1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
				Date uIdate = formatter1.parse(fromTimestamp);
				Date dBdate = formatter1.parse(fromTimestampDB);
				Date todate = formatter1.parse(toTimestamp);
				if (uIdate.compareTo(dBdate) < 0) {
					fromTimestamp = fromTimestampDB;
				}
				if (dBdate.compareTo(todate) > 0) {
					LOGGER.info("from date is greater than to");
					responseMessage.setMessage("Telemetry not found");
					responseEntity = new ResponseEntity<>(responseMessage, HttpStatus.NO_CONTENT);
					return responseEntity;
				}
				TelemetryItemWithPagesDTO telemetryItemWithPagesDTO = telemetryFacade
						.fetchTelemetryFromArrowConnect(deviceHId, fromTimestamp, toTimestamp, propertyName, null);
				for (int i = 1; i < telemetryItemWithPagesDTO.getPages(); i++) {
					TelemetryItemWithPagesDTO itemWithPagesDTO = telemetryFacade
							.fetchTelemetryFromArrowConnect(deviceHId, fromTimestamp, toTimestamp, propertyName, i);
					if (telemetryItemWithPagesDTO.getTelemetryItemDTOs() != null) {
						List<TelemetryItemDTO> telemetryItemDTOs = telemetryItemWithPagesDTO.getTelemetryItemDTOs();
						telemetryItemDTOs.addAll(itemWithPagesDTO.getTelemetryItemDTOs());
						telemetryItemWithPagesDTO.setTelemetryItemDTOs(telemetryItemDTOs);
					} else {
						telemetryItemWithPagesDTO.setTelemetryItemDTOs(itemWithPagesDTO.getTelemetryItemDTOs());
					}
				}

				if (telemetryItemWithPagesDTO.getTelemetryItemDTOs() == null) {

					responseMessage.setMessage("No Telemetry Found");
					responseEntity = new ResponseEntity<>(responseMessage, HttpStatus.NO_CONTENT);
				} else {
					responseEntity = new ResponseEntity<>(telemetryItemWithPagesDTO.getTelemetryItemDTOs(),
							HttpStatus.OK);
				}
			} else {
				responseMessage.setMessage("No Telemetry Found");
				responseEntity = new ResponseEntity<>(responseMessage, HttpStatus.NO_CONTENT);
			}

		} catch (HttpClientErrorException httpClientErrorException) {
			responseMessage.setMessage("This device telemetry not available");
			responseEntity = new ResponseEntity<>(responseMessage, HttpStatus.NO_CONTENT);
		} catch (Exception exception) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

}
