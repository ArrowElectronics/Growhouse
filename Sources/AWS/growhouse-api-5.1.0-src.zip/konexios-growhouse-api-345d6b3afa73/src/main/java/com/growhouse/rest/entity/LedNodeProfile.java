package com.growhouse.rest.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="led_node_profile")
public class LedNodeProfile extends DefaultModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5415649067820703447L;

	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="device_id")
	private Device device;
	
	@Column(name="device_type")
	private String deviceType="LedNode";
	
	@Column(name="profile_name")
	private String profileName;
	
	private String description;
	
	@Column(name="channel_configuration")
	private String channelConfiguration;

	public Device getDevice() {
		return device;
	}

	public void setDevice(Device device) {
		this.device = device;
	}

	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

	public String getProfileName() {
		return profileName;
	}

	public void setProfileName(String profileName) {
		this.profileName = profileName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getChannelConfiguration() {
		return channelConfiguration;
	}

	public void setChannelConfiguration(String channelConfiguration) {
		this.channelConfiguration = channelConfiguration;
	}

	@Override
	public String toString() {
		return "LedNodeProfile [device=" + device + ", deviceType=" + deviceType + ", profileName=" + profileName
		        + ", description=" + description + ", channelConfiguration=" + channelConfiguration + "]";
	}
	
	
}
