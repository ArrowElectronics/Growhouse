package com.growhouse.rest.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.security.core.context.SecurityContextHolder;




@Entity
@Table(name="lednode_profile_events")
public class LedNodeProfileEvent implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	@Column(name = "profile_details")
	private String profileDetails;
	
	@Column(name ="start_date")
	private String startDate;
	
	@Column(name ="start_time")
	private String startTime;
	
	@Column(name ="end_date")
	private String endDate;
	
	@Column(name ="end_time")
	private String endTime;
	
	@Column(name ="job_name")
	private String jobName;
	
	@Column(name ="CH1")
	private Integer ch1; 
	
	@Column(name ="CH2")
	private Integer ch2;
	
	@Column(name ="CH3")
	private Integer ch3;
	
	@Column(name ="CH4")
	private Integer ch4;
	
	@Column(name ="CH5")
	private Integer ch5;
	
	@Column(name ="CH6")
	private Integer ch6;
	
	@Column(name ="preset")
	private Integer preset;
	
	@Column(name ="repeat_time")
	private String repeatTime;
	
	@Column(name="profile_id")
	private Integer profileId;
	
	@Column(name="profile_name")
	private String profileName;
	
	@Column(name="group_id")
	private Integer groupId;

	@Column(name ="facility_id")
	private Integer facilityId;
	
	@Column(name ="facility_name")
	private String facilityName;
	
	@Column(name ="container_id")
	private Integer containerId;
	
	@Column(name ="container_name")
	private String containerName;
	
	@Column(name ="growarea_id")
	private Integer growareaId;
	
	@Column(name ="grow_area_name")
	private String growareaName;
	
	@Column(name = "is_active", columnDefinition = "TINYINT DEFAULT '1'")
	@NotNull
	private boolean isActive = true;
	
	@Column(updatable = false, name = "created_timestamp", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	@Temporal(TemporalType.TIMESTAMP)
	@CreationTimestamp
	private Date createdTimestamp;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "created_by", updatable = false)
	private User createdBy;

	@Column(name = "updated_timestamp", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
	@Temporal(TemporalType.TIMESTAMP)
	@UpdateTimestamp
	private Date updatedTimestamp;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "updated_by")
	private User updatedBy;

	
	@PrePersist
	protected void onCreate() {
		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();	
		if (user != null)
			createdBy = updatedBy = user;
		updatedTimestamp = createdTimestamp = new Date();
	}

	@PreUpdate
	protected void onUpdate() {
		User user = null;
		user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if (user != null)
			updatedBy = user;
		updatedTimestamp = new Date();
	}

	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getProfileDetails() {
		return profileDetails;
	}

	public void setProfileDetails(String profileDetails) {
		this.profileDetails = profileDetails;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public Integer getCh1() {
		return ch1;
	}

	public void setCh1(Integer ch1) {
		this.ch1 = ch1;
	}

	public Integer getCh2() {
		return ch2;
	}

	public void setCh2(Integer ch2) {
		this.ch2 = ch2;
	}

	public Integer getCh3() {
		return ch3;
	}

	public void setCh3(Integer ch3) {
		this.ch3 = ch3;
	}

	public Integer getCh4() {
		return ch4;
	}

	public void setCh4(Integer ch4) {
		this.ch4 = ch4;
	}

	public Integer getCh5() {
		return ch5;
	}

	public void setCh5(Integer ch5) {
		this.ch5 = ch5;
	}

	public Integer getCh6() {
		return ch6;
	}

	public void setCh6(Integer ch6) {
		this.ch6 = ch6;
	}

	public Integer getPreset() {
		return preset;
	}

	public void setPreset(Integer preset) {
		this.preset = preset;
	}

	public String getRepeatTime() {
		return repeatTime;
	}

	public void setRepeatTime(String repeatTime) {
		this.repeatTime = repeatTime;
	}

	public Integer getProfileId() {
		return profileId;
	}

	public void setProfileId(Integer profileId) {
		this.profileId = profileId;
	}

	public String getProfileName() {
		return profileName;
	}

	public void setProfileName(String profileName) {
		this.profileName = profileName;
	}

	public Integer getGroupId() {
		return groupId;
	}

	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}

	public Integer getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(Integer facilityId) {
		this.facilityId = facilityId;
	}

	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public Integer getContainerId() {
		return containerId;
	}

	public void setContainerId(Integer containerId) {
		this.containerId = containerId;
	}

	public String getContainerName() {
		return containerName;
	}

	public void setContainerName(String containerName) {
		this.containerName = containerName;
	}

	public Integer getGrowareaId() {
		return growareaId;
	}

	public void setGrowareaId(Integer growareaId) {
		this.growareaId = growareaId;
	}

	public String getGrowareaName() {
		return growareaName;
	}

	public void setGrowareaName(String growareaName) {
		this.growareaName = growareaName;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public Date getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Date createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public User getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(User createdBy) {
		this.createdBy = createdBy;
	}

	public Date getUpdatedTimestamp() {
		return updatedTimestamp;
	}

	public void setUpdatedTimestamp(Date updatedTimestamp) {
		this.updatedTimestamp = updatedTimestamp;
	}

	public User getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(User updatedBy) {
		this.updatedBy = updatedBy;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "LedNodeProfileEvent [id=" + id + ", profileDetails=" + profileDetails + ", startDate=" + startDate
				+ ", startTime=" + startTime + ", endDate=" + endDate + ", endTime=" + endTime + ", jobName=" + jobName
				+ ", ch1=" + ch1 + ", ch2=" + ch2 + ", ch3=" + ch3 + ", ch4=" + ch4 + ", ch5=" + ch5 + ", ch6=" + ch6
				+ ", preset=" + preset + ", repeatTime=" + repeatTime + ", profileId=" + profileId + ", profileName="
				+ profileName + ", groupId=" + groupId + ", facilityId=" + facilityId + ", facilityName=" + facilityName
				+ ", containerId=" + containerId + ", containerName=" + containerName + ", growareaId=" + growareaId
				+ ", growareaName=" + growareaName + ", isActive=" + isActive + ", createdTimestamp=" + createdTimestamp
				+ ", createdBy=" + createdBy + ", updatedTimestamp=" + updatedTimestamp + ", updatedBy=" + updatedBy
				+ "]";
	}

	

}
