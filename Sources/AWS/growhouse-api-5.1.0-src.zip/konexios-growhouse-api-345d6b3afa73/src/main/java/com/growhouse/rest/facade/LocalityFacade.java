/**
 * 
 */
package com.growhouse.rest.facade;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.growhouse.rest.dto.LocalityDTO;
import com.growhouse.rest.entity.Locality;
import com.growhouse.rest.services.impl.LocalityService;

/**
 * @author dharita.chokshi
 *
 */
@Component
public class LocalityFacade {

	public static final Logger LOGGER = LoggerFactory.getLogger(LocalityFacade.class);

	@Autowired
	private LocalityService localityService;

	@Autowired
	private ModelMapper modelMapper;

	public List<LocalityDTO> getAllLocalities() {
		List<LocalityDTO> localityDTOs = new ArrayList<>();
		List<Locality> localities = localityService.findAll();
		if (localities != null && !localities.isEmpty()) {
			localityDTOs = localities.stream().map(this::convertEntityToDTO)
					.collect(Collectors.toList());
		}
		return localityDTOs;
	}

	public List<LocalityDTO> getLocalitysByStateId(int stateId) {
		List<LocalityDTO> localityDTOs = new ArrayList<>();
		List<Locality> localities = localityService.findByStateId(stateId);
		if (localities != null && !localities.isEmpty()) {
			localityDTOs = localities.stream().map(this::convertEntityToDTO)
					.collect(Collectors.toList());
		}
		return localityDTOs;
	}

	private LocalityDTO convertEntityToDTO(Locality locality) {
		return modelMapper.map(locality, LocalityDTO.class);
	}

}
