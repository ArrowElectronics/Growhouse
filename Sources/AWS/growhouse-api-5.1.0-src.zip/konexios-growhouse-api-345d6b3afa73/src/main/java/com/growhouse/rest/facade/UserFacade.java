/**
 * 
 */
package com.growhouse.rest.facade;

import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.logging.log4j.core.util.IOUtils;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.growhouse.rest.KonexiosConfig;
import com.growhouse.rest.dto.UserDTO;
import com.growhouse.rest.dto.konexios.AuthRequest;
import com.growhouse.rest.dto.konexios.AuthResponse;
import com.growhouse.rest.dto.konexios.ChangePasswordRequest;
import com.growhouse.rest.dto.konexios.ChangePasswordResponse;
import com.growhouse.rest.dto.konexios.Contact;
import com.growhouse.rest.dto.konexios.CreateUserRequest;
import com.growhouse.rest.dto.konexios.CreateUserResponse;
import com.growhouse.rest.dto.konexios.FindUserRequest;
import com.growhouse.rest.dto.konexios.FindUserResponse;
import com.growhouse.rest.dto.konexios.ResetPasswordRequest;
import com.growhouse.rest.dto.konexios.ResetPasswordResponse;
import com.growhouse.rest.dto.konexios.UpdateUserRequest;
import com.growhouse.rest.dto.konexios.UpdateUserResponse;
import com.growhouse.rest.entity.User;
import com.growhouse.rest.services.IUserService;
import com.growhouse.rest.smtp.EmailSender;
import com.growhouse.rest.utils.Constants;
import com.growhouse.rest.utils.Constants.ResetPasswordEmail;

/**
 * @author dharita.chokshi
 *
 */
@Component
public class UserFacade {
	private static final String PASSWORD_CHARS = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ~!#$";
	public static final Logger LOGGER = LoggerFactory.getLogger(UserFacade.class);

	@Autowired
	private IUserService userService;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private KonexiosConfig config;

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private EmailSender emailSender;

	public UserDTO authenticate(String username, String password) {
		User user = userService.getUserByUsername(username);
		if (user == null) {
			throw new HttpClientErrorException(HttpStatus.UNAUTHORIZED, "user not found");
		}
		try {
			// update login accordingly
			AuthRequest request = new AuthRequest().login(config.toKonexiosLogin(username)).password(password);
			LOGGER.info("checking konexios login: " + request.getLogin());

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set(config.getAuthTokenKey(), config.getAuthToken());
			AuthResponse response = restTemplate.exchange(config.buildUserAuthUrl(), HttpMethod.POST,
					new HttpEntity<>(request, headers), AuthResponse.class).getBody();
			if (response.isSuccess()) {
				return convertEntityToDTO(user);
			} else {
				throw new HttpClientErrorException(HttpStatus.UNAUTHORIZED, response.getMessage());
			}
		} catch (HttpStatusCodeException exception) {
			LOGGER.error("HttpStatusCodeException: " + exception.getMessage());
			if (exception.getStatusText().contains("RequiredChangePasswordException")) {
				throw new HttpClientErrorException(HttpStatus.CONFLICT, exception.getStatusText());
			} else {
				throw new HttpClientErrorException(HttpStatus.UNAUTHORIZED, exception.getStatusText());
			}
		} catch (Exception exception) {
			LOGGER.error("Exception", exception);
			throw new HttpClientErrorException(HttpStatus.INTERNAL_SERVER_ERROR, exception.getMessage());
		}
	}

	public String resetPassword(String username) {
		User user = userService.getUserByUsername(username);
		if (user == null) {
			throw new HttpClientErrorException(HttpStatus.BAD_REQUEST, "user not found");
		}
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set(config.getAuthTokenKey(), config.getAuthToken());
			ResetPasswordResponse response = restTemplate.exchange(config.buildUserResetPasswordUrl(user.getUserHid()),
					HttpMethod.POST, new HttpEntity<>(new ResetPasswordRequest().sendEmail(false), headers),
					ResetPasswordResponse.class).getBody();
			if (response.isSuccess()) {
				String password = response.getTemporaryPassword();
				String to = user.getEmail();
				String subject = ResetPasswordEmail.SUBJECT;
				String body = IOUtils
						.toString(new InputStreamReader(getClass().getResourceAsStream(ResetPasswordEmail.TEMPLATE)));
				body = body.replace(ResetPasswordEmail.VAR_NAME, user.fullName())
						.replace(ResetPasswordEmail.VAR_URL, config.getResetPasswordUrl())
						.replace(ResetPasswordEmail.VAR_USERNAME, user.getUsername())
						.replace(ResetPasswordEmail.VAR_PASSWORD, password);

				LOGGER.info("sending email to: " + to);
				emailSender.send(new String[] { to }, null, subject, body, false);
				return password;
			} else {
				throw new HttpClientErrorException(HttpStatus.BAD_REQUEST, response.getMessage());
			}
		} catch (HttpStatusCodeException exception) {
			LOGGER.error("HttpStatusCodeException: " + exception.getMessage());
			throw new HttpClientErrorException(HttpStatus.BAD_REQUEST, exception.getStatusText());
		} catch (Exception exception) {
			LOGGER.error("Exception", exception);
			throw new HttpClientErrorException(HttpStatus.INTERNAL_SERVER_ERROR, exception.getMessage());
		}
	}

	public void changePassword(String username, String currentPassword, String newPassword) {
		User user = userService.getUserByUsername(username);
		if (user == null) {
			throw new HttpClientErrorException(HttpStatus.BAD_REQUEST, "user not found");
		}
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set(config.getAuthTokenKey(), config.getAuthToken());
			ChangePasswordResponse response = restTemplate.exchange(
					config.buildUserChangePasswordUrl(user.getUserHid()), HttpMethod.POST,
					new HttpEntity<>(
							new ChangePasswordRequest().currentPassword(currentPassword).newPassword(newPassword),
							headers),
					ChangePasswordResponse.class).getBody();
			if (!response.isSuccess()) {
				String errors = response.getErrorMessages().stream().collect(Collectors.joining(";"));
				LOGGER.info("errors: " + errors);
				throw new HttpClientErrorException(HttpStatus.BAD_REQUEST, errors);
			} else {
				LOGGER.info("password changed successfully for user: " + username);
			}
		} catch (HttpStatusCodeException exception) {
			LOGGER.error("HttpStatusCodeException: " + exception.getMessage());
			throw new HttpClientErrorException(HttpStatus.BAD_REQUEST, exception.getStatusText());
		} catch (Exception exception) {
			LOGGER.error("Exception", exception);
			throw new HttpClientErrorException(HttpStatus.INTERNAL_SERVER_ERROR, exception.getMessage());
		}
	}

	public List<UserDTO> getUsers() {
		List<UserDTO> userDTOs = new ArrayList<>();
		List<User> users = userService.getActiveUsers();
		if (users != null && !users.isEmpty())
			userDTOs = users.stream().map(this::convertEntityToDTO).collect(Collectors.toList());

		return userDTOs;
	}

	public UserDTO getUserByUserId(int userId) {
		UserDTO userDTO = null;
		User user = userService.getUserById(userId);
		if (user != null) {
			userDTO = convertEntityToDTO(user);
		}

		return userDTO;
	}

	public UserDTO createUser(UserDTO requestedUserDTO) {
		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		User requestedUser = convertDTOToEntity(requestedUserDTO);
		requestedUser.setAccount(user.getAccount());

		User createdUser = userService.createUser(requestedUser);
		if (createdUser != null) {
			createdUser.setUserHid(createKonexiosUser(requestedUserDTO).getHid());
			createdUser = userService.updateUser(createdUser);
		}
		return convertEntityToDTO(createdUser);
	}

	public com.growhouse.rest.dto.konexios.User createKonexiosUser(UserDTO user) {
		LOGGER.info("createKonexiosUser: " + user.getUsername());
		try {
			// lookup konexios
			String login = user.getUsername() + config.getLoginSuffix();
			LOGGER.info("checking konexios for user: " + login);
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set(config.getAuthTokenKey(), config.getAuthToken());
			FindUserResponse findResponse = restTemplate.exchange(config.buildUserFindUrl(), HttpMethod.POST,
					new HttpEntity<FindUserRequest>(new FindUserRequest().login(login), headers),
					FindUserResponse.class).getBody();
			if (findResponse.isSuccess()) {
				LOGGER.info("found existing konexios user: " + findResponse.getUser().getHid());
				return findResponse.getUser();
			} else {
				LOGGER.info("user not found in konexios, creating new one ...");
				CreateUserRequest request = new CreateUserRequest().login(login)
						.password(RandomStringUtils.random(16, PASSWORD_CHARS)).contact(new Contact()
								.firstName(user.getFirstName()).lastName(user.getLastName()).email(user.getEmail()))
						.roleNames(config.getRoleNames());
				CreateUserResponse createResponse = restTemplate
						.exchange(config.buildUserCreateUrl(), HttpMethod.POST,
								new HttpEntity<CreateUserRequest>(request, headers), CreateUserResponse.class)
						.getBody();
				if (createResponse.isSuccess()) {
					LOGGER.info("created new konexios user: " + createResponse.getUser().getHid());
					return createResponse.getUser();
				} else {
					LOGGER.error("error creating konexios user: " + createResponse.getMessage());
					userService.deleteUser(user.getId());
					throw new HttpClientErrorException(HttpStatus.BAD_REQUEST, "Error: " + createResponse.getMessage());
				}
			}
		} catch (HttpStatusCodeException exception) {
			LOGGER.error("HttpStatusCodeException: " + exception.getMessage());
			throw new HttpClientErrorException(HttpStatus.BAD_REQUEST, exception.getStatusText());
		} catch (Exception e) {
			LOGGER.error(ExceptionUtils.getFullStackTrace(e));
			throw e;
		}

	}

	public UserDTO getUserByToken() {
		User existingUser = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if (existingUser == null || !existingUser.isActive()) {
			LOGGER.error(Constants.USER_NOT_FOUND_MESSAGE);
			throw new HttpClientErrorException(HttpStatus.UNAUTHORIZED, Constants.USER_NOT_FOUND_MESSAGE);
		}
		if (!existingUser.getUserRole().getRoleName().equals("SuperAdmin")) {
			LOGGER.info("User is not super admin");
			if (!existingUser.getAccount().isActive())
				throw new HttpClientErrorException(HttpStatus.UNAUTHORIZED, "Account is locked");
			if (!existingUser.isActive())
				throw new HttpClientErrorException(HttpStatus.UNAUTHORIZED, Constants.USER_INACTIVE_MESSAGE);
		}
		return convertEntityToDTO(existingUser);
	}

	public List<UserDTO> getUserByAccountIdAndAdmin(int accountId) {
		List<User> users = userService.getUserRepository().findByAccountIdAndUserRoleRoleNameAndIsActiveTrue(accountId,
				Constants.ADMIN_USER_ROLE);
		return users.stream().map(this::convertEntityToDTO).collect(Collectors.toList());
	}

	public UserDTO updateUser(int userId, UserDTO requestedUserDTO) {
		if (userId != requestedUserDTO.getId())
			throw new HttpClientErrorException(HttpStatus.NOT_ACCEPTABLE,
					"UserId in URL doesnot match with userId of User object");

		User existingUser = userService.getUserById(requestedUserDTO.getId());
		if (existingUser == null)
			throw new HttpClientErrorException(HttpStatus.NOT_FOUND, Constants.USER_NOT_FOUND_MESSAGE);

		if (!existingUser.isActive())
			throw new HttpClientErrorException(HttpStatus.BAD_REQUEST, Constants.USER_INACTIVE_MESSAGE);

		modelMapper.map(requestedUserDTO, existingUser);
		existingUser = userService.updateUser(existingUser);

		UserDTO updatedUserDTO = convertEntityToDTO(existingUser);
		updateKonexiosUser(updatedUserDTO);

		return updatedUserDTO;
	}

	public void updateKonexiosUser(UserDTO user) {
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set(config.getAuthTokenKey(), config.getAuthToken());
			UpdateUserRequest request = new UpdateUserRequest().contact(
					new Contact().firstName(user.getFirstName()).lastName(user.getLastName()).email(user.getEmail()));
			LOGGER.info(objectMapper.writeValueAsString(request));
			UpdateUserResponse response = restTemplate.exchange(config.buildUserUpdateUrl(user.getUserHid()),
					HttpMethod.PUT, new HttpEntity<UpdateUserRequest>(request, headers), UpdateUserResponse.class)
					.getBody();
			LOGGER.info(objectMapper.writeValueAsString(response));
			if (response.isSuccess()) {
				LOGGER.info("user has been updated successfully in konexios");
			} else {
				LOGGER.error("error updating user in konexios");
			}
		} catch (HttpStatusCodeException exception) {
			LOGGER.error("HttpStatusCodeException: " + exception.getMessage());
			throw new HttpClientErrorException(HttpStatus.BAD_REQUEST, exception.getStatusText());
		} catch (Exception e) {
			LOGGER.error(ExceptionUtils.getFullStackTrace(e));
			throw new HttpClientErrorException(HttpStatus.BAD_REQUEST, e.getMessage());
		}
	}

	public User deleteUser(int userId) {
		return userService.deleteUser(userId);
	}

	public UserDTO convertEntityToDTO(User user) {
		return modelMapper.map(user, UserDTO.class);
	}

	public User convertDTOToEntity(UserDTO userDTO) {
		return modelMapper.map(userDTO, User.class);
	}

}
