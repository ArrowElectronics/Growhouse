/**
 * 
 */
package com.growhouse.rest.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author dharita.chokshi
 *
 */
public class UserDTO {

	private Integer id;
	private String username;
	@JsonProperty("user_role")
	private UserRoleDTO userRole;
	@JsonProperty("account")
	private AccountDTO account;
	@JsonProperty("email_id")
	private String email;
	@JsonProperty("user_hid")
	private String userHid;
	@JsonProperty("first_name")
	private String firstName;
	@JsonProperty("last_name")
	private String lastName;

	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * @param username the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}

	/**
	 * @return the userRole
	 */
	public UserRoleDTO getUserRole() {
		return userRole;
	}

	/**
	 * @param userRole the userRole to set
	 */
	public void setUserRole(UserRoleDTO userRole) {
		this.userRole = userRole;
	}

	/**
	 * @return the account
	 */
	public AccountDTO getAccount() {
		return account;
	}

	/**
	 * @param account the account to set
	 */
	public void setAccount(AccountDTO account) {
		this.account = account;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return the userHid
	 */
	public String getUserHid() {
		return userHid;
	}

	/**
	 * @param userHid the userHid to set
	 */
	public void setUserHid(String userHid) {
		this.userHid = userHid;
	}

	@Override
	public String toString() {
		return "UserDTO [id=" + id + ", username=" + username + ", userRole=" + userRole + ", account=" + account
				+ ", email=" + email + "]";
	}
}
