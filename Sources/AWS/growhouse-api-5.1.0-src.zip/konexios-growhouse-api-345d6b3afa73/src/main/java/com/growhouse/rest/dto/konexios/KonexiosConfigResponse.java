package com.growhouse.rest.dto.konexios;

public class KonexiosConfigResponse {
	private String apiUrl;
	private String mqttUrl;
	private String mqttPrefix;
	private String apiKey;
	private String applicationHid;

	public String getApiUrl() {
		return apiUrl;
	}

	public void setApiUrl(String apiUrl) {
		this.apiUrl = apiUrl;
	}

	public String getMqttUrl() {
		return mqttUrl;
	}

	public void setMqttUrl(String mqttUrl) {
		this.mqttUrl = mqttUrl;
	}

	public String getMqttPrefix() {
		return mqttPrefix;
	}

	public void setMqttPrefix(String mqttPrefix) {
		this.mqttPrefix = mqttPrefix;
	}

	public String getApiKey() {
		return apiKey;
	}

	public void setApiKey(String apiKey) {
		this.apiKey = apiKey;
	}

	public String getApplicationHid() {
		return applicationHid;
	}

	public void setApplicationHid(String applicationHid) {
		this.applicationHid = applicationHid;
	}
}
