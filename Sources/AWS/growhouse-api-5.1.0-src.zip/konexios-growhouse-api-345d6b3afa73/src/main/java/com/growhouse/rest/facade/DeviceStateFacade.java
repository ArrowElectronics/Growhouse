package com.growhouse.rest.facade;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.growhouse.rest.dto.CheckDeviceStateDTO;
import com.growhouse.rest.utils.Command;
import com.growhouse.rest.utils.Constants;
import com.growhouse.rest.utils.SendCommandToArrowConnect;

@Component
public class DeviceStateFacade {
	
	@Autowired
	private SendCommandToArrowConnect commandToArrowConnect;
	
	public void checkDeviceState(CheckDeviceStateDTO checkDeviceStateDTO) {
		
		Map<String, Object> map = new HashMap<>();
		map.put(Constants.COMMAND, Command.led_intensity);
		map.put(Constants.DEVICE_HID, checkDeviceStateDTO.getDeviceHid());
		map.put(Constants.MESSAGE_EXPIRATION, 10);
		map.put(Constants.PAYLOAD, Constants.EMPTY_JSON_PAYLOAD);
		commandToArrowConnect.sendCommand(map,checkDeviceStateDTO.getGatewayHid(), checkDeviceStateDTO.getDeviceHid());
	}

}
