package com.growhouse.rest.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "devices")
public class Device extends DefaultModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1912292290928752440L;

	@Column(name = "device_name")
	@NotNull
	private String deviceName;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "grow_area")
	private GrowArea growArea;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "grow_section", nullable = true)
	private GrowSection growSection;

	@NotNull
	private String eui64;

	@NotNull
	private String deviceUId;

	private String deviceHId;
	
	@Column(name = "prefix_keyword")
	private String prefixKeyword;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "device_type")
	private DeviceType deviceType;

	private String description;

	@Column(name = "status", columnDefinition = "TINYINT DEFAULT '1'")
	@NotNull
	private boolean status;
	
	
	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	/**
	 * @return the deviceName
	 */
	public String getDeviceName() {
		return deviceName;
	}

	/**
	 * @param deviceName
	 *            the deviceName to set
	 */
	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}

	/**
	 * @return the growArea
	 */
	public GrowArea getGrowArea() {
		return growArea;
	}

	/**
	 * @param growArea
	 *            the growArea to set
	 */
	public void setGrowArea(GrowArea growArea) {
		this.growArea = growArea;
	}

	/**
	 * @return the growSection
	 */
	public GrowSection getGrowSection() {
		return growSection;
	}

	/**
	 * @param growSection
	 *            the growSection to set
	 */
	public void setGrowSection(GrowSection growSection) {
		this.growSection = growSection;
	}

	/**
	 * @return the eui64
	 */
	public String getEui64() {
		return eui64;
	}

	/**
	 * @param eui64
	 *            the eui64 to set
	 */
	public void setEui64(String eui64) {
		this.eui64 = eui64;
	}

	/**
	 * @return the deviceUId
	 */
	public String getDeviceUId() {
		return deviceUId;
	}

	/**
	 * @param deviceUId
	 *            the deviceUId to set
	 */
	public void setDeviceUId(String deviceUId) {
		this.deviceUId = deviceUId;
	}

	/**
	 * @return the deviceHId
	 */
	public String getDeviceHId() {
		return deviceHId;
	}

	/**
	 * @param deviceHId
	 *            the deviceHId to set
	 */
	public void setDeviceHId(String deviceHId) {
		this.deviceHId = deviceHId;
	}

	/**
	 * @return the deviceType
	 */
	public DeviceType getDeviceType() {
		return deviceType;
	}

	/**
	 * @param deviceType
	 *            the deviceType to set
	 */
	public void setDeviceType(DeviceType deviceType) {
		this.deviceType = deviceType;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description
	 *            the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}



	public String getPrefixKeyword() {
		return prefixKeyword;
	}

	public void setPrefixKeyword(String prefixKeyword) {
		this.prefixKeyword = prefixKeyword;
	}

	@Override
	public String toString() {
		return "Device [deviceName=" + deviceName + ", growArea=" + growArea + ", growSection=" + growSection
				+ ", eui64=" + eui64 + ", deviceUId=" + deviceUId + ", deviceHId=" + deviceHId + ", prefixKeyword="
				+ prefixKeyword + ", deviceType=" + deviceType + ", description=" + description + ", status=" + status
				+ "]";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	

}
