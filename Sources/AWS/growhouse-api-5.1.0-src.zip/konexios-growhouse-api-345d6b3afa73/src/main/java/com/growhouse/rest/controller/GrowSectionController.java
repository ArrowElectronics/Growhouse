/**
 * 
 */
package com.growhouse.rest.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;

import com.growhouse.rest.dto.GrowSectionDTO;
import com.growhouse.rest.dto.GrowSectionDeviceCountDTO;
import com.growhouse.rest.entity.GrowSection;
import com.growhouse.rest.facade.GrowSectionFacade;
import com.growhouse.rest.response.ResponseMessage;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author dharita.chokshi
 *
 */

@RestController
@RequestMapping("/api/growsections")
@Transactional
public class GrowSectionController {

	public static final Logger LOGGER = LoggerFactory.getLogger(GrowSectionController.class);

	@Autowired
	private GrowSectionFacade growSectionFacade;

	/*
	 * Query-- Select grow_area_id from grow_area_assignee where user_id=? and
	 * is_active=true and grow_area.is_active=true Select * from grow_sections where
	 * grow_area_id=? and is_active=true.
	 */
	@GetMapping(value = "")
	@ApiOperation(value = "View list of active grow sections")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "List retrieved successfully"),
			@ApiResponse(code = 204, message = "Empty list") })
	public ResponseEntity<?> getActiveGrowSections() {
		ResponseEntity<?> responseEntity;
		try {
			List<GrowSectionDTO> growSections = growSectionFacade.getActiveGrowSections();
			if (growSections == null || growSections.isEmpty())
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(growSections, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/* Query-- Select * from grow_sections. */
	@GetMapping(value = "/all")
	@ApiOperation(value = "View list of all (active and inactive) grow sections")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "List retrieved successfully"),
			@ApiResponse(code = 204, message = "Empty list.") })
	public ResponseEntity<List<GrowSectionDTO>> getAllGrowSections() {
		ResponseEntity<List<GrowSectionDTO>> responseEntity;
		try {
			List<GrowSectionDTO> growSections = growSectionFacade.getAllGrowSections();
			if (growSections == null || growSections.isEmpty())
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(growSections, HttpStatus.OK);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/*
	 * Query-- Select * from grow_sections where grow_area_id=? and is_active=true.
	 */
	@GetMapping(value = "/growareas/{growAreaId}")
	@ApiOperation(value = "View list of grow sections based on growAreaId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "List retrieved successfully"),
			@ApiResponse(code = 204, message = "Empty list") })
	public ResponseEntity<List<GrowSectionDTO>> getGrowSectionsByGrowAreaId(
			@PathVariable("growAreaId") Integer growAreaId) {
		ResponseEntity<List<GrowSectionDTO>> responseEntity;
		try {
			List<GrowSectionDTO> growSections = growSectionFacade.getGrowSectionsByGrowAreaId(growAreaId);
			if (growSections == null || growSections.isEmpty())
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(growSections, HttpStatus.OK);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@GetMapping(value = "/containers/{containerId}")
	@ApiOperation(value = "View list of grow sections based on containerId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "List retrieved successfully"),
			@ApiResponse(code = 204, message = "Empty list") })
	public ResponseEntity<List<GrowSectionDTO>> getGrowSectionsByContainerId(
			@PathVariable("containerId") Integer containerId) {
		ResponseEntity<List<GrowSectionDTO>> responseEntity;
		try {
			List<GrowSectionDTO> growSections = growSectionFacade.getGrowSectionsByContainerId(containerId);
			if (growSections == null || growSections.isEmpty())
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(growSections, HttpStatus.OK);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@GetMapping(value = "/facilities/{facilityId}")
	@ApiOperation(value = "View list of grow sections based on facilityId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "List retrieved successfully"),
			@ApiResponse(code = 204, message = "Empty list") })
	public ResponseEntity<List<GrowSectionDTO>> getGrowSectionsByFacilityId(
			@PathVariable("facilityId") Integer facilityId) {
		ResponseEntity<List<GrowSectionDTO>> responseEntity;
		try {
			List<GrowSectionDTO> growSections = growSectionFacade.getGrowSectionsByFacilityId(facilityId);
			if (growSections == null || growSections.isEmpty())
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(growSections, HttpStatus.OK);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@GetMapping(value = "/{growSectionId}")
	@ApiOperation(value = "View grow section based on growSectionId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Grow section retrieved successfully"),
			@ApiResponse(code = 403, message = "Grow section is inactive") })
	public ResponseEntity<?> getGrowSectionByGrowSectionId(@PathVariable("growSectionId") Integer growSectionId) {
		ResponseEntity<?> responseEntity;
		try {
			GrowSectionDTO growSections = growSectionFacade.getGrowSectionById(growSectionId);
			if (growSections == null)
				responseEntity = new ResponseEntity<>(HttpStatus.NOT_FOUND);
			else
				responseEntity = new ResponseEntity<>(growSections, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@GetMapping(value = "/{growSectionId}/devices/count")
	@ApiOperation(value = "View grow section devices count based on growSectionId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Grow section retrieved successfully"),
			@ApiResponse(code = 403, message = "Grow section is inactive") })
	public ResponseEntity<?> getGrowSectionDevicesByGrowSectionId(
			@PathVariable("growSectionId") Integer growSectionId) {
		ResponseEntity<?> responseEntity;
		try {
			GrowSectionDeviceCountDTO count = growSectionFacade
					.getGrowSectionDevicesCountByGrowSectionId(growSectionId);
			responseEntity = new ResponseEntity<>(count, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@PostMapping(value = "", consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Create new grow sections")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Grow section created successfully"),
			@ApiResponse(code = 400, message = "Bad Request") })
	public ResponseEntity<?> createGrowSection(@RequestBody List<GrowSectionDTO> growSectionDTOs) {
		ResponseEntity<?> responseEntity;
		try {
			List<GrowSectionDTO> createdGrowSectionDTOs = growSectionFacade.createGrowSection(growSectionDTOs);
			if (createdGrowSectionDTOs == null)
				responseEntity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			else
				responseEntity = new ResponseEntity<>(createdGrowSectionDTOs, HttpStatus.CREATED);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@PutMapping(value = "")
	@ApiOperation(value = "Update existing grow sections")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Grow section updated successfully"),
			@ApiResponse(code = 400, message = "Bad Request"),
			@ApiResponse(code = 403, message = "Grow section is inactive"),
			@ApiResponse(code = 404, message = "Grow section not found") })
	public ResponseEntity<?> updateGrowSection(@RequestBody List<GrowSectionDTO> growSectionDTOs) {
		ResponseEntity<?> responseEntity;
		try {
			List<GrowSectionDTO> updatedGrowSectionDTOs = growSectionFacade.updateGrowSection(growSectionDTOs);
			if (updatedGrowSectionDTOs == null)
				responseEntity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			else
				responseEntity = new ResponseEntity<>(updatedGrowSectionDTOs, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception exception) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@DeleteMapping(value = "/{growSectionId}")
	@ApiOperation(value = "Delete grow section by growSectionId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Grow section deleted successfully") })
	public ResponseEntity<ResponseMessage> deleteGrowSection(@PathVariable("growSectionId") Integer growSectionId) {
		ResponseEntity<ResponseMessage> responseEntity;
		try {
			GrowSection isDeleted = growSectionFacade.deleteGrowSection(growSectionId);
			if (isDeleted != null) {
				ResponseMessage responseMessage = new ResponseMessage();
				responseMessage.setMessage("Grow section deleted successfully");
				responseEntity = new ResponseEntity<>(responseMessage, HttpStatus.OK);
			} else {
				responseEntity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			}
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@DeleteMapping(value = "/growSection/{gatewayId}")
	@ApiOperation(value = "Delete grow section by gatewayId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Grow section deleted successfully") })
	public ResponseEntity<ResponseMessage> deleteGrowSectionByGatewayId(@PathVariable("gatewayId") Integer gatewayId) {
		ResponseEntity<ResponseMessage> responseEntity;
		try {
			growSectionFacade.deleteGrowSectionByGatewayId(gatewayId);
			ResponseMessage responseMessage = new ResponseMessage();
			responseMessage.setMessage("Grow section deleted successfully");
			responseEntity = new ResponseEntity<>(responseMessage, HttpStatus.OK);

		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/**
	 * @param httpClientErrorException
	 * @return
	 */
	private ResponseEntity<ResponseMessage> setResponseMessage(HttpClientErrorException httpClientErrorException) {
		ResponseMessage responseMessage = new ResponseMessage();
		responseMessage.setMessage(httpClientErrorException.getStatusText());
		return new ResponseEntity<>(responseMessage, httpClientErrorException.getStatusCode());
	}

}
