package com.growhouse.rest.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GrowSectionDTO {

	private Integer id;
	@JsonProperty("grow_section_name")
	private String growSectionName;
	@JsonProperty("grow_area")
	private GrowAreaDTO growArea;
	private String description;
	private String size;
	private List<DeviceDTO> devices;

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the growSectionName
	 */
	public String getGrowSectionName() {
		return growSectionName;
	}

	/**
	 * @param growSectionName
	 *            the growSectionName to set
	 */
	public void setGrowSectionName(String growSectionName) {
		this.growSectionName = growSectionName;
	}

	/**
	 * @return the growAreaDTO
	 */
	public GrowAreaDTO getGrowArea() {
		return growArea;
	}

	/**
	 * @param growAreaDTO
	 *            the growAreaDTO to set
	 */
	public void setGrowArea(GrowAreaDTO growAreaDTO) {
		this.growArea = growAreaDTO;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description
	 *            the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the size
	 */
	public String getSize() {
		return size;
	}

	/**
	 * @param size
	 *            the size to set
	 */
	public void setSize(String size) {
		this.size = size;
	}

	/**
	 * @return the deviceDTOs
	 */
	public List<DeviceDTO> getDevices() {
		return devices;
	}

	/**
	 * @param deviceDTOs
	 *            the deviceDTOs to set
	 */
	public void setDevices(List<DeviceDTO> deviceDTOs) {
		this.devices = deviceDTOs;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "GrowSectionDTO [id=" + id + ", growSectionName=" + growSectionName + ", growAreaDTO=" + growArea
				+ ", description=" + description + ", size=" + size + ", deviceDTOs=" + devices + "]";
	}

}
