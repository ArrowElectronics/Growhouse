/**
 * 
 */
package com.growhouse.rest.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;

import com.growhouse.rest.dto.GrowAreaDTO;
import com.growhouse.rest.dto.GrowAreaHeartbeatDTO;
import com.growhouse.rest.dto.GrowAreaOutOfNetworkDTO;
import com.growhouse.rest.dto.OutofNetworkCountDTO;
import com.growhouse.rest.entity.GrowArea;
import com.growhouse.rest.entity.GrowAreaAssignee;
import com.growhouse.rest.facade.GrowAreaFacade;
import com.growhouse.rest.response.ResponseMessage;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author dharita.chokshi
 *
 */

@RestController
@RequestMapping("/api/growareas")
@Transactional
public class GrowAreaController {

	private static final Logger LOGGER = LogManager.getLogger(GrowAreaController.class);

	@Autowired
	private GrowAreaFacade growAreaFacade;

	/*
	 * Query--Select growarea from grow_area_assignee where user_id=? and
	 * growarea.is_active=true
	 */
	@GetMapping(value = "")
	@ApiOperation(value = "View list of active grow areas by user")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "List retrieved successfully"),
			@ApiResponse(code = 204, message = "Empty list") })
	public ResponseEntity<?> getActiveGrowAreas() {
		ResponseEntity<?> responseEntity;
		try {

			List<GrowAreaDTO> growAreas = growAreaFacade.getActiveGrowAreas();
			if (growAreas == null || growAreas.isEmpty())
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(growAreas, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/* Query--Select * from growarea */
	@GetMapping(value = "/all")
	@ApiOperation(value = "View list of all (active) grow areas")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "List retrieved successfully"),
			@ApiResponse(code = 204, message = "Empty list.") })
	public ResponseEntity<List<GrowAreaDTO>> getAllGrowAreas() {
		ResponseEntity<List<GrowAreaDTO>> responseEntity;
		try {
			List<GrowAreaDTO> growAreas = growAreaFacade.getAllGrowAreas();
			if (growAreas == null || growAreas.isEmpty())
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(growAreas, HttpStatus.OK);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/*
	 * Query--Select growarea from grow_area_assignee where user_id=? and
	 * container_id=? and growarea.is_active=true
	 */
	@GetMapping(value = "/containers/{containerId}")
	@ApiOperation(value = "View list of grow areas based on containerId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "List retrieved successfully"),
			@ApiResponse(code = 204, message = "Empty list") })
	public ResponseEntity<List<GrowAreaDTO>> getGrowAreasByContainerId(
			@PathVariable("containerId") Integer containerId) {
		ResponseEntity<List<GrowAreaDTO>> responseEntity;
		try {
			List<GrowAreaDTO> growAreas = growAreaFacade.getGrowAreasByContainerId(containerId);
			if (growAreas == null || growAreas.isEmpty())
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(growAreas, HttpStatus.OK);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/*
	 * Query--Select growarea from grow_area_assignee where user_id=? and
	 * facility_id=? and growarea.is_active=true
	 */
	@GetMapping(value = "/facilities/{facilityId}")
	@ApiOperation(value = "View list of grow areas based on facilityId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "List retrieved successfully"),
			@ApiResponse(code = 204, message = "Empty list") })
	public ResponseEntity<List<GrowAreaDTO>> getGrowAreasByFacilityId(@PathVariable("facilityId") Integer facilityId) {
		ResponseEntity<List<GrowAreaDTO>> responseEntity;
		try {
			List<GrowAreaDTO> growAreas = growAreaFacade.getGrowAreasByFacilityId(facilityId);
			if (growAreas == null || growAreas.isEmpty())
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(growAreas, HttpStatus.OK);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/*
	 * Query--Select growarea from grow_area_assignee where facility_id=? and
	 * user_id=?
	 */
	@GetMapping(value = "/hids/facilities/{facilityId}")
	@ApiOperation(value = "View list of grow areas based on facilityId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "List retrieved successfully"),
			@ApiResponse(code = 204, message = "Empty list") })
	public ResponseEntity<List<String>> getGrowAreasHIdsByFacilityId(@PathVariable("facilityId") Integer facilityId) {
		ResponseEntity<List<String>> responseEntity;
		try {
			List<GrowAreaDTO> growAreas = growAreaFacade.getGrowAreasByFacilityId(facilityId);
			if (growAreas == null || growAreas.isEmpty())
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else {
				List<String> growAreaHids = growAreas.stream().map(GrowAreaDTO::getGrowAreaHId)
						.collect(Collectors.toList());
				responseEntity = new ResponseEntity<>(growAreaHids, HttpStatus.OK);
			}
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/* Query--Select * from grow_areas where grow_area_id=? */
	@GetMapping(value = "/{growAreaId}")
	@ApiOperation(value = "View grow area based on growAreaId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Grow area retrieved successfully"),
			@ApiResponse(code = 403, message = "Grow area is inactive") })
	public ResponseEntity<?> getGrowAreaByGrowAreaId(@PathVariable("growAreaId") Integer growAreaId) {
		ResponseEntity<?> responseEntity;
		try {
			GrowAreaDTO growAreas = growAreaFacade.getGrowAreaById(growAreaId);
			if (growAreas == null)
				responseEntity = new ResponseEntity<>(HttpStatus.NOT_FOUND);
			else
				responseEntity = new ResponseEntity<>(growAreas, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@PostMapping(value = "", consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Create new grow area")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Grow area created successfully"),
			@ApiResponse(code = 400, message = "Bad Request") })
	public ResponseEntity<?> createGrowArea(@RequestBody GrowAreaDTO growAreaDTO) {
		ResponseEntity<?> responseEntity;
		try {
			GrowAreaDTO createdGrowAreas = growAreaFacade.createGrowArea(growAreaDTO);
			if (createdGrowAreas == null)
				responseEntity = new ResponseEntity<>(HttpStatus.NOT_FOUND);
			else
				responseEntity = new ResponseEntity<>(createdGrowAreas, HttpStatus.CREATED);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@PutMapping(value = "/{growAreaId}")
	@ApiOperation(value = "Update existing grow area")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Grow area updated successfully"),
			@ApiResponse(code = 400, message = "Bad Request"),
			@ApiResponse(code = 403, message = "Grow area is inactive"),
			@ApiResponse(code = 404, message = "Grow area not found"),
			@ApiResponse(code = 406, message = "GrowAreaId in URL doesnot match with growAreaId of GrowArea object") })
	public ResponseEntity<?> updateGrowArea(@PathVariable("growAreaId") Integer growAreaId,
			@RequestBody GrowAreaDTO growAreaDTO) {
		ResponseEntity<?> responseEntity;
		try {
			GrowAreaDTO updatedGrowAreas = growAreaFacade.updateGrowArea(growAreaId, growAreaDTO);
			if (updatedGrowAreas == null)
				responseEntity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			else
				responseEntity = new ResponseEntity<>(growAreaDTO, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/*
	 * Query-- Update grow_area_assignee SET is_active=false where grow_area_id=?
	 * and user_id=?
	 * 
	 */
	@PutMapping(value = "/{growAreaId}/removeAssignee/{userId}")
	@ApiOperation(value = "Update existing grow area")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "User successfully removed from selected grow area"),
			@ApiResponse(code = 400, message = "Bad Request"),
			@ApiResponse(code = 403, message = "Grow area is inactive"),
			@ApiResponse(code = 404, message = "Grow area not found") })
	public ResponseEntity<ResponseMessage> removeGrowAreaAssignee(@PathVariable("growAreaId") Integer growAreaId,
			@PathVariable("userId") Integer userId) {
		ResponseEntity<ResponseMessage> responseEntity;
		try {
			GrowAreaAssignee isRemoved = growAreaFacade.removeGrowAreaAssignee(growAreaId, userId);
			if (isRemoved != null) {
				ResponseMessage responseMessage = new ResponseMessage();
				responseMessage.setMessage("User successfully removed from selected grow area");
				responseEntity = new ResponseEntity<>(responseMessage, HttpStatus.OK);
			} else {
				responseEntity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			}
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/*
	 * Query-- Update grow_area SET is_active=false where grow_area_id=?
	 * 
	 */
	@DeleteMapping(value = "/{growAreaId}")
	@ApiOperation(value = "Delete grow area by growAreaId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "GrowArea deleted successfully") })
	public ResponseEntity<ResponseMessage> deleteGrowArea(@PathVariable("growAreaId") Integer growAreaId) {
		ResponseEntity<ResponseMessage> responseEntity;
		try {
			GrowArea deletedGrowArea = growAreaFacade.deleteGrowArea(growAreaId);
			if (deletedGrowArea != null) {
				ResponseMessage responseMessage = new ResponseMessage();
				responseMessage.setMessage("GrowArea deleted successfully");
				responseEntity = new ResponseEntity<>(responseMessage, HttpStatus.OK);
			} else {
				responseEntity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			}
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@PutMapping(value = "/heartbeat/{growAreaHId}")
	@ApiOperation(value = "Update latest heartbeat by growAreaHId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Latest Heartbeat timestamp updated successfully") })
	public ResponseEntity<ResponseMessage> updateGrowAreaHeartbeat(@PathVariable("growAreaHId") String growAreaHId) {
		ResponseEntity<ResponseMessage> responseEntity;

		try {
			growAreaFacade.updateLatestGatewayHeartbeat(growAreaHId, System.currentTimeMillis());
			ResponseMessage responseMessage = new ResponseMessage();
			responseMessage.setMessage("GrowArea latest heartbeat updated successfully");
			responseEntity = new ResponseEntity<>(responseMessage, HttpStatus.OK);
			LOGGER.info("In update gateway heartbeat controller:--" + growAreaHId);
		} catch (HttpClientErrorException httpClientErrorException) {
			LOGGER.info("exception occured in update gateway heartbeat:", httpClientErrorException);
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			LOGGER.info("exception occured in update gateway heartbeat:", e);
			responseEntity = new ResponseEntity<>(HttpStatus.OK);
		}
		return responseEntity;
	}

	@GetMapping(value = "/latestheartbeat")
	@ApiOperation(value = "Fetch latest gateway heartbeat using UserId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Grow area retrieved successfully"),
			@ApiResponse(code = 403, message = "Grow area is inactive") })
	public ResponseEntity<?> getGrowAreaLatestHeartbeatByGrowAreaId(@PathVariable("growAreaId") Integer growAreaId) {
		ResponseEntity<?> responseEntity;
		try {

			List<GrowAreaHeartbeatDTO> growAreaHeartbeatDTOs = growAreaFacade.getLatestGrowAreaHeartbeatByUserId();
			if (growAreaHeartbeatDTOs != null)
				responseEntity = new ResponseEntity<>(growAreaHeartbeatDTOs, HttpStatus.OK);
			else
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);

		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/*
	 * Query-- Select grow_area_id from grow_area_assignee where user_id=? Select *
	 * from grow_area where latest_heartbeat_timestamp < lastthirtymins
	 */
	@GetMapping(value = "/outofnetwork")
	@ApiOperation(value = "Fetch list of out of network GrowAreas")
	@ApiResponses(value = { @ApiResponse(code = 200, message = " List of Grow area retrieved successfully") })
	public ResponseEntity<?> getOutOfNetworkGrowAreas() {
		ResponseEntity<?> responseEntity;
		try {
			List<GrowAreaOutOfNetworkDTO> growAreas = growAreaFacade.getOutOfNetworkGrowAreas();
			if (growAreas == null || growAreas.isEmpty())
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(growAreas, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/*
	 * Query-- Select grow_area_id from grow_area_assignee where user_id=? Select
	 * COUNT(grow_area_id) from grow_area where latest_heartbeat_timestamp <
	 * lastthirtymins and is_active=true
	 */
	@GetMapping(value = "/count/outofnetwork")
	@ApiOperation(value = "View Count of out of network GrowAreas")
	@ApiResponses(value = { @ApiResponse(code = 200, message = " Count of Grow area retrieved successfully") })
	public ResponseEntity<?> getCountOutOfNetworkGrowAreas() {
		ResponseEntity<?> responseEntity;
		try {
			OutofNetworkCountDTO growAreas = growAreaFacade.getcountOutOfNetworkGrowAreas();
			responseEntity = new ResponseEntity<>(growAreas, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/*
	 * Query-- Select grow_area_id from grow_area_assignee where user_id=? and
	 * facility_id=? Select COUNT(grow_area_id) from grow_area where
	 * latest_heartbeat_timestamp < lastthirtymins and is_active=true
	 */
	@GetMapping(value = "/count/outofnetwork/facility/{facilityId}")
	@ApiOperation(value = "View Count of out of network GrowAreas by FacilityId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = " Count of Grow area retrieved successfully") })
	public ResponseEntity<?> getCountOutOfNetworkGrowAreasByFacilityId(@PathVariable("facilityId") Integer facilityId) {
		ResponseEntity<?> responseEntity;
		try {
			OutofNetworkCountDTO growAreas = growAreaFacade.getcountOutOfNetworkGrowAreasByFacilityId(facilityId);
			responseEntity = new ResponseEntity<>(growAreas, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/*
	 * Query-- Select grow_area_id from grow_area_assignee where user_id=? and
	 * container_id=? Select COUNT(grow_area_id) from grow_area where
	 * latest_heartbeat_timestamp < lastthirtymins and is_active=true
	 */
	@GetMapping(value = "/count/outofnetwork/container/{containerId}")
	@ApiOperation(value = "View Count of out of network GrowAreas by ContainerId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = " Count of Grow area retrieved successfully") })
	public ResponseEntity<?> getCountOutOfNetworkGrowAreasBycontainerId(
			@PathVariable("containerId") Integer containerId) {
		ResponseEntity<?> responseEntity;
		try {
			OutofNetworkCountDTO growAreas = growAreaFacade.getcountOutOfNetworkGrowAreasByContainerId(containerId);
			responseEntity = new ResponseEntity<>(growAreas, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@DeleteMapping(value = "/assignee/{growAreaId}")
	@ApiOperation(value = "Delete grow area Assignee by growAreaId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "GrowArea Assignee deleted successfully") })
	public ResponseEntity<ResponseMessage> deleteGrowAreaAssigneeByGatewayId(
			@PathVariable("growAreaId") Integer growAreaId) {
		ResponseEntity<ResponseMessage> responseEntity;
		try {
			growAreaFacade.deleteGrowAreaAssigneeByGatewayId(growAreaId);

			ResponseMessage responseMessage = new ResponseMessage();
			responseMessage.setMessage("GrowArea Assignee deleted successfully");
			responseEntity = new ResponseEntity<>(responseMessage, HttpStatus.OK);

		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/**
	 * @param httpClientErrorException
	 * @return
	 */
	private ResponseEntity<ResponseMessage> setResponseMessage(HttpClientErrorException httpClientErrorException) {
		ResponseMessage responseMessage = new ResponseMessage();
		responseMessage.setMessage(httpClientErrorException.getStatusText());
		return new ResponseEntity<>(responseMessage, httpClientErrorException.getStatusCode());
	}

}
