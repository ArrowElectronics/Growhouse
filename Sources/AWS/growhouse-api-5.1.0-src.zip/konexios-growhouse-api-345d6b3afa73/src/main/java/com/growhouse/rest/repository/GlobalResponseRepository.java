package com.growhouse.rest.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.growhouse.rest.entity.GlobalResponsePayload;

@Repository
public interface GlobalResponseRepository extends JpaRepository<GlobalResponsePayload, Integer> {

	public List<GlobalResponsePayload> findByFacilityIdIn(List<String> facilityIds);
	
	public List<GlobalResponsePayload> findByFacilityId(String facilityId);
	
	public List<GlobalResponsePayload> findByContainerId(String containerId);
	
	public List<GlobalResponsePayload> findByGrowSectionId(String growSectionId);
	
	public List<GlobalResponsePayload> findByGatewayId(String gatewayId);
	
	@Transactional
    @Modifying
    @Query(value="Update global_response_payload p SET p.grow_section_name=?1 where p.grow_section_id=?2",nativeQuery = true)
    public void updateSectionNameBySectionId(String sectionName,String sectionId);
	
}
