/**
 * 
 */
package com.growhouse.rest.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author dharita.chokshi
 *
 */
public class FacilityForGADTO {

	private Integer id;
	@JsonProperty("facility_name")
	private String facilityName;
	private UserForGADTO admin;
	private LocalityDTO locality;

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the facilityName
	 */
	public String getFacilityName() {
		return facilityName;
	}

	/**
	 * @param facilityName
	 *            the facilityName to set
	 */
	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	/**
	 * @return the admin
	 */
	public UserForGADTO getAdmin() {
		return admin;
	}

	/**
	 * @param admin
	 *            the admin to set
	 */
	public void setAdmin(UserForGADTO admin) {
		this.admin = admin;
	}

	public LocalityDTO getLocality() {
		return locality;
	}

	public void setLocality(LocalityDTO locality) {
		this.locality = locality;
	}
	
	
}
