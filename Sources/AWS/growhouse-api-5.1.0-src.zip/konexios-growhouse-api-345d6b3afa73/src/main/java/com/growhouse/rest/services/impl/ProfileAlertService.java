package com.growhouse.rest.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.growhouse.rest.entity.ProfileAlertsUI;
import com.growhouse.rest.repository.ProfileAlertRepository;
import com.growhouse.rest.repository.ProfileAlertsUIRepository;
import com.growhouse.rest.services.IProfileAlertService;

@Service
public class ProfileAlertService implements IProfileAlertService {
	
	@Autowired
	private ProfileAlertsUIRepository profileAlertUIRepo;
	
	@Autowired
	private ProfileAlertRepository profileAlertRepository;

	@Override
	public ProfileAlertRepository getProfileAlertRepository() {
		return profileAlertRepository;
	}

	public ProfileAlertsUI getProfileAlertByProfileId(int profileId)
	{
		return profileAlertUIRepo.getProfileAlertByProfileId(profileId);
	}
	public List<ProfileAlertsUI> getAllProfileAlertByProfileId(int profileId)
	{
		return profileAlertUIRepo.getAllProfileAlertByProfileId(profileId);
	}
	public List<ProfileAlertsUI> getAllProfileAlertByProfileIdAndDateRange(int profileId,long from,long to)
	{
		return profileAlertUIRepo.getAllProfileAlertByProfileIdDateRange(profileId,from,to);
	}
}
