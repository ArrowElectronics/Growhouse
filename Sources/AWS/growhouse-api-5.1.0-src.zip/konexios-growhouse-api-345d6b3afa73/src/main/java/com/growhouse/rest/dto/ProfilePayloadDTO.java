package com.growhouse.rest.dto;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ProfilePayloadDTO {
	private Integer id;

	private Map<String,ArrayList<ProfileConditionDTO>> conditions;

	private List<Monitor> monitors;

	private String name;

	private String ruleHid;
	
	private String type;

	private String timeInterval;
	
	private String profileName;

	private GlobalResponsePayloadDTO globalResponsePayload;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	

	public Map<String, ArrayList<ProfileConditionDTO>> getConditions() {
		return conditions;
	}

	public void setConditions(Map<String, ArrayList<ProfileConditionDTO>> conditions) {
		this.conditions = conditions;
	}

	public List<Monitor> getMonitors() {
		return monitors;
	}

	public void setMonitors(List<Monitor> monitors) {
		this.monitors = monitors;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRuleHid() {
		return ruleHid;
	}

	public void setRuleHid(String ruleHid) {
		this.ruleHid = ruleHid;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getTimeInterval() {
		return timeInterval;
	}

	public void setTimeInterval(String timeInterval) {
		this.timeInterval = timeInterval;
	}

	public String getProfileName() {
		return profileName;
	}

	public void setProfileName(String profileName) {
		this.profileName = profileName;
	}

	public GlobalResponsePayloadDTO getGlobalResponsePayload() {
		return globalResponsePayload;
	}

	public void setGlobalResponsePayload(GlobalResponsePayloadDTO globalResponsePayload) {
		this.globalResponsePayload = globalResponsePayload;
	}

	/**
	 * @return the conditions
	 */
	
	


	


}







