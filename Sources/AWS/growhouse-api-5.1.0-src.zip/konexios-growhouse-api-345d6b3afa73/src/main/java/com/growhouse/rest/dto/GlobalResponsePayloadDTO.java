package com.growhouse.rest.dto;

public class GlobalResponsePayloadDTO {

	private Integer id;

	private Integer containerId;

	private Integer facilityId;

	private Integer gatewayId;

	private String gatewayName;

	private String containerName;

	private String facilityName;

	private Integer growSectionId;

	private String growSectionName;

	private Integer profileId;

	private String profileName;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getContainerId() {
		return containerId;
	}

	public void setContainerId(Integer containerId) {
		this.containerId = containerId;
	}

	public Integer getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(Integer facilityId) {
		this.facilityId = facilityId;
	}

	public Integer getGatewayId() {
		return gatewayId;
	}

	public void setGatewayId(Integer gatewayId) {
		this.gatewayId = gatewayId;
	}

	public String getGatewayName() {
		return gatewayName;
	}

	public void setGatewayName(String gatewayName) {
		this.gatewayName = gatewayName;
	}

	public String getContainerName() {
		return containerName;
	}

	public void setContainerName(String containerName) {
		this.containerName = containerName;
	}

	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public Integer getGrowSectionId() {
		return growSectionId;
	}

	public void setGrowSectionId(Integer growSectionId) {
		this.growSectionId = growSectionId;
	}

	public String getGrowSectionName() {
		return growSectionName;
	}

	public void setGrowSectionName(String growSectionName) {
		this.growSectionName = growSectionName;
	}

	public Integer getProfileId() {
		return profileId;
	}

	public void setProfileId(Integer profileId) {
		this.profileId = profileId;
	}

	public String getProfileName() {
		return profileName;
	}

	public void setProfileName(String profileName) {
		this.profileName = profileName;
	}

}
