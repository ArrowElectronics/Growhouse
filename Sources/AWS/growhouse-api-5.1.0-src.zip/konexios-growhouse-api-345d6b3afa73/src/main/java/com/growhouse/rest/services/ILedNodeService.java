package com.growhouse.rest.services;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.growhouse.rest.entity.LedNodeGroupChannelConfiguration;
import com.growhouse.rest.entity.LedNodeGroupProfile;

public interface ILedNodeService {
	
	public Map<String,Object> getLedNodeStateProperties(String deviceHid);
	
	public LedNodeGroupChannelConfiguration createLedGroup(LedNodeGroupChannelConfiguration ledNodeGroupChannelConfiguration);
	
	public List<LedNodeGroupChannelConfiguration> getLedGroupByGrowareaId(Integer growAreaId);
	
	public LedNodeGroupChannelConfiguration updateLedGroup(LedNodeGroupChannelConfiguration ledNodeGroupChannelConfiguration);
	
	public LedNodeGroupChannelConfiguration deleteLedGroup(Integer groupId);
	
	public Optional<LedNodeGroupChannelConfiguration> getLedGroupById(Integer groupId);
	
	public LedNodeGroupProfile createLedNodeGroupProfile(LedNodeGroupProfile ledNodeGroupProfile);
	
	public List<LedNodeGroupProfile> getLedNodeGrupProfilesByGroupId(Integer groupId);

	public void deleteLedNodeGroupProfilesByGroupId(Integer groupId);
	
	public LedNodeGroupProfile updateLedNodeGroupProfile(LedNodeGroupProfile ledGroupProfile);
	
	public void deleteLedNodeProfileByProfileId(Integer profileId);
	
	public LedNodeGroupProfile getGroupProfileByProfileId(Integer profileId);
	
	public void deleteGroupsByGatewayId(Integer gatewayId);
	
	public void updateEventProfileNameByProfileId(String profileName,Integer profileId);
	
	public LedNodeGroupChannelConfiguration getGroupByGroupNameAndGateway(String groupName,int growAreaId);
	
	public LedNodeGroupProfile getProfileByProfileNameAndGroupId(String profileName,int groupId);

}
