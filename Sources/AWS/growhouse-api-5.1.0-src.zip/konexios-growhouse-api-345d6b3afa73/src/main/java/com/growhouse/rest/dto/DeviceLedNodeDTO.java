package com.growhouse.rest.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class DeviceLedNodeDTO {

	private Integer id;

	private String deviceUId;

	@JsonProperty("device_name")
	private String deviceName;

	private String deviceHId;

	private boolean status;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDeviceUId() {
		return deviceUId;
	}

	public void setDeviceUId(String deviceUId) {
		this.deviceUId = deviceUId;
	}

	public String getDeviceName() {
		return deviceName;
	}

	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}

	public String getDeviceHId() {
		return deviceHId;
	}

	public void setDeviceHId(String deviceHId) {
		this.deviceHId = deviceHId;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "DeviceStatusDTO [id=" + id + ", deviceUId=" + deviceUId + ", deviceName=" + deviceName + ", deviceHId="
				+ deviceHId + ", status=" + status + "]";
	}

}
