package com.growhouse.rest.dto;

public class CreateProfileActionDTO {

	
	private String criteria;
	private Integer expiration;
	private Boolean noTelemetry;
	private Integer noTelemetrySeconds;
	private Boolean enabled;
	private String systemName;
	private ProfileActionParametersDTO parameters;
	
	public String getCriteria() {
		return criteria;
	}
	public void setCriteria(String criteria) {
		this.criteria = criteria;
	}
	public Integer getExpiration() {
		return expiration;
	}
	public void setExpiration(Integer expiration) {
		this.expiration = expiration;
	}
	public Boolean getNoTelemetry() {
		return noTelemetry;
	}
	public void setNoTelemetry(Boolean noTelemetry) {
		this.noTelemetry = noTelemetry;
	}
	public Integer getNoTelemetrySeconds() {
		return noTelemetrySeconds;
	}
	public void setNoTelemetrySeconds(Integer noTelemetrySeconds) {
		this.noTelemetrySeconds = noTelemetrySeconds;
	}
	public Boolean getEnabled() {
		return enabled;
	}
	public void setEnabled(Boolean enabled) {
		this.enabled = enabled;
	}
	public String getSystemName() {
		return systemName;
	}
	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}
	public ProfileActionParametersDTO getParameters() {
		return parameters;
	}
	public void setParameters(ProfileActionParametersDTO parameters) {
		this.parameters = parameters;
	}
}
