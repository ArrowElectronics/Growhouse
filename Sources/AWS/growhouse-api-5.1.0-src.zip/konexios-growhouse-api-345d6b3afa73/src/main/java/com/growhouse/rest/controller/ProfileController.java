package com.growhouse.rest.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;
import com.growhouse.rest.dto.PayloadDTO;
import com.growhouse.rest.dto.ProfileAlertWrapperDTO;
import com.growhouse.rest.dto.ProfileDTO;
import com.growhouse.rest.dto.ProfileResponseDTO;
import com.growhouse.rest.dto.ProfileSubDTO;
import com.growhouse.rest.entity.GlobalResponsePayload;
import com.growhouse.rest.facade.ProfileFacade;
import com.growhouse.rest.response.ResponseMessage;
import com.growhouse.rest.utils.Command;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/api/profile")
@Transactional
public class ProfileController {

	@Autowired
	private ProfileFacade profileFacade;

	@PostMapping(value = "/growsection/{growSectionId}/create", consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Create new profile")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "payload created successfully"),
			@ApiResponse(code = 400, message = "Bad Request") })
	public ResponseEntity<?> createProfile(@PathVariable("growSectionId") Integer growSectionId,
			@RequestBody PayloadDTO payloadDTO) {
		ResponseEntity<?> responseEntity;
		try {
			ProfileDTO requestedDTO = new ProfileDTO();
			requestedDTO.setCommand(Command.createRule.toString());
			requestedDTO.setPayload(payloadDTO);
			requestedDTO.setProfileName(payloadDTO.getProfileName());
			ProfileDTO createdProfile = profileFacade.createProfile(growSectionId, requestedDTO);
			if (createdProfile == null)
				responseEntity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			else {
				ResponseMessage responseMessage = new ResponseMessage();
				responseMessage.setMessage("Profile creation request sent successfully");
				responseEntity = new ResponseEntity<>(responseMessage, HttpStatus.CREATED);
			}

		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@PutMapping(value = "/{profileId}/growsection/{growSectionId}/update", consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Update profile")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "payload created successfully"),
			@ApiResponse(code = 400, message = "Bad Request") })
	public ResponseEntity<?> updateProfile(@PathVariable("profileId") Integer profileId,
			@PathVariable("growSectionId") Integer growSectionId, @RequestBody PayloadDTO payloadDTO) {
		ResponseEntity<?> responseEntity;
		ResponseMessage responseMessage = new ResponseMessage();

		try {
			ProfileDTO requestedDTO = new ProfileDTO();
			requestedDTO.setCommand(Command.updateRule.toString());
			requestedDTO.setPayload(payloadDTO);
			requestedDTO.setProfileName(payloadDTO.getProfileName());
			requestedDTO.setId(profileId);

			ProfileDTO createdProfile = profileFacade.updateProfile(growSectionId, requestedDTO);
			if (createdProfile == null)
				responseEntity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			else {

				responseMessage.setMessage("Profile update request sent successfully");
				responseEntity = new ResponseEntity<>(responseMessage, HttpStatus.CREATED);
			}

		} catch (HttpClientErrorException httpClientErrorException) {

			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@PostMapping(value = "/alert/create", consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Create new Profile alert")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Profile alert created successfully"),
			@ApiResponse(code = 400, message = "Bad Request") })
	public ResponseEntity<?> createProfileAlert(@RequestBody ProfileAlertWrapperDTO profileAlertWrapperDTO) {
		ResponseEntity<?> responseEntity;
		try {
			profileFacade.createProfileAlert(profileAlertWrapperDTO.getTelemetry());
			responseEntity = new ResponseEntity<>(HttpStatus.CREATED);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
		return responseEntity;
	}

	@DeleteMapping(value = "/{profileId}")
	@ApiOperation(value = "Delete profile by profileId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Profile deleted successfully") })
	public ResponseEntity<ResponseMessage> deleteProfile(@PathVariable("profileId") Integer profileId) {
		ResponseEntity<ResponseMessage> responseEntity;
		ResponseMessage responseMessage = new ResponseMessage();
		try {

			profileFacade.deleteProfile(profileId);
			responseMessage.setMessage("Profile deleted successfully");
			responseEntity = new ResponseEntity<>(responseMessage, HttpStatus.OK);

		} catch (HttpClientErrorException httpClientErrorException) {
			responseMessage.setMessage("Profile does not exist on ArrowPortal");
			responseEntity = new ResponseEntity<>(responseMessage, HttpStatus.BAD_REQUEST);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@GetMapping(value = "/{profileId}")
	@ApiOperation(value = "Get profile Alert by profileId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Profile fetched successfully") })
	public ResponseEntity<?> fetchProfile(@PathVariable("profileId") Integer profileId) {
		ResponseEntity<?> responseEntity;
		try {
			ProfileResponseDTO profileResponseDTO = profileFacade.getSpecificProfileAlertByProfileId(profileId);
			if (profileResponseDTO == null)
				responseEntity = new ResponseEntity<>(new ArrayList<>(), HttpStatus.OK);
			else
				responseEntity = new ResponseEntity<>(profileResponseDTO, HttpStatus.OK);

		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@GetMapping(value = "/alert/{profileId}")
	@ApiOperation(value = "Get profile by profileId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Profile fetched successfully") })
	public ResponseEntity<?> getProfileByProfileId(@PathVariable("profileId") Integer profileId) {
		ResponseEntity<?> responseEntity;
		try {
			ProfileSubDTO profileResponseDTO = profileFacade.getProfileByProfileId(profileId);
			if (profileResponseDTO == null)
				responseEntity = new ResponseEntity<>(new ArrayList<>(), HttpStatus.OK);
			else
				responseEntity = new ResponseEntity<>(profileResponseDTO, HttpStatus.OK);

		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@GetMapping(value = "/user")
	@ApiOperation(value = "View all profile based on user")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Data retrieved successfully") })
	public ResponseEntity<?> getProfileByUserId() {
		ResponseEntity<?> responseEntity;
		try {

			List<GlobalResponsePayload> globalResponsePayloads = profileFacade.getProfileByUser();
			if (globalResponsePayloads == null || globalResponsePayloads.isEmpty())
				responseEntity = new ResponseEntity<>(new ArrayList<>(), HttpStatus.OK);
			else
				responseEntity = new ResponseEntity<>(globalResponsePayloads, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return responseEntity;
	}

	@GetMapping(value = "/container/{containerId}")
	@ApiOperation(value = "View all profile based on container id")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Data retrieved successfully") })
	public ResponseEntity<?> getProfileByContainerId(@PathVariable("containerId") String containerId) {
		ResponseEntity<?> responseEntity;
		try {

			List<GlobalResponsePayload> globalResponsePayloads = profileFacade.getProfileByContainerId(containerId);
			if (globalResponsePayloads == null || globalResponsePayloads.isEmpty())
				responseEntity = new ResponseEntity<>(new ArrayList<>(), HttpStatus.OK);
			else
				responseEntity = new ResponseEntity<>(globalResponsePayloads, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return responseEntity;
	}

	@GetMapping(value = "/facility/{facilityId}")
	@ApiOperation(value = "View all profile based on facility id")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Data retrieved successfully") })
	public ResponseEntity<?> getProfileByFacilityId(@PathVariable("facilityId") String facilityId) {
		ResponseEntity<?> responseEntity;
		try {

			List<GlobalResponsePayload> globalResponsePayloads = profileFacade.getProfileByFacilityId(facilityId);
			if (globalResponsePayloads == null || globalResponsePayloads.isEmpty())
				responseEntity = new ResponseEntity<>(new ArrayList<>(), HttpStatus.OK);
			else
				responseEntity = new ResponseEntity<>(globalResponsePayloads, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return responseEntity;
	}

	@GetMapping(value = "/growarea/{growAreaId}")
	@ApiOperation(value = "View all profile based on growArea id")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Data retrieved successfully") })
	public ResponseEntity<?> getProfileByGrowAreaId(@PathVariable("growAreaId") String growAreaId) {
		ResponseEntity<?> responseEntity;
		try {

			List<ProfileDTO> globalResponsePayloads = profileFacade.getProfilesByGrowAreaId(growAreaId);
			if (globalResponsePayloads == null || globalResponsePayloads.isEmpty())
				responseEntity = new ResponseEntity<>(new ArrayList<>(), HttpStatus.OK);
			else
				responseEntity = new ResponseEntity<>(globalResponsePayloads, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return responseEntity;
	}

	@GetMapping(value = "/growsection/{growSectionId}")
	@ApiOperation(value = "View all profile based on growSection id")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Data retrieved successfully") })
	public ResponseEntity<?> getProfileByGrowSectionId(@PathVariable("growSectionId") String growSectionId) {
		ResponseEntity<?> responseEntity;
		try {

			List<GlobalResponsePayload> globalResponsePayloads = profileFacade.getProfileByGrowSectionId(growSectionId);
			if (globalResponsePayloads == null || globalResponsePayloads.isEmpty())
				responseEntity = new ResponseEntity<>(new ArrayList<>(), HttpStatus.OK);
			else
				responseEntity = new ResponseEntity<>(globalResponsePayloads, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return responseEntity;
	}

	@GetMapping(value = "/alerts/growsection/{growSectionId}")
	@ApiOperation(value = "View all profile based on growSection id")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Data retrieved successfully") })
	public ResponseEntity<?> getProfileAlertsByGrowSectionId(@PathVariable("growSectionId") String growSectionId) {
		ResponseEntity<?> responseEntity;
		try {

			List<ProfileSubDTO> profiles = profileFacade.getProfileAlertsByGrowSectionId(growSectionId);
			if (profiles == null || profiles.isEmpty())
				responseEntity = new ResponseEntity<>(new ArrayList<>(), HttpStatus.OK);
			else
				responseEntity = new ResponseEntity<>(profiles, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return responseEntity;
	}

	@DeleteMapping(value = "/growarea/{gatewayId}")
	@ApiOperation(value = "Delete all profile based on growArea id")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Profile deleted successfully") })
	public ResponseEntity<?> deleteProfileByGatewayId(@PathVariable("gatewayId") int gatewayId) {
		ResponseEntity<?> responseEntity;
		try {
			profileFacade.deleteProfileByGatewayId(gatewayId);
			responseEntity = new ResponseEntity<>(HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception exception) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	private ResponseEntity<ResponseMessage> setResponseMessage(HttpClientErrorException httpClientErrorException) {
		ResponseMessage responseMessage = new ResponseMessage();
		responseMessage.setMessage(httpClientErrorException.getStatusText());
		return new ResponseEntity<>(responseMessage, httpClientErrorException.getStatusCode());
	}

}
