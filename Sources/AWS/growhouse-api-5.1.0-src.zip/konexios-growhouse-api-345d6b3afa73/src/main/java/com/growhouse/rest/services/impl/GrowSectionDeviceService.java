/**
 * 
 */
package com.growhouse.rest.services.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;

import com.growhouse.rest.entity.GrowSectionDevice;
import com.growhouse.rest.entity.User;
import com.growhouse.rest.repository.GrowSectionDeviceRepository;
import com.growhouse.rest.services.IGrowSectionDeviceService;


/**
 * @author dharita.chokshi
 *
 */
@Service
public class GrowSectionDeviceService implements IGrowSectionDeviceService {

	@Autowired
	private GrowSectionDeviceRepository growSectionDeviceRepository;

	
	public List<GrowSectionDevice> getActiveByGrowSectionId(int growSectionId) {
		return growSectionDeviceRepository.findByGrowSectionIdAndIsActiveTrue(growSectionId);
	}

	
	public List<GrowSectionDevice> getAllGrowSectionDevices() {
		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		return growSectionDeviceRepository.findByCreatedByIdAndIsActiveTrue(user.getId());
	}

	
	public List<GrowSectionDevice> getActiveByDeviceId(int deviceId) {
		return growSectionDeviceRepository.findByDeviceIdAndIsActiveTrue(deviceId);
	}

	
	public GrowSectionDevice createGrowSectionDevice(GrowSectionDevice growSectionDevice) {
		return growSectionDeviceRepository.save(growSectionDevice);
	}

	
	public List<GrowSectionDevice> createGrowSectionDevicesInBatch(List<GrowSectionDevice> growSectionDevices) {
		return growSectionDeviceRepository.saveAll(growSectionDevices);
	}

	
	public GrowSectionDevice updateGrowSectionDevice(GrowSectionDevice growSectionDevice) {
		return growSectionDeviceRepository.save(growSectionDevice);
	}

	
	public GrowSectionDevice deleteGrowSectionDevice(int id) {
		GrowSectionDevice deletedGrowSectionDevice=null;
		Optional<GrowSectionDevice> optional = growSectionDeviceRepository.findById(id);
		if (optional.isPresent() && optional.get().isActive()) {
			GrowSectionDevice growSectionDevice = optional.get();
			growSectionDevice.setActive(false);
			deletedGrowSectionDevice = growSectionDeviceRepository.save(growSectionDevice);
			
		} else {
			throw new HttpClientErrorException(HttpStatus.NOT_FOUND, "Requested grow section device not found");
		}
		return deletedGrowSectionDevice;
	}

	
	public void deleteGrowSectionDevicesInBatch(List<GrowSectionDevice> growSectionDevices) {
		growSectionDeviceRepository.deleteInBatch(growSectionDevices);
	}

	public int countGrowSectionDevicesByGrowSectionId(int growSectionId)
	{
		return growSectionDeviceRepository.countByGrowSectionIdAndIsActiveTrue(growSectionId);
	}
	
}
