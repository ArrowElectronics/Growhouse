package com.growhouse.rest.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.growhouse.rest.entity.LedNodeProfile;

@Repository
public interface LedNodeProfileRepository extends JpaRepository<LedNodeProfile, Integer> {

	public List<LedNodeProfile> findByDeviceIdAndIsActiveTrue(int deviceId);
	
	@Transactional
	@Modifying
	@Query(value="Update led_node_profile p SET p.is_active=0 where p.device_id=?1 and p.is_active=1",nativeQuery = true)
	public void deleteProfileByDeviceId(int deviceId);
	
	@Transactional
	@Modifying
	@Query(value="Update led_node_profile p SET p.is_active=0 where p.id=?1 and p.is_active=1",nativeQuery = true)
	public void deleteProfileById(int id);
	
	@Transactional
	@Modifying
	public void  deleteByDeviceGrowAreaId(int gatewayId);
	
	public LedNodeProfile findByDeviceIdAndProfileNameAndIsActiveTrue(int deviceId,String name);
}
