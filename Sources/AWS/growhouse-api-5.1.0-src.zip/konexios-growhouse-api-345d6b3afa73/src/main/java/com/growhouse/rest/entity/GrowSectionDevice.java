/**
 * 
 */
package com.growhouse.rest.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * @author dharita.chokshi
 *
 */
@Entity
@Table(name = "grow_section_device")
public class GrowSectionDevice extends DefaultModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -759953882250808825L;

	@OneToOne(fetch = FetchType.EAGER, cascade = { CascadeType.MERGE })
	@JoinColumn(name = "grow_section_id")
	private GrowSection growSection;

	@OneToOne(fetch = FetchType.EAGER, cascade = { CascadeType.MERGE })
	@JoinColumn(name = "device_id")
	private Device device;

	/**
	 * @return the growSection
	 */
	public GrowSection getGrowSection() {
		return growSection;
	}

	/**
	 * @param growSection
	 *            the growSection to set
	 */
	public void setGrowSection(GrowSection growSection) {
		this.growSection = growSection;
	}

	/**
	 * @return the device
	 */
	public Device getDevice() {
		return device;
	}

	/**
	 * @param device
	 *            the device to set
	 */
	public void setDevice(Device device) {
		this.device = device;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "GrowSectionDevices [growSection=" + growSection + ", device=" + device + "]";
	}

}