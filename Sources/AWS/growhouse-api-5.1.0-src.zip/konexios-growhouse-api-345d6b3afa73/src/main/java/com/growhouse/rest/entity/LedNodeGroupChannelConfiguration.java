package com.growhouse.rest.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="lednode_group_channel_configuration")
public class LedNodeGroupChannelConfiguration extends DefaultModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Column(name="grow_area_id")
	private Integer growArea;
	
	@Column(name="group_name")
	private String groupName;
	
	@Column(name="generated_group_name")
	private String generatedGroupName;
	
	@Column(name="CH1")
	private String led1;
	
	@Column(name="CH2")
	private String led2;
	
	@Column(name="CH3")
	private String led3;
	
	@Column(name="CH4")
	private String led4;
	
	@Column(name="CH5")
	private String led5;
	
	@Column(name="CH6")
	private String led6;

	@Column(name ="added_devices")
	private String devices;
	
	private String description;
	
	public Integer getGrowArea() {
		return growArea;
	}

	public void setGrowArea(Integer growArea) {
		this.growArea = growArea;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getLed1() {
		return led1;
	}

	public void setLed1(String led1) {
		this.led1 = led1;
	}

	public String getLed2() {
		return led2;
	}

	public void setLed2(String led2) {
		this.led2 = led2;
	}

	public String getLed3() {
		return led3;
	}

	public void setLed3(String led3) {
		this.led3 = led3;
	}

	public String getLed4() {
		return led4;
	}

	public void setLed4(String led4) {
		this.led4 = led4;
	}

	public String getLed5() {
		return led5;
	}

	public void setLed5(String led5) {
		this.led5 = led5;
	}

	public String getLed6() {
		return led6;
	}

	public void setLed6(String led6) {
		this.led6 = led6;
	}

	public String getGeneratedGroupName() {
		return generatedGroupName;
	}

	public void setGeneratedGroupName(String generatedGroupName) {
		this.generatedGroupName = generatedGroupName;
	}

	public String getDevices() {
		return devices;
	}

	public void setDevices(String devices) {
		this.devices = devices;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "LedNodeGroupChannelConfiguration [growArea=" + growArea + ", groupName=" + groupName
				+ ", generatedGroupName=" + generatedGroupName + ", led1=" + led1 + ", led2=" + led2 + ", led3=" + led3
				+ ", led4=" + led4 + ", led5=" + led5 + ", led6=" + led6 + ", devices=" + devices + ", description="
				+ description + "]";
	}

	
}
