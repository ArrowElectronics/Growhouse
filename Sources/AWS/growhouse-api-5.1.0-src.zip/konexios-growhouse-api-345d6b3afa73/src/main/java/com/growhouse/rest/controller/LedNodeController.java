package com.growhouse.rest.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.quartz.SchedulerException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;
import com.growhouse.rest.dto.DeviceLedNodeDTO;
import com.growhouse.rest.dto.GroupChannelConfigurationDTO;
import com.growhouse.rest.dto.LedNodeGroupChannelConfigurationDTO;
import com.growhouse.rest.dto.LedNodeGroupProfileDTO;
import com.growhouse.rest.dto.LedNodeProfileEventDTO;
import com.growhouse.rest.dto.LedNodeProfileEventNowDTO;
import com.growhouse.rest.facade.LedNodeFacade;
import com.growhouse.rest.response.ResponseMessage;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/api/lednode")
@Transactional
public class LedNodeController {

	public static final Logger LOGGER = LoggerFactory.getLogger(LedNodeController.class);

	@Autowired
	private LedNodeFacade ledNodeFacade;

	/*
	 * Query-- select device_id from devices. call arrow connect API.
	 */
	@GetMapping(value = "/devicestate/{deviceId}/property")
	@ApiOperation(value = "Get devicestate property")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "List retrieved successfully"),
			@ApiResponse(code = 204, message = "Empty list") })
	public ResponseEntity<?> getLedNodeStateProperties(@PathVariable("deviceId") Integer deviceId) {
		ResponseEntity<?> responseEntity;
		try {
			Map<String, Object> ledNodeStateProperty = ledNodeFacade.getLedNodeStateProperties(deviceId);
			if (ledNodeStateProperty == null)
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(ledNodeStateProperty, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			ResponseMessage responseMessage = new ResponseMessage();
			responseMessage.setMessage("Error while fetching device Detail from Arrow-Connect");
			responseEntity = new ResponseEntity<>(responseMessage, HttpStatus.INTERNAL_SERVER_ERROR);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@PostMapping(value = "/group", consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Create new group")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Lednode Group created successfully"),
			@ApiResponse(code = 400, message = "Bad Request") })
	public ResponseEntity<?> createLedGroup(
			@RequestBody LedNodeGroupChannelConfigurationDTO ledNodeGroupChannelConfigurationDTO) {
		ResponseEntity<?> responseEntity;
		try {
			LedNodeGroupChannelConfigurationDTO createdLedGroupDTO = ledNodeFacade
					.createLedGroup(ledNodeGroupChannelConfigurationDTO);
			if (createdLedGroupDTO == null) {
				ResponseMessage responseMessage = new ResponseMessage();
				responseMessage.setMessage("Error occured while creating Lednode Group");
				responseEntity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			} else {
				responseEntity = new ResponseEntity<>(createdLedGroupDTO, HttpStatus.CREATED);
			}
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@GetMapping(value = "/group/growarea/{growareaId}")
	@ApiOperation(value = "View list of Led groups based on growareaId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "List retrieved successfully"),
			@ApiResponse(code = 204, message = "Empty list") })
	public ResponseEntity<?> getLedGroupByGrowareaId(@PathVariable("growareaId") Integer growareaId) {
		ResponseEntity<?> responseEntity;
		try {
			List<LedNodeGroupChannelConfigurationDTO> ledNodeGroup = ledNodeFacade.getLedGroupByGrowareaId(growareaId);
			if (ledNodeGroup == null || ledNodeGroup.isEmpty())
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(ledNodeGroup, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@GetMapping(value = "/group/{groupId}")
	@ApiOperation(value = "Get LedNode Group by group id.")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "LedNode Group retrieved successfully"),
			@ApiResponse(code = 204, message = "Empty list") })
	public ResponseEntity<?> getLedGroupById(@PathVariable("groupId") Integer groupId) {
		ResponseEntity<?> responseEntity;
		try {
			LedNodeGroupChannelConfigurationDTO ledNodeGroup = ledNodeFacade.getLedGroupById(groupId);
			if (ledNodeGroup == null)
				responseEntity = new ResponseEntity<>(HttpStatus.NOT_FOUND);
			else
				responseEntity = new ResponseEntity<>(ledNodeGroup, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@PutMapping(value = "/group", consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Update existing LedNode group")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Lednode Group updated successfully"),
			@ApiResponse(code = 400, message = "Bad Request") })
	public ResponseEntity<?> updateLedGroup(
			@RequestBody LedNodeGroupChannelConfigurationDTO ledNodeGroupChannelConfigurationDTO) {
		ResponseEntity<?> responseEntity;
		try {
			LedNodeGroupChannelConfigurationDTO updatedLedGroupDTO = ledNodeFacade
					.updateLedGroup(ledNodeGroupChannelConfigurationDTO);
			if (updatedLedGroupDTO == null) {
				ResponseMessage responseMessage = new ResponseMessage();
				responseMessage.setMessage("Error occured while updating Lednode Group");
				responseEntity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			} else {
				responseEntity = new ResponseEntity<>(updatedLedGroupDTO, HttpStatus.OK);
			}
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@DeleteMapping(value = "/group/{groupId}")
	@ApiOperation(value = "delete existing LedNode group")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Lednode Group updated successfully"),
			@ApiResponse(code = 400, message = "Bad Request") })
	public ResponseEntity<?> deleteLedGroup(@PathVariable("groupId") Integer groupId) {
		ResponseEntity<?> responseEntity;
		try {
			LedNodeGroupChannelConfigurationDTO deletedLedGroupDTO = ledNodeFacade.deleteLedGroup(groupId);
			if (deletedLedGroupDTO == null) {
				ResponseMessage responseMessage = new ResponseMessage();
				responseMessage.setMessage("Error occured while deleting Lednode Group");
				responseEntity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			} else {
				responseEntity = new ResponseEntity<>(deletedLedGroupDTO, HttpStatus.OK);
			}
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@PostMapping(value = "/group/profile", consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Create new group profile")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Lednode Group profile created successfully"),
			@ApiResponse(code = 400, message = "Bad Request") })
	public ResponseEntity<?> createLedGroupProfile(@RequestBody LedNodeGroupProfileDTO ledNodeGroupProfileDTO) {
		ResponseEntity<?> responseEntity;
		try {
			LedNodeGroupProfileDTO createdLedGroupDTO = ledNodeFacade.createLedGroupProfile(ledNodeGroupProfileDTO);
			if (createdLedGroupDTO == null) {
				ResponseMessage responseMessage = new ResponseMessage();
				responseMessage.setMessage("Error occured while creating Lednode Group");
				responseEntity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			} else {
				responseEntity = new ResponseEntity<>(createdLedGroupDTO, HttpStatus.CREATED);
			}
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@PutMapping(value = "/group/profile", consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "update existing group profile")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Lednode Group profile updated successfully"),
			@ApiResponse(code = 400, message = "Bad Request") })
	public ResponseEntity<?> updateLedGroupProfile(@RequestBody LedNodeGroupProfileDTO ledNodeGroupProfileDTO) {
		ResponseEntity<?> responseEntity;
		try {
			LedNodeGroupProfileDTO createdLedGroupDTO = ledNodeFacade.updateLedGroupProfile(ledNodeGroupProfileDTO);
			if (createdLedGroupDTO == null) {
				ResponseMessage responseMessage = new ResponseMessage();
				responseMessage.setMessage("Error occured while updateding Lednode Group");
				responseEntity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			} else {
				responseEntity = new ResponseEntity<>(createdLedGroupDTO, HttpStatus.OK);
			}
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@DeleteMapping(value = "/group/profile/{profileId}")
	@ApiOperation(value = "delete existing profile")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Lednode Group profile deleted successfully"),
			@ApiResponse(code = 400, message = "Bad Request") })
	public ResponseEntity<?> deleteLedGroupProfile(@PathVariable("profileId") Integer profileId) {
		ResponseEntity<?> responseEntity;
		try {
			ledNodeFacade.deleteProfileByProfileId(profileId);
			ResponseMessage responseMessage = new ResponseMessage();
			responseMessage.setMessage("LedNode profile deleted successfully");
			responseEntity = new ResponseEntity<>(responseMessage, HttpStatus.OK);

		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@GetMapping(value = "/group/profile/{profileId}")
	@ApiOperation(value = "get existing group profile")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Lednode Group profile fetched successfully"),
			@ApiResponse(code = 400, message = "Bad Request") })
	public ResponseEntity<?> getLedGroupProfile(@PathVariable("profileId") Integer profileId) {
		ResponseEntity<?> responseEntity;
		try {
			LedNodeGroupProfileDTO profileDTO = ledNodeFacade.getLedProfileByProfileId(profileId);
			if (profileDTO == null) {
				ResponseMessage responseMessage = new ResponseMessage();
				responseMessage.setMessage("Error occured while getting Lednode profile");
				responseEntity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			} else {
				responseEntity = new ResponseEntity<>(profileDTO, HttpStatus.OK);
			}

		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@GetMapping(value = "/group/{groupId}/profiles")
	@ApiOperation(value = "View list of Led profiles based on groupId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "List retrieved successfully"),
			@ApiResponse(code = 204, message = "Empty list") })
	public ResponseEntity<?> getLedProfileByGroupId(@PathVariable("groupId") Integer groupId) {
		ResponseEntity<?> responseEntity;
		try {
			List<LedNodeGroupProfileDTO> ledNodeGroup = ledNodeFacade.getLedGroupProfileByGroupId(groupId);
			if (ledNodeGroup == null || ledNodeGroup.isEmpty())
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(ledNodeGroup, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@DeleteMapping(value = "/group/{groupId}/profiles")
	@ApiOperation(value = "delete lednode profiles by group id")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Lednode Group deleted successfully"),
			@ApiResponse(code = 400, message = "Bad Request") })
	public ResponseEntity<?> deleteLedNodeProfilesByGroupId(@PathVariable("groupId") Integer groupId) {
		ResponseEntity<?> responseEntity;
		try {
			ledNodeFacade.deleteLedProfileByGroupId(groupId);
			ResponseMessage responseMessage = new ResponseMessage();
			responseMessage.setMessage("LedNode profiles deleted successfully");
			responseEntity = new ResponseEntity<>(responseMessage, HttpStatus.OK);

		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@PutMapping(value = "/group/devices/gateway/{gatewayId}", consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "View list of Devices based on Channel configuration")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "List retrieved successfully"),
			@ApiResponse(code = 204, message = "Empty list") })
	public ResponseEntity<?> getDevicesByChannelConfi(@RequestBody GroupChannelConfigurationDTO channelConfigurationDTO,
			@PathVariable("gatewayId") Integer gatewayId) {
		ResponseEntity<?> responseEntity;
		try {
			List<DeviceLedNodeDTO> devices = ledNodeFacade.getDevicesByChannelConfi(channelConfigurationDTO, gatewayId);
			if (devices == null || devices.isEmpty())
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(devices, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@PostMapping(value = "/group/profile/event", consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Apply LedNode profile Event")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Lednode Group profile applied successfully"),
			@ApiResponse(code = 400, message = "Bad Request") })
	public ResponseEntity<?> applyLedNodeProfileEvent(@RequestBody LedNodeProfileEventDTO eventPayload) {
		ResponseEntity<?> responseEntity;
		try {
			String message = ledNodeFacade.applyLedNodeEvent(eventPayload);
			ResponseMessage responseMessage = new ResponseMessage();
			responseMessage.setMessage(message);
			responseEntity = new ResponseEntity<>(responseMessage, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (SchedulerException exception) {
			ResponseMessage responseMessage = new ResponseMessage();
			responseMessage.setMessage(exception.getMessage());
			responseEntity = new ResponseEntity<>(responseMessage, HttpStatus.BAD_REQUEST);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@PostMapping(value = "/group/profile/now", consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Apply LedNode profile now")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Lednode Group profile applied successfully"),
			@ApiResponse(code = 400, message = "Bad Request") })
	public ResponseEntity<?> applyLedNodeProfileNow(@RequestBody LedNodeProfileEventNowDTO eventPayload) {
		ResponseEntity<?> responseEntity;
		try {
			ledNodeFacade.applyLedNodeGroupProfile(eventPayload);
			responseEntity = new ResponseEntity<>(HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@GetMapping(value = "/group/{groupId}/event")
	@ApiOperation(value = "View list of group events based on groupId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "List retrieved successfully"),
			@ApiResponse(code = 204, message = "Empty list") })
	public ResponseEntity<?> getprofileEventsByGroupId(@PathVariable("groupId") Integer groupId) {
		ResponseEntity<?> responseEntity;
		try {
			List<LedNodeProfileEventDTO> profiles = ledNodeFacade.getProfileEventsByGroupId(groupId);
			if (profiles == null || profiles.isEmpty())
				responseEntity = new ResponseEntity<>(new ArrayList<>(), HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(profiles, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@DeleteMapping(value = "/group/profile/event/{eventName}")
	@ApiOperation(value = "delete lednode profiles by event name")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Lednode profile event deleted successfully"),
			@ApiResponse(code = 400, message = "Bad Request") })
	public ResponseEntity<?> deleteLedNodeEventByEventId(@PathVariable("eventName") String eventName) {
		ResponseEntity<?> responseEntity;
		try {
			ledNodeFacade.deleteEventById(eventName);
			ResponseMessage responseMessage = new ResponseMessage();
			responseMessage.setMessage("LedNode profiles Event deleted successfully");
			responseEntity = new ResponseEntity<>(responseMessage, HttpStatus.OK);

		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@DeleteMapping(value = "/gateway/{gatewayId}/groups")
	@ApiOperation(value = "delete lednode groups by gateway id")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Lednode Groups deleted successfully"),
			@ApiResponse(code = 400, message = "Bad Request") })
	public ResponseEntity<?> deleteLedNodeGroupByGatewayId(@PathVariable("gatewayId") Integer gatewayId) {
		ResponseEntity<?> responseEntity;
		try {
			ledNodeFacade.deleteLedGroupsBygatewayId(gatewayId);
			ResponseMessage responseMessage = new ResponseMessage();
			responseMessage.setMessage("LedNode groups deleted successfully");
			responseEntity = new ResponseEntity<>(responseMessage, HttpStatus.OK);

		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	private ResponseEntity<ResponseMessage> setResponseMessage(HttpClientErrorException httpClientErrorException) {
		ResponseMessage responseMessage = new ResponseMessage();
		responseMessage.setMessage(httpClientErrorException.getStatusText());
		return new ResponseEntity<>(responseMessage, httpClientErrorException.getStatusCode());
	}

}
