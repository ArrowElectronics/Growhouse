package com.growhouse.rest.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;
import com.growhouse.rest.entity.LedNodeChannelConfiguration;

public interface LedNodeChannelConfigRepository extends JpaRepository<LedNodeChannelConfiguration, Integer> {

	public LedNodeChannelConfiguration findByDeviceId(Integer deviceId);
	
	@Query(value="select * from lednode_channel_configuration l1 where l1.ch1=?1 and l1.ch2=?2 and l1.ch3=?3 and l1.ch4=?4 and l1.ch5=?5 and l1.ch6=?6 " ,nativeQuery = true)
	public List<LedNodeChannelConfiguration> findByDeviceByConfiguration(String ch1,String ch2,String ch3,String ch4,String ch5,String ch6);
	
	@Transactional
    @Modifying
    public void deleteByDeviceId(int deviceId);
	
	@Transactional
	@Modifying
	public void  deleteByDeviceGrowAreaId(int gatewayId);
	
	public List<LedNodeChannelConfiguration> findByDeviceGrowAreaIdAndLed1AndLed2AndLed3AndLed4AndLed5AndLed6AndDeviceIsActiveTrue(int gatewayId,String ch1,String ch2,String ch3,String ch4,String ch5,String ch6);

}
