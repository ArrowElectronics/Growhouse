package com.growhouse.rest.entity;

import java.util.List;

public class DeviceProperties {

	private Integer size;
	
	private List<DevicePropertyDetails> data;

	
	
	public Integer getSize() {
		return size;
	}



	public void setSize(Integer size) {
		this.size = size;
	}



	public List<DevicePropertyDetails> getData() {
		return data;
	}



	public void setData(List<DevicePropertyDetails> data) {
		this.data = data;
	}



	@Override
	public String toString() {
		return "DeviceProperties [size=" + size + ", data=" + data + "]";
	}
	
	
}
