package com.growhouse.rest.dto.konexios;

public class AuthResponse extends UserResponse {
}
