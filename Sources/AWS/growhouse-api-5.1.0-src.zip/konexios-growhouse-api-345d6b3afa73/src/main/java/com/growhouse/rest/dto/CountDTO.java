/**
 * 
 */
package com.growhouse.rest.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author dharita.chokshi
 *
 */
public class CountDTO {

	@JsonProperty("accounts_count")
	private int accountCount = 0;
	@JsonProperty("facilities_count")
	private int facilityCount = 0;
	@JsonProperty("containers_count")
	private int containerCount = 0;
	@JsonProperty("grow_areas_count")
	private int growAreaCount = 0;
	@JsonProperty("grow_sections_count")
	private int growSectionCount = 0;
	@JsonProperty("devices_count")
	private DeviceCountDTO devicesCount;
	
	public CountDTO() {
		super();
		this.devicesCount = new DeviceCountDTO();
	}

	/**
	 * @return the accountCount
	 */
	public int getAccountCount() {
		return accountCount;
	}

	/**
	 * @param accountCount
	 *            the accountCount to set
	 */
	public void setAccountCount(int accountCount) {
		this.accountCount = accountCount;
	}

	/**
	 * @return the facilityCount
	 */
	public int getFacilityCount() {
		return facilityCount;
	}

	/**
	 * @param facilityCount
	 *            the facilityCount to set
	 */
	public void setFacilityCount(int facilityCount) {
		this.facilityCount = facilityCount;
	}

	/**
	 * @return the containerCount
	 */
	public int getContainerCount() {
		return containerCount;
	}

	/**
	 * @param containerCount
	 *            the containerCount to set
	 */
	public void setContainerCount(int containerCount) {
		this.containerCount = containerCount;
	}

	/**
	 * @return the growAreaCount
	 */
	public int getGrowAreaCount() {
		return growAreaCount;
	}

	/**
	 * @param growAreaCount
	 *            the growAreaCount to set
	 */
	public void setGrowAreaCount(int growAreaCount) {
		this.growAreaCount = growAreaCount;
	}

	/**
	 * @return the growSectionCount
	 */
	public int getGrowSectionCount() {
		return growSectionCount;
	}

	/**
	 * @param growSectionCount
	 *            the growSectionCount to set
	 */
	public void setGrowSectionCount(int growSectionCount) {
		this.growSectionCount = growSectionCount;
	}

	/**
	 * @return the devicesCount
	 */
	public DeviceCountDTO getDevicesCount() {
		return devicesCount;
	}

	/**
	 * @param devicesCount
	 *            the devicesCount to set
	 */
	public void setDevicesCount(DeviceCountDTO devicesCount) {
		this.devicesCount = devicesCount;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "CountDTO [accountCount=" + accountCount + ", facilityCount=" + facilityCount + ", containerCount="
				+ containerCount + ", growAreaCount=" + growAreaCount + ", growSectionCount=" + growSectionCount
				+ ", devicesCount=" + devicesCount + "]";
	}

}
