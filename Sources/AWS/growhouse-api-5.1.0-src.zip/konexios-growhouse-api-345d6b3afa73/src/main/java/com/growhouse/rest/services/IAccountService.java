/**
 * 
 */
package com.growhouse.rest.services;

import java.util.List;

import com.growhouse.rest.entity.Account;
import com.growhouse.rest.entity.User;

/**
 * @author dharita.chokshi
 *
 */
public interface IAccountService {

	public List<Account> getActiveAccounts();

	public List<Account> getAllAccounts();

	public Account getAccountById(int id);

	public Account createAccount(Account account, User admin);

	public Account updateAccount(Account account);

	public Account deleteAccount(int id);

	public int getActiveAccountCount();

	public Account getAccountByName(String name);

}
