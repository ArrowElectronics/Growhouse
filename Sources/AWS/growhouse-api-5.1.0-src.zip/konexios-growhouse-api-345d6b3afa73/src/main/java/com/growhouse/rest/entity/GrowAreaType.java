/**
 * 
 */
package com.growhouse.rest.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * @author dharita.chokshi
 *
 */
@Entity
@Table(name = "grow_area_types")
public class GrowAreaType extends DefaultModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3959242483109726032L;

	@Column(name = "grow_area_type_name")
	private String growAreaTypeName;

	/**
	 * @return the growAreaTypeName
	 */
	public String getGrowAreaTypeName() {
		return growAreaTypeName;
	}

	/**
	 * @param growAreaTypeName
	 *            the growAreaTypeName to set
	 */
	public void setGrowAreaTypeName(String growAreaTypeName) {
		this.growAreaTypeName = growAreaTypeName;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "GrowAreaType [growAreaTypeName=" + growAreaTypeName + "]";
	}

}
