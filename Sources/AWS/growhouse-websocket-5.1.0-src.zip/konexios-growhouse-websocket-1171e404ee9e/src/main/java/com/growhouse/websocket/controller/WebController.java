package com.growhouse.websocket.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessageHeaderAccessor;
import org.springframework.stereotype.Controller;

@Controller
public class WebController {

	public static ConcurrentHashMap<String, List<String>> concurrentHashMap = new ConcurrentHashMap<>();

	private static final Logger LOGGER = LogManager.getLogger(WebController.class);

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@MessageMapping("/listen")
	public void getInputFromUI(String input, SimpMessageHeaderAccessor headerAccessor) {
		LOGGER.info("Input request :" + input);
		try {
			JSONObject jsonObject = new JSONObject(input);
			String status = jsonObject.getString("status");

			String deviceHid = jsonObject.getString("topic");
			String sessionId = jsonObject.getString("sessionId");
			if (status.equals("subscribe")) {
				headerAccessor.getSessionAttributes().put("sessionId", sessionId);
				headerAccessor.getSessionAttributes().put("deviceHid", deviceHid);
				LOGGER.info("map befor check---" + concurrentHashMap);
				if (concurrentHashMap.containsKey(deviceHid)) {
					List<String> list = concurrentHashMap.get(deviceHid);
					List modifiableList = new ArrayList((list));
					modifiableList.add(sessionId);
					concurrentHashMap.put(deviceHid, modifiableList);
					LOGGER.info("Added new session id , deviceHid already in map--" + concurrentHashMap);
				} else {

					concurrentHashMap.put(deviceHid, Arrays.asList(sessionId));
					LOGGER.info("added new deviceHid and sessionid---" + concurrentHashMap);
				}

			} else {
				LOGGER.info("unscribed request deviceId--" + deviceHid + " sessionid--" + sessionId);
				List<String> list = WebController.concurrentHashMap.get(deviceHid);
				if (list.contains(sessionId)) {
					if (list.size() <= 1) {
						concurrentHashMap.remove(deviceHid);
						LOGGER.info("after removing devicehid key from map---" + concurrentHashMap);
					} else {
						List modifiableList = new ArrayList((list));
						modifiableList.remove(sessionId);
						concurrentHashMap.put(deviceHid, modifiableList);
						LOGGER.info("after removing serssionid from map---" + concurrentHashMap);
					}
				}
			}

		} catch (Exception e) {
			LOGGER.info("Exception in getinpputUI function---" + e);
		}

	}

}
