package com.growhouse.websocket.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class TelemetryItemDTO {

	private String deviceHid;
	private String type;
	private long timestamp;
	private String name;
	private float floatValue;

	public String getDeviceHid() {
		return deviceHid;
	}

	public void setDeviceHid(String deviceHid) {
		this.deviceHid = deviceHid;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public long getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public float getFloatValue() {
		return floatValue;
	}

	public void setFloatValue(float floatValue) {
		this.floatValue = floatValue;
	}

	@Override
	public String toString() {
		return "TelemetryItemDTO [deviceHid=" + deviceHid + ", type=" + type + ", timestamp=" + timestamp + ", name="
				+ name + ", floatValue=" + floatValue + "]";
	}

	
}
