package com.growhouse.websocket.model;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageListener;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.listener.SimpleMessageListenerContainer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.growhouse.websocket.controller.WebController;

@Component
public class AmqpClient implements CommandLineRunner, MessageListener {

	private static final org.apache.logging.log4j.Logger LOGGER = LogManager.getLogger(AmqpClient.class);
	@Autowired
	private ConnectionFactory connectionFactory;

	@Autowired
	private SimpMessagingTemplate template;

	@Autowired
	private ObjectMapper objectMapper;

	private String messageTopic;

	private String deviceHid;

	@Value("${spring.rabbitmq.username}")
	private String applicationHid;

	@Override
	public void onMessage(Message message) {

		List<TelemetryItemDTO> telemetries = new ArrayList<>();
		String body = new String(message.getBody(), StandardCharsets.UTF_8);
		LOGGER.info("onMessage: " + body);

		try {
			telemetries = objectMapper.readValue(body, new TypeReference<List<TelemetryItemDTO>>() {
			});
		} catch (IOException e1) {
			LOGGER.info("Error occured while conver data into telemetry DTO---" + e1);
		}

		try {

			if (WebController.concurrentHashMap.containsKey(telemetries.get(0).getDeviceHid())) {
				LOGGER.info("device HId found in map.msg going to send on sessions:   "
						+ WebController.concurrentHashMap.get(telemetries.get(0).getDeviceHid()) + " telemetry --"
						+ telemetries);

				for (String sessionid : WebController.concurrentHashMap.get(telemetries.get(0).getDeviceHid())) {
					TimeUnit.SECONDS.sleep(1);
					this.template.convertAndSend("/topic/" + telemetries.get(0).getDeviceHid() + "/" + sessionid,
							telemetries);

				}

			}

		} catch (Exception e) {
			LOGGER.info("Exception occured in processing request---" + e);
		}

	}

	@Override
	public void run(String... args) throws Exception {
		SimpleMessageListenerContainer container = new SimpleMessageListenerContainer();
		container.setConnectionFactory(connectionFactory);
		container.setMessageListener(this);
		container.afterPropertiesSet();
		String queueName = String.format("app.%s", applicationHid);
		LOGGER.info("subscribing to queue: " + queueName);
		container.addQueueNames(queueName);
		container.start();
		LOGGER.info("Connection Establish successfully with Rabbitmq");

	}

	public String getMessageTopic() {
		return messageTopic;
	}

	public void setMessageTopic(String messageTopic) {
		this.messageTopic = messageTopic;
	}

	public String getDeviceHid() {
		return deviceHid;
	}

	public void setDeviceHid(String deviceHid) {
		this.deviceHid = deviceHid;
	}

}
