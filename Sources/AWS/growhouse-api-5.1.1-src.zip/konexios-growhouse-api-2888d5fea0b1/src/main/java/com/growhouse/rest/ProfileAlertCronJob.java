package com.growhouse.rest;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.growhouse.rest.dto.TelemetryItemDTO;
import com.growhouse.rest.dto.TelemetryItemWithPagesDTO;
import com.growhouse.rest.entity.Profile;
import com.growhouse.rest.entity.ProfileAlert;
import com.growhouse.rest.entity.kronos.KronosData;
import com.growhouse.rest.entity.kronos.KronosResponse;
import com.growhouse.rest.facade.TelemetryFacade;
import com.growhouse.rest.repository.ProfileRepository;
import com.growhouse.rest.services.impl.ProfileAlertService;
import com.growhouse.rest.services.impl.ProfileService;
import com.growhouse.rest.utils.Constants;

@Component
public class ProfileAlertCronJob {

	private static final Logger log = LoggerFactory.getLogger(ProfileAlertCronJob.class);

	@Autowired
	private ProfileService profileService;

	@Autowired
	private ProfileAlertService profileAlertService;

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private TelemetryFacade telemetryFacade;

	@Autowired
	private KonexiosConfig config;

	@Scheduled(fixedRate = 900000)
	public void reportCurrentTime() {

		List<Profile> profiles = profileService.getProfileRepository().findAll();
		String profileHid = null;

		for (Profile profile : profiles) {
			if (profile.getProfileHid() == null) {
				try {
					profileHid = getDeviceHIdByDeviceUId(profile.getName());
					profile.setProfileHid(profileHid);
					ProfileRepository profileRepository = profileService.getProfileRepository();
					profileRepository.save(profile);
				} catch (Exception e) {
					log.info("unable to get profileHid");
				}
			} else {
				profileHid = profile.getProfileHid();
			}

			Map<Long, ProfileAlert> profileAlertMap = new HashMap<>();
			String isoDatePattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(isoDatePattern);
			simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));

			TelemetryItemWithPagesDTO telemetryItemWithPagesDTO = telemetryFacade.fetchTelemetryFromArrowConnect(
					profileHid, simpleDateFormat.format(new Date(System.currentTimeMillis() - 30 * 60 * 1000)),
					simpleDateFormat.format(new Date()), Constants.PROFILE_PROPERTIES, null);
			List<TelemetryItemDTO> telemetryItemDTOs = telemetryItemWithPagesDTO.getTelemetryItemDTOs();
			if (!telemetryItemDTOs.isEmpty() && telemetryItemDTOs != null) {
				for (TelemetryItemDTO telemetryItemDTO : telemetryItemDTOs) {
					if (profileAlertMap.containsKey(telemetryItemDTO.getTimestamp())) {
						profileAlertMap.put(telemetryItemDTO.getTimestamp(),
								addItemToMap(profileAlertMap.get(telemetryItemDTO.getTimestamp()), telemetryItemDTO));
					} else {
						profileAlertMap.put(telemetryItemDTO.getTimestamp(),
								addItemToMap(getProfileByProfile(profile), telemetryItemDTO));
					}
				}

				profileAlertService.getProfileAlertRepository().saveAll(profileAlertMap.values());
			}
		}

	}

	private ProfileAlert addItemToMap(ProfileAlert profileAlert, TelemetryItemDTO telemetryItemDTO) {
		if (telemetryItemDTO.getName().equalsIgnoreCase(Constants.PROPERTIES))
			profileAlert.setProperties(telemetryItemDTO.getValue().toString());
		else if (telemetryItemDTO.getName().equalsIgnoreCase(Constants.ALERTMESSAGE))
			profileAlert.setAlertMessage(telemetryItemDTO.getValue().toString());
		profileAlert.setTimestamp(telemetryItemDTO.getTimestamp());
		return profileAlert;
	}

	private ProfileAlert getProfileByProfile(Profile profile) {
		ProfileAlert profileAlert = new ProfileAlert();
		profileAlert.setContainerId(profile.getPayload().getGlobalResponsePayload().getContainerId());
		profileAlert.setContainerName(profile.getPayload().getGlobalResponsePayload().getContainerName());
		profileAlert.setFacilityId(profile.getPayload().getGlobalResponsePayload().getFacilityId());
		profileAlert.setFacilityName(profile.getPayload().getGlobalResponsePayload().getFacilityName());
		profileAlert.setGatewayId(profile.getPayload().getGlobalResponsePayload().getGatewayId());
		profileAlert.setGatewayName(profile.getPayload().getGlobalResponsePayload().getGatewayName());
		profileAlert
				.setGrowSectionId(Integer.parseInt(profile.getPayload().getGlobalResponsePayload().getGrowSectionId()));
		profileAlert.setGrowSectionName(profile.getPayload().getGlobalResponsePayload().getGrowSectionName());
		profileAlert.setProfileId(profile.getId());
		profileAlert.setProfileName(profile.getName());
		return profileAlert;
	}

	private String getDeviceHIdByDeviceUId(String deviceUId) {
		String url = config.buildDeviceHidByUidUrl(deviceUId);
		String hid = null;
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set(config.getAuthTokenKey(), config.getAuthToken());

			HttpEntity<String> entity = new HttpEntity<>(headers);
			ResponseEntity<KronosResponse> response = restTemplate.exchange(url, HttpMethod.GET, entity,
					KronosResponse.class);
			if (response.getStatusCode() == HttpStatus.OK) {
				List<KronosData> data = response.getBody().getData();
				hid = data.get(0).getHid();
			}

		} catch (Exception exception) {
			throw new HttpClientErrorException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to fetch Device HId");
		}
		return hid;
	}

}
