package com.growhouse.rest.repository;



import org.springframework.data.jpa.repository.JpaRepository;

import com.growhouse.rest.entity.DevicePropertyDetails;

public interface DevicePropertyDetailsRepository extends JpaRepository<DevicePropertyDetails, Integer> {

	public DevicePropertyDetails findByNameAndTypeAndIsActiveTrue(String name,String type); 
}
