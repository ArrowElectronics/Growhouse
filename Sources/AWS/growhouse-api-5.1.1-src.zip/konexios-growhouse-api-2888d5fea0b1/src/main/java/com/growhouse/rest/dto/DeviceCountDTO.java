/**
 * 
 */
package com.growhouse.rest.dto;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author dharita.chokshi
 *
 */
public class DeviceCountDTO {

	private int total = 0;
	@JsonProperty("devicetype_count")
	private Map<String, Long> deviceTypeCount = new HashMap<>();
	
	

	public Map<String, Long> getDeviceTypeCount() {
		return deviceTypeCount;
	}

	public void setDeviceTypeCount(Map<String, Long> deviceTypeCount) {
		this.deviceTypeCount = deviceTypeCount;
	}

	/**
	 * @return the total
	 */
	public int getTotal() {
		return total;
	}

	/**
	 * @param total
	 *            the total to set
	 */
	public void setTotal(int total) {
		this.total = total;
	}


	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "DeviceCountDTO [total=" + total + ", deviceTypeCount=" + deviceTypeCount + "]";
	}

}

