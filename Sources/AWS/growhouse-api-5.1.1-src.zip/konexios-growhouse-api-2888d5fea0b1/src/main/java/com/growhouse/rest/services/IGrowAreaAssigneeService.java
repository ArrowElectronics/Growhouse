/**
 * 
 */
package com.growhouse.rest.services;

import java.util.List;

import com.growhouse.rest.entity.GrowAreaAssignee;

/**
 * @author dharita.chokshi
 *
 */
public interface IGrowAreaAssigneeService {

	public List<GrowAreaAssignee> getActiveGrowAreaAssignees();

	public List<GrowAreaAssignee> getAllGrowAreaAssignees();
	
	public List<GrowAreaAssignee> getAllGrowAreaAssigneesByGrowAreaId(int growAreaId);
	
	public List<GrowAreaAssignee> getAllGrowAreaAssigneesByUserId(int userId);
	
	public List<GrowAreaAssignee> getAllGrowAreaAssigneesByUserIdAndGrowAreaIsActive(int userId);

	public List<GrowAreaAssignee> createGrowAreaAssigneesInBatch(List<GrowAreaAssignee> growAreaAssignees);

	public GrowAreaAssignee deleteGrowAreaAssignee(int growAreaId, int userId);
	
	public List<GrowAreaAssignee> getAllGrowAreaAssigneesByContainerId(int userId,int containerId);

    public List<GrowAreaAssignee> getAllGrowAreaAssigneesByFacilityId(int userId,int facilityId);
    
    public int countOfAllGrowAreaAssigneesByFacilityId(int userId,int facilityId);
    
    public int countOfAllGrowAreaByContainerId(int userId,int containerId);
    
    public void deleteGrowAreaAssigneeByGatewayId(int gatewayId);

}
