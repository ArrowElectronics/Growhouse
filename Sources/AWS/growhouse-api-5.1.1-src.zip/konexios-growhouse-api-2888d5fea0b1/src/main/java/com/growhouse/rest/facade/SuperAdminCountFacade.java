package com.growhouse.rest.facade;

import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.growhouse.rest.dto.AccountDTO;
import com.growhouse.rest.dto.CountDTO;
import com.growhouse.rest.entity.Account;
import com.growhouse.rest.services.IAccountService;

@Component
public class SuperAdminCountFacade {
	
	public static final Logger LOGGER = LoggerFactory.getLogger(SuperAdminCountFacade.class);

	@Autowired
	private FacilityFacade facilityFacade;

	@Autowired
	private ContainerFacade containerFacade;

	@Autowired
	private AccountFacade accountFacade;
	
	@Autowired
	private IAccountService accountService;
	

	@Autowired
	private GrowAreaFacade growAreaFacade;

	public CountDTO getSuperAdminCount() {
		int facilityCount = 0;
		int accountCount = 0;
		int containerCount = 0;
		int growareaCount = 0;
		CountDTO countDTO = new CountDTO();

		facilityCount = facilityFacade.getActiveFacilityCount();
		accountCount = accountFacade.getActiveAccountsCount();
		containerCount = containerFacade.getCountActiveContainer();
		
		List<Account> accounts=accountService.getActiveAccounts();
		if(accounts!=null && !accounts.isEmpty())
		{
		List<Integer>accountIds=accounts.stream().map(account-> account.getId()).collect(Collectors.toList());
		growareaCount=growAreaFacade.getCountActiveGrowAreaByAccounts(accountIds);
		}
		countDTO.setAccountCount(accountCount);
		countDTO.setFacilityCount(facilityCount);
		countDTO.setContainerCount(containerCount);
		countDTO.setGrowAreaCount(growareaCount);
		return countDTO;
	}

	// Get List of Active account available under SuperAdmin
	public List<AccountDTO> getSuperAdminAccount() {
	
		return accountFacade.getActiveAccounts();
		
	}

}
