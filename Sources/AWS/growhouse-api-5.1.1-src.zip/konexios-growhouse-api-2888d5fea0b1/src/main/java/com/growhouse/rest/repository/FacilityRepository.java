/**
 * 
 */
package com.growhouse.rest.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.growhouse.rest.entity.Facility;

/**
 * @author dharita.chokshi
 *
 */
@Repository
public interface FacilityRepository extends JpaRepository<Facility, Integer> {

	public List<Facility> findByIsActiveTrue();
	
	public List<Facility> findByIsActiveTrueAndCreatedByIdOrAdminIdAndIsActiveTrue(int createdById, int adminId);
	
	public int countByIsActiveTrueAndAccountIsActiveTrue();
	
	public int countByAccountIdAndIsActiveTrue(int accountId);
	
	public List<Facility> findByAccountIdAndIsActiveTrue(int accountId);
	
	public List<Facility> findByAccountIdAndIsActiveTrueOrderByCreatedTimestampDesc(int accountId);

	public Optional<Facility> findByIdAndIsActiveTrue(int id);
	
	public Facility findByFacilityNameAndIsActiveTrueAndAccountId(String facilityName,int accountId);

}
