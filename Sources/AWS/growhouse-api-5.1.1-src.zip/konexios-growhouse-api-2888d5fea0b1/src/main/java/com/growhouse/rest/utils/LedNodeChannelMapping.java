package com.growhouse.rest.utils;

public enum LedNodeChannelMapping {
	ch1("led1"), ch2("led2"), ch3("led3"), ch4("led4"), ch5("led5"), ch6("led6");
	
	 String channelMappingName;
	 LedNodeChannelMapping(String channelMapping) {
		   this.channelMappingName = channelMapping;
	   }
	 public String showLedNodeChannelMappingValue() {
		   return channelMappingName;
	   }
}
