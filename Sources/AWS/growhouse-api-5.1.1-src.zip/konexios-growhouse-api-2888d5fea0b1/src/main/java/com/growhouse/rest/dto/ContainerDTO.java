package com.growhouse.rest.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ContainerDTO {

	private Integer id;
	@JsonProperty("container_name")
	private String containerName;
	@JsonProperty("container_type")
	private ContainerTypeDTO containerType;
	@JsonProperty("facility")
	private FacilityDTO facility;
	private String description;
	@JsonProperty("grow_areas")
	private List<GrowAreaDTO> growAreaDTOs;

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the containerName
	 */
	public String getContainerName() {
		return containerName;
	}

	/**
	 * @param containerName
	 *            the containerName to set
	 */
	public void setContainerName(String containerName) {
		this.containerName = containerName;
	}

	/**
	 * @return the containerTypeId
	 */
	public ContainerTypeDTO getContainerType() {
		return containerType;
	}

	/**
	 * @param containerType
	 *            the containerType to set
	 */
	public void setContainerType(ContainerTypeDTO containerType) {
		this.containerType = containerType;
	}

	/**
	 * @return the facility
	 */
	public FacilityDTO getFacility() {
		return facility;
	}

	/**
	 * @param facility
	 *            the facility to set
	 */
	public void setFacility(FacilityDTO facility) {
		this.facility = facility;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description
	 *            the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the growAreaDTOs
	 */
	public List<GrowAreaDTO> getGrowAreaDTOs() {
		return growAreaDTOs;
	}

	/**
	 * @param growAreaDTOs
	 *            the growAreaDTOs to set
	 */
	public void setGrowAreaDTOs(List<GrowAreaDTO> growAreaDTOs) {
		this.growAreaDTOs = growAreaDTOs;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ContainerDTO [id=" + id + ", containerName=" + containerName + ", containerType=" + containerType
				+ ", facility=" + facility + ", description=" + description + ", growAreaDTOs=" + growAreaDTOs + "]";
	}

}
