/**
 * 
 */
package com.growhouse.rest.facade;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.growhouse.rest.dto.FacilityDTO;
import com.growhouse.rest.entity.Container;
import com.growhouse.rest.entity.Facility;
import com.growhouse.rest.entity.User;
import com.growhouse.rest.repository.LocalityRepository;
import com.growhouse.rest.repository.UserRepository;
import com.growhouse.rest.services.IContainerService;
import com.growhouse.rest.services.IFacilityService;

/**
 * @author dharita.chokshi
 *
 */
@Component
public class FacilityFacade {

	public static final Logger LOGGER = LoggerFactory.getLogger(FacilityFacade.class);

	@Autowired
	private IFacilityService facilityService;

	@Autowired
	private IContainerService containerService;

	@Autowired
	private LocalityRepository localityRepo;

	@Autowired
	private UserRepository userRepo;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private ObjectMapper objectMapper;

	public List<FacilityDTO> getActiveFacilitiesByAccount() {
		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		List<FacilityDTO> facilityDTOs = new ArrayList<>();
		List<Facility> facilities = facilityService.getActiveFacilitiesByAccountId(user.getAccount().getId());
		if (facilities != null && !facilities.isEmpty()) {
			facilityDTOs = facilities.stream().map(this::convertEntityToDTO).collect(Collectors.toList());
		}
		return facilityDTOs;
	}

	public List<FacilityDTO> getActiveFacilities() {
		List<FacilityDTO> facilityDTOs = new ArrayList<>();
		List<Facility> facilities = facilityService.getActiveFacilities();
		if (facilities != null && !facilities.isEmpty()) {
			facilityDTOs = facilities.stream().map(this::convertEntityToDTO).collect(Collectors.toList());
		}
		return facilityDTOs;
	}

	public int getActiveFacilityCountByAccountId(int accountId) {
		return facilityService.getFacilitiRepository().countByAccountIdAndIsActiveTrue(accountId);
	}

	public int getActiveFacilityCount() {
		return facilityService.getActiveFacilityCount();
	}

	public List<FacilityDTO> getAllFacilities() {
		List<FacilityDTO> facilityDTOs = new ArrayList<>();
		List<Facility> facilities = facilityService.getAllFacilities();
		if (facilities != null && !facilities.isEmpty()) {
			facilityDTOs = facilities.stream().map(this::convertEntityToDTO).collect(Collectors.toList());
		}
		return facilityDTOs;
	}

	public FacilityDTO getFacilityById(int facilityId) {
		FacilityDTO facilityDTO = null;
		Facility facility = facilityService.getFacilityById(facilityId);
		if (facility != null) {
			if (!facility.isActive())
				throw new HttpClientErrorException(HttpStatus.FORBIDDEN, "Facility is inactive");
			facilityDTO = convertEntityToDTO(facility);
		}
		return facilityDTO;
	}

	public FacilityDTO createFacility(FacilityDTO requestedFacilityDTO) {
		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		FacilityDTO createdFacilityDTO = null;
		Facility requestedFacility = convertDTOToEntity(requestedFacilityDTO);
		requestedFacility.setAccount(user.getAccount());
		requestedFacility.setFacilityName(requestedFacility.getFacilityName().trim());
		Facility existFacility = facilityService.getFacilityByFacilityName(requestedFacility.getFacilityName(),
				user.getAccount().getId());
		if (existFacility == null) {
			createdFacilityDTO = createFacilitySubFunction(requestedFacilityDTO, requestedFacility, user);
		} else {
			throw new HttpClientErrorException(HttpStatus.BAD_REQUEST, "Facility name already exist.");
		}
		return createdFacilityDTO;
	}

	public FacilityDTO createFacilitySubFunction(FacilityDTO requestedFacilityDTO, Facility requestedFacility,
			User user) {
		FacilityDTO createdFacilityDTO = null;
		if (requestedFacilityDTO.getContainers() == null || requestedFacilityDTO.getContainers().isEmpty()) {
			Facility createdFacility = facilityService.createFacility(requestedFacility);
			if (createdFacility != null)
				createdFacilityDTO = convertEntityToDTO(createdFacility);
		} else {
			String containerName = requestedFacilityDTO.getContainers().get(0).getContainerName().trim();
			Container existContainer = containerService.getContainerByContainerName(containerName,
					user.getAccount().getId());
			if (existContainer == null) {
				Facility createdFacility = facilityService.createFacility(requestedFacility);
				if (createdFacility != null)
					createdFacilityDTO = convertEntityToDTO(createdFacility);
			} else {
				throw new HttpClientErrorException(HttpStatus.BAD_REQUEST, "Container name already exist.");
			}
		}
		return createdFacilityDTO;
	}

	public FacilityDTO updateFacility(int facilityId, FacilityDTO facilityDTO) {
		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if (facilityId != facilityDTO.getId())
			throw new HttpClientErrorException(HttpStatus.NOT_ACCEPTABLE,
					"FacilityId in URL doesnot match with facilityId of Facility object");

		try {
			LOGGER.info("updateFacility: " + objectMapper.writeValueAsString(facilityDTO));
		} catch (JsonProcessingException e) {
		}
		Facility existing = facilityService.getFacilityById(facilityId);
		if (existing == null) {
			throw new HttpClientErrorException(HttpStatus.BAD_REQUEST, "Facility does not exist.");
		}

		Facility duplicate = facilityService.getFacilityByFacilityName(facilityDTO.getFacilityName(),
				user.getAccount().getId());
		if (duplicate != null && !duplicate.getId().equals(existing.getId())) {
			throw new HttpClientErrorException(HttpStatus.BAD_REQUEST, "Duplicate facility name found");
		}

		Facility updated = convertDTOToEntity(facilityDTO);
		updated.setAccount(existing.getAccount());
		updated = facilityService.updateFacility(updated);

		return convertEntityToDTO(updated);
	}

	public Facility deleteFacility(int facilityId) {
		return facilityService.deleteFacility(facilityId);
	}

	private FacilityDTO convertEntityToDTO(Facility facility) {
		return modelMapper.map(facility, FacilityDTO.class);
	}

	private Facility convertDTOToEntity(FacilityDTO facilityDTO) {
		return modelMapper.map(facilityDTO, Facility.class);
	}

}
