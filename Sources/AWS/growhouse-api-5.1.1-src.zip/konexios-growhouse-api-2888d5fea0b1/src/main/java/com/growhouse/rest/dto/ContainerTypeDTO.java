/**
 * 
 */
package com.growhouse.rest.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author dharita.chokshi
 *
 */
public class ContainerTypeDTO {

	private Integer id;
	@JsonProperty("container_type_name")
	private String containerTypeName;

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the containerTypeName
	 */
	public String getContainerTypeName() {
		return containerTypeName;
	}

	/**
	 * @param containerTypeName
	 *            the containerTypeName to set
	 */
	public void setContainerTypeName(String containerTypeName) {
		this.containerTypeName = containerTypeName;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ContainerTypeDTO [id=" + id + ", containerTypeName=" + containerTypeName + "]";
	}

}
