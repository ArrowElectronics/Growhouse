package com.growhouse.rest.dto;

public class ProfileResponseDTO {

	private String profileId;
	private String profileName;
	private String profileVirtualName;
	private String containerName;
	private String facilityName;
	private String growAreaName;
	private String growSectionName;
	private String alertMessage;
	private String properties;
	private Long timestamp;

	public Long getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Long timestamp) {
		this.timestamp = timestamp;
	}

	public String getProfileId() {
		return profileId;
	}

	public void setProfileId(String profileId) {
		this.profileId = profileId;
	}

	public String getProfileName() {
		return profileName;
	}

	public void setProfileName(String profileName) {
		this.profileName = profileName;
	}

	public String getContainerName() {
		return containerName;
	}

	public void setContainerName(String containerName) {
		this.containerName = containerName;
	}

	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public String getGrowAreaName() {
		return growAreaName;
	}

	public void setGrowAreaName(String growAreaName) {
		this.growAreaName = growAreaName;
	}

	public String getGrowSectionName() {
		return growSectionName;
	}

	public void setGrowSectionName(String growSectionName) {
		this.growSectionName = growSectionName;
	}

	public String getAlertMessage() {
		return alertMessage;
	}

	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	public String getProperties() {
		return properties;
	}

	public void setProperties(String properties) {
		this.properties = properties;
	}

	public String getProfileVirtualName() {
		return profileVirtualName;
	}

	public void setProfileVirtualName(String profileVirtualName) {
		this.profileVirtualName = profileVirtualName;
	}

}
