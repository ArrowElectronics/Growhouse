package com.growhouse.rest.dto;



import com.fasterxml.jackson.annotation.JsonProperty;

public class DashBoardDTO {
	private Integer id;
	@JsonProperty("grow_area_name")
	private String growAreaName;
	private ContainerForGADTO container;
	private FacilityForGADTO facility;
	private DeviceCountDTO deviceCountDTO;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getGrowAreaName() {
		return growAreaName;
	}
	public void setGrowAreaName(String growAreaName) {
		this.growAreaName = growAreaName;
	}
	
	public ContainerForGADTO getContainer() {
		return container;
	}
	public void setContainer(ContainerForGADTO container) {
		this.container = container;
	}
	
	
	public FacilityForGADTO getFacility() {
		return facility;
	}
	public void setFacility(FacilityForGADTO facility) {
		this.facility = facility;
	}
	
	public DeviceCountDTO getDeviceCountDTO() {
		return deviceCountDTO;
	}
	public void setDeviceCountDTO(DeviceCountDTO deviceCountDTO) {
		this.deviceCountDTO = deviceCountDTO;
	}
	@Override
	public String toString() {
		return "DashBoardDTO [id=" + id + ", growAreaName=" + growAreaName + ", container=" + container + ", facility="
				+ facility + ", deviceCountDTO=" + deviceCountDTO + "]";
	}
	
	
}
