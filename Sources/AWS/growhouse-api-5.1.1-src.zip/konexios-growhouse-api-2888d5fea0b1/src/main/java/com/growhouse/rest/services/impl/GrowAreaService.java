/**
 * 
 */
package com.growhouse.rest.services.impl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.growhouse.rest.KonexiosConfig;
import com.growhouse.rest.entity.GrowArea;
import com.growhouse.rest.entity.User;
import com.growhouse.rest.entity.kronos.KronosData;
import com.growhouse.rest.entity.kronos.KronosResponse;
import com.growhouse.rest.repository.GrowAreaRepository;
import com.growhouse.rest.services.IGrowAreaService;
import com.growhouse.rest.utils.Constants;

/**
 * @author dharita.chokshi
 *
 */
@Service
public class GrowAreaService implements IGrowAreaService {

	@Autowired
	private GrowAreaRepository growAreaRepository;

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private KonexiosConfig config;

	public List<GrowArea> getActiveGrowAreas() {
		return growAreaRepository.findByIsActiveTrue();
	}

	public List<GrowArea> getAllGrowAreas() {
		return growAreaRepository.findAll();
	}

	public int getCountActiveGrowArea() {
		return growAreaRepository.countByIsActiveTrue();
	}

	public int getCountActiveGrowAreabyAccounts(List<Integer> accountIdList) {
		return growAreaRepository.countByAccountIdInAndIsActiveTrue(accountIdList);
	}

	public List<GrowArea> getGrowAreasByContainerId(int containerId) {
		List<GrowArea> growAreas = growAreaRepository.findByContainerIdAndIsActiveTrue(containerId);
		growAreas = growAreas.stream().filter(growArea -> growArea.getContainer().getId() == containerId)
				.collect(Collectors.toList());
		return growAreas;
	}

	public List<GrowArea> getGrowAreasByFacilityId(int facilityId) {
		List<GrowArea> growAreas = growAreaRepository.findByIsActiveTrue();
		growAreas = growAreas.stream().filter(growArea -> growArea.getContainer().getFacility().getId() == facilityId)
				.collect(Collectors.toList());
		return growAreas;
	}

	public GrowArea getGrowAreaById(int id) {
		Optional<GrowArea> optional = growAreaRepository.findByIdAndIsActiveTrue(id);
		return optional.isPresent() ? optional.get() : null;
	}

	public GrowArea createGrowArea(GrowArea growArea) {
		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		growArea.setAccountId(user.getAccount().getId());
		if (growArea.getGrowAreaHId() == null) {

			String hid = getGrowAreaHIdByGrowAreaUId(growArea.getGrowAreaUId());
			growArea.setGrowAreaHId(hid);

		}
		return growAreaRepository.save(growArea);
	}

	public GrowArea updateGrowArea(GrowArea growArea) {
		return growAreaRepository.save(growArea);
	}

	public GrowArea deleteGrowArea(int id) {
		GrowArea deletedGrowArea = null;
		Optional<GrowArea> optional = growAreaRepository.findById(id);
		if (optional.isPresent() && optional.get().isActive()) {
			GrowArea growArea = optional.get();
			growArea.setActive(false);
			deletedGrowArea = growAreaRepository.save(growArea);
		} else {
			throw new HttpClientErrorException(HttpStatus.NOT_FOUND, "Grow area not found");
		}
		return deletedGrowArea;
	}

	private String getGrowAreaHIdByGrowAreaUId(String growAreaUId) {
		String url = config.buildGatewayHidByUidUrl(growAreaUId);
		String hid = null;
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set(config.getAuthTokenKey(), config.getAuthToken());

			HttpEntity<String> entity = new HttpEntity<>(headers);
			ResponseEntity<KronosResponse> response = restTemplate.exchange(url, HttpMethod.GET, entity,
					KronosResponse.class);
			if (response.getStatusCode() == HttpStatus.OK) {
				List<KronosData> data = response.getBody().getData();
				hid = data.get(0).getHid();
			}

		} catch (Exception exception) {
			throw new HttpClientErrorException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to fetch Grow area HId");
		}
		return hid;
	}

	public GrowAreaRepository getGrowAreaRepository() {
		return growAreaRepository;
	}

	public List<GrowArea> getOutOfNetworkGrowArea(List<Integer> growAreaIdList) {
		long thrityAgo = System.currentTimeMillis() - Constants.THRITY_MINUTES;
		return growAreaRepository.findByIdInAndLatestHeartbeatLessThanAndIsActiveTrue(growAreaIdList, thrityAgo);

	}

	public int getCountOutOfNetworkGrowArea(List<Integer> growAreaIdList) {
		long thrityAgo = System.currentTimeMillis() - Constants.THRITY_MINUTES;
		return growAreaRepository.countByIdInAndLatestHeartbeatLessThanAndIsActiveTrue(growAreaIdList, thrityAgo);
	}

}
