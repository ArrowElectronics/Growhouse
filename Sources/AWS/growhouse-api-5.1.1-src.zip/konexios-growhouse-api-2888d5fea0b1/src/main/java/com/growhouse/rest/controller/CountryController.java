/**
 * 
 */
package com.growhouse.rest.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpServerErrorException;

import com.growhouse.rest.dto.CountryDTO;
import com.growhouse.rest.facade.CountryFacade;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author dharita.chokshi
 *
 */

@RestController
@RequestMapping("/api/countries")
@Transactional
public class CountryController {

	public static final Logger LOGGER = LoggerFactory.getLogger(CountryController.class);

	@Autowired
	private CountryFacade countryFacade;

	/*
	 * Query-- Select * from countries.
	 */
	@GetMapping(value = "")
	@ApiOperation(value = "View list of countries")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "List retrieved successfully"),
			@ApiResponse(code = 204, message = "Empty list") })
	public ResponseEntity<List<CountryDTO>> getCountries() {
		ResponseEntity<List<CountryDTO>> responseEntity;
		try {
			List<CountryDTO> countryDTOs = countryFacade.getCountries();
			if (countryDTOs == null || countryDTOs.isEmpty())
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(countryDTOs, HttpStatus.OK);
		} catch (Exception exception) {
			throw new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

}
