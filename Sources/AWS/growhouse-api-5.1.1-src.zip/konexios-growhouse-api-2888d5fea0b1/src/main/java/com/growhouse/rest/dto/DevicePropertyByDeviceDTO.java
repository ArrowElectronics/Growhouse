package com.growhouse.rest.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class DevicePropertyByDeviceDTO {
	
	@JsonProperty("device_hid")
	private String deviceHId;
	
	@JsonProperty("property_name")
	private String propertyName;

	private String type;
	
	@JsonProperty("display_property_name")
	private String displayPropertyName;

	public String getDeviceHId() {
		return deviceHId;
	}

	public void setDeviceHId(String deviceHId) {
		this.deviceHId = deviceHId;
	}

	public String getPropertyName() {
		return propertyName;
	}

	public void setPropertyName(String propertyName) {
		this.propertyName = propertyName;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getDisplayPropertyName() {
		return displayPropertyName;
	}

	public void setDisplayPropertyName(String displayPropertyName) {
		this.displayPropertyName = displayPropertyName;
	}

	@Override
	public String toString() {
		return "DevicePropertyByDeviceDTO [deviceHId=" + deviceHId + ", propertyName=" + propertyName + ", type=" + type
				+ ", displayPropertyName=" + displayPropertyName + "]";
	}

	
}
