/**
 * 
 */
package com.growhouse.rest.services;

import java.util.List;

import com.growhouse.rest.entity.GrowArea;
import com.growhouse.rest.repository.GrowAreaRepository;

/**
 * @author dharita.chokshi
 *
 */
public interface IGrowAreaService {

	public List<GrowArea> getActiveGrowAreas();

	public List<GrowArea> getAllGrowAreas();
	
	public List<GrowArea> getGrowAreasByContainerId(int containerId);
	
	public List<GrowArea> getGrowAreasByFacilityId(int facilityId);

	public GrowArea getGrowAreaById(int id);
	
	public GrowArea createGrowArea(GrowArea growArea);

	public GrowArea updateGrowArea(GrowArea growArea);

	public GrowArea deleteGrowArea(int id);
	
	public GrowAreaRepository getGrowAreaRepository();
	
	public List<GrowArea> getOutOfNetworkGrowArea(List<Integer> growAreaIdList);
	
	public int getCountOutOfNetworkGrowArea(List<Integer> growAreaIdList);
	
	public int getCountActiveGrowArea();
	
	public int getCountActiveGrowAreabyAccounts(List<Integer>accountIdList);
}
