/**
 * 
 */
package com.growhouse.rest.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author dharita.chokshi
 *
 */
public class UserRoleDTO {

	private Integer id;
	@JsonProperty("role_name")
	private String roleName;
	
	@JsonProperty("virtual_role_name")
	private String virtualRoleName;

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the roleName
	 */
	public String getRoleName() {
		return roleName;
	}

	/**
	 * @param roleName
	 *            the roleName to set
	 */
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getVirtualRoleName() {
		return virtualRoleName;
	}

	public void setVirtualRoleName(String virtualRoleName) {
		this.virtualRoleName = virtualRoleName;
	}

	@Override
	public String toString() {
		return "UserRoleDTO [id=" + id + ", roleName=" + roleName + ", virtualRoleName=" + virtualRoleName + "]";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	

}
