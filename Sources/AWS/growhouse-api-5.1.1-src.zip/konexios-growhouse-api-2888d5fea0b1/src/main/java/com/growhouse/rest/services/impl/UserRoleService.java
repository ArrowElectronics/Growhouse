/**
 * 
 */
package com.growhouse.rest.services.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.growhouse.rest.entity.UserRole;
import com.growhouse.rest.repository.UserRoleRepository;
import com.growhouse.rest.services.IUserRoleService;

/**
 * @author dharita.chokshi
 *
 */
@Service
public class UserRoleService implements IUserRoleService {

	@Autowired
	private UserRoleRepository userRoleRepository;

	public List<UserRole> getAllUserRoles() {
		return userRoleRepository.findByIsActiveTrue();
	}

	
	public UserRole getUserRoleById(int userRoleId) {
		Optional<UserRole> optional = userRoleRepository.findById(userRoleId);
		return optional.isPresent() ? optional.get() : null;
	}

}
