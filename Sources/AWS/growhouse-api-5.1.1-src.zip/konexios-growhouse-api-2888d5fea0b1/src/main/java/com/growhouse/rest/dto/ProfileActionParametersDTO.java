package com.growhouse.rest.dto;

public class ProfileActionParametersDTO {
	
	private String url;
	private String headers;
	private String requestBody;
	private String contentType;
	
	public ProfileActionParametersDTO(String url, String requestBody, String contentType) {
		this.url = url;
		this.requestBody = requestBody;
		this.contentType = contentType;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getHeaders() {
		return headers;
	}

	public void setHeaders(String headers) {
		this.headers = headers;
	}

	public String getRequestBody() {
		return requestBody;
	}

	public void setRequestBody(String requestBody) {
		this.requestBody = requestBody;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	@Override
	public String toString() {
		return "ProfileActionParametersDTO [url=" + url + ", headers=" + headers + ", requestBody=" + requestBody
				+ ", contentType=" + contentType + "]";
	}
	
	
	

}
