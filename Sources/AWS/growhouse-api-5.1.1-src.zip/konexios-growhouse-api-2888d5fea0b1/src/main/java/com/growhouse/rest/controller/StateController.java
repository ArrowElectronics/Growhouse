/**
 * 
 */
package com.growhouse.rest.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpServerErrorException;

import com.growhouse.rest.dto.StateDTO;
import com.growhouse.rest.facade.StateFacade;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author dharita.chokshi
 *
 */

@RestController
@RequestMapping("/api/states")
@Transactional
public class StateController {

	public static final Logger LOGGER = LoggerFactory.getLogger(StateController.class);

	@Autowired
	private StateFacade stateFacade;

	/* Query-- Select * from states. */
	@GetMapping(value = "")
	@ApiOperation(value = "View list of all the states")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "List retrieved successfully"),
			@ApiResponse(code = 204, message = "Empty list") })
	public ResponseEntity<List<StateDTO>> getAllStates() {
		ResponseEntity<List<StateDTO>> responseEntity;
		try {
			List<StateDTO> stateDTOs = stateFacade.getAllStates();
			if (stateDTOs == null || stateDTOs.isEmpty())
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(stateDTOs, HttpStatus.OK);
		} catch (Exception exception) {
			throw new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/* Query-- Select * from states where country_id=? . */
	@GetMapping(value = "/{countryId}")
	@ApiOperation(value = "View list of states based on countryId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "List retrieved successfully"),
			@ApiResponse(code = 204, message = "Empty list") })
	public ResponseEntity<List<StateDTO>> getStatesByCountryId(@PathVariable("countryId") Integer countryId) {
		ResponseEntity<List<StateDTO>> responseEntity;
		try {
			List<StateDTO> stateDTOs = stateFacade.getStatesByCountryId(countryId);
			if (stateDTOs == null || stateDTOs.isEmpty())
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(stateDTOs, HttpStatus.OK);
		} catch (Exception exception) {
			throw new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

}
