package com.growhouse.rest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.growhouse.rest.dto.AccountDTO;
import com.growhouse.rest.dto.CountDTO;

import com.growhouse.rest.facade.SuperAdminCountFacade;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/api/superadmin")
@Transactional
public class SuperAdminCountController {

	@Autowired
	private SuperAdminCountFacade superAdminCountFacade;

	/*
	 * Query-- select COUNT(facility_id) from facility where is_active=true. select
	 * COUNT(account_id) from account where is_active=true. select
	 * COUNT(container_id) from container where is_active=true. select
	 * COUNT(grow_area_id) from grow_area where is_active=true
	 */
	@GetMapping("/dashboard/count")
	@ApiOperation(value = "View Count of SuperAdmin dashboard")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Data retrieved successfully") })
	public ResponseEntity<?> getSuperAdminDashboardCount() {
		ResponseEntity<?> responseEntity;
		try {
			CountDTO countDTO = superAdminCountFacade.getSuperAdminCount();
			responseEntity = new ResponseEntity<>(countDTO, HttpStatus.OK);
		} catch (Exception exception) {
			responseEntity = new ResponseEntity<>(exception.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/* Query-- select * from account where created_by=? and is_active=true */
	@GetMapping("/account")
	@ApiOperation(value = "View list of active accounts")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "List retrieved successfully"),
			@ApiResponse(code = 204, message = "Empty list") })
	public ResponseEntity<?> getSuperAdminAccounts() {
		ResponseEntity<?> responseEntity;
		try {
			List<AccountDTO> accounts = superAdminCountFacade.getSuperAdminAccount();
			if (accounts == null || accounts.isEmpty())
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(accounts, HttpStatus.OK);

		} catch (Exception exception) {
			responseEntity = new ResponseEntity<>(exception.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}
}
