/**
 * 
 */
package com.growhouse.rest.facade;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;

import com.growhouse.rest.dto.AccountDTO;
import com.growhouse.rest.dto.AdminDTO;
import com.growhouse.rest.dto.UserDTO;
import com.growhouse.rest.entity.Account;
import com.growhouse.rest.entity.User;
import com.growhouse.rest.services.IAccountService;
import com.growhouse.rest.services.IUserService;

/**
 * @author dharita.chokshi
 *
 */
@Component
public class AccountFacade {

	public static final Logger LOGGER = LoggerFactory.getLogger(AccountFacade.class);

	@Autowired
	private IAccountService accountService;

	@Autowired
	private IUserService userService;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private UserFacade userFacade;

	public List<AccountDTO> getActiveAccounts() {
		List<AccountDTO> accountDTOs = new ArrayList<>();
		List<Account> accounts = accountService.getActiveAccounts();
		if (accounts != null && !accounts.isEmpty()) {
			accountDTOs = accounts.stream().map(this::convertEntityToDTO).collect(Collectors.toList());
		}
		return accountDTOs;
	}

	public int getActiveAccountsCount() {
		int count = 0;
		count = accountService.getActiveAccountCount();
		return count;
	}

	public List<AccountDTO> getAllAccounts() {
		List<AccountDTO> accountDTOs = new ArrayList<>();
		List<Account> accounts = accountService.getAllAccounts();
		if (accounts != null && !accounts.isEmpty()) {
			accountDTOs = accounts.stream().map(this::convertEntityToDTO).collect(Collectors.toList());
		}
		return accountDTOs;
	}

	public AccountDTO getAccountById(int accountId) {
		AccountDTO accountDTO = null;
		Account account = accountService.getAccountById(accountId);
		if (account != null) {
			accountDTO = convertEntityToDTO(account);
		}
		return accountDTO;
	}

	public AccountDTO createAccount(AccountDTO requestedAccountDTO) {
		AccountDTO createdAccountDTO = null;
		Account requestedAccount = convertDTOToEntity(requestedAccountDTO);
		requestedAccount.setAccountName(requestedAccount.getAccountName().trim());
		Account account = accountService.getAccountByName(requestedAccount.getAccountName());
		if (account == null) {
			Account createdAccount = accountService.createAccount(requestedAccount,
					modelMapper.map(requestedAccountDTO.getAdmin(), User.class));
			if (createdAccount != null) {

				// make sure to sync admin user with konexios
				User admin = userService.getUserById(createdAccount.getAdminId());
				admin.setUserHid(userFacade.createKonexiosUser(userFacade.convertEntityToDTO(admin)).getHid());
				admin = userService.updateUser(admin);

				createdAccountDTO = convertEntityToDTO(createdAccount);
			}
		} else {
			throw new HttpClientErrorException(HttpStatus.BAD_REQUEST, "Account name already exist.");
		}
		return createdAccountDTO;
	}

	public AccountDTO updateAccount(int accountId, AccountDTO requestedAccountDTO) {
		if (accountId != requestedAccountDTO.getId())
			throw new HttpClientErrorException(HttpStatus.NOT_ACCEPTABLE,
					"AccountId in URL doesnot match with accountId of Account object");

		Account existingAccount = accountService.getAccountById(requestedAccountDTO.getId());
		if (existingAccount == null)
			throw new HttpClientErrorException(HttpStatus.NOT_FOUND, "Account not found");

		if (!existingAccount.isActive())
			throw new HttpClientErrorException(HttpStatus.NOT_FOUND, "Account is inactive");

		// check duplicate account name
		Account duplicate = accountService.getAccountByName(requestedAccountDTO.getAccountName());
		if (duplicate != null && !duplicate.getId().equals(accountId)) {
			throw new HttpClientErrorException(HttpStatus.BAD_REQUEST, "Account name already exist.");
		}

		LOGGER.info("updating account ...");
		existingAccount.setAccountName(requestedAccountDTO.getAccountName());
		accountService.updateAccount(existingAccount);

		LOGGER.info("updating account admin ...");
		User admin = userService.getUserById(existingAccount.getAdminId());
		UserDTO adminDTO = userFacade.convertEntityToDTO(admin);
		modelMapper.map(requestedAccountDTO.getAdmin(), adminDTO);
		userFacade.updateUser(adminDTO.getId(), adminDTO);

		return convertEntityToDTO(existingAccount);
	}

	public Account deleteAccount(int accountId) {
		return accountService.deleteAccount(accountId);
	}

	private AccountDTO convertEntityToDTO(Account account) {
		AccountDTO accountDTO = modelMapper.map(account, AccountDTO.class);
		User user = userService.getUserById(account.getAdminId());
		if (user != null) {
			accountDTO.setAdmin(modelMapper.map(user, AdminDTO.class));
		}
		return accountDTO;
	}

	private Account convertDTOToEntity(AccountDTO accountDTO) {
		return modelMapper.map(accountDTO, Account.class);
	}

}
