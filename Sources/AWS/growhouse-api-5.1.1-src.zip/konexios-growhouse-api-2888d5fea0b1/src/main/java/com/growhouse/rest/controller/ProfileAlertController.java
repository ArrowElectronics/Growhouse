package com.growhouse.rest.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;

import com.growhouse.rest.dto.ProfileAlertTimestampDTO;
import com.growhouse.rest.dto.ProfileResponseDTO;
import com.growhouse.rest.facade.ProfileAlertFacade;
import com.growhouse.rest.response.ResponseMessage;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/api/profilealert")
@Transactional
public class ProfileAlertController {

	@Autowired
	private ProfileAlertFacade profileAlertFacade;

	@GetMapping(value = "/user")
	@ApiOperation(value = "View random five profile Alerts based on user")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Data retrieved successfully") })
	public ResponseEntity<?> getProfileAlertByUserId() {
		ResponseEntity<?> responseEntity = null;

		try {
			List<ProfileResponseDTO> profileByUserDTOs = profileAlertFacade.getProfileAlertByUser();
			if (profileByUserDTOs.isEmpty())
				responseEntity = new ResponseEntity<>(new ArrayList<>(), HttpStatus.OK);
			else
				responseEntity = new ResponseEntity<>(profileByUserDTOs, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@GetMapping(value = "/all/user")
	@ApiOperation(value = "View all profile Alerts based on user")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Data retrieved successfully") })
	public ResponseEntity<?> getAllProfileAlertByUserId() {
		ResponseEntity<?> responseEntity = null;

		try {
			List<ProfileResponseDTO> profileByUserDTOs = profileAlertFacade.getAllProfileAlertByUser();
			if (profileByUserDTOs.isEmpty())
				responseEntity = new ResponseEntity<>(new ArrayList<>(), HttpStatus.OK);
			else
				responseEntity = new ResponseEntity<>(profileByUserDTOs, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@GetMapping(value = "/all/filter")
	@ApiOperation(value = "View all profile Alerts based on user")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Data retrieved successfully") })
	public ResponseEntity<?> getAllProfileAlertByFilter(@RequestParam("fromTimestamp") long fromTimestamp,
			@RequestParam("toTimestamp") long toTimestamp, @RequestParam("alertmessage") String alertmessage) {
		ResponseEntity<?> responseEntity = null;

		try {
			List<ProfileResponseDTO> profileByUserDTOs = profileAlertFacade.getAllProfileAlertByFilter(fromTimestamp,
					toTimestamp, alertmessage);
			if (profileByUserDTOs.isEmpty())
				responseEntity = new ResponseEntity<>(new ArrayList<>(), HttpStatus.OK);
			else
				responseEntity = new ResponseEntity<>(profileByUserDTOs, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@GetMapping(value = "/facility/{facilityId}")
	@ApiOperation(value = "View all profile Alerts based on facility id")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Data retrieved successfully") })
	public ResponseEntity<?> getProfileAlertByFacilityId(@PathVariable("facilityId") String facilityId) {
		ResponseEntity<?> responseEntity = null;

		try {
			List<ProfileResponseDTO> profileByUserDTOs = profileAlertFacade.getProfileAlertByFacilityId(facilityId);

			if (profileByUserDTOs == null || profileByUserDTOs.isEmpty())
				responseEntity = new ResponseEntity<>(new ArrayList<>(), HttpStatus.OK);
			else
				responseEntity = new ResponseEntity<>(profileByUserDTOs, HttpStatus.OK);

		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@GetMapping(value = "/all/facility/{facilityId}")
	@ApiOperation(value = "View all profile Alerts based on facility id")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Data retrieved successfully") })
	public ResponseEntity<?> getAllProfileAlertByFacilityId(@PathVariable("facilityId") String facilityId) {
		ResponseEntity<?> responseEntity = null;

		try {
			List<ProfileResponseDTO> profileByUserDTOs = profileAlertFacade.getAllProfileAlertByFacilityId(facilityId);
			if (profileByUserDTOs == null || profileByUserDTOs.isEmpty())
				responseEntity = new ResponseEntity<>(new ArrayList<>(), HttpStatus.OK);
			else
				responseEntity = new ResponseEntity<>(profileByUserDTOs, HttpStatus.OK);

		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@GetMapping(value = "/{profileId}/lasthours")
	@ApiOperation(value = "View all profile Alert based on Profile id")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Data retrieved successfully") })
	public ResponseEntity<?> getProfileAlertByProfileId(@PathVariable("profileId") Integer profileId) {
		ResponseEntity<?> responseEntity = null;
		try {
			List<ProfileAlertTimestampDTO> profileAlertTimestampDTOs = profileAlertFacade
					.getProfileAlertByProfileId(profileId);

			if (profileAlertTimestampDTOs == null || profileAlertTimestampDTOs.isEmpty())
				responseEntity = new ResponseEntity<>(new ArrayList<>(), HttpStatus.OK);
			else
				responseEntity = new ResponseEntity<>(profileAlertTimestampDTOs, HttpStatus.OK);

		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@GetMapping(value = "/{profileId}/history")
	@ApiOperation(value = "View profile Alert History based on Profile id")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Data retrieved successfully") })
	public ResponseEntity<?> getProfileAlertHistoryByProfileId(@PathVariable("profileId") Integer profileId,
			@RequestParam("fromTimestamp") long fromTimestamp, @RequestParam("toTimestamp") long toTimestamp) {
		ResponseEntity<?> responseEntity = null;
		try {
			List<ProfileAlertTimestampDTO> profileAlertTimestampDTOs = profileAlertFacade
					.getProfileAlertHistoryByProfileId(profileId, fromTimestamp, toTimestamp);
			if (profileAlertTimestampDTOs == null || profileAlertTimestampDTOs.isEmpty())
				responseEntity = new ResponseEntity<>(new ArrayList<>(), HttpStatus.OK);
			else
				responseEntity = new ResponseEntity<>(profileAlertTimestampDTOs, HttpStatus.OK);

		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@GetMapping(value = "/container/{containerId}")
	@ApiOperation(value = "View all profile Alerts based on container id ")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Data retrieved successfully") })
	public ResponseEntity<?> getProfileAlertByContainerId(@PathVariable("containerId") String containerId) {
		ResponseEntity<?> responseEntity = null;
		try {
			List<ProfileResponseDTO> profileByUserDTOs = profileAlertFacade.getProfileAlertByContainerId(containerId);

			if (profileByUserDTOs == null || profileByUserDTOs.isEmpty())
				responseEntity = new ResponseEntity<>(new ArrayList<>(), HttpStatus.OK);
			else
				responseEntity = new ResponseEntity<>(profileByUserDTOs, HttpStatus.OK);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@GetMapping(value = "/all/container/{containerId}")
	@ApiOperation(value = "View all profile Alerts based on container id ")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Data retrieved successfully") })
	public ResponseEntity<?> getAllProfileAlertByContainerId(@PathVariable("containerId") String containerId) {
		ResponseEntity<?> responseEntity = null;
		try {
			List<ProfileResponseDTO> profileByUserDTOs = profileAlertFacade
					.getAllProfileAlertByContainerId(containerId);

			if (profileByUserDTOs == null || profileByUserDTOs.isEmpty())
				responseEntity = new ResponseEntity<>(new ArrayList<>(), HttpStatus.OK);
			else
				responseEntity = new ResponseEntity<>(profileByUserDTOs, HttpStatus.OK);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@GetMapping(value = "/growarea/{growAreaId}")
	@ApiOperation(value = "View all profile Alerts based on growArea id")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Data retrieved successfully") })
	public ResponseEntity<?> getProfileAlertByGrowAreaId(@PathVariable("growAreaId") String growAreaId) {
		ResponseEntity<?> responseEntity = null;

		List<ProfileResponseDTO> profileByUserDTOs = profileAlertFacade.getProfileAlertByGrowAreaId(growAreaId);
		if (profileByUserDTOs == null || profileByUserDTOs.isEmpty())
			responseEntity = new ResponseEntity<>(new ArrayList<>(), HttpStatus.OK);
		else
			responseEntity = new ResponseEntity<>(profileByUserDTOs, HttpStatus.OK);
		return responseEntity;
	}

	@GetMapping(value = "/all/growarea/{growAreaId}")
	@ApiOperation(value = "View all profile Alerts based on growArea id")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Data retrieved successfully") })
	public ResponseEntity<?> getAllProfileAlertByGrowAreaId(@PathVariable("growAreaId") String growAreaId) {
		ResponseEntity<?> responseEntity = null;

		List<ProfileResponseDTO> profileByUserDTOs = profileAlertFacade.getAllProfileAlertByGrowAreaId(growAreaId);
		if (profileByUserDTOs == null || profileByUserDTOs.isEmpty())
			responseEntity = new ResponseEntity<>(new ArrayList<>(), HttpStatus.OK);
		else
			responseEntity = new ResponseEntity<>(profileByUserDTOs, HttpStatus.OK);
		return responseEntity;
	}

	@GetMapping(value = "/growsection/{growSectionId}")
	@ApiOperation(value = "View all profile Alerts based on growSection id")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Data retrieved successfully") })
	public ResponseEntity<?> getProfileAlertByGrowSectionId(@PathVariable("growSectionId") String growSectionId) {
		ResponseEntity<?> responseEntity = null;

		List<ProfileResponseDTO> profileByUserDTOs = profileAlertFacade.getProfileAlertByGrowSectionId(growSectionId);

		if (profileByUserDTOs == null)
			responseEntity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		else if (profileByUserDTOs.isEmpty())
			responseEntity = new ResponseEntity<>(new ArrayList<>(), HttpStatus.OK);
		else
			responseEntity = new ResponseEntity<>(profileByUserDTOs, HttpStatus.OK);
		return responseEntity;
	}

	@DeleteMapping(value = "gateway/{gatewayId}")
	@ApiOperation(value = "Delete all profile Alerts based on gateway id")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Profile Alerts deleted successfully") })
	public ResponseEntity<?> deleteProfileAlertsByGatewayId(@PathVariable("gatewayId") int gatewayId) {
		ResponseEntity<?> responseEntity = null;
		try {
			profileAlertFacade.deleteProfileAlertsByGatewayId(gatewayId);
			responseEntity = new ResponseEntity<>(HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception exception) {
			responseEntity = new ResponseEntity<>(exception.getMessage(), HttpStatus.NO_CONTENT);
		}
		return responseEntity;
	}

	@DeleteMapping(value = "profile/{profileId}")
	@ApiOperation(value = "Delete all profile Alerts based on profile id")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Profile Alerts deleted successfully") })
	public ResponseEntity<?> deleteProfileAlertsByProfileId(@PathVariable("profileId") int profileId) {
		ResponseEntity<?> responseEntity = null;
		try {
			profileAlertFacade.deleteProfileAlertsByProfileId(profileId);
			responseEntity = new ResponseEntity<>(HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception exception) {
			responseEntity = new ResponseEntity<>(exception.getMessage(), HttpStatus.NO_CONTENT);
		}
		return responseEntity;
	}

	private ResponseEntity<ResponseMessage> setResponseMessage(HttpClientErrorException httpClientErrorException) {
		ResponseMessage responseMessage = new ResponseMessage();
		responseMessage.setMessage(httpClientErrorException.getStatusText());
		return new ResponseEntity<>(responseMessage, httpClientErrorException.getStatusCode());

	}

}
