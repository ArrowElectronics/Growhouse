/**
 * 
 */
package com.growhouse.rest.facade;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.growhouse.rest.dto.DeviceDTO;
import com.growhouse.rest.dto.DeviceGrowSectionDTO;
import com.growhouse.rest.dto.DeviceLedNodeDTO;
import com.growhouse.rest.dto.DevicePropertyByDeviceDTO;
import com.growhouse.rest.dto.DevicePropertyDetailsDTO;
import com.growhouse.rest.dto.DevicePropertyMappingDTO;
import com.growhouse.rest.dto.DeviceStatusDTO;
import com.growhouse.rest.dto.DeviceTypeDTO;
import com.growhouse.rest.dto.GroupChannelConfigurationDTO;
import com.growhouse.rest.dto.GrowAreaDTO;
import com.growhouse.rest.dto.LedNodeChannelConfigurationDTO;
import com.growhouse.rest.dto.LedNodeHistoryDTO;
import com.growhouse.rest.dto.LedNodeProfileDTO;
import com.growhouse.rest.dto.OutofNetworkCountDTO;
import com.growhouse.rest.dto.TelemetryItemDTO;
import com.growhouse.rest.entity.Device;
import com.growhouse.rest.entity.DevicePropertyMapping;
import com.growhouse.rest.entity.DeviceType;
import com.growhouse.rest.entity.GrowArea;
import com.growhouse.rest.entity.GrowSectionDevice;
import com.growhouse.rest.entity.LedNodeChannelConfiguration;
import com.growhouse.rest.entity.LedNodeHistory;
import com.growhouse.rest.entity.LedNodeProfile;
import com.growhouse.rest.entity.kronos.TelemetryItem;
import com.growhouse.rest.repository.DeviceRepository;
import com.growhouse.rest.repository.GroupDeviceRepository;
import com.growhouse.rest.repository.LedNodeChannelConfigRepository;
import com.growhouse.rest.repository.LedNodeProfileRepository;
import com.growhouse.rest.services.IDeviceService;
import com.growhouse.rest.services.IDeviceTypeService;
import com.growhouse.rest.services.IGrowSectionDeviceService;
import com.growhouse.rest.services.impl.DeviceService;
import com.growhouse.rest.utils.Constants;
import com.growhouse.rest.utils.LedNodeChannelMapping;

/**
 * @author dharita.chokshi
 *
 */
@Component
public class DeviceFacade {

	private static final Logger LOGGER = LogManager.getLogger(DeviceFacade.class);

	@Autowired
	private IDeviceService deviceService;

	@Autowired
	private IDeviceTypeService deviceTypeService;

	@Autowired
	private IGrowSectionDeviceService growSectionDeviceService;

	@Autowired
	private GrowAreaFacade growAreaFacade;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private LedNodeChannelConfigRepository ledNodeChannelConfigRepository;

	@Autowired
	private DeviceService deviceServiceObj;

	@Autowired
	private DeviceRepository deviceRepository;

	@Autowired
	private LedNodeProfileRepository lednodeProfileRep;

	@Autowired
	private GroupDeviceRepository groupDeviceRepo;

	public List<DeviceDTO> getActiveDevices() {
		List<DeviceDTO> deviceDTOs = new ArrayList<>();
		List<Device> devices = deviceService.getActiveDevices();
		if (devices != null && !devices.isEmpty()) {
			deviceDTOs = devices.stream().map(this::convertEntityToDTO).collect(Collectors.toList());
		}
		deviceDTOs = populateDeviceWithGrowSection(deviceDTOs);
		return deviceDTOs;
	}

	public List<DeviceDTO> getAllDevices() {
		List<DeviceDTO> deviceDTOs = new ArrayList<>();
		List<Device> devices = deviceService.getAllDevices();
		if (devices != null && !devices.isEmpty()) {
			deviceDTOs = devices.stream().map(this::convertEntityToDTO).collect(Collectors.toList());
		}
		deviceDTOs = populateDeviceWithGrowSection(deviceDTOs);
		return deviceDTOs;
	}

	public List<DeviceDTO> getDevicesByGrowSectionId(int growSectionId) {
		List<DeviceDTO> deviceDTOs = new ArrayList<>();
		List<GrowSectionDevice> growSectionDevices = growSectionDeviceService.getActiveByGrowSectionId(growSectionId);

		if (growSectionDevices != null && !growSectionDevices.isEmpty()) {
			deviceDTOs = growSectionDevices.stream().map(device -> device.getDevice()).map(this::convertEntityToDTO)
					.collect(Collectors.toList());
		}
		deviceDTOs = populateDeviceWithGrowSection(deviceDTOs);
		return deviceDTOs;
	}

	public List<DeviceDTO> getDevicesByGrowAreaId(int growAreaId) {
		List<DeviceDTO> deviceDTOs = new ArrayList<>();
		List<Device> devices = deviceService.getDevicesByGrowAreaId(growAreaId);

		if (devices != null && !devices.isEmpty()) {
			deviceDTOs = devices.stream().map(this::convertEntityToDTO).collect(Collectors.toList());
		}
		deviceDTOs = populateDeviceWithGrowSection(deviceDTOs);
		return deviceDTOs;
	}

	private List<DeviceDTO> populateDeviceWithGrowSection(List<DeviceDTO> deviceDTOs) {
		return deviceDTOs.stream().map(deviceDto -> {
			List<GrowSectionDevice> growSectionDevices = growSectionDeviceService
					.getActiveByDeviceId(deviceDto.getId());
			if (growSectionDevices == null || growSectionDevices.isEmpty()) {
				deviceDto.setGrowSection(new ArrayList<>());
				return deviceDto;
			} else {
				List<DeviceGrowSectionDTO> deviceGrowSectionDTOs = growSectionDevices.stream()
						.map(growSectionDevice -> {
							DeviceGrowSectionDTO deviceGrowSectionDTO = new DeviceGrowSectionDTO();
							deviceGrowSectionDTO.setId(growSectionDevice.getGrowSection().getId());
							deviceGrowSectionDTO.setName(growSectionDevice.getGrowSection().getGrowSectionName());
							return deviceGrowSectionDTO;
						}).collect(Collectors.toList());
				deviceDto.setGrowSection(deviceGrowSectionDTOs);
				return deviceDto;
			}
		}).filter(Objects::nonNull).collect(Collectors.toList());

	}

	public List<DeviceDTO> getDevicesByGrowAreaIdAndDeviceTypeId(int growAreaId, int deviceTypeId) {
		List<DeviceDTO> deviceDTOs = new ArrayList<>();
		List<Device> devices = deviceService.getDevicesByGrowAreaIdAndDeviceTypeId(growAreaId, deviceTypeId);
		if (devices != null && !devices.isEmpty()) {
			deviceDTOs = devices.stream().filter(device -> device.getGrowArea().isActive())
					.map(this::convertEntityToDTO).collect(Collectors.toList());
		}
		deviceDTOs = populateDeviceWithGrowSection(deviceDTOs);
		return deviceDTOs;
	}

	public List<DeviceDTO> getDevicesByContainerId(int containerId) {
		List<DeviceDTO> deviceDTOs = new ArrayList<>();
		List<Device> devices = deviceService.getDevicesByContainerId(containerId);
		if (devices != null && !devices.isEmpty()) {
			deviceDTOs = devices.stream().filter(device -> device.getGrowArea().getContainer().isActive())
					.map(this::convertEntityToDTO).collect(Collectors.toList());
		}
		deviceDTOs = populateDeviceWithGrowSection(deviceDTOs);
		return deviceDTOs;
	}

	public int getDeviceCountByContainerId(int containerId) {
		return deviceService.getDevicesCountByContainerId(containerId);
	}

	public List<DeviceDTO> getDevicesByFacilityId(int facilityId) {
		List<DeviceDTO> deviceDTOs = new ArrayList<>();
		List<Device> devices = deviceService.getDevicesByFacilityId(facilityId);
		if (devices != null && !devices.isEmpty()) {
			deviceDTOs = devices.stream().filter(device -> device.getGrowArea().getContainer().getFacility().isActive())
					.map(this::convertEntityToDTO).collect(Collectors.toList());
		}
		deviceDTOs = populateDeviceWithGrowSection(deviceDTOs);
		return deviceDTOs;
	}

	public List<DeviceDTO> getDevicesByDeviceType(String deviceTypeName) {
		List<DeviceDTO> deviceDTOs = new ArrayList<>();

		DeviceType deviceType = deviceTypeService.getDeviceTypeByDeviceTypeName(deviceTypeName);
		if (deviceType == null)
			throw new HttpClientErrorException(HttpStatus.NOT_FOUND, "Device with requested device type doesnot exist");

		List<Device> devices = deviceService.getDevicesByDeviceTypeId(deviceType.getId());
		if (devices != null && !devices.isEmpty()) {
			deviceDTOs = devices.stream().filter(device -> device.getDeviceType().isActive())
					.map(this::convertEntityToDTO).collect(Collectors.toList());
		}
		deviceDTOs = populateDeviceWithGrowSection(deviceDTOs);
		return deviceDTOs;
	}

	public DeviceDTO getDeviceById(int deviceId) {
		DeviceDTO deviceDTO = null;
		Device device = deviceService.getDeviceById(deviceId);
		if (device != null) {
			deviceDTO = convertEntityToDTO(device);
		}
		return deviceDTO;
	}

	public DeviceDTO createDevice(DeviceDTO requestedDeviceDTO) {
		DeviceDTO createdDeviceDTO = null;
		requestedDeviceDTO.setStatus(true);
		Device requestedDevice = convertDTOToEntity(requestedDeviceDTO);
		Device device = deviceService.getDeviceByUID(requestedDevice.getDeviceUId());
		if (device == null) {
			Device createdDevice = deviceService.createDevice(requestedDevice);
			if (createdDevice != null) {
				createdDeviceDTO = convertEntityToDTO(createdDevice);
				if (requestedDeviceDTO.getDeviceType().getDeviceTypeName().equals(Constants.LEDNODE)) {
					LedNodeChannelConfigurationDTO ledConfigDTOObj = requestedDeviceDTO.getLedconfiguration();
					LedNodeChannelConfiguration ledConfigObj = modelMapper.map(ledConfigDTOObj,
							LedNodeChannelConfiguration.class);
					ledConfigObj.setDevice(createdDevice);
					ledConfigObj.setDeviceType(Constants.LEDNODE);
					deviceService.setLedNodeChannelConfiguration(ledConfigObj);
				} else {
					LOGGER.info("Device type different");
				}
			}
			return createdDeviceDTO;
		} else {
			deleteSectionDevices(device.getId());
			groupDeviceRepo.deleteGroupDevicesByDeviceId(device.getId());
			LOGGER.info("While Device creating device detached from previous section successfully");
			if (requestedDeviceDTO.getDeviceType().getDeviceTypeName().equals(Constants.LEDNODE)) {
				LedNodeChannelConfigurationDTO ledConfigDTOObj = requestedDeviceDTO.getLedconfiguration();
				LedNodeChannelConfiguration ledConfigObj = modelMapper.map(ledConfigDTOObj,
						LedNodeChannelConfiguration.class);
				LedNodeChannelConfiguration updateObject = deviceService.getLedNodeChannelConfiguration(device.getId());
				if (updateObject != null) {
					ledConfigObj.setId(updateObject.getId());
				}
				ledConfigObj.setDevice(device);
				ledNodeChannelConfigRepository.save(ledConfigObj);
			}
			requestedDeviceDTO.setId(device.getId());
			requestedDeviceDTO.setPrefixKeyword(device.getPrefixKeyword());
			requestedDeviceDTO.setDeviceHID(null);
			return updateDevice(device.getId(), requestedDeviceDTO);

		}
	}

	public DeviceDTO updateDevice(int deviceId, DeviceDTO requestedDeviceDTO) {
		if (deviceId != requestedDeviceDTO.getId())
			throw new HttpClientErrorException(HttpStatus.NOT_ACCEPTABLE,
					"DeviceId in URL doesnot match with deviceId of Device object");

		Device existingDevice = deviceService.getDeviceById(requestedDeviceDTO.getId());
		if (existingDevice == null)
			throw new HttpClientErrorException(HttpStatus.NO_CONTENT, "Device not found");

		if (!existingDevice.isActive())
			throw new HttpClientErrorException(HttpStatus.FORBIDDEN, "Device is inactive");

		DeviceDTO updatedDeviceDTO = null;
		Device requestedDevice = convertDTOToEntity(requestedDeviceDTO);
		Device updatedDevice = deviceService.updateDevice(requestedDevice);
		if (updatedDevice != null)
			updatedDeviceDTO = convertEntityToDTO(updatedDevice);
		return updatedDeviceDTO;
	}

	public List<DevicePropertyByDeviceDTO> getDevicePropertiesByDeviceId(int deviceId) {

		List<DevicePropertyByDeviceDTO> devicePropertyMappingDTOs = new ArrayList<>();
		List<DevicePropertyMapping> devicePropertyMappings = deviceService.getDevicePropertiesByDeviceId(deviceId);

		if (devicePropertyMappings != null && !devicePropertyMappings.isEmpty()) {
			devicePropertyMappingDTOs = devicePropertyMappings.stream()
					.map(this::convertDevicePropertyMappingEntityToDTO).collect(Collectors.toList());
		}
		return devicePropertyMappingDTOs;
	}

	public List<DevicePropertyMappingDTO> getDevicePropertiesByGrowSectionId(int growSectionId) {
		List<GrowSectionDevice> growSectionDevices = growSectionDeviceService.getActiveByGrowSectionId(growSectionId);
		if (growSectionDevices != null && !growSectionDevices.isEmpty()) {
			List<DevicePropertyMappingDTO> devicePropertyMappingDTOs = new ArrayList<>();
			List<DevicePropertyMapping> devicePropertyMappings = deviceService
					.getDevicePropertiesByGrowSectionId(growSectionId, growSectionDevices);
			Map<Integer, List<DevicePropertyDetailsDTO>> map = new HashMap<>();

			if (devicePropertyMappings != null && !devicePropertyMappings.isEmpty()) {
				for (DevicePropertyMapping devicePropertyMapping : devicePropertyMappings) {

					try {
						Map<String, String> propertyMap = new HashMap<>();
						propertyMap.put(Constants.SOILPH_KEY, Constants.SOILPH_VALUE);
						propertyMap.put(Constants.BATTERYVOLTAGE_KEY, Constants.BATTERYVOLTAGE_VALUE);
						propertyMap.put(Constants.SOILMOISTURE_KEY, Constants.SOILMOISTURE_VALUE);
						propertyMap.put(Constants.LED1_KEY, Constants.LED1_VALUE);
						propertyMap.put(Constants.LED2_KEY, Constants.LED2_VALUE);
						propertyMap.put(Constants.LED3_KEY, Constants.LED3_VALUE);
						propertyMap.put(Constants.LED4_KEY, Constants.LED4_VALUE);
						propertyMap.put(Constants.LED5_KEY, Constants.LED5_VALUE);
						propertyMap.put(Constants.LED6_KEY, Constants.LED6_VALUE);

						DevicePropertyDetailsDTO devicePropertyDetailsDTO = new DevicePropertyDetailsDTO();
						devicePropertyDetailsDTO.setDisplayPropertyName(
								propertyMap.get(devicePropertyMapping.getDevicePropertyDetails().getName()));
						devicePropertyDetailsDTO.setName(devicePropertyMapping.getDevicePropertyDetails().getName());
						devicePropertyDetailsDTO.setType(devicePropertyMapping.getDevicePropertyDetails().getType());

						if (map.containsKey(devicePropertyMapping.getDevice().getId())) {
							List<DevicePropertyDetailsDTO> detailsDTOs = map
									.get(devicePropertyMapping.getDevice().getId());
							detailsDTOs = new ArrayList<>(detailsDTOs);
							detailsDTOs.add(devicePropertyDetailsDTO);
							map.put(devicePropertyMapping.getDevice().getId(), detailsDTOs);
						} else {
							map.put(devicePropertyMapping.getDevice().getId(), Arrays.asList(devicePropertyDetailsDTO));
						}
					} catch (Exception exception) {
						LOGGER.info("Error occurred {}" + exception);
					}

				}
				populateWithDeviceProperties(devicePropertyMappingDTOs, devicePropertyMappings, map);
			}

			return devicePropertyMappingDTOs;
		} else {
			throw new HttpClientErrorException(HttpStatus.NO_CONTENT, "Devices Not Found");
		}
	}

	public List<DevicePropertyMappingDTO> getDevicePropertiesByGrowAreaId(int growAreaId) {
		List<Device> devices = deviceService.getDevicesByGrowAreaId(growAreaId);
		if (devices != null && !devices.isEmpty()) {
			List<DevicePropertyMappingDTO> devicePropertyMappingDTOs = new ArrayList<>();
			List<DevicePropertyMapping> devicePropertyMappings = deviceService.getDevicePropertiesByGrowAreaId(devices);
			Map<Integer, List<DevicePropertyDetailsDTO>> map = new HashMap<>();

			if (devicePropertyMappings != null && !devicePropertyMappings.isEmpty()) {
				for (DevicePropertyMapping devicePropertyMapping : devicePropertyMappings) {

					try {
						DevicePropertyDetailsDTO devicePropertyDetailsDTO = new DevicePropertyDetailsDTO();
						devicePropertyDetailsDTO.setName(devicePropertyMapping.getDevicePropertyDetails().getName());
						devicePropertyDetailsDTO.setType(devicePropertyMapping.getDevicePropertyDetails().getType());

						if (map.containsKey(devicePropertyMapping.getDevice().getId())) {
							List<DevicePropertyDetailsDTO> detailsDTOs = map
									.get(devicePropertyMapping.getDevice().getId());
							detailsDTOs = new ArrayList<>(detailsDTOs);
							detailsDTOs.add(devicePropertyDetailsDTO);
							map.put(devicePropertyMapping.getDevice().getId(), detailsDTOs);
						} else {
							map.put(devicePropertyMapping.getDevice().getId(), Arrays.asList(devicePropertyDetailsDTO));
						}
					} catch (Exception exception) {
						LOGGER.info("Error occurred {}" + exception);
					}

				}
				populateWithDeviceProperties(devicePropertyMappingDTOs, devicePropertyMappings, map);
			}
			return devicePropertyMappingDTOs;
		} else {
			throw new HttpClientErrorException(HttpStatus.NO_CONTENT, "Devices Not Found");
		}
	}

	/**
	 * @param devicePropertyMappingDTOs
	 * @param devicePropertyMappings
	 * @param map
	 */
	private void populateWithDeviceProperties(List<DevicePropertyMappingDTO> devicePropertyMappingDTOs,
			List<DevicePropertyMapping> devicePropertyMappings, Map<Integer, List<DevicePropertyDetailsDTO>> map) {
		List<Integer> uniqueIds = new ArrayList<>();
		for (DevicePropertyMapping devicePropertyMapping : devicePropertyMappings) {
			if (!uniqueIds.contains(devicePropertyMapping.getDevice().getId())) {
				DevicePropertyMappingDTO devicePropertyMappingDTO = new DevicePropertyMappingDTO();
				devicePropertyMappingDTO.setDeviceId(devicePropertyMapping.getDevice().getId());
				devicePropertyMappingDTO.setDeviceName(devicePropertyMapping.getDevice().getDeviceName());
				devicePropertyMappingDTO.setDeviceHId(devicePropertyMapping.getDevice().getDeviceHId());
				devicePropertyMappingDTO.setDeviceUId(devicePropertyMapping.getDevice().getDeviceUId());
				devicePropertyMappingDTO.setPrefixKeyword(devicePropertyMapping.getDevice().getPrefixKeyword());
				devicePropertyMappingDTO.setProperties(map.get(devicePropertyMapping.getDevice().getId()));
				uniqueIds.add(devicePropertyMapping.getDevice().getId());
				devicePropertyMappingDTOs.add(devicePropertyMappingDTO);
			}
		}
	}

	public List<TelemetryItemDTO> getDeviceLastTelemetry(String deviceHId) {
		List<String> list = new ArrayList<>();
		List<TelemetryItem> telemetryItems = objectMapper.convertValue(deviceService.getDeviceLastTelemetry(deviceHId),
				new TypeReference<List<TelemetryItem>>() {
				});

		List<TelemetryItemDTO> telemetryItemDTOs = new ArrayList<>();
		List<TelemetryItemDTO> finaltelemetryItemDTOs = new ArrayList<>();
		HashMap<String, Long> map = new HashMap<>();
		HashMap<String, String> valueMap = new HashMap<>();
		for (TelemetryItem telemetryItem : telemetryItems) {
			TelemetryItemDTO telemetryItemDTO = convertTelemetryToTelemetryDTO(telemetryItem);
			if (!list.contains(telemetryItemDTO.getName())) {
				list.add(telemetryItemDTO.getName());
				map.put(telemetryItemDTO.getName(), telemetryItemDTO.getTimestamp());
				valueMap.put(telemetryItemDTO.getName(), telemetryItem.value().toString());
				telemetryItemDTO.setValue(telemetryItem.value().toString());
				telemetryItemDTOs.add(telemetryItemDTO);
			} else {
				long existTime = map.get(telemetryItemDTO.getName());
				if (existTime < telemetryItemDTO.getTimestamp()) {
					map.replace(telemetryItemDTO.getName(), telemetryItemDTO.getTimestamp());
					valueMap.replace(telemetryItemDTO.getName(), telemetryItem.value().toString());
				}
			}
		}
		for (TelemetryItemDTO telemetryItemDTO : telemetryItemDTOs) {
			String name = telemetryItemDTO.getName();
			Long time = map.get(name);
			Object value = valueMap.get(name);
			telemetryItemDTO.setTimestamp(time);
			telemetryItemDTO.setValue(value);
			finaltelemetryItemDTOs.add(telemetryItemDTO);
		}
		return finaltelemetryItemDTOs.stream().sorted(Comparator.comparing(TelemetryItemDTO::getName))
				.collect(Collectors.toList());

	}

	public LedNodeHistoryDTO setLedNodeDesiredvalue(LedNodeHistoryDTO requestedLedNodeHistoryDTO) {
		LedNodeHistoryDTO ledNodeHistoryDTO = null;
		try {
			LedNodeHistory ledNodeHistory = modelMapper.map(requestedLedNodeHistoryDTO, LedNodeHistory.class);
			DeviceDTO deviceDTO = getDeviceById(requestedLedNodeHistoryDTO.getDevice().getId());
			LedNodeHistory createdLedNodeHistory = deviceService.setLedNodedesiredValue(ledNodeHistory,
					setDeviceState(requestedLedNodeHistoryDTO), deviceDTO.getDeviceHID());
			if (createdLedNodeHistory != null)
				ledNodeHistoryDTO = modelMapper.map(createdLedNodeHistory, LedNodeHistoryDTO.class);
		} catch (HttpClientErrorException exception) {
			LOGGER.info("Error occurred while setting desired to LedNode {}" + exception);
			throw new HttpClientErrorException(HttpStatus.BAD_REQUEST,
					"Error Occurred While Set LedNode desired value.");
		}
		return ledNodeHistoryDTO;
	}

	public Map<String, Object> setDeviceState(LedNodeHistoryDTO requestedLedNodeHistoryDTO) {
		Map<String, String> states = new HashMap<>();
		states.put(LedNodeChannelMapping.valueOf(Constants.CHANNEL1).showLedNodeChannelMappingValue(),
				requestedLedNodeHistoryDTO.getCh1().toString());
		states.put(LedNodeChannelMapping.valueOf(Constants.CHANNEL2).showLedNodeChannelMappingValue(),
				requestedLedNodeHistoryDTO.getCh2().toString());
		states.put(LedNodeChannelMapping.valueOf(Constants.CHANNEL3).showLedNodeChannelMappingValue(),
				requestedLedNodeHistoryDTO.getCh3().toString());
		states.put(LedNodeChannelMapping.valueOf(Constants.CHANNEL4).showLedNodeChannelMappingValue(),
				requestedLedNodeHistoryDTO.getCh4().toString());
		states.put(LedNodeChannelMapping.valueOf(Constants.CHANNEL5).showLedNodeChannelMappingValue(),
				requestedLedNodeHistoryDTO.getCh5().toString());
		states.put(LedNodeChannelMapping.valueOf(Constants.CHANNEL6).showLedNodeChannelMappingValue(),
				requestedLedNodeHistoryDTO.getCh6().toString());
		Map<String, Object> deviceState = new HashMap<>();
		String isoDatePattern = "yyyy-MM-dd'T'HH:mm:dd'Z'";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(isoDatePattern);
		deviceState.put("timestamp", simpleDateFormat.format(new Date()));

		try {
			deviceState.put("states", objectMapper.readValue(objectMapper.writeValueAsString(states), Map.class));
		} catch (IOException exception) {
			LOGGER.info("Error occurred while manipulating Json {}" + exception);
		}

		return deviceState;
	}

	public LedNodeChannelConfigurationDTO getLedNodeChannelConfig(Integer deviceId) {
		LedNodeChannelConfigurationDTO responseLedNode = null;

		LedNodeChannelConfiguration ledNodeChannelConfig = deviceService.getLedNodeChannelConfiguration(deviceId);
		if (ledNodeChannelConfig != null) {
			responseLedNode = modelMapper.map(ledNodeChannelConfig, LedNodeChannelConfigurationDTO.class);
			return responseLedNode;
		} else {
			throw new HttpClientErrorException(HttpStatus.NO_CONTENT, "Device Id Channel configuration not found");
		}
	}

	public LedNodeProfileDTO setLedNodeProfile(LedNodeProfileDTO requestedLedNodeProfile) {
		LedNodeProfileDTO createdLedNodeProfileDTO = null;
		LedNodeProfile ledNodeProfile = modelMapper.map(requestedLedNodeProfile, LedNodeProfile.class);
		LedNodeProfile dbProfile = lednodeProfileRep.findByDeviceIdAndProfileNameAndIsActiveTrue(
				ledNodeProfile.getDevice().getId(), ledNodeProfile.getProfileName().trim());
		if (dbProfile == null) {
			LedNodeProfile createdLedNodeProfile = deviceService.setLedNodeProfile(ledNodeProfile);
			if (createdLedNodeProfile != null) {
				createdLedNodeProfileDTO = modelMapper.map(createdLedNodeProfile, LedNodeProfileDTO.class);
			}
		} else
			throw new HttpClientErrorException(HttpStatus.BAD_REQUEST,
					"Profile name already exist in selected device.");

		return createdLedNodeProfileDTO;
	}

	public List<LedNodeProfileDTO> getLedNodeProfile(int deviceId) {
		List<LedNodeProfileDTO> ledNodeProfileDTO = null;
		List<LedNodeProfile> ledNodeProfiles = deviceService.getLedNodeProfile(deviceId);
		if (ledNodeProfiles != null && !ledNodeProfiles.isEmpty()) {
			ledNodeProfileDTO = ledNodeProfiles.stream().map(this::convertLedProfileToLedProfileDTO)
					.collect(Collectors.toList());
		}
		return ledNodeProfileDTO;
	}

	public void deleteLedProfileById(int profileId) {
		deviceServiceObj.deleteLedNodeProfileById(profileId);
	}

	public Device deleteDevice(int deviceId) {

		Device deletedDevice = deviceService.deleteDevice(deviceId);
		if (deletedDevice != null) {
			deleteSectionDevices(deviceId);
			groupDeviceRepo.deleteGroupDevicesByDeviceId(deviceId);
			if (deletedDevice.getDeviceType().getDeviceTypeName().equals(Constants.LEDNODE)) {
				deleteLedNodeProfile(deviceId);
			}
		}
		return deletedDevice;
	}

	public void deleteGrowAreaDevices(int gatewayId) {
		deviceServiceObj.deleteAllGrowAreaDevices(gatewayId);
	}

	public void deleteDevicePropertyMapping(int deviceId) {
		try {
			deviceServiceObj.deleteDevicePropertyMapping(deviceId);
		} catch (HttpClientErrorException httpClientErrorException) {
			throw new HttpClientErrorException(HttpStatus.NO_CONTENT,
					"Error occurred While deleting Device Property mapping.");
		}
	}

	public void deleteDevicePropertyMappingByGatewayId(int gatewayId) {
		try {
			deviceServiceObj.deleteDevicePropertyMappingByGatewayId(gatewayId);
		} catch (HttpClientErrorException httpClientErrorException) {
			throw new HttpClientErrorException(HttpStatus.NO_CONTENT,
					"Error occurred While deleting Device Property mapping.");
		}
	}

	public void deleteLedNodeProfile(int deviceId) {

		try {
			deviceServiceObj.deleteLedNodeProfile(deviceId);
		} catch (HttpClientErrorException httpClientErrorException) {
			throw new HttpClientErrorException(HttpStatus.NO_CONTENT, "Error occurred While deleting LedNode Profile.");
		}
	}

	public void deleteLedNodeProfileByGatewayID(int gatewayId) {

		try {
			deviceServiceObj.deleteLedNodeProfileByGatewayId(gatewayId);
		} catch (HttpClientErrorException httpClientErrorException) {
			throw new HttpClientErrorException(HttpStatus.NO_CONTENT, "Error occurred While deleting LedNode Profile.");
		}
	}

	public void deleteLedNodeDesiredValue(int deviceId) {
		try {
			deviceServiceObj.deleteLedNodeDesiredValue(deviceId);
		} catch (HttpClientErrorException httpClientErrorException) {
			throw new HttpClientErrorException(HttpStatus.NO_CONTENT,
					"Error occurred While deleting LedNodeDesired Value.");
		}
	}

	public void deleteLedNodeDesiredValueByGatewayId(int gatewayId) {
		try {
			deviceServiceObj.deleteLedNodeDesiredValueByGatewayId(gatewayId);
		} catch (HttpClientErrorException httpClientErrorException) {
			throw new HttpClientErrorException(HttpStatus.NO_CONTENT,
					"Error occurred While deleting LedNodeDesired Value.");
		}
	}

	public void deleteLedNodeChannelConfigurationValue(int deviceId) {
		try {
			deviceServiceObj.deleteLedNodeChannelConfigurationValue(deviceId);
		} catch (HttpClientErrorException httpClientErrorException) {
			throw new HttpClientErrorException(HttpStatus.NO_CONTENT,
					"Error occurred While deleting LedNode Channel configuration Values.");
		}
	}

	public void deleteLedNodeChannelConfigurationValueBygatewayId(int gatewayId) {
		try {
			deviceServiceObj.deleteLedNodeChannelConfigurationValueByGatewayId(gatewayId);
		} catch (HttpClientErrorException httpClientErrorException) {
			throw new HttpClientErrorException(HttpStatus.NO_CONTENT,
					"Error occurred While deleting LedNode Channel configuration Values.");
		}
	}

	public void deleteSectionDevices(int deviceId) {
		try {
			deviceServiceObj.deleteSectionDevices(deviceId);
		} catch (HttpClientErrorException httpClientErrorException) {
			throw new HttpClientErrorException(HttpStatus.NO_CONTENT,
					"Error occurred While deleting Growsections Devices ");
		}
	}

	public void deleteSectionDevicesList(int gatewayId) {
		try {
			deviceServiceObj.deleteSectionDevicesList(gatewayId);
		} catch (HttpClientErrorException httpClientErrorException) {
			throw new HttpClientErrorException(HttpStatus.NO_CONTENT,
					"Error occurred While deleting Growsections Devices ");
		}
	}

	public void updateDeviceLatestStatus(List<DeviceStatusDTO> payload, String growAreaHId) {
		for (DeviceStatusDTO device : payload) {
			Device dbDevice = deviceService.getDeviceByUID(device.getDeviceUid());
			if (dbDevice != null && dbDevice.getGrowArea().getGrowAreaHId().equals(growAreaHId)) {
				deviceService.updateDeviceStatus(device.isStatus(), device.getDeviceUid());
				long thrityAgo = System.currentTimeMillis() - Constants.THRITY_MINUTES;
				if (dbDevice.getGrowArea().getLatestHeartbeat() < thrityAgo) {
					growAreaFacade.updateLatestGatewayHeartbeat(dbDevice.getGrowArea().getGrowAreaHId(),
							System.currentTimeMillis());
				}
			}
		}

	}

	public List<DeviceLedNodeDTO> getDeviceBychannelConfi(GroupChannelConfigurationDTO confi, int gatewayId) {
		List<DeviceLedNodeDTO> responseLedNode = null;

		List<LedNodeChannelConfiguration> ledNodeChannelConfig = deviceService.getDevicesBasedonConfiguration(confi,
				gatewayId);
		if (ledNodeChannelConfig != null && !ledNodeChannelConfig.isEmpty()) {
			responseLedNode = ledNodeChannelConfig.stream().map(this::convertLedConfiTODTO)
					.collect(Collectors.toList());

		}
		return responseLedNode;
	}

	private DeviceDTO convertEntityToDTO(Device device) {
		DeviceDTO deviceDTO = new DeviceDTO();
		deviceDTO.setDescription(device.getDescription());
		deviceDTO.setDeviceHID(device.getDeviceHId());
		deviceDTO.setDeviceName(device.getDeviceName());
		deviceDTO.setDeviceType(convertDeviceTypeToDTO(device.getDeviceType()));
		deviceDTO.setDeviceUID(device.getDeviceUId());
		deviceDTO.setEui64(device.getEui64());
		deviceDTO.setGrowArea(convertGrowAreaToDTO(device.getGrowArea()));
		deviceDTO.setPrefixKeyword(device.getPrefixKeyword());
		deviceDTO.setId(device.getId());
		deviceDTO.setStatus(device.isStatus());
		return deviceDTO;
	}

	private DeviceLedNodeDTO convertLedConfiTODTO(LedNodeChannelConfiguration ledNodeChannelConfig) {
		DeviceLedNodeDTO deviceDTO = new DeviceLedNodeDTO();
		deviceDTO.setId(ledNodeChannelConfig.getDevice().getId());
		deviceDTO.setDeviceName(ledNodeChannelConfig.getDevice().getDeviceName());
		deviceDTO.setDeviceHId(ledNodeChannelConfig.getDevice().getDeviceHId());
		deviceDTO.setDeviceUId((ledNodeChannelConfig.getDevice().getDeviceUId()));
		return deviceDTO;
	}

	private GrowAreaDTO convertGrowAreaToDTO(GrowArea growArea) {
		return modelMapper.map(growArea, GrowAreaDTO.class);
	}

	private DeviceTypeDTO convertDeviceTypeToDTO(DeviceType deviceType) {
		return modelMapper.map(deviceType, DeviceTypeDTO.class);
	}

	private Device convertDTOToEntity(DeviceDTO deviceDTO) {
		return modelMapper.map(deviceDTO, Device.class);
	}

	private LedNodeProfileDTO convertLedProfileToLedProfileDTO(LedNodeProfile ledNodeProfile) {
		return modelMapper.map(ledNodeProfile, LedNodeProfileDTO.class);
	}

	private TelemetryItemDTO convertTelemetryToTelemetryDTO(TelemetryItem telemetryItem) {
		Map<String, String> propertyMap = new HashMap<>();
		propertyMap.put(Constants.SOILPH_KEY, Constants.SOILPH_VALUE);
		propertyMap.put(Constants.BATTERYVOLTAGE_KEY, Constants.BATTERYVOLTAGE_VALUE);
		propertyMap.put(Constants.SOILMOISTURE_KEY, Constants.SOILMOISTURE_VALUE);
		TelemetryItemDTO telemetryItemDTO = modelMapper.map(telemetryItem, TelemetryItemDTO.class);
		telemetryItemDTO.setDisplayPropertyName(propertyMap.get(telemetryItemDTO.getName()));
		return telemetryItemDTO;
	}

	private DevicePropertyByDeviceDTO convertDevicePropertyMappingEntityToDTO(
			DevicePropertyMapping devicePropertyMapping) {
		Map<String, String> propertyMap = new HashMap<>();
		propertyMap.put(Constants.SOILPH_KEY, Constants.SOILPH_VALUE);
		propertyMap.put(Constants.BATTERYVOLTAGE_KEY, Constants.BATTERYVOLTAGE_VALUE);
		propertyMap.put(Constants.SOILMOISTURE_KEY, Constants.SOILMOISTURE_VALUE);
		propertyMap.put(Constants.LED1_KEY, Constants.LED1_VALUE);
		propertyMap.put(Constants.LED2_KEY, Constants.LED2_VALUE);
		propertyMap.put(Constants.LED3_KEY, Constants.LED3_VALUE);
		propertyMap.put(Constants.LED4_KEY, Constants.LED4_VALUE);
		propertyMap.put(Constants.LED5_KEY, Constants.LED5_VALUE);
		propertyMap.put(Constants.LED6_KEY, Constants.LED6_VALUE);
		DevicePropertyByDeviceDTO devicePropertyMappingDTO = modelMapper.map(devicePropertyMapping,
				DevicePropertyByDeviceDTO.class);
		devicePropertyMappingDTO
				.setDisplayPropertyName(propertyMap.get(devicePropertyMapping.getDevicePropertyDetails().getName()));
		devicePropertyMappingDTO.setPropertyName(devicePropertyMapping.getDevicePropertyDetails().getName());
		devicePropertyMappingDTO.setDeviceHId(devicePropertyMapping.getDevice().getDeviceHId());
		devicePropertyMappingDTO.setType(devicePropertyMapping.getDevicePropertyDetails().getType());
		return devicePropertyMappingDTO;
	}

	public OutofNetworkCountDTO getcountOutOfNetworkDevicesByGrowarea(int gatewayId) {
		int count = 0;
		OutofNetworkCountDTO outofNetworkCountDTO = new OutofNetworkCountDTO();
		outofNetworkCountDTO.setCount(count);
		count = deviceRepository.countByIsActiveTrueAndGrowAreaIdAndStatus(gatewayId, false);
		outofNetworkCountDTO.setCount(count);
		return outofNetworkCountDTO;
	}

	public OutofNetworkCountDTO getcountOutOfNetworkDevicesByGrowareaAndType(int gatewayId, int deviceType) {
		int count = 0;
		OutofNetworkCountDTO outofNetworkCountDTO = new OutofNetworkCountDTO();
		outofNetworkCountDTO.setCount(count);
		count = deviceRepository.countByIsActiveTrueAndGrowAreaIdAndStatusAndDeviceTypeId(gatewayId, false, deviceType);
		outofNetworkCountDTO.setCount(count);
		return outofNetworkCountDTO;
	}

}
