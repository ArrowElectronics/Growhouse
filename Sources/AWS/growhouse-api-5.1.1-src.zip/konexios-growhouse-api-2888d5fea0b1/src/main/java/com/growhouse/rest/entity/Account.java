/**
 * 
 */
package com.growhouse.rest.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

/**
 * @author dharita.chokshi
 *
 */
@Entity
@Table(name = "accounts")
public class Account extends DefaultModel implements Serializable {
	private static final long serialVersionUID = 8939776794163516638L;

	@Column(name = "account_name")
	@NotNull
	private String accountName;

	@Column(name = "admin_id")
	private Integer adminId;

	@Deprecated
	@Column(name = "email_id")
	private String emailId;

	@Deprecated
	public String getEmailId() {
		return emailId;
	}

	@Deprecated
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public Integer getAdminId() {
		return this.adminId;
	}

	public void setAdminId(Integer adminId) {
		this.adminId = adminId;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	@Override
	public String toString() {
		return "{" + " accountName='" + getAccountName() + "'" + ", adminId='" + getAdminId() + "'" + "}";
	}
}
