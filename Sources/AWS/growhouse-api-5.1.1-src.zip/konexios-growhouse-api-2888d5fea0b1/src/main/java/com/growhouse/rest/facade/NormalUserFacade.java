package com.growhouse.rest.facade;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import com.growhouse.rest.dto.NormalUserDashboardCountDTO;
import com.growhouse.rest.dto.NormalUserDeviceTypeCount;
import com.growhouse.rest.entity.Device;
import com.growhouse.rest.entity.GrowAreaAssignee;
import com.growhouse.rest.entity.User;
import com.growhouse.rest.services.impl.DeviceService;
import com.growhouse.rest.services.impl.GrowAreaAssigneeService;
import com.growhouse.rest.utils.DeviceType;
import com.growhouse.rest.utils.DeviceTypeUIName;

@Component
public class NormalUserFacade {

	@Autowired
	private GrowAreaAssigneeService growAreaAssigneeService;

	@Autowired
	private DeviceService deviceService;

	public NormalUserDashboardCountDTO getNormalUserCount() {
		NormalUserDashboardCountDTO normalUserDashboardCountDTO = new NormalUserDashboardCountDTO();
		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		List<GrowAreaAssignee> growAreaAssignees = growAreaAssigneeService
		        .getAllGrowAreaAssigneesByUserIdAndGrowAreaIsActive(user.getId());
		List<Integer> growAreaIds = growAreaAssignees.stream()
		        .map(growAreaAssigne -> growAreaAssigne.getGrowArea().getId()).collect(Collectors.toList());
		normalUserDashboardCountDTO.setGrowAreaIds(growAreaIds);
		List<Device> devices = deviceService.getDeviceRepository().findByIsActiveTrueAndGrowAreaIdIn(growAreaIds);
		Map<String, Long> deviceTypeCount = devices.stream().collect(Collectors.groupingBy(
		        device -> DeviceTypeUIName.valueOf(device.getDeviceType().getDeviceTypeName()).showDevicePrefixValue(),
		        Collectors.counting()));
		if (!deviceTypeCount
		        .containsKey(DeviceTypeUIName.valueOf(DeviceType.HumidityNode.toString()).showDevicePrefixValue()))
			deviceTypeCount.put(DeviceTypeUIName.valueOf(DeviceType.HumidityNode.toString()).showDevicePrefixValue(),
			        0L);
		if (!deviceTypeCount
		        .containsKey(DeviceTypeUIName.valueOf(DeviceType.LightShield.toString()).showDevicePrefixValue()))
			deviceTypeCount.put(DeviceTypeUIName.valueOf(DeviceType.LightShield.toString()).showDevicePrefixValue(),
			        0L);
		if (!deviceTypeCount
		        .containsKey(DeviceTypeUIName.valueOf(DeviceType.SCMNode.toString()).showDevicePrefixValue()))
			deviceTypeCount.put(DeviceTypeUIName.valueOf(DeviceType.SCMNode.toString()).showDevicePrefixValue(), 0L);
		if (!deviceTypeCount
		        .containsKey(DeviceTypeUIName.valueOf(DeviceType.SoilNode.toString()).showDevicePrefixValue()))
			deviceTypeCount.put(DeviceTypeUIName.valueOf(DeviceType.SoilNode.toString()).showDevicePrefixValue(), 0L);
		if (!deviceTypeCount
		        .containsKey(DeviceTypeUIName.valueOf(DeviceType.LedNode.toString()).showDevicePrefixValue()))
			deviceTypeCount.put(DeviceTypeUIName.valueOf(DeviceType.LedNode.toString()).showDevicePrefixValue(), 0L);

		NormalUserDeviceTypeCount normalUserDeviceTypeCount = new NormalUserDeviceTypeCount();
		normalUserDeviceTypeCount.setDevicesTypeCount(deviceTypeCount);
		normalUserDashboardCountDTO.setDevicesCount(normalUserDeviceTypeCount);
		normalUserDashboardCountDTO.setGrowAreaCount(growAreaIds.size());
		return normalUserDashboardCountDTO;
	}

}
