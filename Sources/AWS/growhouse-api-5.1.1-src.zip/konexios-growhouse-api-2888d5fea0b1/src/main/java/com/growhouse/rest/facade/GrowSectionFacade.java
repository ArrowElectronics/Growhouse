/**
 * 
 */
package com.growhouse.rest.facade;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;

import com.growhouse.rest.dto.DeviceDTO;
import com.growhouse.rest.dto.GrowSectionDTO;
import com.growhouse.rest.dto.GrowSectionDeviceCountDTO;
import com.growhouse.rest.entity.Device;
import com.growhouse.rest.entity.GrowSection;
import com.growhouse.rest.entity.GrowSectionDevice;
import com.growhouse.rest.services.IGlobalResponseService;
import com.growhouse.rest.services.IGrowSectionDeviceService;
import com.growhouse.rest.services.IGrowSectionService;

/**
 * @author dharita.chokshi
 *
 */
@Component
public class GrowSectionFacade {

	public static final Logger LOGGER = LoggerFactory.getLogger(GrowSectionFacade.class);

	@Autowired
	private IGrowSectionService growSectionService;

	@Autowired
	private IGrowSectionDeviceService growSectionDeviceService;
	
	@Autowired
	private IGlobalResponseService globalResponseService;
	
	@Autowired
	private ModelMapper modelMapper;

	public List<GrowSectionDTO> getActiveGrowSections() {
		List<GrowSectionDTO> growSectionDTOs = new ArrayList<>();
		List<GrowSection> growSections = growSectionService.getActiveGrowSections();
		convertGrowSectionToGrowSectionDTO(growSectionDTOs, growSections);
		return growSectionDTOs;
	}

	public List<GrowSectionDTO> getAllGrowSections() {
		List<GrowSectionDTO> growSectionDTOs = new ArrayList<>();
		List<GrowSection> growSections = growSectionService.getAllGrowSections();
		convertGrowSectionToGrowSectionDTO(growSectionDTOs, growSections);
		return growSectionDTOs;
	}

	public List<GrowSectionDTO> getGrowSectionsByGrowAreaId(int growAreaId) {
		List<GrowSectionDTO> growSectionDTOs = new ArrayList<>();
		List<GrowSection> growSections = growSectionService.getGrowSectionsByGrowAreaId(growAreaId);
		if (growSections != null && !growSections.isEmpty()) {
			List<GrowSection> activeGrowSection = growSections.stream().filter(gs -> gs.getGrowArea().isActive())
					.collect(Collectors.toList());
			convertGrowSectionToGrowSectionDTO(growSectionDTOs, activeGrowSection);
		}
		return growSectionDTOs;
	}

	public int getGrowSectionCountByGrowAreaId(int growAreaId) {
		int count = 0;
		List<GrowSection> growSections = growSectionService.getGrowSectionsByGrowAreaId(growAreaId);
		if (growSections != null && !growSections.isEmpty()) {
			count = growSections.stream().filter(gs -> gs.getGrowArea().isActive()).collect(Collectors.toList()).size();
		}
		return count;
	}

	public int getGrowSectionCountByGrowAreaIds(List<Integer> growAreaIdList) {
		return growSectionService.getGrowSectionRepository().countByIsActiveTrueAndGrowAreaIdIn(growAreaIdList);

	}

	public List<GrowSectionDTO> getGrowSectionsByContainerId(int containerId) {
		List<GrowSectionDTO> growSectionDTOs = new ArrayList<>();
		List<GrowSection> growSections = growSectionService.getActiveGrowSections();
		if (growSections != null && !growSections.isEmpty()) {
			List<GrowSection> activeGrowSection = growSections.stream()
					.filter(gs -> gs.getGrowArea().getContainer().getId() == containerId
							&& gs.getGrowArea().getContainer().isActive())
					.collect(Collectors.toList());
			convertGrowSectionToGrowSectionDTO(growSectionDTOs, activeGrowSection);
		}
		return growSectionDTOs;
	}

	public int getGrowSectionCountByContainerId(int containerId) {
		int count = 0;

		List<GrowSection> growSections = growSectionService.getActiveGrowSections();
		if (growSections != null && !growSections.isEmpty()) {
			count = growSections.stream().filter(gs -> gs.getGrowArea().getContainer().getId() == containerId
					&& gs.getGrowArea().getContainer().isActive()).collect(Collectors.toList()).size();
		}
		return count;
	}

	public List<GrowSectionDTO> getGrowSectionsByFacilityId(int facilityId) {
		List<GrowSectionDTO> growSectionDTOs = new ArrayList<>();
		List<GrowSection> growSections = growSectionService.getActiveGrowSections();
		if (growSections != null && !growSections.isEmpty()) {
			List<GrowSection> activeGrowSection = growSections.stream()
					.filter(gs -> gs.getGrowArea().getContainer().getFacility().getId() == facilityId
							&& gs.getGrowArea().getContainer().getFacility().isActive())
					.collect(Collectors.toList());
			convertGrowSectionToGrowSectionDTO(growSectionDTOs, activeGrowSection);
		}
		return growSectionDTOs;
	}

	public int getGrowSectionCountByFacilityId(int facilityId) {
		int count = 0;
		List<GrowSection> growSections = growSectionService.getActiveGrowSections();
		if (growSections != null && !growSections.isEmpty()) {
			count = growSections.stream()
					.filter(gs -> gs.getGrowArea().getContainer().getFacility().getId() == facilityId
							&& gs.getGrowArea().getContainer().getFacility().isActive())
					.collect(Collectors.toList()).size();
		}
		return count;
	}

	public GrowSectionDTO getGrowSectionById(int growSectionId) {
		GrowSectionDTO growSectionDTO = null;
		GrowSection growSection = growSectionService.getGrowSectionById(growSectionId);
		if (growSection != null) {
			if (!growSection.isActive())
				throw new HttpClientErrorException(HttpStatus.FORBIDDEN, "Grow section is inactive");

			growSectionDTO = convertEntityToDTO(growSection);
			List<GrowSectionDevice> growSectionDevices = growSectionDeviceService
					.getActiveByGrowSectionId(growSection.getId());
			if (growSectionDevices != null && !growSectionDevices.isEmpty()) {
				List<DeviceDTO> deviceDTOs = growSectionDevices.stream()
						.map(gsd -> modelMapper.map(gsd.getDevice(), DeviceDTO.class)).collect(Collectors.toList());
				growSectionDTO.setDevices(deviceDTOs);
			}
		}
		return growSectionDTO;
	}

	public GrowSectionDeviceCountDTO getGrowSectionDevicesCountByGrowSectionId(int growSectionId) {

		GrowSectionDeviceCountDTO growSectionDeviceCountDTO = new GrowSectionDeviceCountDTO();
		int count = growSectionDeviceService.countGrowSectionDevicesByGrowSectionId(growSectionId);
		growSectionDeviceCountDTO.setCount(count);
		return growSectionDeviceCountDTO;
	}

	public List<GrowSectionDTO> createGrowSection(List<GrowSectionDTO> requestedGrowSectionDTOs) {
		List<GrowSectionDTO> createdGrowSectionDTOs = new ArrayList<>();
		List<GrowSectionDevice> requestedGrowSectionDevices = new ArrayList<>();
		for (GrowSectionDTO requestedGrowSectionDTO : requestedGrowSectionDTOs) {
			GrowSection requestedGrowSection = convertDTOToEntity(requestedGrowSectionDTO);
			GrowSection createdGrowSection = growSectionService.createGrowSection(requestedGrowSection);
			createGrowSectionDeviceObject(requestedGrowSectionDevices, requestedGrowSectionDTO, createdGrowSection);
			GrowSectionDTO createdGrowSectionDTO = convertEntityToDTO(createdGrowSection);
			createdGrowSectionDTO.setDevices(requestedGrowSectionDTO.getDevices());
			createdGrowSectionDTOs.add(createdGrowSectionDTO);
		}
		growSectionDeviceService.createGrowSectionDevicesInBatch(requestedGrowSectionDevices);
		return createdGrowSectionDTOs;
	}

	public List<GrowSectionDTO> updateGrowSection(List<GrowSectionDTO> requestedGrowSectionDTOs) {
		List<GrowSectionDTO> createdGrowSectionDTOs = new ArrayList<>();
		List<GrowSectionDevice> requestedGrowSectionDevices = new ArrayList<>();
		List<GrowSectionDevice> growSectionDevicesToDelete = new ArrayList<>();

		for (GrowSectionDTO requestedGrowSectionDTO : requestedGrowSectionDTOs) {

			GrowSection existingGrowSection = growSectionService.getGrowSectionById(requestedGrowSectionDTO.getId());
			if (existingGrowSection == null)
				throw new HttpClientErrorException(HttpStatus.NOT_FOUND, "Grow section not found");

			if (!existingGrowSection.isActive())
				throw new HttpClientErrorException(HttpStatus.FORBIDDEN, "Grow section is inactive");

			GrowSection requestedGrowSection = convertDTOToEntity(requestedGrowSectionDTO);
			GrowSection updatedGrowSection = growSectionService.updateGrowSection(requestedGrowSection);

			createGrowSectionDeviceObject(requestedGrowSectionDevices, requestedGrowSectionDTO, updatedGrowSection);

			GrowSectionDTO createdGrowSectionDTO = convertEntityToDTO(updatedGrowSection);
			createdGrowSectionDTO.setDevices(requestedGrowSectionDTO.getDevices());
			createdGrowSectionDTOs.add(createdGrowSectionDTO);

			growSectionDevicesToDelete
					.addAll(growSectionDeviceService.getActiveByGrowSectionId(updatedGrowSection.getId()));
			
			globalResponseService.updateSectionNameBySectionId(requestedGrowSectionDTO.getId(),requestedGrowSectionDTO.getGrowSectionName());
		}

		growSectionDeviceService.deleteGrowSectionDevicesInBatch(growSectionDevicesToDelete);
		growSectionDeviceService.createGrowSectionDevicesInBatch(requestedGrowSectionDevices);
		return createdGrowSectionDTOs;
	}

	private void createGrowSectionDeviceObject(List<GrowSectionDevice> requestedGrowSectionDevices,
			GrowSectionDTO requestedGrowSectionDTO, GrowSection updatedGrowSection) {
		if (requestedGrowSectionDTO.getDevices() != null) {
			for (DeviceDTO deviceDTO : requestedGrowSectionDTO.getDevices()) {
				Device device = modelMapper.map(deviceDTO, Device.class);
				GrowSectionDevice growSectionDevice = new GrowSectionDevice();
				growSectionDevice.setGrowSection(updatedGrowSection);
				growSectionDevice.setDevice(device);
				requestedGrowSectionDevices.add(growSectionDevice);
			}
		}
	}

	public GrowSection deleteGrowSection(int growSectionId) {
		return growSectionService.deleteGrowSection(growSectionId);
	}

	public void deleteGrowSectionByGatewayId(int gatewayId) {
		growSectionService.deleteGrowSectionByGatewayId(gatewayId);
	}

	private GrowSectionDTO convertEntityToDTO(GrowSection growSection) {
		return modelMapper.map(growSection, GrowSectionDTO.class);
	}

	private GrowSection convertDTOToEntity(GrowSectionDTO growSectionDTO) {
		return modelMapper.map(growSectionDTO, GrowSection.class);
	}

	private void convertGrowSectionToGrowSectionDTO(List<GrowSectionDTO> growSectionDTOs,
			List<GrowSection> growSections) {

		if (growSections != null && !growSections.isEmpty()) {
			for (GrowSection growSection : growSections) {

				GrowSectionDTO growSectionDTO = convertEntityToDTO(growSection);
				List<GrowSectionDevice> growSectionDevices = growSectionDeviceService
						.getActiveByGrowSectionId(growSection.getId());
				if (growSectionDevices != null && !growSectionDevices.isEmpty()) {
					List<DeviceDTO> deviceDTOs = growSectionDevices.stream()
							.map(gsd -> modelMapper.map(gsd.getDevice(), DeviceDTO.class)).collect(Collectors.toList());
					growSectionDTO.setDevices(deviceDTOs);
				} else {
					growSectionDTO.setDevices(new ArrayList<>());
				}
				growSectionDTOs.add(growSectionDTO);
			}
		}
	}
}
