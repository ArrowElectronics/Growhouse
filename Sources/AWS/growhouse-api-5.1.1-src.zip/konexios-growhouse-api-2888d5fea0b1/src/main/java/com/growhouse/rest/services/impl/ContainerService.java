/**
 * 
 */
package com.growhouse.rest.services.impl;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;

import com.growhouse.rest.entity.Container;
import com.growhouse.rest.repository.ContainerRepository;
import com.growhouse.rest.services.IContainerService;


/**
 * @author dharita.chokshi
 *
 */
@Service
public class ContainerService implements IContainerService {

	@Autowired
	private ContainerRepository containerRepository;

	
	public List<Container> getActiveContainers() {
		return containerRepository.findByIsActiveTrue();
	}

	public List<Container> getActiveContainersByAccount(int accountId) {
		return containerRepository.findByAccountIdAndFacilityIsActiveTrueAndIsActiveTrueOrderByCreatedTimestampDesc(accountId);
	}

	public int getCountActiveContainer() {
		return containerRepository.countByIsActiveTrueAndFacilityIsActiveTrueAndAccountIsActiveTrue();
	}

	
	public List<Container> getAllContainers() {
		return containerRepository.findAll();
	}

	
	public List<Container> getContainersByFacilityId(int facilityId) {
	    return containerRepository.findByFacilityIdAndIsActiveTrueOrderByCreatedTimestampDesc(facilityId);
	}

	public int getCountOfContainersByFacilityId(int facilityId) {
		return containerRepository.countByFacilityIdAndIsActiveTrue(facilityId);
	}

	
	public Container getContainerById(int id) {
		Optional<Container> optional = containerRepository.findByIdAndIsActiveTrue(id);
		if (optional.isPresent()) {
			return optional.get();
		}
		return null;
	}

	
	public Container createContainer(Container container) {
		return containerRepository.save(container);
	}

	
	public List<Container> createContainersInBatch(List<Container> containers) {
		return containerRepository.saveAll(containers);
	}

	
	public Container updateContainer(Container container) {
		return containerRepository.save(container);
	}

	public Container deleteContainer(int id) {
		Container deletedContainer=null;
		Optional<Container> optional = containerRepository.findById(id);
		if (optional.isPresent() && optional.get().isActive()) {
			Container container = optional.get();
			container.setActive(false);
			deletedContainer = containerRepository.save(container);
		} else {
			throw new HttpClientErrorException(HttpStatus.NOT_FOUND, "Requested container not found");
		}
		return deletedContainer;
	}

	@Override
	public ContainerRepository getContainerRepository() {
		return containerRepository;
	}

	public Container getContainerByContainerName(String containerName,int accountId)
	{
		return containerRepository.findByContainerNameAndIsActiveTrueAndFacilityIsActiveTrueAndAccountId(containerName, accountId);
	}
}
