package com.growhouse.rest;

import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import java.io.File;
import java.io.IOException;

@SpringBootApplication
@EnableCaching
@EnableAsync
@EnableScheduling
public class GrowHouseRestApiApplication {

	@Bean
	public ModelMapper modelMapper() {
		ModelMapper mapper = new ModelMapper();
		mapper.getConfiguration().setPropertyCondition(Conditions.isNotNull());
		return mapper;
	}

	@Bean
	public ObjectMapper objectMapper() {
		ObjectMapper objectMapper = new ObjectMapper();

		// support of Java 8 time
		objectMapper.registerModule(new JavaTimeModule());

		// ignore nanoseconds
		objectMapper.configure(SerializationFeature.WRITE_DATE_TIMESTAMPS_AS_NANOSECONDS, false);

		// serialize date/time as String
		objectMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);

		// ignore getters/setters
		objectMapper.getVisibilityChecker().withGetterVisibility(Visibility.NONE)
				.withIsGetterVisibility(Visibility.NONE).withSetterVisibility(Visibility.NONE);

		// ignore null properties
		objectMapper.setSerializationInclusion(Include.NON_NULL);

		// ignore unknown properties
		objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

		// turn off pretty-print
		objectMapper.configure(SerializationFeature.INDENT_OUTPUT, false);

		return objectMapper;
	}

	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}

	public static void main(String[] args) throws IOException {
		File filename = new File("gatewayHeartbeatConfig.txt"); 
		if (filename.exists()) {
            System.out.println("Exists");
		}else {
			filename.createNewFile();
            System.out.println("Does not Exists so created new");} 
		SpringApplication.run(GrowHouseRestApiApplication.class, args);
	}
}
