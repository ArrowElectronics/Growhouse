package com.growhouse.rest.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "global_response_payload")
public class GlobalResponsePayload implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3762324729214932771L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "container_id")
	private String containerId;

	@Column(name = "facility_id")
	private String facilityId;

	@Column(name = "gateway_id")
	private String gatewayId;

	@Column(name = "gateway_name")
	private String gatewayName;

	@Column(name = "container_name")
	private String containerName;

	@Column(name = "facility_name")
	private String facilityName;

	@Column(name = "profile_id")
	private Integer profileId;
	
	@Column(name = "profile_name")
	private String profileName;
	
	@Column(name = "grow_section_id")
	private String growSectionId;
	
	public String getGrowSectionId() {
		return growSectionId;
	}

	public void setGrowSectionId(String growSectionId) {
		this.growSectionId = growSectionId;
	}

	public String getGrowSectionName() {
		return growSectionName;
	}

	public void setGrowSectionName(String growSectionName) {
		this.growSectionName = growSectionName;
	}

	@Column(name = "grow_section_name")
	private String growSectionName;
	
		

	public Integer getProfileId() {
		return profileId;
	}

	public void setProfileId(Integer profileId) {
		this.profileId = profileId;
	}

	public String getProfileName() {
		return profileName;
	}

	public void setProfileName(String profileName) {
		this.profileName = profileName;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}


	public String getGatewayName() {
		return gatewayName;
	}

	public void setGatewayName(String gatewayName) {
		this.gatewayName = gatewayName;
	}

	public String getContainerName() {
		return containerName;
	}

	public void setContainerName(String containerName) {
		this.containerName = containerName;
	}

	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public String getContainerId() {
		return containerId;
	}

	public void setContainerId(String containerId) {
		this.containerId = containerId;
	}

	public String getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(String facilityId) {
		this.facilityId = facilityId;
	}

	public String getGatewayId() {
		return gatewayId;
	}

	public void setGatewayId(String gatewayId) {
		this.gatewayId = gatewayId;
	}


	
	

}
