package com.growhouse.rest.dto.konexios;

import java.util.List;

public class ChangePasswordResponse extends BaseResponse {
    private List<String> errorMessages;

    public List<String> getErrorMessages() {
        return this.errorMessages;
    }

    public void setErrorMessages(List<String> errorMessages) {
        this.errorMessages = errorMessages;
    }
}