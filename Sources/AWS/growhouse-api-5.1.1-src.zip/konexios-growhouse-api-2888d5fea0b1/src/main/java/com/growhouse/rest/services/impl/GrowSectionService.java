/**
 * 
 */
package com.growhouse.rest.services.impl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;

import com.growhouse.rest.entity.GrowAreaAssignee;
import com.growhouse.rest.entity.GrowSection;
import com.growhouse.rest.entity.User;
import com.growhouse.rest.facade.ProfileFacade;
import com.growhouse.rest.repository.GrowSectionDeviceRepository;
import com.growhouse.rest.repository.GrowSectionRepository;
import com.growhouse.rest.services.IGrowAreaAssigneeService;
import com.growhouse.rest.services.IGrowSectionService;
import com.growhouse.rest.utils.Constants;


/**
 * @author dharita.chokshi
 *
 */
@Service
public class GrowSectionService implements IGrowSectionService {
	
	public static final Logger LOGGER = LoggerFactory.getLogger(GrowSectionService.class);


	@Autowired
	private GrowSectionRepository growSectionRepository;

	@Autowired
	private IGrowAreaAssigneeService growAreaAssigneeService;
	
	@Autowired
	private ProfileFacade profileFacade;
	
	@Autowired
	private GrowSectionDeviceRepository growSectionDeviceRepository;
	
	public List<GrowSection> getActiveGrowSections() {
		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		List<GrowAreaAssignee> growAreaAssignees = growAreaAssigneeService
		        .getAllGrowAreaAssigneesByUserId(user.getId());
		List<Integer> growAreaIdList = growAreaAssignees.stream()
		        .map(growAreaAssinee -> growAreaAssinee.getGrowArea().getId()).collect(Collectors.toList());
		if (growAreaIdList != null && !growAreaIdList.isEmpty()) {
			return growSectionRepository.findByIsActiveTrueAndGrowAreaIdIn(growAreaIdList);
		} else {
			throw new HttpClientErrorException(HttpStatus.NO_CONTENT, "this user have not access of any Grow Sections");
		}
	}

	
	public List<GrowSection> getAllGrowSections() {
		return growSectionRepository.findAll();
	}

	
	public List<GrowSection> getGrowSectionsByGrowAreaId(int growAreaId) {
		return growSectionRepository.findByGrowAreaIdAndIsActiveTrue(growAreaId);
	}

	
	public List<GrowSection> getGrowSectionsByContainerId(int containerId) {
		return growSectionRepository.findByGrowAreaIdAndIsActiveTrue(containerId);
	}

	
	public List<GrowSection> getGrowSectionsByFacilityId(int facilityId) {
		return growSectionRepository.findByGrowAreaIdAndIsActiveTrue(facilityId);
	}

	
	public GrowSection getGrowSectionById(int id) {
		Optional<GrowSection> optional = growSectionRepository.findById(id);
		return optional.isPresent() ? optional.get() : null;
	}

	
	public GrowSection createGrowSection(GrowSection growSection) {
		return growSectionRepository.save(growSection);
	}
	
	
	public List<GrowSection> createGrowSectionsInBatch(List<GrowSection> growSections) {
		return growSectionRepository.saveAll(growSections);
	}

	
	public GrowSection updateGrowSection(GrowSection growSection) {
		return growSectionRepository.save(growSection);
	}

	
	public GrowSection deleteGrowSection(int id) {
		 long thrityAgo = System.currentTimeMillis() - Constants.THRITY_MINUTES;
		GrowSection deletedGrowSection=null;
		Optional<GrowSection> optional = growSectionRepository.findById(id);
		if (optional.isPresent() && optional.get().isActive()) {
			GrowSection growSection = optional.get();
			if(growSection.getGrowArea().getLatestHeartbeat()<thrityAgo)
			{
				throw new HttpClientErrorException(HttpStatus.NOT_FOUND, "Failed to delete Grow Section as Gateway is currently out of network.");
			}
			growSection.setActive(false);
			int layout=growSection.getGrowArea().getLayout();
			layout=layout-1;
			growSection.getGrowArea().setLayout(layout);
			growSectionDeviceRepository.deleteDeviceSectionBySectionId(id);
			LOGGER.info("Growsection device dettached Successfully----{}",id);
			profileFacade.deleteProfileByGrowSectionId(id);
			LOGGER.info("Growsection Profiles deleted Successfully----{}",id);
			deletedGrowSection = growSectionRepository.save(growSection);
			LOGGER.info("Growsection deleted Successfully----{}",id);
		} else {
			throw new HttpClientErrorException(HttpStatus.NOT_FOUND, "Grow section not found");
		}
		return deletedGrowSection;
	}
	
	public void deleteGrowSectionByGatewayId(int gatewayId)
	{
		try {
		 growSectionRepository.deleteGrowSectionByGatewayId(gatewayId);
		}
		catch(HttpClientErrorException clientErrorException) 
		{
			throw new HttpClientErrorException(HttpStatus.NOT_FOUND,clientErrorException.getMessage());
		}
	}

	public List<GrowSection> getGrowSectionsByGrowAreaIdList(List<Integer> growAreaIdList) {
		return growSectionRepository.findByIsActiveTrueAndGrowAreaIdIn(growAreaIdList);
	}
	
	@Override
    public GrowSectionRepository getGrowSectionRepository() {
        return growSectionRepository;
    }
}
