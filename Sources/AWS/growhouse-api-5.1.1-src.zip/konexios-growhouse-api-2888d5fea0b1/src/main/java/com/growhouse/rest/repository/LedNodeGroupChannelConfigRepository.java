package com.growhouse.rest.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.growhouse.rest.entity.LedNodeGroupChannelConfiguration;

@Repository
public interface LedNodeGroupChannelConfigRepository extends JpaRepository<LedNodeGroupChannelConfiguration, Integer> {

	public List<LedNodeGroupChannelConfiguration> findByGrowAreaAndIsActiveTrueOrderByCreatedTimestampDesc(Integer gatewayId);
	
	public LedNodeGroupChannelConfiguration findByGrowAreaAndGroupNameAndIsActiveTrue(int growAreaId,String groupName);
	
}
