package com.growhouse.rest.dto;

public class ProfileSubDTO {

	private Integer id;
	private String command;
	private String deviceHid;
	private Integer messageExpiration;
	private ProfilePayloadDTO payload;
	private String profileName;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getCommand() {
		return command;
	}
	public void setCommand(String command) {
		this.command = command;
	}
	public String getDeviceHid() {
		return deviceHid;
	}
	public void setDeviceHid(String deviceHid) {
		this.deviceHid = deviceHid;
	}
	public Integer getMessageExpiration() {
		return messageExpiration;
	}
	public void setMessageExpiration(Integer messageExpiration) {
		this.messageExpiration = messageExpiration;
	}
	public ProfilePayloadDTO getPayload() {
		return payload;
	}
	public void setPayload(ProfilePayloadDTO payload) {
		this.payload = payload;
	}
	public String getProfileName() {
		return profileName;
	}
	public void setProfileName(String profileName) {
		this.profileName = profileName;
	}
	@Override
	public String toString() {
		return "ProfileSubDTO [id=" + id + ", command=" + command + ", deviceHid=" + deviceHid + ", messageExpiration="
				+ messageExpiration + ", payload=" + payload + ", profileName=" + profileName + "]";
	}
	
	
	
}
