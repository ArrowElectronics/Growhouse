package com.growhouse.rest.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.growhouse.rest.repository.GlobalResponseRepository;
import com.growhouse.rest.services.IGlobalResponseService;

@Service
public class GlobalResponseService  implements IGlobalResponseService{

	@Autowired
	private GlobalResponseRepository globalResponseRepository;
	
	@Override
	public GlobalResponseRepository getGlobalResponseRepository() {
		return globalResponseRepository;
	}

	public void updateSectionNameBySectionId(int id,String sectionName)
	{
		String sectionId=Integer.toString(id);
		globalResponseRepository.updateSectionNameBySectionId(sectionName, sectionId);
	}
}
