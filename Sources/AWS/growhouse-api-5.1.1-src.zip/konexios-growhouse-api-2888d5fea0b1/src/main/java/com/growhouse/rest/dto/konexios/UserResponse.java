package com.growhouse.rest.dto.konexios;

public class UserResponse extends BaseResponse {
    private User user;

    public User getUser() {
        return this.user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}