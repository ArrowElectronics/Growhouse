/**
 * 
 */
package com.growhouse.rest.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.growhouse.rest.entity.Country;
import com.growhouse.rest.repository.CountryRepository;
import com.growhouse.rest.services.ICountryService;

/**
 * @author dharita.chokshi
 *
 */
@Service
public class CountryService implements ICountryService {

	@Autowired
	private CountryRepository countryRepository;

	
	public List<Country> getAllCountries() {
		return countryRepository.findAll();
	}

}
