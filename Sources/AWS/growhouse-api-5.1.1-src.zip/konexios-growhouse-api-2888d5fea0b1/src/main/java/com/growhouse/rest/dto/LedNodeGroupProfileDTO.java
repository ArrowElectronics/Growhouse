package com.growhouse.rest.dto;

import com.fasterxml.jackson.annotation.JsonProperty;


public class LedNodeGroupProfileDTO {

	private Integer id;
	
	@JsonProperty("group_id")
	private Integer groupId;
	
	@JsonProperty("led_profile_name")
	private String ledProfileName;
	
	@JsonProperty("channel_configuration")
	private GroupChannelConfigurationDTO channelConfiguration;
	
	@JsonProperty("channel_values")
	private GroupChannelValuesDTO channelValues;
	
	private String description;
	
	private boolean status;
	
	private Integer preset;
	

	public Integer getPreset() {
		return preset;
	}

	public void setPreset(Integer preset) {
		this.preset = preset;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getGroupId() {
		return groupId;
	}

	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}

	public String getLedProfileName() {
		return ledProfileName;
	}

	public void setLedProfileName(String ledProfileName) {
		this.ledProfileName = ledProfileName;
	}

	public GroupChannelConfigurationDTO getChannelConfiguration() {
		return channelConfiguration;
	}

	public void setChannelConfiguration(GroupChannelConfigurationDTO channelConfiguration) {
		this.channelConfiguration = channelConfiguration;
	}

	public GroupChannelValuesDTO getChannelValues() {
		return channelValues;
	}

	public void setChannelValues(GroupChannelValuesDTO channelValues) {
		this.channelValues = channelValues;
	}
	
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	
	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "LedNodeGroupProfileDTO [id=" + id + ", groupId=" + groupId + ", ledProfileName=" + ledProfileName
				+ ", channelConfiguration=" + channelConfiguration + ", channelValues=" + channelValues
				+ ", description=" + description + ", status=" + status + ", preset=" + preset + "]";
	}


	

	
	
	
	
}
