/**
 * 
 */
package com.growhouse.rest.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;

import com.growhouse.rest.dto.DeviceDTO;
import com.growhouse.rest.dto.DevicePropertyByDeviceDTO;
import com.growhouse.rest.dto.DevicePropertyMappingDTO;
import com.growhouse.rest.dto.DeviceStatusDTO;
import com.growhouse.rest.dto.LedNodeChannelConfigurationDTO;
import com.growhouse.rest.dto.LedNodeHistoryDTO;
import com.growhouse.rest.dto.LedNodeProfileDTO;
import com.growhouse.rest.dto.OutofNetworkCountDTO;
import com.growhouse.rest.dto.TelemetryItemDTO;
import com.growhouse.rest.entity.Device;
import com.growhouse.rest.facade.DeviceFacade;
import com.growhouse.rest.response.ResponseMessage;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author dharita.chokshi
 *
 */

@RestController
@RequestMapping("/api/devices")
@Transactional
public class DeviceController {

	private static final Logger LOGGER = LogManager.getLogger(DeviceController.class);

	@Autowired
	private DeviceFacade deviceFacade;

	/*
	 * Query-- select grow_area_id from grow_area_assignee where user_id=? Select *
	 * from devices where grow_area_id in grow_area_ids_list and is_active=true
	 * 
	 */
	@GetMapping(value = "")
	@ApiOperation(value = "View list of active devices")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "List retrieved successfully"),
			@ApiResponse(code = 204, message = "Empty list") })
	public ResponseEntity<?> getActiveDevices() {
		ResponseEntity<?> responseEntity;
		try {
			List<DeviceDTO> devices = deviceFacade.getActiveDevices();
			if (devices == null || devices.isEmpty())
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(devices, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/* Query-- Select * from devices */
	@GetMapping(value = "/all")
	@ApiOperation(value = "View list of all (active and inactive) devices")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "List retrieved successfully"),
			@ApiResponse(code = 204, message = "Empty list.") })
	public ResponseEntity<?> getAllDevices() {
		ResponseEntity<?> responseEntity;
		try {
			List<DeviceDTO> devices = deviceFacade.getAllDevices();
			if (devices == null || devices.isEmpty())
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(devices, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/*
	 * Query-- Select * from devices where devices.grow_section_id=? and
	 * devices.is_active=true
	 */
	@GetMapping(value = "/growsection/{growSectionId}")
	@ApiOperation(value = "View list of devices based on growSectionId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "List retrieved successfully"),
			@ApiResponse(code = 204, message = "Empty list") })
	public ResponseEntity<?> getDevicesByGrowSectionId(@PathVariable("growSectionId") Integer growSectionId) {
		ResponseEntity<?> responseEntity;
		try {
			List<DeviceDTO> devices = deviceFacade.getDevicesByGrowSectionId(growSectionId);
			if (devices == null || devices.isEmpty())
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(devices, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/*
	 * Query-- Select * from devices where devices.grow_area_id=? and
	 * devices.is_active=true
	 */
	@GetMapping(value = "/growareas/{growAreaId}")
	@ApiOperation(value = "View list of devices based on growAreaId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "List retrieved successfully"),
			@ApiResponse(code = 204, message = "Empty list") })
	public ResponseEntity<List<DeviceDTO>> getDevicesByGrowAreaId(@PathVariable("growAreaId") Integer growAreaId) {
		ResponseEntity<List<DeviceDTO>> responseEntity;
		try {
			List<DeviceDTO> devices = deviceFacade.getDevicesByGrowAreaId(growAreaId);
			if (devices == null || devices.isEmpty())
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(devices, HttpStatus.OK);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/*
	 * Query-- Select * from devices where device_type_id=? and grow_area_id=? and
	 * is_active=?
	 */
	@GetMapping(value = "/growareas/{growAreaId}/devicetype/{deviceTypeId}")
	@ApiOperation(value = "View list of devices based on growAreaId and deviceTypeId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "List retrieved successfully"),
			@ApiResponse(code = 204, message = "Empty list") })
	public ResponseEntity<List<DeviceDTO>> getDevicesByDeviceTypeByGrowAreaId(
			@PathVariable("growAreaId") Integer growAreaId, @PathVariable("deviceTypeId") Integer deviceTypeId) {
		ResponseEntity<List<DeviceDTO>> responseEntity;
		try {
			List<DeviceDTO> devices = deviceFacade.getDevicesByGrowAreaIdAndDeviceTypeId(growAreaId, deviceTypeId);
			if (devices == null || devices.isEmpty())
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(devices, HttpStatus.OK);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/*
	 * Query-- Select grow_area_id from grow_area_assignee where user_id=? and
	 * container_id=? Select * from devices where grow_area_id in grow_area_id_list
	 */
	@GetMapping(value = "/containers/{containerId}")
	@ApiOperation(value = "View list of devices based on containerId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "List retrieved successfully"),
			@ApiResponse(code = 204, message = "Empty list") })
	public ResponseEntity<List<DeviceDTO>> getDevicesByContainerId(@PathVariable("containerId") Integer containerId) {
		ResponseEntity<List<DeviceDTO>> responseEntity;
		try {
			List<DeviceDTO> devices = deviceFacade.getDevicesByContainerId(containerId);
			if (devices == null || devices.isEmpty())
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(devices, HttpStatus.OK);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/*
	 * Query-- Select grow_area_id from grow_area_assignee where user_id=? and
	 * facility_id=? Select * from devices where grow_area_id in grow_area_id_list
	 */
	@GetMapping(value = "/facilities/{facilityId}")
	@ApiOperation(value = "View list of devices based on facilityId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "List retrieved successfully"),
			@ApiResponse(code = 204, message = "Empty list") })
	public ResponseEntity<List<DeviceDTO>> getDevicesByFacilityId(@PathVariable("facilityId") Integer facilityId) {
		ResponseEntity<List<DeviceDTO>> responseEntity;
		try {
			List<DeviceDTO> devices = deviceFacade.getDevicesByFacilityId(facilityId);
			if (devices == null || devices.isEmpty())
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(devices, HttpStatus.OK);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/* Query-- Select * from device_types where devie_type_name=? */
	@GetMapping(value = "/devicetype/{devicetype}")
	@ApiOperation(value = "View list of devices based on devicetype")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "List retrieved successfully"),
			@ApiResponse(code = 204, message = "Empty list") })
	public ResponseEntity<?> getDevicesByDeviceType(@PathVariable("devicetype") String devicetype) {
		ResponseEntity<?> responseEntity;
		try {
			List<DeviceDTO> devices = deviceFacade.getDevicesByDeviceType(devicetype);
			if (devices == null || devices.isEmpty())
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(devices, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/* Query-- Select * from devices where device_id=? */
	@GetMapping(value = "/{deviceId}")
	@ApiOperation(value = "View grow section based on deviceId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Device retrieved successfully"),
			@ApiResponse(code = 403, message = "Device is inactive") })
	public ResponseEntity<?> getDeviceByDeviceId(@PathVariable("deviceId") Integer deviceId) {
		ResponseEntity<?> responseEntity;
		try {
			DeviceDTO devices = deviceFacade.getDeviceById(deviceId);
			if (devices == null)
				responseEntity = new ResponseEntity<>("Device not found", HttpStatus.NOT_FOUND);
			else
				responseEntity = new ResponseEntity<>(devices, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@PostMapping(value = "", consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Create new Device")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Device created successfully"),
			@ApiResponse(code = 400, message = "Bad Request") })
	public ResponseEntity<?> createDevice(@RequestBody DeviceDTO deviceDTO) {
		ResponseEntity<?> responseEntity;
		try {
			LOGGER.info("Requested deviceDTO: {}" + deviceDTO);
			DeviceDTO createdDeviceDTO = deviceFacade.createDevice(deviceDTO);
			if (createdDeviceDTO == null) {
				ResponseMessage responseMessage = new ResponseMessage();
				responseMessage.setMessage("Error occured while creating device");
				responseEntity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			} else {
				responseEntity = new ResponseEntity<>(createdDeviceDTO, HttpStatus.CREATED);
			}
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
			LOGGER.info("Exception occured in create device: {}" + httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
			LOGGER.info("Exception occured in create device: {}" + e);
		}
		return responseEntity;
	}

	@PutMapping(value = "/{deviceId}")
	@ApiOperation(value = "Update existing grow section")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Device updated successfully"),
			@ApiResponse(code = 400, message = "Bad Request"), @ApiResponse(code = 403, message = "Device is inactive"),
			@ApiResponse(code = 404, message = "Device not found"),
			@ApiResponse(code = 406, message = "DeviceId in URL doesnot match with deviceId of Device object") })
	public ResponseEntity<?> updateDevice(@PathVariable("deviceId") Integer deviceId,
			@RequestBody DeviceDTO deviceDTO) {
		ResponseEntity<?> responseEntity;
		try {
			DeviceDTO updatedDevices = deviceFacade.updateDevice(deviceId, deviceDTO);
			if (updatedDevices == null) {
				ResponseMessage responseMessage = new ResponseMessage();
				responseMessage.setMessage("Error occured while updating device.");
				responseEntity = new ResponseEntity<>(responseMessage, HttpStatus.BAD_REQUEST);
			} else {
				responseEntity = new ResponseEntity<>(deviceDTO, HttpStatus.OK);
			}
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/* Query-- Update devices SET is_active=false where device_id=? */
	@DeleteMapping(value = "/{deviceId}")
	@ApiOperation(value = "Delete Device by deviceId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Device deleted successfully") })
	public ResponseEntity<ResponseMessage> deleteDevice(@PathVariable("deviceId") Integer deviceId) {
		ResponseEntity<ResponseMessage> responseEntity;
		ResponseMessage responseMessage = new ResponseMessage();
		try {
			Device deletedDevice = deviceFacade.deleteDevice(deviceId);
			if (deletedDevice != null) {
				responseMessage.setMessage("Device deleted successfully");
				responseEntity = new ResponseEntity<>(responseMessage, HttpStatus.OK);
			} else {
				responseMessage.setMessage("Device is not deleted on GrowHouse Portal.");
				responseEntity = new ResponseEntity<>(responseMessage, HttpStatus.BAD_REQUEST);
			}
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
			LOGGER.info("Exception occured in deleting device: {}" + httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
			LOGGER.info("Exception occured in deleting device: {}" + e);
		}
		return responseEntity;
	}

	/* Query-- In this Function Use Arrow connect API */
	@GetMapping(value = "/properties/device/{deviceId}")
	@ApiOperation(value = "View device properties based on deviceId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Device retrieved successfully"),
			@ApiResponse(code = 403, message = "Device is inactive") })
	public ResponseEntity<?> getDevicePropertiesByDeviceId(@PathVariable("deviceId") Integer deviceId) {
		ResponseEntity<?> responseEntity;
		try {
			List<DevicePropertyByDeviceDTO> devices = deviceFacade.getDevicePropertiesByDeviceId(deviceId);
			if (devices == null || devices.isEmpty())
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(devices, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/*
	 * Query-- Select device_id from grow_section_device where grow_section_id=?
	 * call Arrow connect query
	 */
	@GetMapping(value = "/properties/growSection/{growSectionId}")
	@ApiOperation(value = "View device properties based on growSectionId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Device retrieved successfully"),
			@ApiResponse(code = 403, message = "Device is inactive") })
	public ResponseEntity<?> getDevicePropertiesByGrowSectionId(@PathVariable("growSectionId") Integer growSectionId) {
		ResponseEntity<?> responseEntity;
		try {
			List<DevicePropertyMappingDTO> devices = deviceFacade.getDevicePropertiesByGrowSectionId(growSectionId);
			if (devices == null || devices.isEmpty())
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(devices, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/*
	 * Query-- Select device_id from devices where grow_area_id=? call Arrow connect
	 * query
	 */
	@GetMapping(value = "/properties/growarea/{growareaId}")
	@ApiOperation(value = "View device properties based on growAreaId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Device retrieved successfully"),
			@ApiResponse(code = 403, message = "Device is inactive") })
	public ResponseEntity<?> getDevicePropertiesByGrowAreaId(@PathVariable("growareaId") Integer growareaId) {
		ResponseEntity<?> responseEntity;
		try {
			List<DevicePropertyMappingDTO> devices = deviceFacade.getDevicePropertiesByGrowAreaId(growareaId);
			if (devices == null)
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(devices, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/* call arrow connect API */
	@GetMapping(value = "/{deviceHId}/telemtry/last")
	@ApiOperation(value = "Get last telemtry of device")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Telemetries retrived successfully") })
	public ResponseEntity<?> getDeviceLastTelemetry(@PathVariable("deviceHId") String deviceHId) {
		ResponseEntity<?> responseEntity;
		try {
			List<TelemetryItemDTO> telemetries = deviceFacade.getDeviceLastTelemetry(deviceHId);
			if (telemetries != null) {
				responseEntity = new ResponseEntity<>(telemetries, HttpStatus.OK);
			} else {
				responseEntity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			}
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception exception) {
			responseEntity = new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		return responseEntity;
	}

	@PostMapping(value = "/lednodevalue/history")
	@ApiOperation(value = "Post LED node desired value")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Value set successfully") })
	public ResponseEntity<?> postLedNodeDesiredValue(@RequestBody LedNodeHistoryDTO ledNodeHistoryDTO) {
		ResponseEntity<?> responseEntity;
		try {
			Assert.notNull(ledNodeHistoryDTO.getCh1(), "Channel 1 value Must need to provide");
			Assert.notNull(ledNodeHistoryDTO.getCh2(), "Channel 2 value Must need to provide");
			Assert.notNull(ledNodeHistoryDTO.getCh3(), "Channel 3 value Must need to provide");
			Assert.notNull(ledNodeHistoryDTO.getCh4(), "Channel 4 value Must need to provide");
			Assert.notNull(ledNodeHistoryDTO.getCh5(), "Channel 5 value Must need to provide");
			Assert.notNull(ledNodeHistoryDTO.getCh6(), "Channel 6 value Must need to provide");
			LedNodeHistoryDTO createdLedNodeHistoryDTO = deviceFacade.setLedNodeDesiredvalue(ledNodeHistoryDTO);
			if (createdLedNodeHistoryDTO != null) {
				responseEntity = new ResponseEntity<>(createdLedNodeHistoryDTO, HttpStatus.OK);
			} else {
				responseEntity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			}
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception exception) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/* Select * from lednode_channel_configuration where device_id=? */
	@GetMapping(value = "/lednode/{deviceId}/channelconfiguration")
	@ApiOperation(value = "Get Led Node Channel configurations")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Led Node channel configuration retrived successfully") })
	public ResponseEntity<?> getLedNodeChannelConfiguration(@PathVariable("deviceId") Integer deviceId) {
		ResponseEntity<?> responseEntity;
		try {
			LedNodeChannelConfigurationDTO ledNodeChannelConfigurationDTO = deviceFacade
					.getLedNodeChannelConfig(deviceId);
			if (ledNodeChannelConfigurationDTO != null) {
				responseEntity = new ResponseEntity<>(ledNodeChannelConfigurationDTO, HttpStatus.OK);
			} else {
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception exception) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@PostMapping(value = "/lednode/profile")
	@ApiOperation(value = "Create LED node profile")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Value set successfully") })
	public ResponseEntity<?> postLedNodeProfile(@RequestBody LedNodeProfileDTO ledNodeProfileDTO) {
		ResponseEntity<?> responseEntity;
		try {
			LedNodeProfileDTO createdLedNodeprofileDTO = deviceFacade.setLedNodeProfile(ledNodeProfileDTO);
			if (createdLedNodeprofileDTO != null) {
				responseEntity = new ResponseEntity<>(createdLedNodeprofileDTO, HttpStatus.OK);
			} else {
				responseEntity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			}
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception exception) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/* Select * from led_node_profile where device_id=? */
	@GetMapping(value = "/lednode/{deviceId}/profile")
	@ApiOperation(value = "Get Led Node Profiles")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Led Node profile retrived successfully") })
	public ResponseEntity<?> getLedNodeProfile(@PathVariable("deviceId") Integer deviceId) {
		ResponseEntity<?> responseEntity;
		try {
			List<LedNodeProfileDTO> ledNodeProfileDTO = deviceFacade.getLedNodeProfile(deviceId);
			if (ledNodeProfileDTO != null && !ledNodeProfileDTO.isEmpty()) {
				responseEntity = new ResponseEntity<>(ledNodeProfileDTO, HttpStatus.OK);
			} else {
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception exception) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@DeleteMapping(value = "/lednode/profile/{profileId}")
	@ApiOperation(value = "Delete LedNode profile by profileId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Deleted LedNode Profile successfully") })
	public ResponseEntity<?> deleteLedProfileById(@PathVariable("profileId") Integer profileId) {
		ResponseEntity<?> responseEntity;
		try {
			deviceFacade.deleteLedProfileById(profileId);
			responseEntity = new ResponseEntity<>(HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception exception) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@DeleteMapping(value = "/propertyMapping/{deviceId}")
	@ApiOperation(value = "Delete Device Property Mapping by deviceId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Deleted Device property successfully") })
	public ResponseEntity<?> deleteDevicePropertyMapping(@PathVariable("deviceId") Integer deviceId) {
		ResponseEntity<?> responseEntity;
		try {
			deviceFacade.deleteDevicePropertyMapping(deviceId);
			responseEntity = new ResponseEntity<>(HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception exception) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@DeleteMapping(value = "/propertyMapping/gateway/{gatewayId}")
	@ApiOperation(value = "Delete Device Property Mapping by gatewayId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Deleted Device property successfully") })
	public ResponseEntity<?> deleteDevicePropertyMappingByGatewayId(@PathVariable("gatewayId") Integer gatewayId) {
		ResponseEntity<?> responseEntity;
		try {
			deviceFacade.deleteDevicePropertyMappingByGatewayId(gatewayId);
			responseEntity = new ResponseEntity<>(HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception exception) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@DeleteMapping(value = "/ledNode/Profile/{deviceId}")
	@ApiOperation(value = "Delete LedNode Profile by device Id")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Deleted LedNode Profile successfully") })
	public ResponseEntity<?> deleteLedNodeProfile(@PathVariable("deviceId") Integer deviceId) {
		ResponseEntity<?> responseEntity;
		try {
			deviceFacade.deleteLedNodeProfile(deviceId);
			responseEntity = new ResponseEntity<>(HttpStatus.OK);

		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception exception) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return responseEntity;
	}

	@DeleteMapping(value = "/ledNode/Profile/gateway/{gatewayId}")
	@ApiOperation(value = "Delete LedNode Profile by gatewayId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Deleted LedNode Profile successfully") })
	public ResponseEntity<?> deleteLedNodeProfileByGatewayId(@PathVariable("gatewayId") Integer gatewayId) {
		ResponseEntity<?> responseEntity;
		try {
			deviceFacade.deleteLedNodeProfileByGatewayID(gatewayId);
			responseEntity = new ResponseEntity<>(HttpStatus.OK);

		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception exception) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return responseEntity;
	}

	@DeleteMapping(value = "/ledNode/desiredValue/{deviceId}")
	@ApiOperation(value = "Delete LedNode Desired Values by deviceId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Deleted LedNode Desired Value successfully") })
	public ResponseEntity<?> deleteLedNodeDesiredValue(@PathVariable("deviceId") Integer deviceId) {
		ResponseEntity<?> responseEntity;
		try {
			deviceFacade.deleteLedNodeDesiredValue(deviceId);
			responseEntity = new ResponseEntity<>(HttpStatus.OK);

		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception exception) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return responseEntity;
	}

	@DeleteMapping(value = "/ledNode/desiredValue/gateway/{gatewayId}")
	@ApiOperation(value = "Delete LedNode Desired Values by gatewayId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Deleted LedNode Desired Value successfully") })
	public ResponseEntity<?> deleteLedNodeDesiredValueByGatewayId(@PathVariable("gatewayId") Integer gatewayId) {
		ResponseEntity<?> responseEntity;
		try {
			deviceFacade.deleteLedNodeDesiredValueByGatewayId(gatewayId);
			responseEntity = new ResponseEntity<>(HttpStatus.OK);

		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception exception) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return responseEntity;
	}

	@DeleteMapping(value = "/ledNode/channelConfig/{deviceId}")
	@ApiOperation(value = "Delete LedNode Channel Configuration Values by deviceId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Deleted LedNode Channel Configuration successfully") })
	public ResponseEntity<?> deleteLedNodeChannelConfigurationValue(@PathVariable("deviceId") Integer deviceId) {
		ResponseEntity<?> responseEntity;
		try {
			deviceFacade.deleteLedNodeChannelConfigurationValue(deviceId);
			responseEntity = new ResponseEntity<>(HttpStatus.OK);

		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception exception) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return responseEntity;
	}

	@DeleteMapping(value = "/ledNode/channelConfig/gateway/{gatewayId}")
	@ApiOperation(value = "Delete LedNode Channel Configuration Values by gatewayId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Deleted LedNode Channel Configuration successfully") })
	public ResponseEntity<?> deleteLedNodeChannelConfigurationValueByGatewayId(
			@PathVariable("gatewayId") Integer gatewayId) {
		ResponseEntity<?> responseEntity;
		try {
			deviceFacade.deleteLedNodeChannelConfigurationValueBygatewayId(gatewayId);
			responseEntity = new ResponseEntity<>(HttpStatus.OK);

		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception exception) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return responseEntity;
	}

	@DeleteMapping(value = "/section/{deviceId}")
	@ApiOperation(value = "Delete Devices From Section")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Deleted Device from section successfully") })
	public ResponseEntity<?> deleteDeviceSection(@PathVariable("deviceId") Integer deviceId) {
		ResponseEntity<?> responseEntity;
		try {
			deviceFacade.deleteSectionDevices(deviceId);
			responseEntity = new ResponseEntity<>(HttpStatus.OK);

		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception exception) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return responseEntity;
	}

	@DeleteMapping(value = "/section/gateway/{gatewayId}")
	@ApiOperation(value = "Delete Devices From Section by gatewayId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Deleted Device from section successfully") })
	public ResponseEntity<?> deleteDeviceSectionList(@PathVariable("gatewayId") Integer gatewayId) {
		ResponseEntity<?> responseEntity;
		try {
			deviceFacade.deleteSectionDevicesList(gatewayId);
			responseEntity = new ResponseEntity<>(HttpStatus.OK);

		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception exception) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return responseEntity;
	}

	@DeleteMapping(value = "/gateway/{gatewayId}")
	@ApiOperation(value = "Delete Devices From gateway by gatewayId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Deleted Device from Gateway successfully") })
	public ResponseEntity<?> deleteDeviceListFromGateway(@PathVariable("gatewayId") Integer gatewayId) {
		ResponseEntity<?> responseEntity;
		ResponseMessage responseMessage = new ResponseMessage();
		try {
			deviceFacade.deleteGrowAreaDevices(gatewayId);
			responseEntity = new ResponseEntity<>(HttpStatus.OK);

		} catch (HttpClientErrorException httpClientErrorException) {
			responseMessage.setMessage("Device is not available on Arrow Portal");
			responseEntity = new ResponseEntity<>(responseMessage, HttpStatus.NOT_FOUND);
		} catch (Exception exception) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return responseEntity;
	}

	@PutMapping(value = "/status/gateway/{growAreaHId}")
	@ApiOperation(value = "Update latest status of devices")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Latest status of devices updated successfully") })
	public ResponseEntity<ResponseMessage> updateDeviceHeartbeat(@RequestBody List<DeviceStatusDTO> payload,
			@PathVariable("growAreaHId") String growAreaHId) {
		ResponseEntity<ResponseMessage> responseEntity;
		try {

			deviceFacade.updateDeviceLatestStatus(payload, growAreaHId);
			ResponseMessage responseMessage = new ResponseMessage();
			responseMessage.setMessage("Devices latest status updated successfully");
			responseEntity = new ResponseEntity<>(responseMessage, HttpStatus.OK);

		} catch (HttpClientErrorException httpClientErrorException) {
			LOGGER.info("exception occured in update device status:", httpClientErrorException);
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			LOGGER.info("exception occured in update device status:", e);
			responseEntity = new ResponseEntity<>(HttpStatus.OK);
		}
		return responseEntity;

	}

	@GetMapping(value = "/count/outofnetwork/{gatewayId}")
	@ApiOperation(value = "Get Led Node Profiles")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Out of network device count fetched successfully") })
	public ResponseEntity<?> getOutOfNetworkDeviceCountByGateway(@PathVariable("gatewayId") int gatewayId) {
		ResponseEntity<?> responseEntity;
		try {
			OutofNetworkCountDTO outofNetworkCountDTO = deviceFacade.getcountOutOfNetworkDevicesByGrowarea(gatewayId);
			responseEntity = new ResponseEntity<>(outofNetworkCountDTO, HttpStatus.OK);

		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception exception) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@GetMapping(value = "/count/outofnetwork/{gatewayId}/{deviceType}")
	@ApiOperation(value = "Get Led Node Profiles")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Out of network device count fetched successfully") })
	public ResponseEntity<?> getOutOfNetworkDeviceCountByGatewayAndType(@PathVariable("gatewayId") int gatewayId,
			@PathVariable("deviceType") int deviceType) {
		ResponseEntity<?> responseEntity;
		try {
			OutofNetworkCountDTO outofNetworkCountDTO = deviceFacade
					.getcountOutOfNetworkDevicesByGrowareaAndType(gatewayId, deviceType);
			responseEntity = new ResponseEntity<>(outofNetworkCountDTO, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception exception) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/**
	 * @param httpClientErrorException
	 * @return
	 */
	private ResponseEntity<ResponseMessage> setResponseMessage(HttpClientErrorException httpClientErrorException) {
		ResponseMessage responseMessage = new ResponseMessage();
		responseMessage.setMessage(httpClientErrorException.getStatusText());
		return new ResponseEntity<>(responseMessage, httpClientErrorException.getStatusCode());
	}

}
