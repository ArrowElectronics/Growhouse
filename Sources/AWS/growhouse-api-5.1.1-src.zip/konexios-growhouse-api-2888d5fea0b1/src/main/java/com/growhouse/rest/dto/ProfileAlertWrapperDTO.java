package com.growhouse.rest.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ProfileAlertWrapperDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 938591176425407519L;
	
	private ProfileAlertDTO telemetry;

	public ProfileAlertDTO getTelemetry() {
		return telemetry;
	}

	public void setTelemetry(ProfileAlertDTO telemetry) {
		this.telemetry = telemetry;
	}

}
