package com.growhouse.rest.facade;


import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.growhouse.rest.controller.CountController;
import com.growhouse.rest.dto.CountDTO;
import com.growhouse.rest.dto.DashBoardDTO;
import com.growhouse.rest.dto.DeviceDTO;

@Component
public class CountFacade {
	
	@Autowired
	private DeviceFacade deviceFacade;
	
	@Autowired
	private CountController countController;
	
	@Autowired
	private GrowAreaFacade growAreaFacade;
	
	public List<DashBoardDTO> getDevicesByGrowAreaId(List<DashBoardDTO> growAreas)
	
	{  
		return growAreas.stream().map(growArea ->{
			 CountDTO countDetails = new CountDTO();
			   DashBoardDTO dashBoardDTO=new DashBoardDTO();
			   dashBoardDTO.setId(growArea.getId());
			   dashBoardDTO.setFacility(growArea.getFacility());
			   dashBoardDTO.setContainer(growArea.getContainer());
			   dashBoardDTO.setGrowAreaName(growArea.getGrowAreaName());
				List<DeviceDTO> deviceDTOs=deviceFacade.getDevicesByGrowAreaId(growArea.getId());
				if (deviceDTOs != null && !deviceDTOs.isEmpty()) {
					countController.setDeviceByTypeCount(countDetails, deviceDTOs);
					dashBoardDTO.setDeviceCountDTO(countDetails.getDevicesCount());
				} else {
					countController.setDefaultCountDetails(countDetails);
					dashBoardDTO.setDeviceCountDTO(countDetails.getDevicesCount());
				}
				return dashBoardDTO;
		}).collect(Collectors.toList());
	  
	}

	
	public List<DashBoardDTO> getGrowAreaByUserId()
	{
		 
		return growAreaFacade.getActiveGrowAreasForDashboard();
	
	}
	
}
