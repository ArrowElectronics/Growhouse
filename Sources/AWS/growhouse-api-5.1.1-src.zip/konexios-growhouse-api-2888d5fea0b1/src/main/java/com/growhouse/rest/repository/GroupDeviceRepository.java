/**
 * 
 */
package com.growhouse.rest.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.growhouse.rest.entity.GroupDevice;

/**
 * @author dharita.chokshi
 *
 */
@Repository
public interface GroupDeviceRepository extends JpaRepository<GroupDevice, Integer> {

	@Transactional
    @Modifying   
    @Query(value="DELETE FROM led_group_device where group_id =?1 and is_active=1",nativeQuery = true)
	public void deleteGroupDevicesByGroupId(int groupId);
	
	@Transactional
    @Modifying
    @Query(value="Update led_group_device p SET p.is_active=0 where p.group_id =?1",nativeQuery = true)
	public void updateGroupDevicesByGroupId(int groupId);
	
	public List<GroupDevice> findByGroupIdAndIsActiveTrue(int groupId);
	
	@Transactional
    @Modifying
    @Query(value="Update led_group_device p SET p.is_active=0 where p.device_id =?1",nativeQuery = true)
	public void deleteGroupDevicesByDeviceId(int deviceId);
}
