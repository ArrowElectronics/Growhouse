package com.growhouse.rest.utils;

public enum Command {

	createRule,deleteRule,led_intensity,deleteDevice,updateRule,deleteGateway;
}

