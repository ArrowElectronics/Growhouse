package com.growhouse.rest.dto.konexios;

public class CreateUserResponse extends UserResponse {
}