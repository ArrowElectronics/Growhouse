package com.growhouse.rest.dto.konexios;

public class ResetPasswordRequest {
    private boolean sendEmail;
    private String resetPasswordUrl;

    public ResetPasswordRequest sendEmail(boolean sendEmail) {
        this.sendEmail = sendEmail;
        return this;
    }

    public ResetPasswordRequest resetPasswordUrl(String resetPasswordUrl) {
        this.resetPasswordUrl = resetPasswordUrl;
        return this;
    }

    public boolean isSendEmail() {
        return this.sendEmail;
    }

    public boolean getSendEmail() {
        return this.sendEmail;
    }

    public void setSendEmail(boolean sendEmail) {
        this.sendEmail = sendEmail;
    }

    public String getResetPasswordUrl() {
        return this.resetPasswordUrl;
    }

    public void setResetPasswordUrl(String resetPasswordUrl) {
        this.resetPasswordUrl = resetPasswordUrl;
    }
}