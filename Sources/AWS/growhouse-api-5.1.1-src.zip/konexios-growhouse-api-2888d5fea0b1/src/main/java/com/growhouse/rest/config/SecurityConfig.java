package com.growhouse.rest.config;

import java.util.Arrays;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.growhouse.rest.filter.CustomAuthorizationFilter;
import com.growhouse.rest.services.impl.UserService;

@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true, securedEnabled = true)
public class SecurityConfig extends WebSecurityConfigurerAdapter {

	@Autowired
	private UserService userService;
	@Autowired
	private StringRedisTemplate redis;
	@Autowired
	private ObjectMapper mapper;

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		CustomAuthorizationFilter customAuthorizationFilter = new CustomAuthorizationFilter(authenticationManager());
		customAuthorizationFilter.setUserService(userService);
		customAuthorizationFilter.setRedis(redis);
		customAuthorizationFilter.setMapper(mapper);
		http.csrf().disable().cors().and().authorizeRequests().anyRequest().authenticated().and()
				.addFilter(customAuthorizationFilter);
	}

	@Override
	public void configure(WebSecurity web) throws Exception {
		web.ignoring().antMatchers("/v2/api-docs", "/configuration/ui", "/swagger-resources", "/configuration/security",
				"/swagger-ui.html", "/webjars/**", "/api/growareas/heartbeat/**", "/api/devices/status/gateway/**",
				"/api/profile/alert/create", "/api/users/login", "/api/users/logout", "/api/users/*/reset-password",
				"/api/users/*/change-password");
	}

	@Bean
	public WebMvcConfigurer corsConfigurer() {
		return new WebMvcConfigurer() {
			@Override
			public void addCorsMappings(CorsRegistry registry) {
				RequestMethod[] allMethods = RequestMethod.values();
				registry.addMapping("/api/**")
						.allowedMethods(Arrays.asList(allMethods).stream().map(RequestMethod::name)
								.collect(Collectors.toList()).toArray(new String[allMethods.length]))
						.allowedOrigins("*").allowedHeaders("*").allowCredentials(true);
			}
		};
	}
}