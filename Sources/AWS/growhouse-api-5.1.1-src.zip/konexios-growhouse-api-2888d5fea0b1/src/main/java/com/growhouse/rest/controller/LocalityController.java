/**
 * 
 */
package com.growhouse.rest.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpServerErrorException;

import com.growhouse.rest.dto.LocalityDTO;
import com.growhouse.rest.facade.LocalityFacade;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author dharita.chokshi
 *
 */

@RestController
@RequestMapping("/api/localities")
@Transactional
public class LocalityController {

	public static final Logger LOGGER = LoggerFactory.getLogger(LocalityController.class);

	@Autowired
	private LocalityFacade localityFacade;

	/* Query-- Select * from localities */
	@GetMapping(value = "")
	@ApiOperation(value = "View list of all localities")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "List retrieved successfully"),
			@ApiResponse(code = 204, message = "Empty list") })
	public ResponseEntity<List<LocalityDTO>> getAllLocalities() {
		ResponseEntity<List<LocalityDTO>> responseEntity;
		try {
			List<LocalityDTO> localityDTOs = localityFacade.getAllLocalities();
			if (localityDTOs == null || localityDTOs.isEmpty())
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(localityDTOs, HttpStatus.OK);
		} catch (Exception exception) {
			throw new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/* Query-- Select * from localities where state_id=? */
	@GetMapping(value = "/{stateId}")
	@ApiOperation(value = "View list of localities based on stateId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "List retrieved successfully"),
			@ApiResponse(code = 204, message = "Empty list") })
	public ResponseEntity<List<LocalityDTO>> getStatesByStateId(@PathVariable("stateId") Integer stateId) {
		ResponseEntity<List<LocalityDTO>> responseEntity;
		try {
			List<LocalityDTO> localityDTOs = localityFacade.getLocalitysByStateId(stateId);
			if (localityDTOs == null || localityDTOs.isEmpty())
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(localityDTOs, HttpStatus.OK);
		} catch (Exception exception) {
			throw new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

}
