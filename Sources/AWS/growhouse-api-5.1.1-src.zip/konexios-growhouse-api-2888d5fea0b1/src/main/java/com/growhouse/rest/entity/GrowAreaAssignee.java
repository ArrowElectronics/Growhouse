/**
 * 
 */
package com.growhouse.rest.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * @author dharita.chokshi
 *
 */
@Entity
@Table(name = "grow_area_assignee")
public class GrowAreaAssignee extends DefaultModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4706564946304327276L;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "grow_area_id")
	private GrowArea growArea;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "user_id")
	private User user;
	
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "facility_id")
	private Facility facility;
	
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "container_id")
	private Container container;

	public GrowArea getGrowArea() {
		return growArea;
	}

	public void setGrowArea(GrowArea growArea) {
		this.growArea = growArea;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Facility getFacility() {
		return facility;
	}

	public void setFacility(Facility facility) {
		this.facility = facility;
	}

	public Container getContainer() {
		return container;
	}

	public void setContainer(Container container) {
		this.container = container;
	}

	@Override
	public String toString() {
		return "GrowAreaAssignee [growArea=" + growArea + ", user=" + user + ", facility=" + facility + ", container="
		        + container + "]";
	}

	

}
