/**
 * 
 */
package com.growhouse.rest.services;

import java.util.List;

import com.growhouse.rest.entity.GrowAreaType;

/**
 * @author dharita.chokshi
 *
 */
public interface IGrowAreaTypeService {

	public List<GrowAreaType> getAllGrowAreaTypes();

	public GrowAreaType getGrowAreaTypeById(int growAreaTypeId);

}
