package com.growhouse.rest.dto;

public class GrowSectionDeviceCountDTO {

	
	private int count;

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	

	
}
