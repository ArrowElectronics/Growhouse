package com.growhouse.rest.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.growhouse.rest.entity.ProfileAlert;
import com.growhouse.rest.entity.ProfileAlertsUI;

@Repository
public interface ProfileAlertRepository extends JpaRepository<ProfileAlert, Integer> {
	
	@Query(value ="SELECT DISTINCT p.profile_id FROM profile_alerts p WHERE p.gateway_id IN ?1", nativeQuery = true)
	public List<Integer> findUniqueProfileIdByGatewayId(List<String> gatewayIds);
	
	@Query(value ="SELECT DISTINCT p.profile_id FROM profile_alerts p WHERE p.gateway_id IN ?1 and LOCATE(?2,p.alert_message)", nativeQuery = true)
	public List<Integer> findUniqueProfileIdByGatewayIdAndAlertMessage(List<String> gatewayIds,String alertMessage);
	
	
	@Query(value ="SELECT DISTINCT p.profile_id FROM profile_alerts p WHERE p.facility_id = ?1", nativeQuery = true)
	public List<Integer> findUniqueProfileIdByFacilityId(String facilityId);
	
	@Query(value ="SELECT DISTINCT p.profile_id FROM profile_alerts p WHERE p.container_id = ?1", nativeQuery = true)
	public List<Integer> findUniqueProfileIdByContainerId(String containerId);
	
	@Query(value ="SELECT DISTINCT p.profile_id FROM profile_alerts p WHERE p.gateway_id  = ?1", nativeQuery = true)
	public List<Integer> findUniqueProfileIdByGrowAreaId(String growAreaId);
	
	@Query(value ="SELECT DISTINCT p.profile_id FROM profile_alerts p WHERE p.grow_section_id = ?1", nativeQuery = true)
	public List<Integer> findUniqueProfileIdByGrowSectionId(String growSectionId);
	
	@Query(value ="SELECT * FROM profile_alerts p WHERE p.profile_id = ?1 ORDER BY timestamp DESC LIMIT 1",nativeQuery = true)	
	public ProfileAlert findProfileAlertUsingProfileId(Integer profileId);
	
	@Query(value ="SELECT pa.*, p.profile_name as profile_virtual_name FROM profile_alerts as pa \r\n" + 
			"join profile as p on pa.profile_id = p.id and pa.profile_id = 15 ORDER BY timestamp Limit 1",nativeQuery = true)
	public List<ProfileAlertsUI> test(Integer profileId);
	
	@Query(value ="SELECT * FROM profile_alerts p WHERE p.profile_id = ?1 AND p.timestamp > ?2 ORDER BY timestamp DESC ",nativeQuery = true)
	public List<ProfileAlert> findByProfileIdAndTimestampGreaterThan(Integer profileId,Long timestamp);

	@Query(value ="SELECT * FROM profile_alerts p WHERE p.profile_id = ?1 AND p.timestamp > ?2 and p.timestamp < ?3 ORDER BY timestamp DESC ",nativeQuery = true)
	public List<ProfileAlert> findProfileAlertsHistory(Integer profileId,long fromTimestamp,long toTimestamp);
	
	@Transactional
	@Modifying
	@Query(value="DELETE FROM profile_alerts where gateway_id=?1",nativeQuery = true)
    public void deleteProfileAlertsByGatewayId(String gatewayId);
	
	@Transactional
	@Modifying
	@Query(value="DELETE FROM profile_alerts where profile_id=?1",nativeQuery=true)
	public void deleteProfileAlertsByProfileId(int profileId);
}
