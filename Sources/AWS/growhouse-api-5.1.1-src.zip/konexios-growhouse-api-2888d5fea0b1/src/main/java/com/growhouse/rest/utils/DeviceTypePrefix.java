package com.growhouse.rest.utils;

public enum DeviceTypePrefix {
	
	SCMNode("SCM"), SoilNode("SN"), LightShield("LS"), LedNode("LN"), HumidityNode("HN");
	
	 String devicePrefixName;
	 DeviceTypePrefix(String devicePrefixName) {
		   this.devicePrefixName = devicePrefixName;
	   }
	   String showDevicePrefixValue() {
		   return devicePrefixName;
	   }

}
