/**
 * 
 */
package com.growhouse.rest.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author dharita.chokshi
 *
 */
public class AccountDTO {

	@JsonProperty("id")
	private Integer id;

	@JsonProperty("account_name")
	private String accountName;

	@JsonProperty("admin")
	private AdminDTO admin;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public AdminDTO getAdmin() {
		return admin;
	}

	public void setAdmin(AdminDTO admin) {
		this.admin = admin;
	}
}
