/**
 * 
 */
package com.growhouse.rest.facade;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;

import com.growhouse.rest.dto.ContainerTypeDTO;
import com.growhouse.rest.entity.ContainerType;
import com.growhouse.rest.services.IContainerTypeService;

/**
 * @author dharita.chokshi
 *
 */
@Component
public class ContainerTypeFacade {

	public static final Logger LOGGER = LoggerFactory.getLogger(ContainerTypeFacade.class);

	@Autowired
	private IContainerTypeService containerTypeService;

	@Autowired
	private ModelMapper modelMapper;

	public List<ContainerTypeDTO> getContainerTypes() {
		List<ContainerTypeDTO> containerTypeDTOs = new ArrayList<>();
		List<ContainerType> containerTypes = containerTypeService.getAllContainerTypes();
		if (containerTypes != null && !containerTypes.isEmpty()) {
			containerTypeDTOs = containerTypes.stream().map(this::convertEntityToDTO)
					.collect(Collectors.toList());
		}
		return containerTypeDTOs;
	}

	public ContainerTypeDTO getContainerTypeById(int containerTypeId) {
		ContainerTypeDTO containerTypeDTO = null;
		ContainerType containerType = containerTypeService.getContainerTypeById(containerTypeId);
		if (containerType != null) {
			if (!containerType.isActive())
				throw new HttpClientErrorException(HttpStatus.FORBIDDEN, "Container type is inactive");
			containerTypeDTO = convertEntityToDTO(containerType);
		}
		return containerTypeDTO;
	}

	private ContainerTypeDTO convertEntityToDTO(ContainerType containerType) {
		return modelMapper.map(containerType, ContainerTypeDTO.class);
	}

}
