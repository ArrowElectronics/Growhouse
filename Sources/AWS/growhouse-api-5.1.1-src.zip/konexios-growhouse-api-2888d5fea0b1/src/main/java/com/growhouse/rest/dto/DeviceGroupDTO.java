package com.growhouse.rest.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class DeviceGroupDTO {

	private Integer id;
	
	private String status;
	 
	private String deviceUId;
	
	private String deviceHId;
	
	@JsonProperty("device_name")
	private String deviceName;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDeviceUId() {
		return deviceUId;
	}

	public void setDeviceUId(String deviceUId) {
		this.deviceUId = deviceUId;
	}

	public String getDeviceHId() {
		return deviceHId;
	}

	public void setDeviceHId(String deviceHId) {
		this.deviceHId = deviceHId;
	}

	public String getDeviceName() {
		return deviceName;
	}

	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}

	@Override
	public String toString() {
		return "DeviceGroupDTO [id=" + id + ", status=" + status + ", deviceUId=" + deviceUId + ", deviceHId="
				+ deviceHId + ", deviceName=" + deviceName + "]";
	}
	
	
	
}
