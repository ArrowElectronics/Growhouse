package com.growhouse.rest.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.growhouse.rest.entity.LedNodeProfileEvent;

@Repository
public interface LedNodeProfileEventRepository extends JpaRepository<LedNodeProfileEvent, Integer> {

	public List<LedNodeProfileEvent> findByGroupIdAndIsActiveTrueOrderByCreatedTimestampDesc(int groupId);
	
	public List<LedNodeProfileEvent> findByProfileIdAndIsActiveTrue(int profileId);
	
	@Query(value = "select * from lednode_profile_events ga where locate(?1,ga.repeat_time) and end_date >= ?2 and ga.is_active=1", nativeQuery = true)
	public List<LedNodeProfileEvent> findByPofileEvents(String day,String todayDate);
	
	//@Query(value = "select * from lednode_profile_events ga where ((locate(?1,ga.repeat_time) and end_date >= ?2 and start_date<= ?2) or (start_date=?2)) and ga.is_active=1 order by created_timestamp desc", nativeQuery = true)
	@Query(value = "select * from lednode_profile_events ga where ((locate(?1,ga.repeat_time) and end_date >= ?2 and start_date<= ?2) or ((start_date=?2) and (end_date is null))) and ga.is_active=1 order by created_timestamp desc", nativeQuery = true)
	public List<LedNodeProfileEvent> getEventByCron(String repeatMsg,String todayDate);
	
	@Modifying(clearAutomatically = true)
	@Transactional
	@Query(value = "update lednode_profile_events ga set ga.is_active = 0 where ga.group_id = ?1", nativeQuery = true)
	public void deleteLedNodeProfileEventByGroupId(int groupId);
	
	@Modifying(clearAutomatically = true)
	@Transactional
	@Query(value = "update lednode_profile_events ga set ga.is_active = 0 where ga.profile_id = ?1", nativeQuery = true)
	public void deleteLedNodeProfileEventByProfileId(int profileId);
	
	@Modifying(clearAutomatically = true)
	@Transactional
	@Query(value = "update lednode_profile_events ga set ga.is_active = 0 where ga.job_name = ?1", nativeQuery = true)
	public void deleteLedNodeProfileEventByEventName(String jobName);
	
	@Modifying(clearAutomatically = true)
	@Transactional
	@Query(value = "update lednode_profile_events ga set ga.is_active = 0 where (ga.end_date = ?1) or (ga.start_date = ?1 and end_date IS NULL)", nativeQuery = true)
	public void deleteLedNodeProfileEventBydate(String endDate);
	
	@Modifying(clearAutomatically = true)
	@Transactional
	@Query(value = "update lednode_profile_events ga set ga.profile_name = ?1 where ga.profile_id = ?2 and ga.is_active=1", nativeQuery = true)
	public void updateEventProfileNameByProfileId(String profileName,int profileId);
	
	@Query(value = "select * from lednode_profile_events ga where ga.start_date = ?1 and start_time = ?2 and ga.group_id = ?3 and ga.is_active=1 ORDER BY created_timestamp DESC LIMIT 1", nativeQuery = true)
	public LedNodeProfileEvent getEventByStartDateAndTime(String startDate,String stime,int groupId);
	
	@Query(value = "select * from lednode_profile_events ga where ga.start_date = ?1 and start_time = ?2 and LOCATE(?3 ,ga.repeat_time) and ga.group_id = ?4  and ga.is_active=1 ORDER BY created_timestamp DESC LIMIT 1", nativeQuery = true)
	public LedNodeProfileEvent getEventByStartDateAndTimeAndDay(String startDate,String stime,String repeatDay,int groupId);
	
	}
