/**
 * 
 */
package com.growhouse.rest.services.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.growhouse.rest.entity.DeviceType;
import com.growhouse.rest.repository.DeviceTypeRepository;
import com.growhouse.rest.services.IDeviceTypeService;

/**
 * @author dharita.chokshi
 *
 */
@Service
public class DeviceTypeService implements IDeviceTypeService {

	@Autowired
	private DeviceTypeRepository deviceTypeRepository;

	
	public List<DeviceType> getAllDeviceTypes() {
		return deviceTypeRepository.findByIsActiveTrue();
	}

	
	public DeviceType getDeviceTypeById(int id) {
		Optional<DeviceType> optional = deviceTypeRepository.findById(id);
		return optional.isPresent() ? optional.get() : null;
	}

	
	public DeviceType getDeviceTypeByDeviceTypeName(String deviceTypeName) {
		return deviceTypeRepository.findByDeviceTypeName(deviceTypeName);
	}

}
