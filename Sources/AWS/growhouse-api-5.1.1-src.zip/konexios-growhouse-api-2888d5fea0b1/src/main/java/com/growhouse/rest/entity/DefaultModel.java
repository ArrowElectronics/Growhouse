/**
 * 
 */
package com.growhouse.rest.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MappedSuperclass;
import javax.persistence.OneToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.context.SecurityContextHolder;


/**
 * @author dharita.chokshi
 *
 */
@MappedSuperclass
public abstract class DefaultModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5466532557666546377L;
	
	public static final Logger LOGGER = LoggerFactory.getLogger(DefaultModel.class);

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "is_active", columnDefinition = "TINYINT DEFAULT '1'")
	@NotNull
	private boolean isActive = true;

	@Column(updatable = false, name = "created_timestamp", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	@Temporal(TemporalType.TIMESTAMP)
	@CreationTimestamp
	private Date createdTimestamp;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "created_by", updatable = false)
	private User createdBy;

	@Column(name = "updated_timestamp", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
	@Temporal(TemporalType.TIMESTAMP)
	@UpdateTimestamp
	private Date updatedTimestamp;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "updated_by")
	private User updatedBy;

	@PrePersist
	protected void onCreate() {
		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();	
		if (user != null)
			createdBy = updatedBy = user;
		updatedTimestamp = createdTimestamp = new Date();
	}

	@PreUpdate
	protected void onUpdate() {
		User user = null;
		try {
		user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		}catch(Exception e) {
			LOGGER.info("Not get User for update");
		}
		if (user != null)
			updatedBy = user;
		updatedTimestamp = new Date();
	}

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the isActive
	 */
	public boolean isActive() {
		return isActive;
	}

	/**
	 * @param isActive
	 *            the isActive to set
	 */
	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	/**
	 * @return the createdTimestamp
	 */
	public Date getCreatedTimestamp() {
		return createdTimestamp;
	}

	/**
	 * @param createdTimestamp
	 *            the createdTimestamp to set
	 */
	public void setCreatedTimestamp(Date createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	/**
	 * @return the createdBy
	 */
	public User getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy
	 *            the createdBy to set
	 */
	public void setCreatedBy(User createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the updatedTimestamp
	 */
	public Date getUpdatedTimestamp() {
		return updatedTimestamp;
	}

	/**
	 * @param updatedTimestamp
	 *            the updatedTimestamp to set
	 */
	public void setUpdatedTimestamp(Date updatedTimestamp) {
		this.updatedTimestamp = updatedTimestamp;
	}

	/**
	 * @return the updatedBy
	 */
	public User getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy
	 *            the updatedBy to set
	 */
	public void setUpdatedBy(User updatedBy) {
		this.updatedBy = updatedBy;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "DefaultModel [id=" + id + ", isActive=" + isActive + ", createdTimestamp=" + createdTimestamp
				+ ", createdBy=" + createdBy + ", updatedTimestamp=" + updatedTimestamp + ", updatedBy=" + updatedBy
				+ "]";
	}

}
