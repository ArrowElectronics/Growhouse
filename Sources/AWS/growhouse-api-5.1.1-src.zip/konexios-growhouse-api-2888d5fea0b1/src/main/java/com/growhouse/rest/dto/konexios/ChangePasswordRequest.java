package com.growhouse.rest.dto.konexios;

public class ChangePasswordRequest {
    private String currentPassword;
    private String newPassword;

    public ChangePasswordRequest currentPassword(String currentPassword) {
        this.currentPassword = currentPassword;
        return this;
    }

    public ChangePasswordRequest newPassword(String newPassword) {
        this.newPassword = newPassword;
        return this;
    }

    public String getCurrentPassword() {
        return this.currentPassword;
    }

    public void setCurrentPassword(String currentPassword) {
        this.currentPassword = currentPassword;
    }

    public String getNewPassword() {
        return this.newPassword;
    }

    public void setNewPassword(String newPassword) {
        this.newPassword = newPassword;
    }
}