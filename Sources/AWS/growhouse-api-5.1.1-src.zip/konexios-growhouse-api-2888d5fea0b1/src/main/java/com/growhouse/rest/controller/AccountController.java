/**
 * 
 */
package com.growhouse.rest.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;

import com.growhouse.rest.dto.AccountDTO;
import com.growhouse.rest.entity.Account;
import com.growhouse.rest.facade.AccountFacade;
import com.growhouse.rest.response.ResponseMessage;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author dharita.chokshi
 *
 */

@RestController
@RequestMapping("/api/accounts")
@Transactional
public class AccountController extends ControllerAbstract {

	public static final Logger LOGGER = LoggerFactory.getLogger(AccountController.class);

	@Autowired
	private AccountFacade accountFacade;

	/*
	 * Query--Select * from account where account.created_by=? and
	 * account.is_active=?
	 */
	@GetMapping(value = "")
	@ApiOperation(value = "View list of active accounts")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "List retrieved successfully"),
			@ApiResponse(code = 204, message = "Empty list") })
	public ResponseEntity<List<AccountDTO>> getActiveAccounts() {
		ResponseEntity<List<AccountDTO>> responseEntity;
		if (!isSuperAdmin()) {
			responseEntity = new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
		} else {
			try {
				List<AccountDTO> accounts = accountFacade.getActiveAccounts();
				if (accounts == null || accounts.isEmpty())
					responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
				else
					responseEntity = new ResponseEntity<>(accounts, HttpStatus.OK);
			} catch (Exception e) {
				LOGGER.error("getActiveAccounts", e);
				responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
		return responseEntity;
	}

	/* Query-- Select * from account where account.id=? */
	@GetMapping(value = "/{accountId}")
	@ApiOperation(value = "View account based on accountId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Account retrieved successfully"),
			@ApiResponse(code = 403, message = "Account is inactive") })
	public ResponseEntity<?> getAccountByAccountId(@PathVariable("accountId") Integer accountId) {
		ResponseEntity<?> responseEntity;
		try {
			AccountDTO accounts = accountFacade.getAccountById(accountId);
			if (accounts == null)
				responseEntity = new ResponseEntity<>(HttpStatus.NOT_FOUND);
			else
				responseEntity = new ResponseEntity<>(accounts, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			LOGGER.error("getAccountByAccountId", e);
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@PostMapping(value = "", consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Create new account")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Account created successfully"),
			@ApiResponse(code = 400, message = "Bad Request") })
	public ResponseEntity<?> createAccount(@RequestBody AccountDTO accountDTO) {
		ResponseEntity<?> responseEntity;
		if (!isSuperAdmin()) {
			responseEntity = new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
		} else {
			try {
				AccountDTO createdAccountDTO = accountFacade.createAccount(accountDTO);
				if (createdAccountDTO == null)
					responseEntity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
				else
					responseEntity = new ResponseEntity<>(createdAccountDTO, HttpStatus.CREATED);
			} catch (HttpClientErrorException httpClientErrorException) {
				responseEntity = setResponseMessage(httpClientErrorException);
			} catch (Exception e) {
				LOGGER.error("createAccount", e);
				responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
		return responseEntity;
	}

	@PutMapping(value = "/{accountId}")
	@ApiOperation(value = "Update existing account")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Account updated successfully"),
			@ApiResponse(code = 403, message = "Account is inactive"),
			@ApiResponse(code = 400, message = "Bad Request"),
			@ApiResponse(code = 406, message = "AccountId in URL doesnot match with accountId of Account object") })
	public ResponseEntity<?> updateAccount(@PathVariable("accountId") Integer accountId,
			@RequestBody AccountDTO accountDTO) {
		ResponseEntity<?> responseEntity;
		try {
			AccountDTO updatedAccounts = accountFacade.updateAccount(accountId, accountDTO);
			if (updatedAccounts == null)
				responseEntity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			else
				responseEntity = new ResponseEntity<>(accountDTO, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			LOGGER.error("updateAccount", e);
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/* Query-- Update account SET is_active=false where account.id=? */
	@DeleteMapping(value = "/{accountId}")
	@ApiOperation(value = "Delete account by accountId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Account deleted successfully"),
			@ApiResponse(code = 403, message = "Account is inactive") })
	public ResponseEntity<ResponseMessage> deleteAccount(@PathVariable("accountId") Integer accountId) {
		ResponseEntity<ResponseMessage> responseEntity;
		if (!isSuperAdmin()) {
			responseEntity = new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
		} else {
			try {
				Account deletedAccount = accountFacade.deleteAccount(accountId);
				if (deletedAccount != null) {
					ResponseMessage responseMessage = new ResponseMessage();
					responseMessage.setMessage("Account deleted successfully");
					responseEntity = new ResponseEntity<>(responseMessage, HttpStatus.OK);
				} else {
					responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
				}
			} catch (HttpClientErrorException httpClientErrorException) {
				responseEntity = setResponseMessage(httpClientErrorException);
			} catch (Exception e) {
				LOGGER.error("deleteAccount", e);
				responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
		return responseEntity;
	}

	/**
	 * @param httpClientErrorException
	 * @return
	 */
	private ResponseEntity<ResponseMessage> setResponseMessage(HttpClientErrorException httpClientErrorException) {
		ResponseMessage responseMessage = new ResponseMessage();
		responseMessage.setMessage(httpClientErrorException.getStatusText());
		return new ResponseEntity<>(responseMessage, httpClientErrorException.getStatusCode());
	}

}
