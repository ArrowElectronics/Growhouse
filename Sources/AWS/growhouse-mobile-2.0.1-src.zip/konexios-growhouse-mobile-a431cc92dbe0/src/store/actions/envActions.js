import {Alert, AsyncStorage} from 'react-native';
import * as Urls from '../../Urls';
import {SELECT_ENVIRONMENT, SET_ENVIRONMENTS} from './actionTypes';

export const getEnvironments = () => {
  return async dispatch => {
    const url = Urls.ENV_URL;
    console.log('getEnvironment() url: ' + url);
    return await fetch(url, {
      method: 'GET',
      headers: {
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        Pragma: 'no-cache',
        Expires: 0,
      },
    })
      .then(response => {
        if (response.status === 200) {
          return response.json();
        } else {
          throw new Error('unable to load environments!');
        }
      })
      .then(environments => {
        console.log(JSON.stringify(environments));
        dispatch({
          type: SET_ENVIRONMENTS,
          environments: environments,
        });
      })
      .catch(error => {
        console.log(error.message);
        Alert.alert(error.message);
      });
  };
};

export const selectEnvironment = environment => {
  AsyncStorage.setItem('environment', JSON.stringify(environment)).then(() => {
    console.log('persisted environment to storage: ' + environment.name);
  });
  return {
    type: SELECT_ENVIRONMENT,
    environment: environment,
  };
};
