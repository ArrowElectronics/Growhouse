/* eslint-disable no-alert */
import {
  SET_GROWAREAS,
  SET_GROWAREAS_BY_CONTAINER_ID,
  DELETE_GATEWAY,
  GET_ALL_GATEWAYS,
  SET_GROWAREA_TYPES,
  SET_COUNT_BY_GROWAREA_ID,
} from './actionTypes';
import {
  uiStartLoading,
  uiStopLoading,
  countUiStartLoading,
  countUiStopLoading,
  sessionExpired,
  sessionEstablished,
} from './rootActions';
import {AsyncStorage} from 'react-native';
import * as Urls from '../../Urls';
import {apiDebug} from '../../../app.json';

export const setGrowAreas = growareas => {
  growareas.sort(function(a, b) {
    return b.id - a.id;
  });
  return {
    type: SET_GROWAREAS,
    growareas: growareas,
  };
};

export const setGrowAreasByContainerId = (
  containerId,
  growareasByContainerId,
) => {
  growareasByContainerId.sort(function(a, b) {
    return b.id - a.id;
  });
  return {
    type: SET_GROWAREAS_BY_CONTAINER_ID,
    growareasByContainerId: growareasByContainerId,
    containerId: containerId,
  };
};

export const setGrowAreaTypes = growAreaTypes => {
  growAreaTypes.sort(function(a, b) {
    return b.id - a.id;
  });
  return {
    type: SET_GROWAREA_TYPES,
    growAreaTypes: growAreaTypes,
  };
};

export const setCountsByGrowAreaId = (growAreaId, countsByGrowAreaId) => {
  return {
    type: SET_COUNT_BY_GROWAREA_ID,
    growAreaId: growAreaId,
    countsByGrowAreaId: countsByGrowAreaId,
  };
};

export const getGrowAreas = (containerId, inBackground, isLessThenVersion4) => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    let url = Urls.GET_ALL_GROW_AREAS.replace(
      '{BASE_URL}',
      getState().root.environment.url,
    );
    if (containerId) {
      url = url + '/containers/' + containerId;
    }
    console.log('getGrowAreas: ' + url);
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    if (!inBackground) {
      dispatch(uiStartLoading());
    }
    fetch(url, {
      method: 'GET',
      headers,
    })
      .catch(error => {
        throw new Error('Network error!');
      })
      .then(res => {
        if (res.ok) {
          if (res.status === 204) {
            return [];
          }
          return res.json();
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else {
          throw new Error('getGrowAreas failed:' + res.status);
        }
      })
      .then(parsedRes => {
        if (isLessThenVersion4) {
          dispatch({type: GET_ALL_GATEWAYS, payload: parsedRes});
          console.log('in isLessThenVersion4', parsedRes.length);
        }
        if (containerId) {
          dispatch(setGrowAreasByContainerId(containerId, parsedRes));
        } else {
          dispatch(setGrowAreas(parsedRes));
        }
        if (!inBackground) {
          dispatch(uiStopLoading());
        }
        dispatch(sessionEstablished());
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          if (!inBackground) {
            alert(error.message);
          }
          console.log(error);
        }
        if (!inBackground) {
          dispatch(uiStopLoading());
        }
      });
  };
};

export const getGrowAreaTypes = inBackground => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url = Urls.GET_ALL_GROW_AREA_TYPES.replace(
      '{BASE_URL}',
      getState().root.environment.url,
    );
    console.log('getGrowAreaTypes: ' + url);
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    if (!inBackground) {
      dispatch(uiStartLoading());
    }
    fetch(url, {
      method: 'GET',
      headers,
    })
      .catch(error => {
        throw new Error('Network error!');
      })
      .then(res => {
        if (res.ok) {
          if (res.status === 204) {
            return [];
          }
          return res.json();
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else {
          throw new Error('getGrowAreaTypes failed:' + res.status);
        }
      })
      .then(parsedRes => {
        dispatch(setGrowAreaTypes(parsedRes));
        if (!inBackground) {
          dispatch(uiStopLoading());
        }
        dispatch(sessionEstablished());
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          if (!inBackground) {
            alert(error.message);
          }
          console.log(error);
        }
        if (!inBackground) {
          dispatch(uiStopLoading());
        }
      });
  };
};

export const getGrowAreaCounts = (growAreaId, inBackground) => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url =
      Urls.GET_ALL_GROW_AREA_COUNTS.replace(
        '{BASE_URL}',
        getState().root.environment.url,
      ) +
      '/' +
      growAreaId;
    console.log('getGrowAreaCounts: ' + url);
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    if (!inBackground) {
      dispatch(countUiStartLoading());
    }
    fetch(url, {
      method: 'GET',
      headers,
    })
      .catch(error => {
        throw new Error('Network error!');
      })
      .then(res => {
        if (res.ok) {
          if (res.status === 204) {
            return {};
          }
          return res.json();
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else {
          throw new Error('getGrowAreaCounts failed:' + res.status);
        }
      })
      .then(parsedRes => {
        dispatch(setCountsByGrowAreaId(growAreaId, parsedRes));
        if (!inBackground) {
          dispatch(countUiStopLoading());
        }
        dispatch(sessionEstablished());
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          if (!inBackground) {
            alert(error.message);
          }
          console.log(error);
        }
        if (!inBackground) {
          dispatch(countUiStopLoading());
        }
      });
  };
};

export const deleteLedNodeProfile = gatewayId => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url =
      Urls.DELETE_ALL_PROFILES.replace(
        '{BASE_URL}',
        getState().root.environment.url,
      ) + `/${gatewayId}`;
    console.log('deleteLedNodeProfile: ' + url);
    dispatch(uiStartLoading());
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    fetch(url, {
      method: 'DELETE',
      headers,
    })
      .catch(error => {
        throw new Error('Network error!');
      })
      .then(res => {
        if (res.ok) {
          if (res.status === 204) {
            return {};
          }
          return res;
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else {
          throw new Error('deleteLedNodeProfile failed:' + res.status);
        }
      })
      .then(res => {
        dispatch(deleteLEDNodeDesiredValue(gatewayId));
        dispatch(sessionEstablished());
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          setTimeout(() => {
            alert(error.message);
          }, 100);
          console.log(error);
        }
        dispatch(uiStopLoading());
      });
  };
};

export const deleteLEDNodeDesiredValue = gatewayId => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url =
      Urls.DELETE_ALL_DESIRED_VALUE.replace(
        '{BASE_URL}',
        getState().root.environment.url,
      ) + `/${gatewayId}`;
    console.log('deleteLEDNodeDesiredValue: ' + url);
    dispatch(uiStartLoading());
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    fetch(url, {
      method: 'DELETE',
      headers,
    })
      .catch(error => {
        throw new Error('Network error!');
      })
      .then(res => {
        if (res.ok) {
          if (res.status === 204) {
            return {};
          }
          return res;
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else {
          throw new Error('deleteLEDNodeDesiredValue failed:' + res.status);
        }
      })
      .then(res => {
        dispatch(deleteLEDNodeChannelConfing(gatewayId));
        dispatch(sessionEstablished());
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          setTimeout(() => {
            alert(error.message);
          }, 100);
          console.log(error);
        }
        dispatch(uiStopLoading());
      });
  };
};

export const deleteLEDNodeChannelConfing = gatewayId => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url =
      Urls.DELETE_ALL_CHANNEL_CONFIG.replace(
        '{BASE_URL}',
        getState().root.environment.url,
      ) + `/${gatewayId}`;
    console.log('deleteLEDNodeChannelConfing: ' + url);
    dispatch(uiStartLoading());
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    fetch(url, {
      method: 'DELETE',
      headers,
    })
      .catch(error => {
        throw new Error('Network error!');
      })
      .then(res => {
        if (res.ok) {
          if (res.status === 204) {
            return {};
          }
          return res;
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else {
          throw new Error('deleteLEDNodeChannelConfing failed:' + res.status);
        }
      })
      .then(res => {
        dispatch(deleteDevicePropertyMapping(gatewayId));
        dispatch(sessionEstablished());
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          setTimeout(() => {
            alert(error.message);
          }, 100);
          console.log(error);
        }
        dispatch(uiStopLoading());
      });
  };
};

export const deleteDevicePropertyMapping = gatewayId => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url =
      Urls.DELETE_ALL_MAPPING.replace(
        '{BASE_URL}',
        getState().root.environment.url,
      ) + `/${gatewayId}`;
    console.log('deleteDevicePropertyMapping: ' + url);
    dispatch(uiStartLoading());
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    fetch(url, {
      method: 'DELETE',
      headers,
    })
      .catch(error => {
        throw new Error('Network error!');
      })
      .then(res => {
        if (res.ok) {
          if (res.status === 204) {
            return {};
          }
          return res;
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else {
          throw new Error('deleteDevicePropertyMapping failed:' + res.status);
        }
      })
      .then(res => {
        dispatch(deleteDeviceSection(gatewayId));
        dispatch(sessionEstablished());
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          setTimeout(() => {
            alert(error.message);
          }, 100);
          console.log(error);
        }
        dispatch(uiStopLoading());
      });
  };
};

export const deleteDeviceSection = gatewayId => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url =
      Urls.DELETE_DEVICE_SECTION.replace(
        '{BASE_URL}',
        getState().root.environment.url,
      ) + `/${gatewayId}`;
    console.log('deleteDeviceSection: ' + url);
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    dispatch(uiStartLoading());
    fetch(url, {
      method: 'DELETE',
      headers,
    })
      .catch(error => {
        throw new Error('Network error!');
      })
      .then(res => {
        if (res.ok) {
          if (res.status === 204) {
            return {};
          }
          return res;
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else {
          throw new Error('deleteDeviceSection failed:' + res.status);
        }
      })
      .then(res => {
        dispatch(deleteDevicesGateway(gatewayId));
        dispatch(sessionEstablished());
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          setTimeout(() => {
            alert(error.message);
          }, 100);
          console.log(error);
        }
        dispatch(uiStopLoading());
      });
  };
};

export const deleteDevicesGateway = gatewayId => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url =
      Urls.DELETE_DEVICE_GATEWAY.replace(
        '{BASE_URL}',
        getState().root.environment.url,
      ) + `/${gatewayId}`;
    console.log('deleteDevicesGateway: ' + url);
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    dispatch(uiStartLoading());
    fetch(url, {
      method: 'DELETE',
      headers,
    })
      .catch(error => {
        throw new Error('Network error!');
      })
      .then(res => {
        if (res.ok) {
          if (res.status === 204) {
            return {};
          }
          return res;
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else {
          console.log('body', res, res.message);
          throw new Error('deleteDevicesGateway failed:' + res.status);
        }
      })
      .then(res => {
        dispatch(deleteProfileAlert(gatewayId));
        dispatch(sessionEstablished());
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          setTimeout(() => {
            alert(error.message);
          }, 100);
          console.log(error);
        }
        dispatch(uiStopLoading());
      });
  };
};

export const deleteProfileAlert = gatewayId => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url =
      Urls.DELETE_ALL_PROFILE_ALERTS.replace(
        '{BASE_URL}',
        getState().root.environment.url,
      ) + `/${gatewayId}`;
    console.log('deleteProfileAlert: ' + url);
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    dispatch(uiStartLoading());
    fetch(url, {
      method: 'DELETE',
      headers,
    })
      .catch(error => {
        throw new Error('Network error!');
      })
      .then(res => {
        if (res.ok) {
          if (res.status === 204) {
            return {};
          }
          return res;
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else {
          throw new Error('deleteProfileAlert failed:' + res.status);
        }
      })
      .then(res => {
        dispatch(deleteAllProfile(gatewayId));
        dispatch(sessionEstablished());
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          setTimeout(() => {
            alert(error.message);
          }, 100);
          console.log(error);
        }
        dispatch(uiStopLoading());
      });
  };
};

export const deleteAllProfile = gatewayId => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url =
      Urls.DELETE_ALL_GROWAREA_PROFILE.replace(
        '{BASE_URL}',
        getState().root.environment.url,
      ) + `/${gatewayId}`;
    console.log('deleteAllProfile: ' + url);
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    dispatch(uiStartLoading());
    fetch(url, {
      method: 'DELETE',
      headers,
    })
      .catch(error => {
        throw new Error('Network error!');
      })
      .then(res => {
        if (res.ok) {
          if (res.status === 204) {
            return {};
          }
          return res;
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else {
          throw new Error('deleteAllProfile failed:' + res.status);
        }
      })
      .then(res => {
        dispatch(deleteGrowSection(gatewayId));
        dispatch(sessionEstablished());
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          setTimeout(() => {
            alert(error.message);
          }, 100);
          console.log(error);
        }
        dispatch(uiStopLoading());
      });
  };
};

export const deleteGrowSection = gatewayId => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url =
      Urls.DELETE_ALL_GROW_SECTION.replace(
        '{BASE_URL}',
        getState().root.environment.url,
      ) + `/${gatewayId}`;
    console.log('deleteGrowSection: ' + url);
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    dispatch(uiStartLoading());
    fetch(url, {
      method: 'DELETE',
      headers,
    })
      .catch(error => {
        throw new Error('Network error!');
      })
      .then(res => {
        if (res.ok) {
          if (res.status === 204) {
            return {};
          }
          return res;
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else {
          throw new Error('deleteGrowSection failed:' + res.status);
        }
      })
      .then(res => {
        dispatch(deleteGroups(gatewayId));
        dispatch(sessionEstablished());
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          setTimeout(() => {
            alert(error.message);
          }, 100);
          console.log(error);
        }
        dispatch(uiStopLoading());
      });
  };
};

export const deleteGroups = gatewayId => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url =
      Urls.DELETE_GROWAREA_GROUPS.replace(
        '{BASE_URL}',
        getState().root.environment.url,
      ) + `/${gatewayId}/groups`;
    console.log('deleteGroups: ' + url);
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    dispatch(uiStartLoading());
    fetch(url, {
      method: 'DELETE',
      headers,
    })
      .catch(error => {
        throw new Error('Network error!');
      })
      .then(res => {
        if (res.ok) {
          if (res.status === 204) {
            return {};
          }
          return res;
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else {
          throw new Error('deleteGroups failed:' + res.status);
        }
      })
      .then(res => {
        dispatch(deleteAssigneeGateway(gatewayId));
        dispatch(sessionEstablished());
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          setTimeout(() => {
            alert(error.message);
          }, 100);
          console.log(error);
        }
        dispatch(uiStopLoading());
      });
  };
};

export const deleteAssigneeGateway = gatewayId => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url =
      Urls.DELETE_ASSIGNEE_GROWAREA.replace(
        '{BASE_URL}',
        getState().root.environment.url,
      ) + `/${gatewayId}`;
    console.log('deleteAssigneeGateway: ' + url);
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    dispatch(uiStartLoading());
    fetch(url, {
      method: 'DELETE',
      headers,
    })
      .catch(error => {
        throw new Error('Network error!');
      })
      .then(res => {
        if (res.ok) {
          if (res.status === 204) {
            return {};
          }
          return res;
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else {
          throw new Error('deleteAssigneeGateway failed:' + res.status);
        }
      })
      .then(res => {
        dispatch(deleteGateway(gatewayId));
        dispatch(sessionEstablished());
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          setTimeout(() => {
            alert(error.message);
          }, 100);
          console.log(error);
        }
        dispatch(uiStopLoading());
      });
  };
};

export const deleteGateway = gatewayId => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url =
      Urls.DELETE_GROWAREA.replace(
        '{BASE_URL}',
        getState().root.environment.url,
      ) + `/${gatewayId}`;
    console.log('deleteGateway: ' + url);
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    dispatch(uiStartLoading());
    fetch(url, {
      method: 'DELETE',
      headers,
    })
      .catch(error => {
        throw new Error('Network error!');
      })
      .then(res => {
        if (res.ok) {
          if (res.status === 204) {
            return {};
          }
          return res;
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else {
          throw new Error('deleteGateway failed:' + res.status);
        }
      })
      .then(res => {
        dispatch(deleteGatewayResponse(true));
        dispatch(sessionEstablished());
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          console.log('error in gateway deletion', error);
          setTimeout(() => {
            alert(error.message);
          }, 200);
        }
        dispatch(uiStopLoading());
      });
  };
};

export const deleteGatewayResponse = flag => {
  return {
    type: DELETE_GATEWAY,
    payload: flag,
  };
};
