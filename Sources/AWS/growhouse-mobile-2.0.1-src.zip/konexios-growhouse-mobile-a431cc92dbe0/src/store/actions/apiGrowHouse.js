/* eslint-disable no-alert */

import * as RegistrationStates from '../../RegistrationStates';
import * as Urls from '../../Urls';
import {GET_ALL_GATEWAYS, REGISTERED_DEVICE_COUNT} from './actionTypes';
import {
  getGrowAreas,
  sessionEstablished,
  sessionExpired,
  uiUpdateRegistrationState,
} from './rootActions';

export const registerGateway = (reqData, bleDevice) => {
  return (dispatch, getState) => {
    const url = Urls.INTERNAL_GATEWAY_REGISTRATION_URL.replace(
      '{BASE_URL}',
      getState().root.environment.url,
    );
    const payload = JSON.stringify(reqData);
    const token = getState().root.token;

    console.log('registerGateway: ' + url);
    console.log('payload: ', payload);
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    dispatch(
      uiUpdateRegistrationState(
        RegistrationStates.REGISTRATION_STARTED_TO_INTERNAL_CLOUD,
      ),
    );
    fetch(url, {
      method: 'POST',
      headers,
      body: payload,
    })
      .catch(error => {
        console.log(error);
        bleDevice.cancelConnection();
        throw new Error('Network error!');
      })
      .then(res => {
        console.log(res.status);
        if (res.ok) {
          if (res.status === 204) {
            return [];
          }
          return res.json();
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else {
          throw new Error('registerGateway failed:' + res.status);
        }
      })
      .then(parsedRes => {
        console.log(url);
        console.log('Updating registration state1');
        dispatch(
          uiUpdateRegistrationState(
            RegistrationStates.REGISTRATION_SUCCESS_TO_INTERNAL_CLOUD,
          ),
        );
        console.log('Updating registration state2');
        setTimeout(() => {
          console.log('Updating registration state');
          dispatch(
            uiUpdateRegistrationState(
              RegistrationStates.REGISTRATION_PROCESS_COMPLETE,
            ),
          );
          dispatch(getGrowAreas(JSON.parse(payload).container.id), true);
          dispatch(getGrowAreas(null, true));
          dispatch(sessionEstablished());
        }, 1000);
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          bleDevice.cancelConnection();
          alert(error.message);
          dispatch(sessionEstablished());
          dispatch(
            uiUpdateRegistrationState(
              RegistrationStates.REGISTRATION_FAILED_TO_INTERNAL_CLOUD,
            ),
          );
        }
      });
  };
};

export const registerDevices = device => {
  return (dispatch, getState) => {
    const url = Urls.INTERNAL_DEVICE_REGISTRATION_URL.replace(
      '{BASE_URL}',
      getState().root.environment.url,
    );
    const payload = JSON.stringify(device);
    const token = getState().root.token;

    console.log('registerDevices: ' + url);
    console.log(payload);
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    fetch(url, {
      method: 'POST',
      headers,
      body: payload,
    })
      .catch(error => {
        console.log(error);
        throw new Error('Network error!');
      })
      .then(res => {
        console.log(res.status);
        if (res.ok) {
          if (res.status === 204) {
            return [];
          }
          return res.json();
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else {
          throw new Error('registerDevices failed:' + res.status);
        }
      })
      .then(parsedRes => {
        dispatch({type: REGISTERED_DEVICE_COUNT, payload: 1});
        dispatch(sessionEstablished());
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          console.log(error);
          dispatch({type: REGISTERED_DEVICE_COUNT, payload: -1});
          setTimeout(() => {
            alert(error.message);
          }, 500);
        }
      });
  };
};

const gettingAllGateways = () => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url =
      Urls.GET_ALL_GROW_AREAS.replace(
        '{BASE_URL}',
        getState().root.environment.url,
      ) + '/all';
    console.log('gettingAllGateways: ' + url);
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    fetch(url, {
      method: 'GET',
      headers,
    })
      .catch(error => {
        throw new Error('Network error!');
      })
      .then(res => {
        if (res.ok) {
          if (res.status === 204) {
            return [];
          }
          return res.json();
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else {
          throw new Error('gettingAllGateways failed:' + res.status);
        }
      })
      .then(parsedRes => {
        dispatch({type: GET_ALL_GATEWAYS, payload: parsedRes});
        dispatch(sessionEstablished());
      })
      .catch(async error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          alert(error.message);
          console.log(error);
        }
      });
  };
};

export const getAllGateways = (containerId, inBackground) => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url = Urls.GET_SERVER_VERSION.replace(
      '{BASE_URL}',
      getState().root.environment.url,
    );
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    fetch(url, {
      method: 'GET',
      headers,
    })
      .catch(error => {
        throw new Error('Network error!');
      })
      .then(res => {
        if (res.ok) {
          if (res.status === 204) {
            return [];
          }
          return res.json();
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else {
          throw new Error('getAllGateways failed:' + res.status);
        }
      })
      .then(parsedRes => {
        dispatch(gettingAllGateways());
        dispatch(sessionEstablished());
      })
      .catch(async error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          alert(error.message);
          console.log(error);
        }
      });
  };
};
