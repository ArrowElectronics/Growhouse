/* eslint-disable no-alert */
import {
  FIND_LEDNODE_FOR_GROUP,
  GET_GROUP_DETAILS,
  GET_LEDNODE_GROUP_LIST,
  IS_GROUP_PROFILE_DETAILS_LOADING,
  FIND_DEVICES_LOADER,
  GROUPE_LIST_PROCEESSING,
  IS_LED_GROUP_INDIVIDUAL_GROUP_LOADING,
  IS_LED_GROUP_LIST_LOADING,
} from './actionTypes';
import {uiStopLoading, sessionExpired, sessionEstablished} from './rootActions';
import * as Urls from '../../Urls';

export const getLEDGroupList = id => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url =
      Urls.GET_LEDNODE_GROUP_LIST.replace(
        '{BASE_URL}',
        getState().root.environment.url,
      ) + `/${id}`;
    console.log('getLEDGroupList: ' + url);
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    dispatch(isLEDGroupLoading(true));
    fetch(url, {
      method: 'GET',
      headers,
    })
      .catch(error => {
        throw new Error('Network error!');
      })
      .then(res => {
        if (res.ok) {
          if (res.status === 204) {
            return [];
          }
          return res.json();
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else {
          throw new Error('getLEDGroupList failed:' + res.status);
        }
      })
      .then(parsedRes => {
        dispatch({type: GET_LEDNODE_GROUP_LIST, payload: parsedRes});
        dispatch(sessionEstablished());
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          console.log('error in gateway deletion', error);
          setTimeout(() => {
            alert(error.message);
          }, 200);
        }
        dispatch(isLEDGroupLoading(false));
      });
  };
};

export const isLEDGroupLoading = flag => {
  console.log('flag-------->', flag);
  return {
    type: IS_LED_GROUP_LIST_LOADING,
    payload: flag,
  };
};

export const findDevices = (id, reqData) => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url =
      Urls.FIND_DEVICES_FOR_GROUP.replace(
        '{BASE_URL}',
        getState().root.environment.url,
      ) + `/${id}`;
    console.log('findDevices: ' + url);
    const payload = JSON.stringify(reqData);
    let headers = {
      Authorization: token,
      accept: 'application/json',
      'Content-Type': 'application/json',
    };
    dispatch({type: FIND_DEVICES_LOADER, payload: true});
    fetch(url, {
      method: 'PUT',
      headers,
      body: payload,
    })
      .catch(error => {
        throw new Error('Network error!');
      })
      .then(res => {
        if (res.ok) {
          if (res.status === 204) {
            return [];
          }
          return res.json();
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else {
          throw new Error('findDevices failed:' + res.status);
        }
      })
      .then(parsedRes => {
        dispatch({type: FIND_LEDNODE_FOR_GROUP, payload: parsedRes});
        dispatch(sessionEstablished());
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          console.log('error in finding devices', error);
          setTimeout(() => {
            alert(error.message);
          }, 200);
        }
        dispatch(uiStopLoading());
      });
  };
};

export const createLedGroup = reqData => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url = Urls.CREATE_LED_GROUP.replace(
      '{BASE_URL}',
      getState().root.environment.url,
    );
    console.log('createLedGroup: ' + url);
    let payload = JSON.stringify(reqData);
    let headers = {
      Authorization: token,
      accept: 'application/json',
      'Content-Type': 'application/json',
    };
    dispatch(isLEDGroupLoading(true));
    fetch(url, {
      method: 'POST',
      headers,
      body: payload,
    })
      .catch(error => {
        throw new Error('Network error!');
      })
      .then(async res => {
        if (res.ok) {
          if (res.status === 204) {
            return [];
          }
          return res.json();
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else if (res.status === 400) {
          let errorJson = await res.json();
          dispatch({
            type: IS_GROUP_PROFILE_DETAILS_LOADING,
            payload: false,
          });
          let message = await errorJson.message;
          throw new Error(`${message}`);
        } else {
          throw new Error('createLedGroup failed:' + res.status);
        }
      })
      .then(parsedRes => {
        dispatch(stopProccessing(true));
        dispatch(isLEDGroupLoading(false));
        dispatch(sessionEstablished());
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          console.log('error in finding devices', error);
          setTimeout(() => {
            alert(error.message);
          }, 200);
        }
        dispatch(isLEDGroupLoading(false));
      });
  };
};

export const stopProccessing = flag => {
  return {
    type: GROUPE_LIST_PROCEESSING,
    payload: flag,
  };
};

export const deleteGroup = groupId => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url =
      Urls.DELETE_LED_GROUP.replace(
        '{BASE_URL}',
        getState().root.environment.url,
      ) + `/${groupId}`;
    console.log('deleteGroup: ' + url);
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    dispatch(isLEDGroupLoading(true));
    fetch(url, {
      method: 'DELETE',
      headers,
    })
      .catch(error => {
        throw new Error('Network error!');
      })
      .then(res => {
        if (res.ok) {
          if (res.status === 204) {
            return [];
          }
          return res.json();
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else {
          throw new Error('deleteGroup failed:' + res.status);
        }
      })
      .then(parsedRes => {
        dispatch(stopProccessing(true));
        dispatch(isLEDGroupLoading(false));
        dispatch(sessionEstablished());
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          console.log('error in finding devices', error);
          setTimeout(() => {
            alert(error.message);
          }, 200);
        }
        dispatch(isLEDGroupLoading(false));
      });
  };
};

export const updateGroup = reqData => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url = Urls.UPDATE_LED_GROUP.replace(
      '{BASE_URL}',
      getState().root.environment.url,
    );
    console.log('updateGroup: ' + url);
    let payload = JSON.stringify(reqData);
    let headers = {
      Authorization: token,
      accept: 'application/json',
      'Content-Type': 'application/json',
    };
    dispatch(isLEDGroupLoading(true));
    fetch(url, {
      method: 'PUT',
      headers,
      body: payload,
    })
      .catch(error => {
        throw new Error('Network error!');
      })
      .then(async res => {
        if (res.ok) {
          if (res.status === 204) {
            return [];
          }
          return res.json();
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else if (res.status === 400) {
          let errorJson = await res.json();
          dispatch({
            type: IS_GROUP_PROFILE_DETAILS_LOADING,
            payload: false,
          });
          let message = await errorJson.message;
          throw new Error(`${message}`);
        } else {
          throw new Error('updateGroup failed:' + res.status);
        }
      })
      .then(parsedRes => {
        dispatch(stopProccessing(true));
        dispatch(isLEDGroupLoading(false));
        dispatch(sessionEstablished());
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          console.log('error in finding devices', error);
          setTimeout(() => {
            alert(error.message);
          }, 200);
        }
        dispatch(uiStopLoading());
      });
  };
};

export const getGroupDetails = id => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url =
      Urls.GET_INDIVIDUAL_GROUP.replace(
        '{BASE_URL}',
        getState().root.environment.url,
      ) + `/${id}`;
    console.log('getGroupDetails: ' + url);
    dispatch({type: IS_LED_GROUP_INDIVIDUAL_GROUP_LOADING, payload: true});
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    fetch(url, {
      method: 'GET',
      headers,
    })
      .catch(error => {
        throw new Error('Network error!');
      })
      .then(res => {
        if (res.ok) {
          if (res.status === 204) {
            return [];
          }
          return res.json();
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else {
          throw new Error('getGroupDetails failed:' + res.status);
        }
      })
      .then(parsedRes => {
        dispatch({type: GET_GROUP_DETAILS, payload: parsedRes});
        dispatch({
          type: IS_LED_GROUP_INDIVIDUAL_GROUP_LOADING,
          payload: false,
        });
        dispatch(sessionEstablished());
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          console.log('error in fetching group details', error);
          setTimeout(() => {
            alert(error.message);
          }, 200);
        }
        dispatch({
          type: IS_LED_GROUP_INDIVIDUAL_GROUP_LOADING,
          payload: false,
        });
      });
  };
};
