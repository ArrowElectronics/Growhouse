/* eslint-disable no-alert */
import {
  GET_EVENT_LIST,
  IS_EVENT_LOADING,
  EVENT_LIST_PROCEESSING,
} from './actionTypes';
import {sessionExpired, sessionEstablished} from './rootActions';
import * as Urls from '../../Urls';

export const getEventList = id => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url =
      Urls.GET_INDIVIDUAL_GROUP.replace(
        '{BASE_URL}',
        getState().root.environment.url,
      ) + `/${id}/event`;
    console.log('getEventList: ' + url);
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    dispatch(isEventLoading(true));
    fetch(url, {
      method: 'GET',
      headers,
    })
      .catch(error => {
        throw new Error('Network error!');
      })
      .then(res => {
        if (res.ok) {
          if (res.status === 204) {
            return [];
          }
          return res.json();
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else {
          throw new Error('getEventList failed:' + res.status);
        }
      })
      .then(parsedRes => {
        dispatch({type: GET_EVENT_LIST, payload: parsedRes});
        dispatch(sessionEstablished());
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          console.log('error in gateway deletion', error);
          setTimeout(() => {
            alert(error.message);
          }, 200);
        }
        dispatch(isEventLoading(false));
      });
  };
};

export const stopEventProccessing = flag => {
  return {
    type: EVENT_LIST_PROCEESSING,
    payload: flag,
  };
};

export const isEventLoading = flag => {
  console.log('flag-------->', flag);
  return {
    type: IS_EVENT_LOADING,
    payload: flag,
  };
};

export const deleteEvent = jobName => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url =
      Urls.DELETE_EVENT.replace('{BASE_URL}', getState().root.environment.url) +
      `/${jobName}`;
    console.log('deleteEvent: ' + url);
    dispatch(isEventLoading(true));
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    fetch(url, {
      method: 'DELETE',
      headers,
    })
      .catch(error => {
        throw new Error('Network error!');
      })
      .then(res => {
        if (res.ok) {
          if (res.status === 204) {
            return [];
          }
          return res.json();
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else {
          throw new Error('deleteEvent failed:' + res.status);
        }
      })
      .then(parsedRes => {
        dispatch(stopEventProccessing(true));
        dispatch(isEventLoading(false));
        dispatch(sessionEstablished());
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          console.log('error in deleting events', error);
          setTimeout(() => {
            alert(error.message);
          }, 200);
        }
        dispatch(isEventLoading(false));
      });
  };
};
