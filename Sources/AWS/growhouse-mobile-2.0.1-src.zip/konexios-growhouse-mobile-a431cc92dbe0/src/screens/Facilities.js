/* eslint-disable react-native/no-inline-styles */
import React, {Component} from 'react';
import {
  ActivityIndicator,
  FlatList,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import {SearchBar} from 'react-native-elements';
import {Navigation} from 'react-native-navigation';
import Icon from 'react-native-vector-icons/FontAwesome';
import {connect} from 'react-redux';
import * as Constant from '../Constant';
import {getFacilities} from '../store/actions/rootActions';
import {debug} from './../../app.json';

class Facilities extends Component {
  static get options() {
    return Constant.DEFAULT_NAVIGATOR_STYLE;
  }
  visible = false;

  constructor(props) {
    super(props);
    Navigation.events().bindComponent(this);
    this.state = {
      refreshing: false,
    };
  }

  async componentDidAppear() {
    this.visible = true;
    this.props.facilities = [];
    this._onRefresh();
    this.forceUpdate();
  }

  _onRefresh = () => {
    this.setState({refreshing: true, searching: false, filterKey: ''});
    Promise.resolve(this.props.onGetFacilities(false)).then(() => {
      this.setState({refreshing: false});
    });
  };

  onListItemClickHandler = facility => {
    Navigation.push(this.props.componentId, {
      component: {
        name: 'ContainersScreen',
        passProps: {
          selectedFacility: {
            id: facility.id,
            name: facility.facility_name,
          },
        },
        options: {
          topBar: {
            title: {
              text: facility.facility_name,
            },
          },
        },
      },
    });
  };

  shouldComponentUpdate(nextProps, nextState) {
    return this.visible;
  }

  getListData() {
    let data = this.props.facilities;
    if (this.state.filterKey) {
      const newData = data.filter(item => {
        const itemData = `${item.facility_name.toUpperCase()}`;
        return itemData.indexOf(this.state.filterKey.toUpperCase()) > -1;
      });
      return newData;
    }
    return data;
  }

  onClearSearch = () => {
    this.setState({
      searching: false,
      filterKey: '',
    });
  };

  render() {
    let listData = this.getListData() || [];

    let facilitiesList = (
      <FlatList
        data={listData}
        renderItem={info => (
          <TouchableOpacity
            onPress={() => this.onListItemClickHandler(info.item)}>
            <View
              style={
                info.index === listData.length - 1
                  ? [
                      styles.listItem,
                      {
                        borderBottomWidth: 2,
                      },
                    ]
                  : styles.listItem
              }>
              <Text>
                {debug ? info.item.id + '-' : ''}
                {info.item.facility_name}
              </Text>
            </View>
          </TouchableOpacity>
        )}
        keyExtractor={item => item.id.toString()}
        refreshControl={
          <RefreshControl
            refreshing={this.state.refreshing}
            onRefresh={this._onRefresh}
            colors={['red', 'green', 'blue']}
          />
        }
      />
    );

    if (this.props.isLoading) {
      facilitiesList = (
        <View style={styles.activityIndicator}>
          <ActivityIndicator size="large" color="#acd373" />
        </View>
      );
    } else if (listData.length === 0) {
      facilitiesList = (
        <ScrollView
          contentContainerStyle={styles.activityIndicator}
          refreshControl={
            <RefreshControl
              refreshing={this.state.refreshing}
              onRefresh={this._onRefresh}
              colors={['red', 'green', 'blue']}
            />
          }>
          <Text color="#00ff00">No facilities found.</Text>
        </ScrollView>
      );
    }

    return (
      <View style={styles.container}>
        <View style={styles.greenBackgroundContainer} />
        <View style={styles.listContainer}>
          <View style={{flexDirection: 'row', alignItems: 'center'}}>
            <Text style={[styles.listTitle, {flex: 1}]}> Facilities</Text>
            {!this.state.searching && listData.length > 0 && (
              <Icon
                name="search"
                size={24}
                style={{padding: 10}}
                onPress={() => {
                  this.setState({
                    searching: true,
                  });
                  var myInterval = setInterval(() => {
                    if (this.search) {
                      this.search.focus();
                      clearInterval(myInterval);
                    }
                  }, 100);
                }}
              />
            )}
          </View>
          {this.state.searching && (
            <SearchBar
              ref={search => (this.search = search)}
              lightTheme
              value={this.state.filterKey}
              onChangeText={filterKey => this.setState({filterKey})}
              onClear={() => this.onClearSearch()}
              placeholder="Search facility..."
              containerStyle={{
                backgroundColor: Constant.LIGHT_GREY_COLOR,
                padding: 2,
              }}
              inputContainerStyle={{
                backgroundColor: Constant.WHITE_BACKGROUND_COLOR,
              }}
              inputStyle={{fontSize: 16}}
            />
          )}
          {facilitiesList}
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    backgroundColor: Constant.LIGHT_GREY_COLOR,
  },
  greenBackgroundContainer: {
    backgroundColor: Constant.PRIMARY_COLOR,
    width: '100%',
    height: '25%',
    position: 'absolute',
  },
  listContainer: {
    flex: 1,
    flexDirection: 'column',
    backgroundColor: Constant.WHITE_BACKGROUND_COLOR,
    marginLeft: '5%',
    marginRight: '5%',
    borderRadius: 5,
  },
  listTitle: {
    padding: 10,
    fontWeight: 'bold',
    borderBottomColor: Constant.LIGHT_GREY_COLOR,
  },
  listItem: {
    width: '100%',
    borderTopWidth: 2,
    borderColor: Constant.LIGHT_GREY_COLOR,
    padding: 10,
    flexDirection: 'row',
    alignItems: 'center',
  },
  activityIndicator: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

const mapStatesToProps = state => {
  return {
    facilities: state.root.facilities,
    isLoading: state.ui.isLoading,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onGetFacilities: inBackground => dispatch(getFacilities(inBackground)),
  };
};

export default connect(
  mapStatesToProps,
  mapDispatchToProps,
)(Facilities);
