// export const ENV_URL =
//  'https://content.konexios.io/private/growhouse/api/env-dev.json';

export const ENV_URL =
  'https://content.konexios.io/private/growhouse/api/env.json';

export const LIVE_CHART_HIDS =
  '0933bc4b7ba3ef75f0574750ddf8e2440af40ee2-9d2c83029ea635046a40d16d294c5045f8522e7b';

export const GET_SERVER_VERSION = '{BASE_URL}/release/version';
export const GET_ALL_FACILITIES = '{BASE_URL}/facilities';
export const GET_ALL_CONTAINERS = '{BASE_URL}/containers';
export const GET_ALL_GROW_AREAS = '{BASE_URL}/growareas';
export const GET_ALL_GROW_AREA_TYPES = '{BASE_URL}/growareatypes';
export const GET_ALL_GROW_AREA_COUNTS = '{BASE_URL}/count/bygrowarea';
export const GET_ALL_DEVICE_TYPES = '{BASE_URL}/devicetypes';
export const GET_ALL_GROW_SECTIONS = '{BASE_URL}/growsections';
export const GET_ALL_DEVICES = '{BASE_URL}/devices';
export const GET_ALL_USERS = '{BASE_URL}/users';
export const VERIFY_USER = '{BASE_URL}/users/token';
export const INTERNAL_GATEWAY_REGISTRATION_URL = '{BASE_URL}/growareas';
export const INTERNAL_DEVICE_REGISTRATION_URL = '{BASE_URL}/devices';
export const DELETE_ASSIGNEE_GROWAREA = '{BASE_URL}/growareas/assignee';
export const DELETE_GROWAREA = '{BASE_URL}/growareas';
export const DELETE_DEVICE = '{BASE_URL}/devices';
export const GET_DASHBOARD_COUNT = '{BASE_URL}/count';
export const GET_DASHBOARD_ALERT = '{BASE_URL}/profilealert/user';

export const GET_KONEXIOS_CONFIG = '{BASE_URL}/konexios/config';

export const KONEXIOS_GATEWAY_REGISTRATION_URL =
  '{BASE_URL}/api/v1/kronos/gateways';

export const KONEXIOS_GATEWAY_CONFIG_GET_URL =
  '{BASE_URL}/api/v1/kronos/gateways/{0}/config';

export const GET_LEDNODE_GROUP_LIST = '{BASE_URL}/lednode/group/growarea';
export const FIND_DEVICES_FOR_GROUP =
  '{BASE_URL}/lednode/group/devices/gateway';
export const CREATE_LED_GROUP = '{BASE_URL}/lednode/group';
export const UPDATE_LED_GROUP = '{BASE_URL}/lednode/group';
export const DELETE_LED_GROUP = '{BASE_URL}/lednode/group';
export const GET_INDIVIDUAL_GROUP = '{BASE_URL}/lednode/group';

export const CREATE_GROUP_PROFILE = '{BASE_URL}/lednode/group/profile';
export const GET_LEDNODE_GROUP_PROFILE_LIST = '{BASE_URL}/lednode/group';
export const DELETE_EVENT = '{BASE_URL}/lednode/group/profile/event';
export const DELETE_ALL_PROFILES = '{BASE_URL}/devices/ledNode/Profile/gateway';
export const DELETE_ALL_DESIRED_VALUE =
  '{BASE_URL}/devices/ledNode/desiredValue/gateway';
export const DELETE_ALL_CHANNEL_CONFIG =
  '{BASE_URL}/devices/ledNode/channelConfig/gateway';
export const DELETE_ALL_MAPPING = '{BASE_URL}/devices/propertyMapping/gateway';
export const DELETE_DEVICE_SECTION = '{BASE_URL}/devices/section/gateway';
export const DELETE_DEVICE_GATEWAY = '{BASE_URL}/devices/gateway';
export const DELETE_ALL_PROFILE_ALERTS = '{BASE_URL}/profilealert/gateway';
export const DELETE_ALL_GROWAREA_PROFILE = '{BASE_URL}/profile/growarea';
export const DELETE_ALL_GROW_SECTION = '{BASE_URL}/growsections/growSection';
export const DELETE_GROWAREA_GROUPS = '{BASE_URL}/lednode/gateway';

export const USER_LOGIN = '{BASE_URL}/users/login';
export const USER_LOGOUT = '{BASE_URL}/users/logout';
