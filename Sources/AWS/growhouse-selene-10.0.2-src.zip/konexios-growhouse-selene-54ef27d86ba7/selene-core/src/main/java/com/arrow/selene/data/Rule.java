package com.arrow.selene.data;

public class Rule extends BaseEntity {
	private static final long serialVersionUID = -789487206970685861L;

	private String ruleHid;
	private String ruleModel;

	public String getRuleHid() {
		return ruleHid;
	}

	public void setRuleHid(String ruleHid) {
		this.ruleHid = ruleHid;
	}

	public String getRuleModel() {
		return ruleModel;
	}

	public void setRuleModel(String ruleModel) {
		this.ruleModel = ruleModel;
	}

}
