package com.arrow.selene.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import com.arrow.selene.data.Rule;

public class RuleDao extends DaoAbstract<Rule> {

	private static final class SingletonHolder {
		static final RuleDao SINGLETON = new RuleDao();
	}

	public static RuleDao getInstance() {
		return SingletonHolder.SINGLETON;
	}

	private RuleDao() {
	}

	@Override
	protected int commonStatement(PreparedStatement stmt, Rule entity, int idx) throws SQLException {
		if (entity.getRuleHid() != null) {
			stmt.setString(++idx, entity.getRuleHid());
		} else {
			stmt.setNull(++idx, Types.VARCHAR);
		}
		if (entity.getRuleModel() != null) {
			stmt.setString(++idx, entity.getRuleModel());
		} else {
			stmt.setNull(++idx, Types.VARCHAR);
		}
		stmt.setLong(++idx, entity.getCreatedTs());
		stmt.setBoolean(++idx, entity.isEnabled());
		stmt.setLong(++idx, entity.getModifiedTs());

		return idx;
	}

	@Override
	protected Rule populate(ResultSet rset) throws SQLException {
		Rule entity = new Rule();
		entity.setId(rset.getLong("ID"));
		entity.setCreatedTs(rset.getLong("CREATEDTS"));
		entity.setEnabled(rset.getBoolean("ENABLED"));
		entity.setModifiedTs(rset.getLong("MODIFIEDTS"));
		entity.setRuleHid(rset.getString("RULEHID"));
		entity.setRuleModel(rset.getString("RULEMODEL"));
		return entity;
	}

	public Rule findByHid(String ruleHid) {
		return DaoManager.getInstance().execute(connection -> {
			PreparedStatement findByHid = connection.prepareStatement(getQueries().getProperty("findByHid"));
			findByHid.setString(1, ruleHid);
			try (PreparedStatement stmt = findByHid; ResultSet rset = stmt.executeQuery()) {
				return rset.next() ? populate(rset) : null;
			}
		});
	}

	public int delete(String hid) {
		return DaoManager.getInstance().execute(connection -> {
			try (PreparedStatement stmt = connection.prepareStatement(getQueries().getProperty("delete"))) {
				stmt.setString(1, hid);
				return stmt.executeUpdate();
			}
		});
	}
}
