package com.arrow.selene.data;

public enum MessageSeverity {
	INFO, WARNING, ERROR, TRACE, DEBUG
}
