package com.arrow.selene.edge.devicetwin;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.arrow.acs.Loggable;
import com.arrow.selene.data.Telemetry;
import com.arrow.selene.engine.state.StateUpdate;

public class ShadowManager extends Loggable {

	private Map<String, ShadowData> deviceShadow = new HashMap<>();

	public synchronized void createOrUpdateShadow(List<Telemetry> telemetries) {
		telemetries.forEach(telemetry -> {
			deviceShadow.put(telemetry.getName(), new ShadowData(telemetry));
		});
	}

	public synchronized void createOrUpdateShadow(StateUpdate states) {
		states.getStates().entrySet().forEach(e -> {
			deviceShadow.put(e.getKey(), new ShadowData(e.getValue()));
		});
	}

	public synchronized Map<String, ShadowData> getShadow() {
		return deviceShadow;
	}
}
