package com.arrow.selene.engine;

public interface RedisModule extends Module {
}
