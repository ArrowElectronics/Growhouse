package com.arrow.selene.engine;

public enum ModuleState {
    CREATED, STARTING, STARTED, STOPPING, STOPPED, ERROR
}
