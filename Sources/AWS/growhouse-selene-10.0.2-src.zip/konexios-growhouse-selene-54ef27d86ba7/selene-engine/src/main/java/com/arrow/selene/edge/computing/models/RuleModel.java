package com.arrow.selene.edge.computing.models;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class RuleModel implements Serializable {
	private static final long serialVersionUID = 4516055036672908223L;

	private String ruleHid;
	private String type;
	private String name;
	private long timeInterval;

	private List<MonitorModel> monitors;
	private List<ConditionModel> conditions;
	private Map<String, String> globalResponsePayload;

	public String getRuleHid() {
		return ruleHid;
	}

	public void setRuleHid(String ruleHid) {
		this.ruleHid = ruleHid;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getTimeInterval() {
		return timeInterval;
	}

	public void setTimeInterval(long timeInterval) {
		this.timeInterval = timeInterval;
	}

	public List<MonitorModel> getMonitors() {
		return monitors;
	}

	public void setMonitors(List<MonitorModel> monitors) {
		this.monitors = monitors;
	}

	public List<ConditionModel> getConditions() {
		return conditions;
	}

	public void setConditions(List<ConditionModel> conditions) {
		this.conditions = conditions;
	}

	public Map<String, String> getGlobalResponsePayload() {
		return globalResponsePayload;
	}

	public void setGlobalResponsePayload(Map<String, String> globalResponsePayload) {
		this.globalResponsePayload = globalResponsePayload;
	}

}
