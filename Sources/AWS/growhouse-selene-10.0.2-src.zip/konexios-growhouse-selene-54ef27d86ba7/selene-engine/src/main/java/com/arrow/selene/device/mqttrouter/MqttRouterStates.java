package com.arrow.selene.device.mqttrouter;

import com.arrow.selene.device.mqtt.MqttDeviceStates;

public class MqttRouterStates extends MqttDeviceStates {
	private static final long serialVersionUID = 1670632214431115545L;
}
