package com.arrow.selene.engine;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Objects;
import java.util.Properties;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.Validate;

import com.arrow.acn.client.ClientConstants;
import com.arrow.acn.client.api.AcnClient;
import com.arrow.acs.JsonUtils;
import com.arrow.acs.client.api.ApiConfig;
import com.arrow.acs.client.api.ConnectionManager;
import com.arrow.acs.client.model.VersionModel;
import com.arrow.pegasus.security.CryptoMode;
import com.arrow.selene.Loggable;
import com.arrow.selene.SeleneException;
import com.arrow.selene.dao.DaoManager;
import com.arrow.selene.device.self.NetworkIfaceConverter;
import com.arrow.selene.device.self.NetworkIfaceHolder;
import com.arrow.selene.device.self.SelfInfo;
import com.arrow.selene.device.self.SelfModule;
import com.arrow.selene.device.self.VersionModelHolderConverter;
import com.arrow.selene.engine.cloud.AwsModule;
import com.arrow.selene.engine.cloud.AzureModule;
import com.arrow.selene.engine.cloud.IbmModule;
import com.arrow.selene.engine.cloud.IotConnectModule;
import com.arrow.selene.engine.service.ConfigService;
import com.arrow.selene.engine.service.DeviceService;
import com.arrow.selene.engine.service.GatewayService;
import com.arrow.selene.engine.service.ModuleService;
import com.arrow.selene.service.CryptoService;

public class Engine extends Loggable {
	private Thread shutdownThread;
	private boolean shuttingDown;
	private ModuleService moduleService = ModuleService.getInstance();
	private AcnClient acnClient;

	private static class SingletonHolder {
		static final Engine SINGLETON = new Engine();
	}

	public static Engine getInstance() {
		return SingletonHolder.SINGLETON;
	}

	public void shutdown() {
		String method = "shutdown";
		shuttingDown = true;
		moduleService.stopAllModules();
		logInfo(method, "exiting ...");
	}

	public AcnClient getAcnClient() {
		Validate.notNull(acnClient, "acnClient is not initialized");
		return acnClient;
	}

	private void start() {
		String method = "start";
		try {
			logInfo(method, "SeleneEngineVersion: %s", printVersion(SeleneEngineVersion.get()));
			try {
				File file = new File("/opt/selene/selene_version");

				// Write Content
				FileWriter writer = new FileWriter(file);
				writer.write(printVersion(SeleneEngineVersion.get()));
				writer.close();
			} catch (Exception e) {
				logInfo(method, "%s", e.getMessage());
			}

			logInfo(method, "default crypto mode: %s", CryptoMode.AES_256.toString());
			CryptoService.getInstance().init(CryptoMode.AES_256.toString());

			ModuleStrategy moduleStrategy = ModuleStrategy
					.valueOf(ConfigService.getInstance().getEngineProperties().getModuleStrategy());
			logInfo(method, "modules loading strategy: %s", moduleStrategy.name());

			boolean selfModuleFound = false;
			if (moduleStrategy != ModuleStrategy.PROPERTIES && GatewayService.getInstance().findOne() != null) {
				selfModuleFound = initSelfModule(DeviceService.getInstance().find(SelfInfo.DEFAULT_DEVICE_TYPE).stream()
						.map(Utils::getProperties).collect(Collectors.toSet()));
			}
			if (!selfModuleFound) {
				selfModuleFound = initSelfModule(SelfModule.getInstance()
						.loadPropsFromFiles(DirectoryManager.getInstance().getDevices().getPath()));
			}
			if (selfModuleFound) {
				String apikey = SelfModule.getInstance().getProperties().getApiKey();
				String secretkey = SelfModule.getInstance().getProperties().getSecretKey();

				if ((StringUtils.isBlank(apikey)) || (StringUtils.isBlank(secretkey))) {
					logError(method, "could not found ApiKey or SecretKey..");
					throw new SeleneException("Fatal Error");
					// Crypto crypto = CryptoService.getInstance().getCrypto();
					// ApiConfig config = new
					// ApiConfig().withApiKey(SelfModule.getInstance().getProperties().getApiKey())
					// .withSecretkey(SelfModule.getInstance().getProperties().getSecretKey())
					// .withBaseUrl(SelfModule.getInstance().getProperties().getIotConnectUrl());

					// logInfo(method, "initializing acnClient ...");
					// acnClient = new AcnClient(config);
				} else {

					// Crypto crypto = CryptoService.getInstance().getCrypto();
					ApiConfig config = new ApiConfig().withApiKey(SelfModule.getInstance().getProperties().getApiKey())
							.withSecretkey(SelfModule.getInstance().getProperties().getSecretKey())
							.withBaseUrl(SelfModule.getInstance().getProperties().getIotConnectUrl());

					logInfo(method, "initializing acnClient ...");
					acnClient = new AcnClient(config);
				}
			} else {
				logError(method, "could not load SelfModule");
				throw new SeleneException("Fatal Error");
			}
		} catch (Exception e) {
			// shuttingDown = true;
			// shutdown();
			// System.exit(0);
			// throw new SeleneException("Fatal Error");
			// logInfo(method, "exception catched ...");
			logInfo(method, "force terminating ...");

			String cmd = "sudo systemctl stop selene";
			Runtime run = Runtime.getRuntime();
			Process pr = null;
			try {
				pr = run.exec(cmd);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			logInfo(method, "executed command...");
			try {
				pr.waitFor();
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
			logInfo(method, "terminated...");

		}

		// start self module first
		SelfModule self = SelfModule.getInstance();
		moduleService.startModule(self);

		logInfo(method, "waiting for system ready ...");
		self.waitForSystemReady();

		switch (self.getGateway().getCloudPlatform()) {
		case Aws:
			moduleService.registerModule(AwsModule.getInstance());
			break;
		case Azure:
			moduleService.registerModule(IotConnectModule.getInstance());
			moduleService.registerModule(AzureModule.getInstance());
			break;
		case Ibm:
			moduleService.registerModule(IotConnectModule.getInstance());
			moduleService.registerModule(IbmModule.getInstance());
			break;
		case IotConnect:
			moduleService.registerModule(IotConnectModule.getInstance());
			break;
		}

		logInfo(method, "starting all modules ...");
		moduleService.startAllModules();
	}

	private boolean initSelfModule(Set<Properties> properties) {
		String method = "initSelfModule";
		boolean result = false;
		for (Properties props : properties) {
			try {
				String deviceClass = Utils.getRequiredProperty(props, EngineConstants.DEVICE_CLASS);
				if (Objects.equals(deviceClass, SelfModule.class.getName())) {
					logInfo(method, "instantiating SelfModule: %s", deviceClass);
					SelfModule.getInstance().init(props);
					moduleService.registerModule(SelfModule.getInstance());
					result = true;
					break;
				}
			} catch (RuntimeException e) {
				logError(method, "error initializing SelModule", e);
			}
		}
		return result;
	}

	private void hookShutdown() {
		String method = "hookShutdown";
		logInfo(method, "installing hookShutdown ...");
		shutdownThread = new Thread(() -> {
			try {
				logInfo(method, "hookShutdown called");
				shutdown();
			} catch (Exception e) {
			}
		}, "shutdown thread");
		Runtime.getRuntime().addShutdownHook(shutdownThread);
	}

	private void waitForExit() {
		String method = "waitForExit";
		// infinite loop waiting for shutdown
		while (!shuttingDown) {
			try {
				Thread.sleep(5000L);
			} catch (Exception e) {
			}
		}

		if (shutdownThread != null && shutdownThread.isAlive()) {
			try {
				shutdownThread.join(ClientConstants.DEFAULT_SHUTDOWN_WAITING_MS);
			} catch (Exception e) {
			}
			shutdownThread = null;
		}
		logInfo(method, "terminated!");
	}

	private String printVersion(VersionModel model) {
		StringBuilder sb = new StringBuilder();
		sb.append(model.getMajor() != null ? model.getMajor() : "?");
		sb.append(".");
		sb.append(model.getMinor() != null ? model.getMinor() : "?");
		sb.append(".");
		sb.append(model.getBuild() != null ? model.getBuild() : "0");
		return sb.toString();
	}

	public static void main(String[] args) {
		try {
			DirectoryManager.getInstance().init();
			new Thread(() -> {
				CryptoService.getInstance();
			}).start();
			new Thread(() -> {
				DaoManager.getInstance();
			}).start();
			new Thread(() -> {
				ConnectionManager.getInstance();
			}).start();
			new Thread(() -> {
				ConvertUtils.register(new NetworkIfaceConverter(), NetworkIfaceHolder.class);
				ConvertUtils.register(new VersionModelHolderConverter(), VersionModelHolderConverter.class);
				JsonUtils.getObjectMapper();
			}).start();
			Engine engine = getInstance();
			engine.start();
			engine.hookShutdown();

			engine.waitForExit();

		} catch (Throwable t) {
			t.printStackTrace();
		}
		System.exit(0);
	}
}
