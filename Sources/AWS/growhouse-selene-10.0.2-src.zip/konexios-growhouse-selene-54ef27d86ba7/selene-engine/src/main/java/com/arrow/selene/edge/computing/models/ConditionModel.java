package com.arrow.selene.edge.computing.models;

import java.io.Serializable;
import java.util.List;

public class ConditionModel implements Serializable {
	private static final long serialVersionUID = -4681484911070675702L;

	private String expression;
	private List<ActionModel> actions;

	public String getExpression() {
		return expression;
	}

	public void setExpression(String expression) {
		this.expression = expression;
	}

	public List<ActionModel> getActions() {
		return actions;
	}

	public void setActions(List<ActionModel> actions) {
		this.actions = actions;
	}

}
