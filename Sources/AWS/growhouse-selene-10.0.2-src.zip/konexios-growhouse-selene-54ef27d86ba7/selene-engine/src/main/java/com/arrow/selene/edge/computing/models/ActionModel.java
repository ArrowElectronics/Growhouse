package com.arrow.selene.edge.computing.models;

import java.io.Serializable;
import java.util.List;

public class ActionModel implements Serializable {
	private static final long serialVersionUID = 8218326078308349312L;

	private String type;
	private String alertMessage;

	// For set_device_state
	private List<OperationModel> operations;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getAlertMessage() {
		return alertMessage;
	}

	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	public List<OperationModel> getOperations() {
		return operations;
	}

	public void setOperations(List<OperationModel> operations) {
		this.operations = operations;
	}

}
