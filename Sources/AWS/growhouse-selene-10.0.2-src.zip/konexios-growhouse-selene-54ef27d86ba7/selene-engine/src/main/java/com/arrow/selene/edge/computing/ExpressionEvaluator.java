package com.arrow.selene.edge.computing;

import java.util.Map;

import org.apache.commons.jexl3.JexlBuilder;
import org.apache.commons.jexl3.JexlContext;
import org.apache.commons.jexl3.JexlEngine;
import org.apache.commons.jexl3.JexlExpression;
import org.apache.commons.jexl3.MapContext;

import com.arrow.selene.Loggable;
import com.arrow.selene.SeleneException;

public class ExpressionEvaluator {
	private static JexlEngine jexlEngine = new JexlBuilder().strict(true).silent(false).create();
	private static final Loggable LOGGER = new Loggable();

	public static boolean evaluate(String expression, Map<String, Object> map) {
		String method = "evaluate";
		LOGGER.logInfo(method, "Expresssion :: %s", expression);
		JexlExpression expr = jexlEngine.createExpression(expression);
		JexlContext ctx = new MapContext();
		map.entrySet().forEach(e -> ctx.set(e.getKey(), e.getValue()));
		LOGGER.logInfo(method, "Map Context :: %s", ctx.toString());
		try {
			Object result = expr.evaluate(ctx);
			if (result instanceof Boolean) {
				LOGGER.logInfo(method, "Result === %b", result);
				return (boolean) result;
			} else {
				LOGGER.logError(method, "Result of expression is not boolean! Result : %s", result.toString());
				throw new SeleneException("Expression (" + expression + ") cannot be evaluated to boolean value!");
			}
		} catch (Exception e) {
			LOGGER.logError(method, "Device information is not available to evaluate expression : %s", expression);
			throw new SeleneException("Device information is not available");
		}

	}
}
