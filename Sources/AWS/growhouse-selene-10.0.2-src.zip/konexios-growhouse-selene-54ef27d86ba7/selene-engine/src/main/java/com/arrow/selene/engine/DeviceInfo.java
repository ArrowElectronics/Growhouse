package com.arrow.selene.engine;

import java.beans.PropertyDescriptor;
import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.PropertyUtils;

import com.arrow.selene.SeleneException;

public class DeviceInfo implements Serializable {
	private static final long serialVersionUID = -6339858783115576156L;
	private static final String INFO = "info";

	private String name;
	private String uid;
	private String type;
	private String deviceClass;
	private String hid;
	private Map<String, String> info = new LinkedHashMap<>();
	private String softwareVersion;
	private String softwareName;
	private boolean isFOTAPerformed;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getDeviceClass() {
		return deviceClass;
	}

	public void setDeviceClass(String deviceClass) {
		this.deviceClass = deviceClass;
	}

	public String getHid() {
		return hid;
	}

	public void setHid(String hid) {
		this.hid = hid;
	}

	public Map<String, String> getInfo() {
		return info;
	}

	public void setInfo(Map<String, String> info) {
		this.info = info;
	}

	public String getSoftwareVersion() {
		return softwareVersion;
	}

	public void setSoftwareVersion(String softwareVersion) {
		this.softwareVersion = softwareVersion;
	}

	public String getSoftwareName() {
		return softwareName;
	}

	public void setSoftwareName(String softwareName) {
		this.softwareName = softwareName;
	}

	public boolean isFOTAPerformed() {
		return isFOTAPerformed;
	}

	public void setFOTAPerformed(boolean isFOTAPerformed) {
		this.isFOTAPerformed = isFOTAPerformed;
	}

	public Map<String, String> exportInfo() {
		try {
			Map<String, String> map = BeanUtils.describe(this);
			map.remove(INFO);
			map.putAll(info);
			return map;
		} catch (Exception e) {
			throw new SeleneException("Error exporting info", e);
		}
	}

	public void importInfo(Map<String, String> map) {
		try {
			for (PropertyDescriptor propertyDescriptor : PropertyUtils.getPropertyDescriptors(this)) {
				String value = map.remove(propertyDescriptor.getName());
				BeanUtils.setProperty(this, propertyDescriptor.getName(), value);
			}
			BeanUtils.setProperty(this, INFO, map);
		} catch (Exception e) {
			throw new SeleneException("Error importing info", e);
		}
	}
}
