package com.arrow.selene.device.mqttrouter;

import java.util.List;
import java.util.Map;

public class DeviceRegistrationInfo {

	private String deviceUid;
	private String deviceName;
	private String deviceType;
	private List<Map<String, ?>> properties;
	private Map<?, ?> metadata;
	private String softwareRelease;
	private String softwareName;
	private String softwareVersion;

	public String getDeviceUid() {
		return deviceUid;
	}

	public void setDeviceUid(String deviceUid) {
		this.deviceUid = deviceUid;
	}

	public String getDeviceName() {
		return deviceName;
	}

	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}

	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

	public List<Map<String, ?>> getProperties() {
		return properties;
	}

	public void setProperties(List<Map<String, ?>> properties) {
		this.properties = properties;
	}

	public Map<?, ?> getMetadata() {
		return metadata;
	}

	public void setMetadata(Map<?, ?> metadata) {
		this.metadata = metadata;
	}

	public String getSoftwareRelease() {
		return softwareRelease;
	}

	public void setSoftwareRelease(String softwareRelease) {
		this.softwareRelease = softwareRelease;
	}

	public String getSoftwareName() {
		return softwareName;
	}

	public void setSoftwareName(String softwareName) {
		this.softwareName = softwareName;
	}

	public String getSoftwareVersion() {
		return softwareVersion;
	}

	public void setSoftwareVersion(String softwareVersion) {
		this.softwareVersion = softwareVersion;
	}

}
