package com.arrow.selene.device.mqttrouter;

import com.arrow.selene.engine.DeviceInfo;

public class MqttRouterDeviceInfo extends DeviceInfo {
	private static final long serialVersionUID = -5690541334879572167L;
	public static final String DEFAULT_DEVICE_TYPE = "MqttRouterDevice";

	// public MqttRouterDeviceInfo() {
	// setType(DEFAULT_DEVICE_TYPE);
	// setDeviceClass(MqttRouterDeviceModule.class.getCanonicalName());
	// setName("MqttRouterDevice");
	// setUid(SelfModule.getInstance().getGateway().getUid() + "_" +
	// DEFAULT_DEVICE_TYPE);
	// }

}
