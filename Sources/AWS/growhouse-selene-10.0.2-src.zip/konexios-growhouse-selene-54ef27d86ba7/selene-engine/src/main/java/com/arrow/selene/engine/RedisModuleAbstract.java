package com.arrow.selene.engine;

import java.nio.charset.StandardCharsets;
import java.util.List;

import org.apache.commons.lang3.Validate;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

public abstract class RedisModuleAbstract extends ModuleAbstract implements RedisModule {
    private JedisPool jedisPool;
    private RedisListener listener;

    public RedisModuleAbstract() {
        jedisPool = new JedisPool();
        listener = new RedisListener();
    }

    @Override
    public void start() {
        String method = "RedisModuleAbstract.start";
        logInfo(method, "starting ...");
        super.start();
        logInfo(method, "started");
        setState(ModuleState.STARTED);
    }

    @Override
    public void stop() {
        super.stop();

        String method = "ListenerAbstract.stop";
        logInfo(method, "stopping ...");

        if (jedisPool != null) {
            try {
                logInfo(method, "destroying jedisPool ...");
                jedisPool.destroy();
            } catch (Throwable t) {
            }
            jedisPool = null;
        }

        if (listener != null && listener.isAlive()) {
            try {
                listener.interrupt();
                listener.join(1000);
            } catch (Exception e) {
            }
            listener = null;
        }

        logInfo(method, "shutdown complete");
    }

    protected void startRedisSubscriber() {
        String method = "startSubscriber";
        final String queue = getSubscriberQueue();
        Validate.notEmpty(queue, "subscriberQueue is empty!");

        logInfo(method, "starting listener ...");
        listener.start();
    }

    protected void processRedisMessage(String queue, byte[] message) {
        String method = "processRedisMessage";
        logInfo(method, "received message from queue %s: %d", queue, message.length);
    }

    protected JedisPool getJedisPool() {
        return jedisPool;
    }

    protected abstract String getSubscriberQueue();

    private class RedisListener extends Thread {
        @Override
        public void run() {
            String method = "RedisListener.run";
            logInfo(method, "waiting for new message ...");
            while (!isShuttingDown()) {
                try (Jedis jedis = getJedisPool().getResource()) {
                    List<byte[]> result = jedis.blpop(10, getSubscriberQueue().getBytes(StandardCharsets.UTF_8));
                    if (result != null && !result.isEmpty()) {
                        String queue = new String(result.get(0), StandardCharsets.UTF_8);
                        byte[] message = result.get(1);
                        processRedisMessage(queue, message);
                        // getService().submit(new Runnable() {
                        // @Override
                        // public void run() {
                        // processRedisMessage(queue, message);
                        // }
                        // });
                    }
                } catch (Exception e) {
                    if (!isShuttingDown()) {
                        logError(method, "error polling messages", e);
                    }
                }
            }
        }
    }
}
