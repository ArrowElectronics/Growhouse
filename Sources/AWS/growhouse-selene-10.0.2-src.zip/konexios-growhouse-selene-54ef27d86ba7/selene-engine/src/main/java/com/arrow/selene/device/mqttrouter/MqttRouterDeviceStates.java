package com.arrow.selene.device.mqttrouter;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import org.apache.commons.beanutils.BeanUtils;

import com.arrow.acs.JsonUtils;
import com.arrow.selene.SeleneException;
import com.arrow.selene.engine.EngineConstants;
import com.arrow.selene.engine.state.DeviceStates;
import com.arrow.selene.engine.state.State;

public class MqttRouterDeviceStates extends DeviceStates {
	private static final long serialVersionUID = 2007776204901287073L;

	private Map<String, State> deviceStates = new HashMap<>();

	@Override
	public Map<String, String> importStates(Map<String, State> states) {
		Map<String, String> result = new HashMap<>();
		Map<String, String> currentStates = exportStates();

		for (Entry<String, ? extends State> entry : states.entrySet()) {
			State state = new State();
			try {
				BeanUtils.populate(state,
				        JsonUtils.fromJson(currentStates.get(entry.getKey()), EngineConstants.MAP_TYPE_REF));
				if (!Objects.equals(state.getValue(), entry.getValue().getValue())) {
					result.put(entry.getKey(), entry.getValue().getValue());
				}
			} catch (Exception e) {
				throw new SeleneException("unable to compering currentState value with new State", e);
			}
		}
		try {
			updateState(states);
		} catch (Exception e) {
			throw new SeleneException("Error importing states", e);
		}
		return result;
	}

	public void updateState(Map<String, State> states) {
		states.entrySet().stream().filter(state -> deviceStates.containsKey(state.getKey()))
		        .forEach(state -> deviceStates.put(state.getKey(), state.getValue()));
	}

	@Override
	public Map<String, String> exportStates() {
		try {
			return deviceStates.entrySet().stream()
			        .collect(Collectors.toMap((entry -> entry.getKey()), (entry -> entry.getValue().toString())));
		} catch (Exception e) {
			throw new SeleneException("Error exporting states", e);
		}
	}

	public Map<String, State> extractStates(Map<String, String> stateChangeProperties) {

		List<String> availableProperties = stateChangeProperties.keySet().stream()
		        .filter(propertyName -> deviceStates.containsKey(propertyName)).collect(Collectors.toList());

		return availableProperties.stream()
		        .filter(propertyName -> !Objects.equals(stateChangeProperties.get(propertyName),
		                deviceStates.get(propertyName).getValue()))
		        .collect(Collectors.toMap(s -> s, s -> new State().withValue(stateChangeProperties.get(s))));
	}

	public Map<String, State> getDeviceStates() {
		return deviceStates;
	}

	public void setDeviceStates(Map<String, State> deviceStates) {
		this.deviceStates = deviceStates;
	}

	public void addDeviceStates(String propertyName) {
		deviceStates.put(propertyName, new State());
	}
}
