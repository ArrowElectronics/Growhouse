package com.arrow.selene.device.edge;

import com.arrow.selene.device.self.SelfModule;
import com.arrow.selene.engine.DeviceInfo;

public class RuleEngineInfo extends DeviceInfo {
	public static final String DEFAULT_DEVICE_TYPE = "edge_rule";
	private static final long serialVersionUID = -6586224013064209367L;

	public RuleEngineInfo() {
		setType(DEFAULT_DEVICE_TYPE);
		setDeviceClass(RuleEngineModule.class.getCanonicalName());
		setName("Rule Engine");
		setUid(SelfModule.getInstance().getGateway().getUid() + "_" + DEFAULT_DEVICE_TYPE);
	}
}
