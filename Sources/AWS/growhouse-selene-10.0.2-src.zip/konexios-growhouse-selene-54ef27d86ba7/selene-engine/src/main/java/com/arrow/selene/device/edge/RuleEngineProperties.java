package com.arrow.selene.device.edge;

import com.arrow.selene.engine.DeviceProperties;

public class RuleEngineProperties extends DeviceProperties {
	private static final long serialVersionUID = 5803104520737366341L;

	public RuleEngineProperties() {
		setEnabled(true);
	}
}
