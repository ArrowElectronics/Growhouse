package com.arrow.selene.device.edge;

import java.util.Map;

import com.arrow.acs.JsonUtils;
import com.arrow.selene.SeleneException;
import com.arrow.selene.edge.computing.RuleAlertProcessor;
import com.arrow.selene.edge.computing.RuleManager;
import com.arrow.selene.edge.computing.models.RuleModel;
import com.arrow.selene.engine.DeviceModuleAbstract;
import com.arrow.selene.model.StatusModel;
import com.fasterxml.jackson.core.type.TypeReference;

public class RuleEngineModule
        extends DeviceModuleAbstract<RuleEngineInfo, RuleEngineProperties, RuleEngineStates, RuleEngineData>
        implements RuleAlertProcessor {
	private static String PAYLOAD_PROPERTY_NAME = "payload";
	private static TypeReference<Map<String, String>> mapTypeRef;

	private static final StatusModel COMMAND_NOT_SUPPORTED = new StatusModel().withStatus("ERROR")
	        .withMessage("Command is not supported");
	private static final StatusModel COMMAND_SUCCESS = new StatusModel().withStatus("OK")
	        .withMessage("Rule processed successfully");

	// private static class SingletonHolder {
	// static final RuleEngineModule SINGLETON = new RuleEngineModule();
	// }
	//
	// public static RuleEngineModule getInstance() {
	// return SingletonHolder.SINGLETON;
	// }

	public RuleEngineModule() {
		logInfo("RuleEngineModule", "Constructed!");
	}

	@Override
	protected RuleEngineProperties createProperties() {
		return new RuleEngineProperties();
	}

	@Override
	protected RuleEngineInfo createInfo() {
		return new RuleEngineInfo();
	}

	@Override
	protected RuleEngineStates createStates() {
		return new RuleEngineStates();
	}

	@Override
	public StatusModel performCommand(byte... bytes) {
		String method = "performCommand";
		logInfo(method, "command received");
		try {
			Map<String, String> params = JsonUtils.fromJsonBytes(bytes, getMapTypeRef());
			logInfo(method, "Message ::: %s", params.toString());

			RuleModel ruleModel = JsonUtils.fromJson(params.get(PAYLOAD_PROPERTY_NAME), RuleModel.class);

			RuleManager.getInstance().processRule(ruleModel);
			return COMMAND_SUCCESS;

		} catch (

		SeleneException e) {
			logError(method, e);
			return new StatusModel().withStatus("ERROR").withMessage(e.getMessage());

		} catch (Exception e) {
			logError(method, e);
			return COMMAND_NOT_SUPPORTED;
		}
	}

	@Override
	public void start() {
		logInfo("start", "Start function is called!");
		super.start();
		// String msg =
		// "{\"id\":\"5bb1d5f107229b959875d756\",\"createdDate\":\"2018-10-01T08:08:17.407Z\",\"createdBy\":\"5ac37314cca6f42ca0c3beed\",\"name\":\"Hero123\",\"timeInterval\":10,\"enabled\":true,\"monitors\":[{\"gatewayHid\":\"02d7cfe192fea5cb121dac21fa43fd98a12083c7\",\"deviceHids\":[\"c7682939eb4cd2cfc7dd5243fc4d1123bd0d7abc\"]}],\"conditions\":[{\"expression\":\"c7682939eb4cd2cfc7dd5243fc4d1123bd0d7abc.strVal
		// ==
		// /home/ashutosh/Videos/arrow/selene/selene-web\",\"actions\":[{\"type\":\"send_alarm\",\"responsePayload\":\"Hello
		// world\"}]}],\"ruleHid\":\"36eb3b3deb56828753caef59f80d56912333f061\",\"type\":\"CREATE\"}";
		// RuleModel ruleModel = JsonUtils.fromJson(msg, RuleModel.class);
		// RuleManager.getInstance().processRule(ruleModel);
		try {
			RuleManager.getInstance().setAlertProcessor(this, getInfo().getUid());
		} catch (Exception e) {
			logError("start", e);
		}
	}

	private static TypeReference<Map<String, String>> getMapTypeRef() {
		return mapTypeRef != null ? mapTypeRef : (mapTypeRef = new TypeReference<Map<String, String>>() {
		});
	}

	@Override
	public void processAlert(RuleEngineData alertModel) {
		// logInfo("processAlert", "Received alert model :: %s",
		// JsonUtils.toJson(alertModel));
		queueDataForSending(alertModel, true);
	}
}
