package com.arrow.selene.engine.service;

import java.io.File;
import java.nio.charset.StandardCharsets;

import org.apache.commons.io.FileUtils;

import com.arrow.acn.client.model.aws.ConfigModel;
import com.arrow.selene.data.Aws;
import com.arrow.selene.engine.EngineConstants;
import com.arrow.selene.service.CryptoService;

public class AwsService extends com.arrow.selene.service.AwsService {

	private static class SingletonHolder {
		static final AwsService SINGLETON = new AwsService();
	}

	public static AwsService getInstance() {
		return SingletonHolder.SINGLETON;
	}

	public Aws upsert(ConfigModel model) {
		String method = "upsert";

		boolean insert = false;
		Aws aws = findOne();
		if (aws == null) {
			aws = new Aws();
			insert = true;
		}

		// populate data
		aws = populate(aws, model);

		// default to enabled
		aws.setEnabled(true);

		if (insert) {
			getAwsDao().insert(aws);
			logInfo(method, "inserted aws record, host: %s", aws.getHost());
		} else {
			getAwsDao().update(aws);
			logInfo(method, "updated  aws record, host: %s", aws.getHost());
		}

		// growhouse - save certs to local files
		try {
			File dir = new File(EngineConstants.DEFAULT_AWS_CONFIG_DIR);
			logInfo(method, "mkdirs: %s", dir.mkdirs());
			if (dir.exists() && dir.isDirectory()) {
				logInfo(method, "writing ca cert ...");
				FileUtils.write(new File(dir, "ca.pem"), model.getCaCert(), StandardCharsets.UTF_8);
				logInfo(method, "writing client cert ...");
				FileUtils.write(new File(dir, "client.pem"), model.getClientCert(), StandardCharsets.UTF_8);
				logInfo(method, "writing private key ...");
				FileUtils.write(new File(dir, "private.pem"), model.getPrivateKey(), StandardCharsets.UTF_8);
			} else {
				logError(method, "invalid AWS configuration directory: %s", EngineConstants.DEFAULT_AWS_CONFIG_DIR);
			}
		} catch (Exception e) {
			logError(method, e);
		}

		return aws;
	}

	public void checkAndDisable() {
		String method = "checkAndDisable";
		Aws aws = findOne();
		if (aws != null && aws.isEnabled()) {
			aws.setEnabled(false);
			getAwsDao().update(aws);
			logInfo(method, "set AWS profile to disabled");
		}
	}

	private Aws populate(Aws aws, ConfigModel model) {
		aws.setHost(model.getHost());
		aws.setPort(model.getPort());
		CryptoService crypto = getCryptoService();
		aws.setRootCert(crypto.encrypt(model.getCaCert()));
		aws.setClientCert(crypto.encrypt(model.getClientCert()));
		aws.setPrivateKey(crypto.encrypt(model.getPrivateKey()));
		return aws;
	}
}
