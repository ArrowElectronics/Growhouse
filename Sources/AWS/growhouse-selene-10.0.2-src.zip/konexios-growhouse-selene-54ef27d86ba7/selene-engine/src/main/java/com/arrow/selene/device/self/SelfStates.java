package com.arrow.selene.device.self;

import com.arrow.selene.engine.state.DeviceStates;

public class SelfStates extends DeviceStates {
	private static final long serialVersionUID = -436519396208032749L;
}
