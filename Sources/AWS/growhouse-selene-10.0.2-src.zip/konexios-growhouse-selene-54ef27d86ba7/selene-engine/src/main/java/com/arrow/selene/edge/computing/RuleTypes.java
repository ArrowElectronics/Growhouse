package com.arrow.selene.edge.computing;

public interface RuleTypes {
	public String CREATE = "CREATE";
	public String DELETE = "DELETE";
	public String ENABLE = "ENABLE";
	public String DISABLE = "DISABLE";
	public String UPDATE = "UPDATE";

}
