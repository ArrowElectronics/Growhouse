import { Component, OnInit, ViewChild } from "@angular/core";
import { FormControl, FormGroup, Validators } from "@angular/forms";
import { ActivatedRoute, Params, Router } from "@angular/router";
import { DataTableDirective } from "angular-datatables";
import { Moment } from "moment";
import { BreadcrumbsService } from "ng6-breadcrumbs";
import { ToastrService } from "ngx-toastr";
import { Subject } from "rxjs";
import { ValidationPatterns } from "src/app/global";
import { Container } from "../models/container.model";
import { Facility } from "../models/facility.model";
import { Group } from "../models/group.model";
import { GrowArea } from "../models/growarea.model";
import { User } from "../models/user.model";
import { ContainerService } from "../services/container-service";
import { DeviceService } from "../services/device-service";
import { FacilityService } from "../services/facility-service";
import { GlobalService } from "../services/global-service";
import { GroupService } from "../services/group-service";
import { GrowAreaService } from "../services/growarea-service";
import { LedProfileService } from "../services/ledprofile-service";
declare var $: any;

@Component({
  selector: "app-led-profiles",
  templateUrl: "./led-profiles.component.html",
  styleUrls: ["./led-profiles.component.css"],
})
export class LedProfilesComponent implements OnInit {
  uiTimeFormat = "HH:mm";
  dtOptions: any = {};
  dtTrigger: Subject<any> = new Subject();
  @ViewChild(DataTableDirective)
  private datatableElement: DataTableDirective;
  selectedGrowArea: GrowArea;
  selectedFacility: Facility;
  selectedContainer: Container;
  selectedGroup: Group;
  loggedInUser: User;
  selectedProfile;
  profiles = [];
  isProfilesLoad = false;
  isApiLoading = false;
  isEditProfile = false;
  delete = false;
  deleteProfile;
  addProfileForm: FormGroup;
  addChannelValuesForm: FormGroup;
  sceduleProfileForm: FormGroup;
  selectedProfileFlag = false;
  applyProfile = null;
  devices: any[];
  addedDevices = [];
  remainingDevices = [];
  selectedDevices = [];
  startSelected: { start: Moment };
  endSelected: { start: Moment };
  repeatList = [
    "Every Day",
    "Every Sunday",
    "Every Monday",
    "Every Tuesday",
    "Every Wednesday",
    "Every Thursday",
    "Every Friday",
    "Every Saturday",
  ];
  selectedDate = true;
  startDate: any = null;
  endDate: any = null;
  constructor(
    private growareaService: GrowAreaService,
    private toastrService: ToastrService,
    private groupService: GroupService,
    private ledProfileService: LedProfileService,
    private containerService: ContainerService,
    private facilityService: FacilityService,
    private route: ActivatedRoute,
    private breadcrumbService: BreadcrumbsService,
    private deviceService: DeviceService,
    private router: Router,
    private globalService: GlobalService
  ) {}

  ngOnInit() {
    this.breadcrumbService.store([
      { label: "Profiles", url: "/profiles", params: [] },
    ]);
    const elem = document.getElementById("headerMenuCollapse");
    if (elem) {
      elem.classList.remove("show");
    }
    // datatable options for facility table
    this.loggedInUser = JSON.parse(localStorage.getItem("loggedInUser"));
    this.dtOptions = {
      pagingType: "full_numbers",
      pageLength: 10,
      info: false,
      order: [],
      lengthChange: false,
      select: true,
      language: {
        zeroRecords: "No Profiles to display",
        paginate: {
          next: ">", // or '→'
          previous: "<", // or '←',
        },
      },
    };
    this.groupService.selectedGroup.subscribe((group: Group) => {
      this.selectedGroup = group;
    });
    this.ledProfileService.selectedProfile.subscribe((profile) => {
      this.selectedProfile = profile;
    });
    this.route.params.subscribe((params: Params) => {
      console.log(params);
      if (
        params.facilityId &&
        params.containerId &&
        params.growareaId &&
        params.groupId
      ) {
        console.log("Params" + JSON.stringify(params));
        this.getFacilityById(
          params.facilityId,
          params.containerId,
          params.growareaId,
          params.groupId
        );
        this.getProfiles(params.groupId);
      } else if (params.facilityId && params.growareaId && params.groupId) {
        console.log("Params" + JSON.stringify(params));
        this.getFacilityById(
          params.facilityId,
          undefined,
          params.growareaId,
          params.groupId
        );
        this.getProfiles(params.groupId);
      } else if (params.containerId && params.growareaId && params.groupId) {
        console.log("Params" + JSON.stringify(params));
        this.getContainerById(
          params.containerId,
          params.growareaId,
          params.groupId
        );
        this.getProfiles(params.groupId);
      } else if (params.growareaId && params.groupId) {
        console.log("Params" + JSON.stringify(params));
        this.getGrowareaById(params.growareaId, params.groupId);
        this.getProfiles(params.groupId);
      } else {
        console.log("Params" + JSON.stringify(params));
        this.getProfiles(params.groupId);
      }
    });
    this.onNewProfile();
  }
  getProfiles(groupId) {
    this.profiles = [];
    this.isProfilesLoad = true;
    console.log(groupId);
    this.ledProfileService.getProfilesByGroupId(groupId).subscribe(
      (response: any[]) => {
        setTimeout(() => {
          console.log(response);
          this.profiles = response;
          this.dtTrigger.next();
        }, 500);
        this.isProfilesLoad = false;
      },
      (error) => {
        console.log("Error" + JSON.stringify(error));
        this.isProfilesLoad = false;
      }
    );
  }
  onNewProfile() {
    this.isEditProfile = false;
    this.addProfileForm = new FormGroup({
      id: new FormControl(null, []),
      led_profile_name: new FormControl(null, [
        Validators.required,
        Validators.maxLength(25),
        Validators.pattern(ValidationPatterns.username),
      ]),
      description: new FormControl(null, [Validators.maxLength(200)]),
    });
    this.addChannelValuesForm = new FormGroup({
      CH1: new FormControl(0, []),
      CH2: new FormControl(0, []),
      CH3: new FormControl(0, []),
      CH4: new FormControl(0, []),
      CH5: new FormControl(0, []),
      CH6: new FormControl(0, []),
    });
    console.log(this.addChannelValuesForm.value);
  }
  onEditProfile(profile) {
    this.isEditProfile = true;
    this.addProfileForm.patchValue({
      led_profile_name: profile.led_profile_name,
      id: profile.id,
      description: profile.description,
    });
    this.addChannelValuesForm.patchValue({
      CH1: profile.channel_values.CH1,
      CH2: profile.channel_values.CH2,
      CH3: profile.channel_values.CH3,
      CH4: profile.channel_values.CH4,
      CH5: profile.channel_values.CH5,
      CH6: profile.channel_values.CH6,
    });
  }
  onDeletChanges(profile) {
    this.delete = true;
    console.log("OnDeletChanges called");
    this.deleteProfile = profile;
  }
  getFacilityById(id, containerId, growareaId, groupId) {
    this.facilityService.getFacilityById(id).subscribe((response: Facility) => {
      this.selectedFacility = response;
      if (containerId && growareaId && groupId) {
        this.getContainerById(containerId, growareaId, groupId);
      } else if (containerId) {
        this.getContainerById(containerId, undefined, undefined);
      } else {
        this.getGrowareaById(growareaId, groupId);
      }
    });
  }
  onProfileRowSelected(profile) {
    this.selectedProfileFlag = true;
    if (!this.isProfilesLoad) {
      this.selectedProfile = profile;
      this.router.navigate([this.selectedProfile.id], {
        relativeTo: this.route,
      });
    }
  }
  getContainerById(containerId, growareaId, groupId) {
    this.containerService
      .getContainerById(containerId)
      .subscribe((response: Container) => {
        this.selectedContainer = response;
        this.getGrowareaById(growareaId, groupId);
      });
  }
  getGrowareaById(growareaId, groupId) {
    this.growareaService
      .getGrowAreaById(growareaId)
      .subscribe((response: GrowArea) => {
        this.selectedGrowArea = response;
        this.getGroupByGroupId(groupId);
      });
  }
  getGroupByGroupId(groupId) {
    this.groupService
      .getGroupByGroupId(groupId)
      .subscribe((response: Group) => {
        this.selectedGroup = response;
        console.log(this.selectedGrowArea);
        this.groupService.selectedGroup.emit(this.selectedGroup);
        if (
          this.selectedFacility &&
          this.selectedContainer &&
          this.selectedGrowArea &&
          this.selectedGroup
        ) {
          this.breadcrumbService.store([
            { label: "Facilities", url: "/facilities", params: [] },
            {
              label: this.selectedFacility.facility_name,
              url: "/facilities/" + this.selectedFacility.id,
              params: [],
            },
            {
              label: "Containers",
              url: "/facilities/" + this.selectedFacility.id + "/containers",
              params: [],
            },
            {
              label: this.selectedContainer.container_name + "",
              url:
                "/facilities/" +
                this.selectedFacility.id +
                "/containers/" +
                this.selectedContainer.id,
              params: [],
            },
            {
              label: "Grow Areas",
              url:
                "/facilities/" +
                this.selectedFacility.id +
                "/containers/" +
                this.selectedContainer.id +
                "/grow-areas",
              params: [],
            },
            {
              label: this.selectedGrowArea.grow_area_name + "",
              url:
                "/facilities/" +
                this.selectedFacility.id +
                "/containers/" +
                this.selectedContainer.id +
                "/grow-areas/" +
                this.selectedGrowArea.id,
              params: [],
            },
            {
              label: "Groups",
              url:
                "/facilities/" +
                this.selectedFacility.id +
                "/containers/" +
                this.selectedContainer.id +
                "/grow-areas/" +
                this.selectedGrowArea.id +
                "/groups",
              params: [],
            },
            {
              label: this.selectedGroup.group_name + "",
              url:
                "/facilities/" +
                this.selectedFacility.id +
                "/containers/" +
                this.selectedContainer.id +
                "/grow-areas/" +
                this.selectedGrowArea.id +
                "/groups/" +
                this.selectedGroup.id,
              params: [],
            },
            { label: "Profiles", url: "", params: [] },
          ]);
        } else if (
          this.selectedFacility &&
          this.selectedGrowArea &&
          this.selectedGroup
        ) {
          this.breadcrumbService.store([
            { label: "Facilities", url: "/facilities", params: [] },
            {
              label: this.selectedFacility.facility_name,
              url: "/facilities/" + this.selectedFacility.id,
              params: [],
            },
            {
              label: "Grow Areas",
              url: "/facilities/" + this.selectedFacility.id + "/grow-areas",
              params: [],
            },
            {
              label: this.selectedGrowArea.grow_area_name + "",
              url:
                "/facilities/" +
                this.selectedFacility.id +
                "/grow-areas/" +
                this.selectedGrowArea.id,
              params: [],
            },
            {
              label: "Groups",
              url:
                "/facilities/" +
                this.selectedFacility.id +
                "/grow-areas/" +
                this.selectedGrowArea.id +
                "/groups",
              params: [],
            },
            {
              label: this.selectedGroup.group_name + "",
              url:
                "/facilities/" +
                this.selectedFacility.id +
                "/grow-areas/" +
                this.selectedGrowArea.id +
                "/groups/" +
                this.selectedGroup.id,
              params: [],
            },
            { label: "Profiles", url: "", params: [] },
          ]);
        } else if (
          this.selectedContainer &&
          this.selectedGrowArea &&
          this.selectedGroup
        ) {
          this.breadcrumbService.store([
            { label: "Containers", url: "/containers", params: [] },
            {
              label: this.selectedContainer.container_name + "",
              url: "/containers/" + this.selectedContainer.id,
              params: [],
            },
            {
              label: "Grow Areas",
              url: "/containers/" + this.selectedContainer.id + "/grow-areas",
              params: [],
            },
            {
              label: this.selectedGrowArea.grow_area_name + "",
              url:
                "/containers/" +
                this.selectedContainer.id +
                "/grow-areas/" +
                this.selectedGrowArea.id,
              params: [],
            },
            {
              label: "Groups",
              url:
                "/containers/" +
                this.selectedContainer.id +
                "/grow-areas/" +
                this.selectedGrowArea.id +
                "/groups",
              params: [],
            },
            {
              label: this.selectedGroup.group_name + "",
              url:
                "/containers/" +
                this.selectedContainer.id +
                "/grow-areas/" +
                this.selectedGrowArea.id +
                "/groups/" +
                this.selectedGroup.id,
              params: [],
            },
            { label: "Profiles", url: "", params: [] },
          ]);
        } else if (this.selectedGrowArea && this.selectedGroup) {
          this.breadcrumbService.store([
            {
              label: "Grow Areas",
              url: "/grow-areas",
              params: [],
            },
            {
              label: this.selectedGrowArea.grow_area_name + "",
              url: "/grow-areas/" + this.selectedGrowArea.id,
              params: [],
            },
            {
              label: "Groups",
              url: "/grow-areas/" + this.selectedGrowArea.id + "/groups",
              params: [],
            },
            {
              label: this.selectedGroup.group_name + "",
              url:
                "/grow-areas/" +
                this.selectedGrowArea.id +
                "/groups/" +
                this.selectedGroup.id,
              params: [],
            },
            { label: "Profiles", url: "", params: [] },
          ]);
        } else {
          this.breadcrumbService.store([
            { label: "Profiles", url: "", params: [] },
          ]);
        }
        this.addReloadEventToBreadcrumb();
      });
  }
  addReloadEventToBreadcrumb() {
    setTimeout(() => {
      const elems = document.querySelectorAll(".breadcrumb-item a");
      console.log(elems);
      console.log("length     ", elems.length);
      for (let i = 0; i < elems.length; i++) {
        elems[i].addEventListener("click", this.globalService.handleClick);
      }
    }, 100);
  }
  removeData() {
    this.addProfileForm.reset();
    this.addChannelValuesForm.reset();
    this.isApiLoading = false;
    this.isEditProfile = false;
    $("#myModal").modal("hide");
  }
  disableSave() {
    const flag = true;
    if (this.addProfileForm && this.addChannelValuesForm) {
      if (!this.addProfileForm.valid || !this.addChannelValuesForm.valid) {
        return flag;
      } else {
        return false;
      }
    }
    return flag;
  }
  onAddProfileSubmit() {
    console.log(this.addChannelValuesForm.value);
    console.log(this.addProfileForm.value);
    this.isApiLoading = true;
    const obj = {};
    obj["group_id"] = this.selectedGroup.id;
    obj["led_profile_name"] = this.addProfileForm.value.led_profile_name;
    obj["description"] = this.addProfileForm.value.description;
    obj["channel_configuration"] = this.selectedGroup.channel_configuration;
    obj["channel_values"] = this.addChannelValuesForm.value;
    obj["preset"] = 100;

    console.log(obj);
    this.ledProfileService.createProfile(obj).subscribe(
      (successResponse: Response) => {
        console.log(successResponse);
        this.toastrService.success(
          "Profile created successfully.",
          "Create Profile"
        );
        this.datatableElement.dtInstance.then((dtInstance: DataTables.Api) => {
          // Destroy the table first
          dtInstance.destroy();
        });
        this.addProfileForm.reset();
        this.addChannelValuesForm.reset();
        this.getProfiles(this.selectedGroup.id);
        this.isApiLoading = false;
        $("#myModal").modal("hide");
      },
      (error) => {
        this.addProfileForm.reset();
        this.addChannelValuesForm.reset();
        this.isApiLoading = false;
        $("#myModal").modal("hide");
      }
    );
  }
  onEditProfileSubmit() {
    this.isApiLoading = true;
    console.log(this.addProfileForm.value);
    console.log(this.addChannelValuesForm.value);
    const obj = {};
    obj["id"] = this.addProfileForm.value.id;
    obj["group_id"] = this.selectedGroup.id;
    obj["led_profile_name"] = this.addProfileForm.value.led_profile_name;
    obj["description"] = this.addProfileForm.value.description;
    obj["channel_configuration"] = this.selectedGroup.channel_configuration;
    obj["channel_values"] = this.addChannelValuesForm.value;
    obj["preset"] = 100;

    console.log(obj);
    this.ledProfileService.updateProfile(obj).subscribe(
      (successResponse: Response) => {
        console.log(successResponse);
        this.toastrService.success(
          "Profile updated successfully.",
          "Update Profile"
        );
        this.datatableElement.dtInstance.then((dtInstance: DataTables.Api) => {
          // Destroy the table first
          dtInstance.destroy();
        });
        this.ledProfileService.ediProfile.emit(this.addProfileForm.value.id);
        this.addProfileForm.reset();
        this.addChannelValuesForm.reset();
        this.isApiLoading = false;
        this.isEditProfile = false;
        $("#myModal").modal("hide");
        this.getProfiles(this.selectedGroup.id);
      },
      (error) => {
        this.addProfileForm.reset();
        this.addChannelValuesForm.reset();
        this.isApiLoading = false;
        this.isEditProfile = false;
        $("#myModal").modal("hide");
      }
    );
  }
  onDeleteProfile() {
    this.isApiLoading = true;
    this.ledProfileService.deleteProfile(this.deleteProfile.id).subscribe(
      (response) => {
        console.log(response);
        this.toastrService.success(
          "Profile deleted successfully",
          "Delete Profile"
        );
        this.datatableElement.dtInstance.then((dtInstance: DataTables.Api) => {
          // Destroy the table first
          dtInstance.destroy();
        });
        this.isApiLoading = false;
        console.log(this.selectedProfile);
        if (this.selectedProfile) {
          this.selectedProfile = null;
          if (
            this.selectedFacility &&
            this.selectedContainer &&
            this.selectedGrowArea &&
            this.selectedGroup
          ) {
            this.router.navigate([
              "/facilities/" +
                this.selectedFacility.id +
                "/containers/" +
                this.selectedContainer.id +
                "/grow-areas/" +
                this.selectedGroup.growarea_id +
                "/groups/" +
                this.selectedGroup.id +
                "/profiles",
            ]);
            this.getFacilityById(
              this.selectedFacility.id,
              this.selectedContainer.id,
              this.selectedGrowArea.id,
              this.selectedGroup.id
            );
          } else if (
            this.selectedFacility &&
            this.selectedGrowArea &&
            this.selectedGroup
          ) {
            this.router.navigate([
              "/facilities/" +
                this.selectedFacility.id +
                "/grow-areas/" +
                this.selectedGroup.growarea_id +
                "/groups/" +
                this.selectedGroup.id +
                "/profiles",
            ]);
            this.getFacilityById(
              this.selectedFacility.id,
              undefined,
              this.selectedGrowArea.id,
              this.selectedGroup.id
            );
          } else if (
            this.selectedContainer &&
            this.selectedGrowArea &&
            this.selectedGroup
          ) {
            this.router.navigate([
              "/containers/" +
                this.selectedContainer.id +
                "/grow-areas/" +
                this.selectedGroup.growarea_id +
                "/groups/" +
                this.selectedGroup.id +
                "/profiles",
            ]);
            this.getContainerById(
              this.selectedContainer.id,
              this.selectedGrowArea.id,
              this.selectedGroup.id
            );
          } else if (this.selectedGrowArea && this.selectedGroup) {
            this.router.navigate([
              "/grow-areas/" +
                this.selectedGroup.growarea_id +
                "/groups/" +
                this.selectedGroup.id +
                "/profiles",
            ]);
            this.getGrowareaById(
              this.selectedGroup.growarea_id,
              this.selectedGroup.id
            );
          } else if (this.selectedGroup) {
            this.router.navigate([
              "/groups/" + this.selectedGroup.id + "/profiles",
            ]);
            this.getGroupByGroupId(this.selectedGroup.id);
          }
        }
        this.getProfiles(this.selectedGroup.id);
      },
      (error) => {
        this.deleteProfile = null;
        this.isApiLoading = false;
      }
    );
  }
  formatLabel(value: number | null) {
    if (!value) {
      return 0;
    }
    return value;
  }
}
