import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { Subject } from 'rxjs';
import { GrowSection } from '../models/growsection.model';
import { Facility } from '../models/facility.model';

import { GrowArea } from '../models/growarea.model';
import { ToastrService } from 'ngx-toastr';

import { GrowAreaService } from '../services/growarea-service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ContainerService } from '../services/container-service';
import { FacilityService } from '../services/facility-service';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { BreadcrumbsService, BreadcrumbComponent } from 'ng6-breadcrumbs';
import { DeviceService } from '../services/device-service';
import { Device } from '../models/device.model';
import { Container } from '../models/container.model';
import { DataTableDirective } from 'angular-datatables';
import { User } from '../models/user.model';
import { GlobalService } from '../services/global-service';

@Component({
  selector: 'app-devices',
  templateUrl: './devices.component.html',
  styleUrls: ['./devices.component.css']
})

export class DevicesComponent implements OnInit, OnDestroy {

  dtOptions: any = {};
  dtTrigger: Subject<any> = new Subject();
  selectedDevice: Device;
  delet = false;
  deletDevice: Device;
  @ViewChild(DataTableDirective)
  private datatableElement: DataTableDirective;
  devices: Device[] = [];
  @ViewChild(BreadcrumbComponent) breadcrumbRef: BreadcrumbComponent;
  selectedFacility: Facility;
  selectedContainer: Container;
  selectedGrowArea: GrowArea;
  scmNode = false;
  totalGrowSectionCount: number;
  activeDeviceCount: number;
  loggedInUser: User;
  routingFlag = false;
  isDevicesLoad = false;
  countOutOffNetwork = 0;
  apiLoading =false;
  constructor(
    private deviceService: DeviceService,
    private growareaService: GrowAreaService,
    private spinner: NgxSpinnerService,
    private containerService: ContainerService,
    private facilityService: FacilityService,
    private route: ActivatedRoute,
    private toastrService: ToastrService,
    private globalService: GlobalService,
    private breadcrumbService: BreadcrumbsService,
    private router: Router,

  ) {
  }

  ngOnInit() {
    this.breadcrumbService.store([
      { label: 'Devices', url: 'devices', params: [] }
    ]);
    this.loggedInUser = JSON.parse(localStorage.getItem('loggedInUser'));
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 10,
      info: false,
      order: [],
      lengthChange: false,
      select: true,
      language: {
        zeroRecords: 'No Devices to display',
        paginate: {
          next: '>', // or '→'
          previous: '<', // or '←',
        }
      }
    };
    this.deviceService.selectedDevice.subscribe(
      (device: Device) => {
        this.selectedDevice = device;
      }
    );

    this.route.params.subscribe((params: Params) => {
      console.log(params);
      if (params.growareaId) {
        this.getOutOfNetworkCount(params.growareaId);
      }
      if (params.facilityId && params.containerId && params.growareaId) {
        console.log('Params' + JSON.stringify(params));
        this.getFacilityById(
          params.facilityId,
          params.containerId,
          params.growareaId
        );
        this.getDevices(params.growareaId);
      } else if (params.facilityId && params.containerId) {
        console.log('Params' + JSON.stringify(params));
        this.getFacilityById(params.facilityId, params.containerId, undefined);
        this.getDevicesByConatinerId(params.containerId);
      } else if (params.facilityId && params.growareaId) {
        console.log('Params' + JSON.stringify(params));
        this.getFacilityById(params.facilityId, undefined, params.growareaId);
        this.getDevices(params.growareaId);
      } else if (params.containerId && params.growareaId) {
        console.log('Params' + JSON.stringify(params));
        this.getContainerById(params.containerId, params.growareaId);
        this.getDevices(params.growareaId);
      } else if (params.growareaId) {
        console.log('Params' + JSON.stringify(params));
        this.getGrowareaById(params.growareaId);
        this.getDevices(params.growareaId);
      } else if (params.containerId) {
        this.getContainerById(params.containerId, undefined);
        this.getDevicesByConatinerId(params.containerId);
      } else if (params.facilityId) {
        console.log('Params' + JSON.stringify(params));
        this.getFacilityById(params.facilityId, undefined, undefined);
        this.getDevicesByFacilityId(params.facilityId);
      } else {
        console.log('Params' + JSON.stringify(params));
        this.getDevices(params.growAreaId);
      }
    });
  }


  getOutOfNetworkCount(id) {
    this.deviceService.getOutOfNetworkCountOfAllDevices(id).subscribe(
      (response: any) => {
        this.countOutOffNetwork = response.count;
      }
    );
  }
  // ngAfterContentChecked(){

  //   console.log('routingFlag',this.routingFlag);

  //   if(this.routingFlag){
  //     this.route.params.subscribe((params: Params) => {
  //       console.log(params);

  //       if (params.facilityId && params.containerId && params.growareaId) {
  //         console.log('Params' + JSON.stringify(params));
  //         this.getFacilityById(
  //           params.facilityId,
  //           params.containerId,
  //           params.growareaId
  //         );
  //         this.getDevices(params.growareaId);
  //       } else if (params.facilityId && params.containerId) {
  //         console.log('Params' + JSON.stringify(params));
  //         this.getFacilityById(params.facilityId, params.containerId, undefined);
  //         this.getDevicesByConatinerId(params.containerId);
  //       } else if (params.facilityId && params.growareaId) {
  //         console.log('Params' + JSON.stringify(params));
  //         this.getFacilityById(params.facilityId, undefined, params.growareaId);
  //         this.getDevices(params.growareaId);
  //       } else if (params.containerId && params.growareaId) {
  //         console.log('Params' + JSON.stringify(params));
  //         this.getContainerById(params.containerId, params.growareaId);
  //         this.getDevices(params.growareaId);
  //       } else if (params.growareaId) {
  //         console.log('Params' + JSON.stringify(params));
  //         this.getGrowareaById(params.growareaId);
  //         this.getDevices(params.growareaId);
  //       } else if (params.containerId) {
  //         this.getContainerById(params.containerId, undefined);
  //         this.getDevicesByConatinerId(params.containerId);
  //       } else if (params.facilityId) {
  //         console.log('Params' + JSON.stringify(params));
  //         this.getFacilityById(params.facilityId, undefined, undefined);
  //         this.getDevicesByFacilityId(params.facilityId);
  //       } else {
  //         console.log('Params' + JSON.stringify(params));
  //         this.getDevices(params.growAreaId);
  //       }
  //     });
  //     this.routingFlag = false;
  //   }
  // }

  getFacilityById(id, containerId, growareaId) {
    this.facilityService.getFacilityById(id).subscribe((response: Facility) => {
      this.selectedFacility = response;

      if (growareaId === undefined && containerId === undefined) {
        this.breadcrumbService.store([
          { label: 'Facilities', url: '/facilities', params: [] },
          {
            label: this.selectedFacility.facility_name + '',
            url: '/facilities/' + this.selectedFacility.id,
            params: []
          },
          { label: 'Devices', url: '', params: [] }
        ]);
        this.addReloadEventToBreadcrumb();
      } else {
        if (containerId && growareaId) {
          this.getContainerById(containerId, growareaId);
        } else if (containerId) {
          this.getContainerById(containerId, undefined);
        } else {
          this.getGrowareaById(growareaId);
        }
      }
    });
  }

  addReloadEventToBreadcrumb() {
    setTimeout(() => {
      const elems = document.querySelectorAll('.breadcrumb-item a');
      console.log(elems);
      console.log('length     ', elems.length);
      for (let i = 0; i < elems.length; i++) {
        elems[i].addEventListener('click', this.globalService.handleClick);
      }
    }, 100);
  }
  getContainerById(containerId, growareaId) {
    this.containerService
      .getContainerById(containerId)
      .subscribe((response: Container) => {
        this.selectedContainer = response;

        if (this.selectedFacility === undefined && growareaId === undefined) {
          this.breadcrumbService.store([
            { label: 'Containers', url: '/containers', params: [] },
            { label: this.selectedContainer.container_name + '', url: '/containers/' + this.selectedContainer.id, params: [] },
            { label: 'Devices', url: '', params: [] },
          ]);
          this.addReloadEventToBreadcrumb();
        } else if (this.selectedFacility && growareaId === undefined) {
          this.breadcrumbService.store([
            { label: 'Facilities', url: '/facilities', params: [] },
            { label: this.selectedFacility.facility_name + '', url: '/facilities/' + this.selectedFacility.id, params: [] },
            { label: 'Containers', url: 'facilities/' + this.selectedFacility.id + '/containers', params: [] },
            {
              label: this.selectedContainer.container_name + '',
              url: 'facilities/' + this.selectedFacility.id + '/containers/' + this.selectedContainer.id, params: []
            },
            { label: 'Devices', url: '', params: [] },
          ]);
          this.addReloadEventToBreadcrumb();
        } else {
          this.getGrowareaById(growareaId);
        }
      });
  }

  getGrowareaById(growareaId) {
    this.growareaService
      .getGrowAreaById(growareaId)
      .subscribe((response: GrowArea) => {
        this.selectedGrowArea = response;
        if (this.selectedFacility === undefined && this.selectedContainer === undefined && this.selectedGrowArea) {
          this.breadcrumbService.store([
            { label: 'Grow Areas', url: '/grow-areas', params: [] },
            { label: this.selectedGrowArea.grow_area_name + '', url: '/grow-areas/' + this.selectedGrowArea.id, params: [] },
            { label: 'Devices', url: '', params: [] },
          ]);
        } else if (this.selectedFacility && this.selectedContainer === undefined && this.selectedGrowArea) {
          this.breadcrumbService.store([
            { label: 'Facilities', url: '/facilities', params: [] },
            { label: this.selectedFacility.facility_name + '', url: '/facilities/' + this.selectedFacility.id, params: [] },
            { label: 'Grow Areas', url: '/facilities/' + this.selectedFacility.id + '/grow-areas', params: [] },
            {
              label: this.selectedGrowArea.grow_area_name + '',
              url: '/facilities/' + this.selectedFacility.id + '/grow-areas/' + this.selectedGrowArea.id, params: []
            },
            { label: 'Devices', url: '', params: [] },
          ]);
        } else if (this.selectedFacility === undefined && this.selectedContainer && this.selectedGrowArea) {
          this.breadcrumbService.store([
            { label: 'Containers', url: '/containers', params: [] },
            { label: this.selectedContainer.container_name + '', url: '/containers/' + this.selectedContainer.id, params: [] },
            { label: 'Grow Areas', url: '/containers/' + this.selectedContainer.id + '/grow-areas', params: [] },
            {
              label: this.selectedGrowArea.grow_area_name + '',
              url: '/containers/' + this.selectedContainer.id + '/grow-areas/' + this.selectedGrowArea.id, params: []
            },
            { label: 'Devices', url: '', params: [] },
          ]);
        } else if (this.selectedFacility && this.selectedContainer && this.selectedGrowArea){
          this.breadcrumbService.store([
            { label: 'Facilities', url: '/facilities', params: [] },
            { label: this.selectedFacility.facility_name + '', url: '/facilities/' + this.selectedFacility.id, params: [] },
            { label: 'Containers', url: '/facilities/' + this.selectedFacility.id + '/containers', params: [] },
            {
              label: this.selectedContainer.container_name + '',
              url: '/facilities/' + this.selectedFacility.id + '/containers/' + this.selectedContainer.id, params: []
            },
            {
              label: 'Grow Areas',
              url: '/facilities/' + this.selectedFacility.id + '/containers/' + this.selectedContainer.id + '/grow-areas', params: []
            },
            {
              label: this.selectedGrowArea.grow_area_name + '',
              url: '/facilities/' + this.selectedFacility.id + '/containers/' + this.selectedContainer.id
                + '/grow-areas/' + this.selectedGrowArea.id,
              params: []
            },
            { label: 'Devices', url: '', params: [] },
          ]);
        } else {
          this.breadcrumbService.store([
            { label: 'Devices', url: '', params: [] },
          ]);
        }
        this.addReloadEventToBreadcrumb();
      });
  }

  getDevices(growAreaId) {
    this.devices = [];
    this.isDevicesLoad = true;
    this.deviceService
      .getDevicesByGrowarea(growAreaId)
      .subscribe((response: Device[]) => {
        setTimeout(() => {
          this.devices = response;
          if (this.devices) {
            this.activeDeviceCount = this.devices.length;
          } else {
            this.activeDeviceCount = 0;
          }
          this.dtTrigger.next();
        }, 500
        );
        this.isDevicesLoad = false;

      }
      , (error) => {
        console.log('Error' + JSON.stringify(error));
        this.isDevicesLoad = false;
      });
  }

  getDevicesByFacilityId(facilityId) {
    this.devices = [];
    this.isDevicesLoad = true;
    this.deviceService
      .getDevicesByFacility(facilityId)
      .subscribe((response: Device[]) => {
        setTimeout(
          () => {
            this.devices = response;
            if (this.devices) {
              this.activeDeviceCount = this.devices.length;
            } else {
              this.activeDeviceCount = 0;
            }
            this.dtTrigger.next();
          }, 500
        );
      });
    this.isDevicesLoad = false;
  }

  getDevicesByConatinerId(conatinerId) {
    this.devices = [];
    this.isDevicesLoad = true;
    this.deviceService
      .getDevicesByContainer(conatinerId)
      .subscribe((response: Device[]) => {
        setTimeout(
          () => {
            this.devices = response;
            if (this.devices) {
              this.activeDeviceCount = this.devices.length;
            } else {
              this.activeDeviceCount = 0;
            }
            this.dtTrigger.next();
          }, 500
        );
        this.isDevicesLoad = false;
      });
  }

  // getDevicesByGrowareaId(growareaId, deviceTypeId) {
  //   if (this.router.url.indexOf('devicetype') !== -1) {
  //     this.devices = [];
  //     this.isDevicesLoad = true;
  //     this.deviceService
  //       .getDevicesByGrowareaAndDeviceType(growareaId, deviceTypeId)
  //       .subscribe((response: Device[]) => {
  //         setTimeout(
  //           () => {
  //             this.devices = response;
  //             this.activeDeviceCount = this.devices.length;
  //             this.dtTrigger.next();
  //           }, 500
  //         );
  //         this.isDevicesLoad = false;
  //       });
  //   } else {
  //     this.devices = [];
  //     this.isDevicesLoad = true;
  //     this.deviceService
  //       .getDevicesByGrowarea(growareaId)
  //       .subscribe((response: Device[]) => {
  //         setTimeout(
  //           () => {
  //             this.devices = response;
  //             this.activeDeviceCount = this.devices.length;
  //             this.dtTrigger.next();
  //           }, 500
  //         );
  //         this.isDevicesLoad = false;
  //       });
  //   }
  // }

  onClickOfDevice(device) {
    this.selectedDevice = device;
    this.routingFlag = true;
    this.router.navigate([this.selectedDevice.id], { relativeTo: this.route });
  }

  onDeletChanges(deviceId: Device) {
    this.delet = true;
    console.log('OnDeletChanges called');
    this.deletDevice = deviceId;
  }

  // on delete facility in table
  onDeleteDevice() {
    this.apiLoading = true;

    console.log('this.device delet' + this.deletDevice.id);
    console.log('typppp', typeof this.deletDevice.id);
    this.deviceService.deleteDeviceById(this.deletDevice.id).subscribe(
      response => {
        console.log(response);
        this.datatableElement.dtInstance.then((dtInstance: DataTables.Api) => {
          // Destroy the table first
          dtInstance.destroy();
        });
        this.toastrService.success(
          'Device Deleted Successfully',
          'Delete Device'
        );
        if (this.selectedDevice) {
          this.selectedDevice = null;
          if (this.selectedFacility && this.selectedContainer && this.selectedGrowArea) {
            this.router.navigate(['/facilities/' + this.selectedFacility.id + '/containers/' + this.selectedContainer.id
             + '/grow-areas/' + this.selectedGrowArea.id + '/devices' ]);
             this.getFacilityById(this.selectedFacility.id, this.selectedContainer.id, this.selectedGrowArea.id);
          } else if (this.selectedFacility && this.selectedGrowArea) {
            this.router.navigate(['/facilities/' + this.selectedFacility.id + '/grow-areas/' + this.selectedGrowArea.id + '/devices' ]);
            this.getFacilityById(this.selectedFacility.id, undefined, this.selectedGrowArea.id);
          } else if (this.selectedContainer && this.selectedGrowArea) {
            this.router.navigate(['/containers/' + this.selectedContainer.id + '/grow-areas/' + this.selectedGrowArea.id + '/devices' ]);
            this.getContainerById(this.selectedContainer.id, this.selectedGrowArea.id);
          } else {
            this.router.navigate(['/grow-areas/' + this.selectedGrowArea.id + '/devices']);
          this.getGrowareaById(this.selectedGrowArea.id);
          }
        }
        this.getDevices(this.selectedGrowArea.id);
        // this.router.navigate(['/grow-areas/'+this.selectedGrowArea.id+'/devices']);
        this.apiLoading = false;
      }, (error) => {
        console.log('Error' + JSON.stringify(error));
        this.apiLoading = false;
      });
  }

  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }
}
