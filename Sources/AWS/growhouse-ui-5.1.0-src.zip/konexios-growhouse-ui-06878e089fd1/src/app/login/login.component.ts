import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { ToastrService } from "ngx-toastr";
import { UserSession } from "../models/user.model";
import { LoginService } from "../services/login-service";
declare var $: any;

@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.css"],
})
export class LoginComponent implements OnInit {
  loading: boolean = false;
  error: boolean = false;
  resetPasswordMsg: boolean = false;
  changePassword: boolean = false;
  changePasswordMsg: boolean = false;

  signInForm: FormGroup;
  resetPasswordForm: FormGroup;
  changePasswordForm: FormGroup;

  constructor(
    private formBuilder: FormBuilder,
    private loginService: LoginService,
    private router: Router,
    private route: ActivatedRoute,
    private toasterService: ToastrService
  ) {}

  ngOnInit() {
    this.signInForm = this.formBuilder.group({
      login: [
        "",
        [
          Validators.required,
          Validators.maxLength(40),
          // Validators.pattern(ValidationPatterns.username),
        ],
      ],
      password: [
        "",
        [
          Validators.required,
          Validators.maxLength(40),
          // Validators.pattern(ValidationPatterns.passwordPattern),
        ],
      ],
    });

    this.resetPasswordForm = this.formBuilder.group({
      login: ["", [Validators.required, Validators.maxLength(40)]],
    });

    this.changePasswordForm = this.formBuilder.group({
      login: [
        "",
        [
          Validators.required,
          Validators.maxLength(40),
          // Validators.pattern(ValidationPatterns.username),
        ],
      ],
      currentPassword: [
        "",
        [
          Validators.required,
          Validators.maxLength(40),
          // Validators.pattern(ValidationPatterns.passwordPattern),
        ],
      ],
      newPassword: [
        "",
        [
          Validators.required,
          Validators.maxLength(40),
          // Validators.pattern(ValidationPatterns.passwordPattern),
        ],
      ],
      confirmNewPassword: [
        "",
        [
          Validators.required,
          Validators.maxLength(40),
          // Validators.pattern(ValidationPatterns.passwordPattern),
        ],
      ],
    });

    this.route.url.subscribe((urls) => {
      if (
        (this.changePassword =
          urls.find((url) => url.path == "change-password") !== undefined)
      ) {
        this.openChangePassword();
      }
    });
  }

  onSignIn() {
    if (this.signInForm.invalid) {
      return;
    }

    this.loading = true;
    this.resetPasswordMsg = false;
    this.changePasswordMsg = false;
    this.loginService.resetStorage();
    this.loginService.signIn(this.signInForm.value).subscribe(
      (session: UserSession) => {
        const user = session.userDTO;
        localStorage.setItem(
          "userDetails",
          JSON.stringify({
            name: user.first_name + " " + user.last_name,
            email: user.email_id,
            token: session.sessionId,
          })
        );
        localStorage.setItem("loggedInUser", JSON.stringify(user));
        this.router.navigate(["/dashboard"], { relativeTo: this.route });
        this.loading = false;
      },
      (error) => {
        this.loading = false;
        console.log("login error", error);
        if (error.status === 401) {
          $("#loginFailedModal").modal("show", {
            backdrop: "static",
            keyboard: false,
          });
        } else if (error.status === 409) {
          this.openChangePassword();
        }
      }
    );
  }

  openResetPassword() {
    const login = this.resetPasswordForm.get("login");
    login.setValue(null);
    login.markAsUntouched();
    $("#resetPasswordModal").modal("show", {
      backdrop: "static",
      keyboard: false,
    });
  }

  onResetPassword() {
    this.loading = true;
    if (this.resetPasswordForm.invalid) {
      this.loading = false;
      return;
    }
    this.loginService
      .resetPassword(this.resetPasswordForm.get("login").value)
      .subscribe(
        () => {
          console.log("resetPassword OK!");
          $("#resetPasswordModal").modal("hide");
          this.loading = false;
          this.resetPasswordMsg = true;
          this.loginService.resetStorage();
        },
        (error) => {
          console.log("resetPassword error: " + JSON.stringify(error));
          $("#resetPasswordModal").modal("hide");
          this.loading = false;
          this.loginService.resetStorage();
        }
      );
  }

  openChangePassword() {
    this.changePasswordForm.reset();
    this.changePasswordForm.markAsUntouched();
    $("#changePasswordModal").modal("show", {
      backdrop: "static",
      keyboard: false,
    });
  }

  onChangePassword() {
    this.loading = true;
    console.log(JSON.stringify(this.changePasswordForm.value));
    this.loginService.changePassword(this.changePasswordForm.value).subscribe(
      () => {
        console.log("changePassword OK!");
        $("#changePasswordModal").modal("hide");
        this.loading = false;
        this.changePassword = false;
        this.changePasswordMsg = true;
        this.loginService.resetStorage();
      },
      (error) => {
        console.log("changePassword ERROR: " + JSON.stringify(error));
        $("#changePasswordModal").modal("hide");
        this.loginService.resetStorage();
        this.loading = false;
      }
    );
  }

  onChangePasswordMissing(name: string) {
    let field = this.changePasswordForm.get(name);
    return !field.value && field.touched;
  }

  onChangePasswordMatched() {
    const first = this.changePasswordForm.get("newPassword");
    const second = this.changePasswordForm.get("confirmNewPassword");
    return !second.touched || (second.touched && first.value == second.value);
  }

  onSignInMissing(name: string) {
    let field = this.signInForm.get(name);
    return !field.value && field.touched;
  }
}
