import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GrowSectionComponent } from './grow-section.component';

describe('GrowSectionComponent', () => {
  let component: GrowSectionComponent;
  let fixture: ComponentFixture<GrowSectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GrowSectionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GrowSectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
