import { Injectable, EventEmitter } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { environment } from "../../environments/environment";
import { Facility } from "../models/facility.model";
import { appConfig } from "../global";

@Injectable({
  providedIn: "root",
})
export class FacilityService {
  private url: string = environment.appServerURL;
  selectedFacility = new EventEmitter<Facility>();
  ediFacility = new EventEmitter<Facility>();

  constructor(private http: HttpClient) {}

  getFacility() {
    return this.http.get(this.url + appConfig.facilities);
  }

  getCountByFacilityId(facilityId: number) {
    return this.http.get(
      this.url + appConfig.countByFacility + "/" + facilityId
    );
  }

  createFacility(facilityObj: Facility) {
    return this.http.post(this.url + appConfig.facilities, facilityObj);
  }

  editFacility(facilityId: number, facilityObj: Facility) {
    return this.http.put(
      this.url + appConfig.facilities + "/" + facilityId,
      facilityObj
    );
  }

  deleteFacility(facilityId: number) {
    return this.http.delete(this.url + appConfig.facilities + "/" + facilityId);
  }

  getCountrys() {
    return this.http.get(this.url + appConfig.countries);
  }

  getStates(countryId) {
    return this.http.get(this.url + appConfig.states + "/" + countryId);
  }

  getLocalities(stateId) {
    return this.http.get(this.url + appConfig.localities + "/" + stateId);
  }

  getFacilityById(facilityId: number) {
    return this.http.get(this.url + appConfig.facilities + "/" + facilityId);
  }
}
