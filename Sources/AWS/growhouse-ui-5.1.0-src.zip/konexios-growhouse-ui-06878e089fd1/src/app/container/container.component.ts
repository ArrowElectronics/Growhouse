import { Component, OnDestroy, OnInit } from "@angular/core";
import { ActivatedRoute, Params, Router } from "@angular/router";
import { BreadcrumbsService } from "ng6-breadcrumbs";
import { NgxSpinnerService } from "ngx-spinner";
import { ToastrService } from "ngx-toastr";
import { ProfileMessage } from "src/app/global";
import { ContainerService } from "src/app/services/container-service";
import { Container } from "../models/container.model";
import { Facility } from "../models/facility.model";
import { AlertsService } from "../services/alerts-service";
import { FacilityService } from "../services/facility-service";
import { GlobalService } from "../services/global-service";
import { WebSocketService } from "../services/websocket-service";

@Component({
  selector: "app-container",
  templateUrl: "./container.component.html",
  styleUrls: ["./container.component.css"],
})
export class ContainerComponent implements OnInit, OnDestroy {
  selectedContainer: Container;
  selectedFacility: Facility;
  containerCountObj;
  // boolean
  redPlant = false;
  bluePlant = false;
  yellowPlant = false;
  greenPlant = false;
  isHistoricAlertButton = true;
  isLiveAlertButton = false;
  alertsOfProfileLoad = false;

  // any Data
  alerts: any[] = [];
  liveAlerts: any[] = [];
  ws: any = {};
  topic: string[] = [];
  profiles: any[] = [];
  ALL_OK = ProfileMessage.ALL_OK;
  NEED_WATER = ProfileMessage.NEED_WATER;
  NEED_SUN = ProfileMessage.NEED_SUN;
  MORE_SUN = ProfileMessage.MORE_SUN;
  constructor(
    private containerService: ContainerService,
    private facilityService: FacilityService,
    private spinner: NgxSpinnerService,
    private webSocketService: WebSocketService,
    private globalService: GlobalService,
    private toastrService: ToastrService,
    private router: Router,
    private route: ActivatedRoute,
    private breadcrumService: BreadcrumbsService,
    private alertsService: AlertsService
  ) {}

  ngOnInit() {
    this.route.params.subscribe((params: Params) => {
      console.log(params);
      if (params.containerId) {
        this.getContainerById(params.containerId);
        this.getCountsById(params.containerId);
        this.getProfilesByContainerId(params.containerId);
        this.route.parent.params.subscribe((parentParams: Params) => {
          console.log(parentParams);
          if (parentParams.facilityId) {
            this.getFacilityById(parentParams.facilityId, params.containerId);
          }
        });
      }
    });
    this.facilityService.selectedFacility.subscribe((facility: Facility) => {
      this.selectedFacility = facility;
    });
    this.containerService.ediContainer.subscribe((response) => {
      console.log(response);
      this.getContainerById(response);
    });
  }

  getCountsById(id) {
    // this.containerCountObj = {};

    this.containerService.getCountByContainerId(id).subscribe((response) => {
      this.containerCountObj = response;
    });
  }

  getProfilesByContainerId(containerId) {
    this.globalService
      .getProfileAlertsByContainerId(containerId)
      .subscribe((response: any[]) => {
        this.profiles = response;
        for (let i = 0; i < this.profiles.length; i++) {
          let properties;
          const properties_arr = [];
          properties = JSON.parse(this.profiles[i].properties);
          // tslint:disable-next-line:forin
          for (const key in properties) {
            properties_arr.push({ name: key, value: properties[key] });
          }
          this.profiles[i].properties = properties_arr.sort((a, b) =>
            a.name > b.name ? 1 : -1
          );
          console.log("Alert Message:" + this.profiles[i].alertMessage);

          // if (this.profiles[i].alertMessage === this.ALL_OK) {
          //   // this.greenPlant = true;
          //   // this.yellowPlant = false;
          //   // this.bluePlant = false;
          //   // this.redPlant = false;
          //   this.profiles[i].imageURL = '../../assets/images/green-plant.svg';
          //   console.log('green plant');
          // } else if (this.profiles[i].alertMessage === this.NEED_WATER) {
          //   // this.yellowPlant = true;
          //   this.profiles[i].imageURL = '../../assets/images/yellow-plant.svg';
          //   console.log('yellow plant');
          // } else if (this.profiles[i].alertMessage === this.NEED_SUN) {
          //   // this.greenPlant = false;
          //   // this.yellowPlant = false;
          //   // this.bluePlant = true;
          //   // this.redPlant = false;
          //   this.profiles[i].imageURL = '../../assets/images/blue-plant.svg';

          //   console.log('blue plant');

          // } else {
          //   // this.greenPlant = false;
          //   // this.yellowPlant = false;
          //   // this.bluePlant = false;
          //   // this.redPlant = true;
          //   this.profiles[i].imageURL = '../../assets/images/red-plant.svg';
          //   console.log('red plant');

          // }
        }
      });
  }

  getContainerById(id) {
    this.containerService
      .getContainerById(id)
      .subscribe((response: Container) => {
        this.selectedContainer = response;
        console.log(this.selectedContainer);
        this.containerService.selectedContainer.emit(this.selectedContainer);
        if (this.selectedFacility) {
          this.breadcrumService.store([
            { label: "Facilities", url: "/facilities", params: [] },
            {
              label: this.selectedFacility.facility_name + "",
              url: "/facilities/" + this.selectedFacility.id,
              params: [],
            },
            {
              label: "Containers",
              url: "/facilities/" + this.selectedFacility.id + "/containers",
              params: [],
            },
            {
              label: this.selectedContainer.container_name + "",
              url:
                "/facilities/" +
                this.selectedFacility.id +
                "/conatiners/" +
                this.selectedContainer.id,
              params: [],
            },
          ]);
        } else {
          // console.log('container called');
          this.breadcrumService.store([
            { label: "Containers", url: "/containers", params: [] },
            {
              label: this.selectedContainer.container_name + "",
              url: "/conatiners/" + this.selectedContainer.id,
              params: [],
            },
          ]);
        }
        this.addReloadEventToBreadcrumb();
      });
  }

  addReloadEventToBreadcrumb() {
    setTimeout(() => {
      const elems = document.querySelectorAll(".breadcrumb-item a");
      console.log(elems);
      console.log("length     ", elems.length);
      for (let i = 0; i < elems.length; i++) {
        elems[i].addEventListener("click", this.globalService.handleClick);
      }
    }, 100);
  }

  getFacilityById(id, containerId) {
    this.facilityService.getFacilityById(id).subscribe((response: Facility) => {
      this.selectedFacility = response;
      console.log(this.selectedFacility);
      this.facilityService.selectedFacility.emit(this.selectedFacility);
      this.getContainerById(containerId);
    });
  }

  onLoadAllProfile() {
    this.router.navigate(["profiles"], { relativeTo: this.route });
  }

  onClickOfGrowArea() {
    this.router.navigate(["grow-areas"], { relativeTo: this.route });
  }

  onClickOfGrowSection() {
    this.router.navigate(["grow-sections"], { relativeTo: this.route });
  }

  onClickOfDevice() {
    this.router.navigate(["devices"], { relativeTo: this.route });
  }

  ngOnDestroy() {
    this.containerService.selectedContainer.emit(undefined);
  }
  onClickViewAllAlerts() {
    this.alerts = [];
    this.alertsOfProfileLoad = true;
    let prop_arr = [];
    let properties;
    this.alertsService
      .getAllProfileAlertsByContainerId(this.selectedContainer.id)
      .subscribe(
        (response: any) => {
          console.log(response);
          if (response) {
            this.alerts = response;
            for (let i = 0; i < this.alerts.length; i++) {
              properties = this.alerts[i].properties
                ? JSON.parse(this.alerts[i].properties)
                : {};
              console.log(properties);
              // tslint:disable-next-line:forin
              prop_arr = [];
              for (const key in properties) {
                prop_arr.push({ name: key, value: properties[key] });
              }
              this.alerts[i].properties = prop_arr;
            }
            // this.alerts.sort((val1, val2) => {
            //   const date1 = parseInt(val2.created_date, 10);
            //   const date2 = parseInt(val1.created_date, 10);
            //   return date1 - date2;
            // });
          }
          console.log(this.alerts);
          this.alertsOfProfileLoad = false;
        },
        (error) => {
          this.alertsOfProfileLoad = false;
        }
      );
  }
}
