import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LedProfileComponent } from './led-profile.component';

describe('LedProfileComponent', () => {
  let component: LedProfileComponent;
  let fixture: ComponentFixture<LedProfileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LedProfileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LedProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
