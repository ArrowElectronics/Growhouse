import { Component, OnInit } from '@angular/core';
import { Group } from '../models/group.model';
import { Container } from '../models/container.model';
import { Facility } from '../models/facility.model';
import { GrowArea } from '../models/growarea.model';
import { GrowAreaService } from '../services/growarea-service';
import { ToastrService } from 'ngx-toastr';
import { GroupService } from '../services/group-service';
import { ContainerService } from '../services/container-service';
import { FacilityService } from '../services/facility-service';
import { BreadcrumbsService } from 'ng6-breadcrumbs';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { LedProfileService } from '../services/ledprofile-service';
import { FormGroup, FormControl, Validators, FormArray } from '@angular/forms';

declare var $: any;
import { Pipe, PipeTransform } from '@angular/core'; import { DatePipe } from '@angular/common';
import { Moment } from 'moment';
import * as moment from 'moment';
import { GlobalService } from '../services/global-service';





@Component({
  selector: 'app-led-profile',
  templateUrl: './led-profile.component.html',
  styleUrls: ['./led-profile.component.css']
})
export class LedProfileComponent implements OnInit {
  selectedGrowArea: GrowArea;
  selectedContainer: Container;
  selectedFacility: Facility;
  selectedGroup;
  selectedProfile;
  dropdownList = [];
  selectedItems = [];
  dropdownSettings = {};
  getChannelValuesForm1: FormGroup;
  getChannelValuesForm: FormGroup;
  sceduleProfileStartForm: FormGroup;
  sceduleProfileEndForm: FormGroup;
  repeatList = [
    'Every Sunday',
    'Every Monday',
    'Every Tuesday',
    'Every Wednesday',
    'Every Thursday',
    'Every Friday',
    'Every Saturday'
  ];
  startDate: any = null;
  endDate: any = null;
  uiTimeFormat = 'HH:mm';
  isDateCorrect = 0;
  wrongTime = 0;
  today = moment();

  constructor(
    private growareaService: GrowAreaService,
    private toastrService: ToastrService,
    private groupService: GroupService,
    private containerService: ContainerService,
    private facilityService: FacilityService,
    private route: ActivatedRoute,
    private breadcrumbService: BreadcrumbsService,
    private router: Router,
    private ledProfileService: LedProfileService,
    private datePipe: DatePipe,
    private globalService: GlobalService
  ) {}

  ngOnInit() {
    let containerId, facilityId, growareaId, groupId, profileId;
    this.route.params.subscribe((parentParams: Params) => {
      console.log(parentParams);
      this.route.parent.params.subscribe((params: Params) => {
        console.log(params);
        if (parentParams.facilityId) {
          facilityId = parentParams.facilityId;
        }
        if (parentParams.containerId) {
          containerId = parentParams.containerId;
        }
        if (parentParams.growareaId) {
          growareaId = parentParams.growareaId;
        }

        if (params.facilityId) {
          facilityId = params.facilityId;
        }
        if (params.containerId) {
          containerId = params.containerId;
        }
        if (params.growareaId) {
          growareaId = params.growareaId;
        }
        if (params.groupId) {
          groupId = params.groupId;
        }
        if (parentParams.profileId) {
          profileId = parentParams.profileId;
        }
        if (facilityId) {
          this.getFacilityById(
            facilityId,
            containerId,
            growareaId,
            groupId,
            profileId
          );
        } else if (containerId) {
          this.getContainerById(containerId, growareaId, groupId, profileId);
        } else if (growareaId) {
          this.getGrowAreaById(growareaId, groupId, profileId);
        } else {
          this.getProfileByProfileId(profileId);
        }
      });
    });
    this.groupService.selectedGroup.subscribe((group: Group) => {
      this.selectedGroup = group;
    });
    this.ledProfileService.ediProfile.subscribe(
      (response) => {
        console.log(response);
        this.getProfileByProfileId(response);
      }
    );
    this.getChannelValuesForm1 = new FormGroup({
      CH1: new FormControl(0, []),
      CH2: new FormControl(0, []),
      CH3: new FormControl(0, []),
      CH4: new FormControl(0, []),
      CH5: new FormControl(0, []),
      CH6: new FormControl(0, []),
      preseted: new FormControl(100, [])
    });
    this.initialiseForms();
    this.dropdownList = [
      { id: 1, name: 'Every Sunday' },
      { id: 2, name: 'Every Monday' },
      { id: 3, name: 'Every Tuesday' },
      { id: 4, name: 'Every Wednesday' },
      { id: 5, name: 'Every Thursday' },
      { id: 6, name: 'Every Friday' },
      { id: 7, name: 'Every Saturday' }
    ];
    this.dropdownSettings = {
      singleSelection: false,
      idField: 'id',
      textField: 'name',
      selectAllText: 'Every Day',
      unSelectAllText: 'Every Day',
      itemsShowLimit: 2,
      allowSearchFilter: false
    };
  }

  getFacilityById(id, containerId, growareaId, groupId, profileId) {
    this.facilityService.getFacilityById(id).subscribe((response: Facility) => {
      this.selectedFacility = response;
      console.log(this.selectedFacility);
      this.facilityService.selectedFacility.emit(this.selectedFacility);
      if (containerId) {
        this.getContainerById(containerId, growareaId, groupId, profileId);
      } else if (growareaId) {
        this.getGrowAreaById(growareaId, groupId, profileId);
      } else {
        this.getProfileByProfileId(profileId);
      }
    });
  }
  getContainerById(id, growareaId, groupId, profileId) {
    this.containerService
      .getContainerById(id)
      .subscribe((response: Container) => {
        this.selectedContainer = response;
        if (growareaId) {
          this.getGrowAreaById(growareaId, groupId, profileId);
        } else {
          this.getProfileByProfileId(profileId);
        }
      });
  }
  getGrowAreaById(id, groupId, profileId) {
    this.growareaService.getGrowAreaById(id).subscribe((response: GrowArea) => {
      this.selectedGrowArea = response;
      console.log(this.selectedGrowArea);
      if (groupId && profileId) {
        this.getGroupByGroupId(groupId, profileId);
      }
    });
  }
  getGroupByGroupId(id, profileId) {
    this.groupService.getGroupByGroupId(id).subscribe((response: Group) => {
      this.selectedGroup = response;
      console.log(this.selectedGroup);
      if (profileId) {
        this.getProfileByProfileId(profileId);
      }
    });
  }
  getProfileByProfileId(profileId) {
    this.ledProfileService
      .getProfileByProfileId(profileId)
      .subscribe(response => {
        this.selectedProfile = response;
        this.getChannelValuesForm1.patchValue({
          CH1: this.selectedProfile.channel_values.CH1,
          CH2: this.selectedProfile.channel_values.CH2,
          CH3: this.selectedProfile.channel_values.CH3,
          CH4: this.selectedProfile.channel_values.CH4,
          CH5: this.selectedProfile.channel_values.CH5,
          CH6: this.selectedProfile.channel_values.CH6,
          preseted: 100
        });
        this.ledProfileService.selectedProfile.emit(this.selectedProfile);
        if (
          this.selectedFacility &&
          this.selectedContainer &&
          this.selectedGrowArea &&
          this.selectedGroup
        ) {
          this.breadcrumbService.store([
            { label: 'Facilities', url: '/facilities', params: [] },
            {
              label: this.selectedFacility.facility_name,
              url: '/facilities/' + this.selectedFacility.id,
              params: []
            },
            {
              label: 'Containers',
              url: '/facilities/' + this.selectedFacility.id + '/containers',
              params: []
            },
            {
              label: this.selectedContainer.container_name + '',
              url:
                '/facilities/' +
                this.selectedFacility.id +
                '/containers/' +
                this.selectedContainer.id,
              params: []
            },
            {
              label: 'Grow Areas',
              url:
                '/facilities/' +
                this.selectedFacility.id +
                '/containers/' +
                this.selectedContainer.id +
                '/grow-areas',
              params: []
            },
            {
              label: this.selectedGrowArea.grow_area_name + '',
              url:
                '/facilities/' +
                this.selectedFacility.id +
                '/containers/' +
                this.selectedContainer.id +
                '/grow-areas/' +
                this.selectedGrowArea.id,
              params: []
            },
            {
              label: 'Groups',
              url:
                '/facilities/' +
                this.selectedFacility.id +
                '/containers/' +
                this.selectedContainer.id +
                '/grow-areas/' +
                this.selectedGrowArea.id +
                '/groups',
              params: []
            },
            {
              label: this.selectedGroup.group_name + '',
              url:
                '/facilities/' +
                this.selectedFacility.id +
                '/containers/' +
                this.selectedContainer.id +
                '/grow-areas/' +
                this.selectedGrowArea.id +
                '/groups/' +
                this.selectedGroup.id,
              params: []
            },
            {
              label: 'Profiles',
              url:
                '/facilities/' +
                this.selectedFacility.id +
                '/containers/' +
                this.selectedContainer.id +
                '/grow-areas/' +
                this.selectedGrowArea.id +
                '/groups/' +
                this.selectedGroup.id +
                '/profiles',
              params: []
            },
            {
              label: this.selectedProfile.led_profile_name + '',
              url:
                '/facilities/' +
                this.selectedFacility.id +
                '/containers/' +
                this.selectedContainer.id +
                '/grow-areas/' +
                this.selectedGrowArea.id +
                '/groups/' +
                this.selectedGroup.id +
                '/profiles' +
                this.selectedProfile.led_profile_name,
              params: []
            }
          ]);
        } else if (
          this.selectedFacility &&
          this.selectedGrowArea &&
          this.selectedGroup
        ) {
          // alert(2);

          this.breadcrumbService.store([
            { label: 'Facilities', url: '/facilities', params: [] },
            {
              label: this.selectedFacility.facility_name,
              url: '/facilities/' + this.selectedFacility.id,
              params: []
            },
            {
              label: 'Grow Areas',
              url: '/facilities/' + this.selectedFacility.id + '/grow-areas',
              params: []
            },
            {
              label: this.selectedGrowArea.grow_area_name + '',
              url:
                '/facilities/' +
                this.selectedFacility.id +
                '/grow-areas/' +
                this.selectedGrowArea.id,
              params: []
            },
            {
              label: 'Groups',
              url:
                '/facilities/' +
                this.selectedFacility.id +
                '/grow-areas/' +
                this.selectedGrowArea.id +
                '/groups',
              params: []
            },
            {
              label: this.selectedGroup.group_name + '',
              url:
                '/facilities/' +
                this.selectedFacility.id +
                '/grow-areas/' +
                this.selectedGrowArea.id +
                '/groups/' +
                this.selectedGroup.id,
              params: []
            },
            {
              label: 'Profiles',
              url:
                '/facilities/' +
                this.selectedFacility.id +
                '/grow-areas/' +
                this.selectedGrowArea.id +
                '/groups/' +
                this.selectedGroup.id +
                '/profiles',
              params: []
            },
            {
              label: this.selectedProfile.led_profile_name + '',
              url:
                '/facilities/' +
                this.selectedFacility.id +
                '/grow-areas/' +
                this.selectedGrowArea.id +
                '/groups/' +
                this.selectedGroup.id +
                '/profiles' +
                this.selectedProfile.led_profile_name,
              params: []
            }
          ]);
        } else if (
          this.selectedContainer &&
          this.selectedGrowArea &&
          this.selectedGroup
        ) {
          // alert(3);

          this.breadcrumbService.store([
            { label: 'Containers', url: '/containers', params: [] },
            {
              label: this.selectedContainer.container_name + '',
              url: '/containers/' + this.selectedContainer.id,
              params: []
            },
            {
              label: 'Grow Areas',
              url: '/containers/' + this.selectedContainer.id + '/grow-areas',
              params: []
            },
            {
              label: this.selectedGrowArea.grow_area_name + '',
              url:
                '/containers/' +
                this.selectedContainer.id +
                '/grow-areas/' +
                this.selectedGrowArea.id,
              params: []
            },
            {
              label: 'Groups',
              url:
                '/containers/' +
                this.selectedContainer.id +
                '/grow-areas/' +
                this.selectedGrowArea.id +
                '/groups',
              params: []
            },
            {
              label: this.selectedGroup.group_name + '',
              url:
                '/containers/' +
                this.selectedContainer.id +
                '/grow-areas/' +
                this.selectedGrowArea.id +
                '/groups/' +
                this.selectedGroup.id,
              params: []
            },
            {
              label: 'Profiles',
              url:
                '/containers/' +
                this.selectedContainer.id +
                '/grow-areas/' +
                this.selectedGrowArea.id +
                '/groups/' +
                this.selectedGroup.id +
                '/profiles',
              params: []
            },
            {
              label: this.selectedProfile.led_profile_name + '',
              url:
                '/containers/' +
                this.selectedContainer.id +
                '/grow-areas/' +
                this.selectedGrowArea.id +
                '/groups/' +
                this.selectedGroup.id +
                '/profiles' +
                this.selectedProfile.led_profile_name,
              params: []
            }
          ]);
        } else if (this.selectedGrowArea && this.selectedGroup) {
          // alert(4);

          this.breadcrumbService.store([
            {
              label: 'Grow Areas',
              url: '/grow-areas',
              params: []
            },
            {
              label: this.selectedGrowArea.grow_area_name + '',
              url: '/grow-areas/' + this.selectedGrowArea.id,
              params: []
            },
            {
              label: 'Groups',
              url: '/grow-areas/' + this.selectedGrowArea.id + '/groups',
              params: []
            },
            {
              label: this.selectedGroup.group_name + '',
              url:
                '/grow-areas/' +
                this.selectedGrowArea.id +
                '/groups/' +
                this.selectedGroup.id,
              params: []
            },
            {
              label: 'Profiles',
              url:
                '/grow-areas/' +
                this.selectedGrowArea.id +
                '/groups/' +
                this.selectedGroup.id +
                '/profiles',
              params: []
            },
            {
              label: this.selectedProfile.led_profile_name + '',
              url:
                '/grow-areas/' +
                this.selectedGrowArea.id +
                '/groups/' +
                this.selectedGroup.id +
                '/profiles' +
                this.selectedProfile.led_profile_name,
              params: []
            }
          ]);
        } else if(this.selectedGrowArea && this.selectedGroup && this.selectedProfile){
          // alert(5);
          this.breadcrumbService.store([
            {
              label: 'Profiles',
              url:
                '/grow-areas/' +
                this.selectedGrowArea.id +
                '/groups/' +
                this.selectedGroup.id +
                '/profiles',
              params: []
            },
            {
              label: this.selectedProfile.led_profile_name + '',
              url:
                '/grow-areas/' +
                this.selectedGrowArea.id +
                '/groups/' +
                this.selectedGroup.id +
                '/profiles' +
                this.selectedProfile.led_profile_name,
              params: []
            }
          ]);
        }
        this.addReloadEventToBreadcrumb();
      });
  }
  addReloadEventToBreadcrumb() {
    setTimeout(() => {
      const elems = document.querySelectorAll('.breadcrumb-item a');
      console.log(elems);
      console.log('length     ', elems.length);
      for (let i = 0; i < elems.length; i++) {
        elems[i].addEventListener('click', this.globalService.handleClick);
      }
    }, 100);
  }
resetForm(){
  if(this.getChannelValuesForm1){
  this.getChannelValuesForm1.patchValue({
    CH1: this.selectedProfile.channel_values.CH1,
    CH2: this.selectedProfile.channel_values.CH2,
    CH3: this.selectedProfile.channel_values.CH3,
    CH4: this.selectedProfile.channel_values.CH4,
    CH5: this.selectedProfile.channel_values.CH5,
    CH6: this.selectedProfile.channel_values.CH6,
    preseted: 100
  });
}
}
  formatLabel(value: number | null) {
    // if (!value) {
    //   return 0;
    // }
    if (this.getChannelValuesForm1) {
      this.setChannel(this.selectedProfile.channel_values.CH1, 'CH1');
      this.setChannel(this.selectedProfile.channel_values.CH2, 'CH2');
      this.setChannel(this.selectedProfile.channel_values.CH3, 'CH3');
      this.setChannel(this.selectedProfile.channel_values.CH4, 'CH4');
      this.setChannel(this.selectedProfile.channel_values.CH5, 'CH5');
      this.setChannel(this.selectedProfile.channel_values.CH6, 'CH6');
    }
    return value;
  }

  takeRound(value, config) {
    return config === 'NC' ? 0 : Math.round(value);
  }

  setChannel(value, channel) {
    if (this.getChannelValuesForm1) {
      const newval = this.takeRound(
        (value * this.getChannelValuesForm1.value.preseted) / 100,
        this.selectedGroup.channel_configuration[channel]
      );
      this.getChannelValuesForm1.patchValue({ [channel]: newval });
    }
    console.log(JSON.stringify(this.getChannelValuesForm1.value));
  }

  public checkTime = (control: FormControl) => {
    if(this.startDate && control){
      const date = (new Date (this.startDate + ' ' + this.convertTime(control.value)));
      console.log(this.sceduleProfileStartForm.controls['start_time'].valid);
      console.log((date.getTime() > (new Date).getTime()) ? { doubleDot: true } : null);

      return (date.getTime() > (new Date).getTime()) ? null : { doubleDot: true } ;
    }
    return null;
  }
  convertTime(time) {
    const dateobj = new Date(time); 
    const format = 'MM-dd-yyyy HH:mm zzzz'; 
    const result = this.datePipe.transform(dateobj, format);
    const date = JSON.stringify(result).split(' ')[1];
    return date ;
  }
  applyNow(){
    // console.log(this.selectedGroup.added_devices.length);
    // if(this.selectedGroup.added_devices.length < 1){
    //   this.toastrService.error('No device added in selected Group.' , 'Apply Profile');
    //   return;
    // }
    const obj = {};
    obj['profile_details'] = this.selectedProfile;
    obj['CH1'] = this.getChannelValuesForm1.value.CH1;
    obj['CH2'] = this.getChannelValuesForm1.value.CH2;
    obj['CH3'] = this.getChannelValuesForm1.value.CH3;
    obj['CH4'] = this.getChannelValuesForm1.value.CH4;
    obj['CH5'] = this.getChannelValuesForm1.value.CH5;
    obj['CH6'] = this.getChannelValuesForm1.value.CH6;
    obj['preset'] = this.getChannelValuesForm1.value.preseted;
    obj['facility_id'] = this.selectedGrowArea.container.facility.id;
    obj[
      'facility_name'
    ] = this.selectedGrowArea.container.facility.facility_name;
    obj['container_id'] = this.selectedGrowArea.container.id;
    obj['container_name'] = this.selectedGrowArea.container.container_name;
    obj['growarea_id'] = this.selectedGrowArea.id;
    obj['growarea_name'] = this.selectedGrowArea.grow_area_name;

    console.log(obj);
     this.ledProfileService.applyProfileNow(obj).subscribe(
      (successResponse: Response) => {
        console.log(successResponse);
        this.toastrService.success(
          'Profile applied successfully.',
          'Apply Profile'
        );
        this.resetForm();
      },
      error => {
        this.resetForm();
      }
    );
  }
  onApplyProfile() {
    // console.log(this.selectedGroup.added_devices.length);
    // if(this.selectedGroup.added_devices.length < 1){
    //   this.toastrService.error('No device added in selected Group.' , 'Schedule Profile');
    //   return;
    // }
    const obj = {};
    const arr = [];
    if (this.showEnd()) {
      for (
        let i = 0;
        i < this.sceduleProfileStartForm.value.repeat.length;
        i++
      ) {
        arr.push(this.sceduleProfileStartForm.value.repeat[i].name);
      }
    }
    const div = this.getTimeOne(this.sceduleProfileStartForm.value.start_date, this.convertTime(
      this.sceduleProfileStartForm.value.start_time
    ), this.sceduleProfileStartForm.value.timezoneOffset);
    obj['profile_details'] = this.selectedProfile;
    obj['start_date'] = div['d'] ? div['d'] : null;
    obj['start_time'] = div['t'] ? div['t'] : null;
    // obj['timezoneOffset'] = this.sceduleProfileStartForm.value.timezoneOffset ? this.sceduleProfileStartForm.value.timezoneOffset : 0;
    obj['repeat_time'] = arr;
    console.log(this.sceduleProfileEndForm.value.end_date);
    if (this.endDate) {
      obj['end_date'] = this.sceduleProfileEndForm.value.end_date;
    } else {
      obj['end_date'] = null;
    }
    obj['end_time'] = null;
    obj['CH1'] = this.getChannelValuesForm1.value.CH1;
    obj['CH2'] = this.getChannelValuesForm1.value.CH2;
    obj['CH3'] = this.getChannelValuesForm1.value.CH3;
    obj['CH4'] = this.getChannelValuesForm1.value.CH4;
    obj['CH5'] = this.getChannelValuesForm1.value.CH5;
    obj['CH6'] = this.getChannelValuesForm1.value.CH6;
    obj['preset'] = this.getChannelValuesForm1.value.preseted;
    obj['facility_id'] = this.selectedGrowArea.container.facility.id;
    obj[
      'facility_name'
    ] = this.selectedGrowArea.container.facility.facility_name;
    obj['container_id'] = this.selectedGrowArea.container.id;
    obj['container_name'] = this.selectedGrowArea.container.container_name;
    obj['growarea_id'] = this.selectedGrowArea.id;
    obj['growarea_name'] = this.selectedGrowArea.grow_area_name;
    console.log(obj);
    this.ledProfileService.applyProfile(obj).subscribe(
      (successResponse: Response) => {
        console.log(successResponse);
        this.toastrService.success(
          'Profile scheduled successfully.',
          'Schedule Profile'
        );
        this.resetForm();
        this.sceduleProfileEndForm = new FormGroup({
          end_date: new FormControl(null, [Validators.required]),
        });
        this.sceduleProfileStartForm.reset();
        this.startDate = null;
        this.endDate = null;
        $('#myApplyModal').modal('hide');
        this.wrongTime = 0;
      },
      error => {
        this.resetForm();
        this.sceduleProfileEndForm = new FormGroup({
          end_date: new FormControl(null, [Validators.required]),
        });
        this.sceduleProfileStartForm.reset();
        this.startDate = null;
        this.endDate = null;
        this.wrongTime = 0;
      }
    );
  }
  rangeStartSelected(data) {
    if (data.start) {
      const dateobj = new Date(data.start);
      const format = 'MM/dd/yyyy HH:mm zzzz'; 
      const result = this.datePipe.transform(dateobj, format);
      this.startDate = JSON.stringify(result).split(' ')[0].substr(1);
      this.sceduleProfileStartForm.controls['start_date'].setValue(this.startDate);
      this.sceduleProfileStartForm.controls['timezoneOffset'].setValue(dateobj.getTimezoneOffset());
    }
    this.timeVerify();
    if (this.startDate && this.endDate) {
      this.isDateCorrect = new Date(this.startDate) > new Date(this.endDate) ? 1 : 0;
    }
  }
  rangeEndSelected(data) {
    if (data.end) {
      const dateobj = new Date(data.end); 
      const format = 'MM/dd/yyyy HH:mm zzzz'; 
      const result = this.datePipe.transform(dateobj, format);
      this.endDate = JSON.stringify(result).split(' ')[0].substr(1);
      this.sceduleProfileEndForm.controls['end_date'].setValue(this.endDate);
    }
    if (this.startDate && this.endDate) {
      this.isDateCorrect = new Date(this.startDate) > new Date(this.endDate) ? 2 : 0;
    }
  }
  // rangeEndSelected(data) {
  //   if (data.end) {
  //     const date = JSON.stringify(
  //       new Date(data.end.add(1, 'days').format('MM/DD/YYYY'))
  //     );
  //     this.endDate = date
  //       .split('T')[0]
  //       .replace(date.split('T')[0].charAt(0), '');
  //     this.sceduleProfileEndForm.controls['end_date'].setValue(this.endDate);
  //   }
  //   if (this.startDate && this.endDate) {
  //     this.isDateCorrect =
  //       new Date(this.startDate) > new Date(this.endDate) ? 2 : 0;
  //   }
  // }
  showEnd() {
    if (this.sceduleProfileStartForm.value.repeat) {
      return this.sceduleProfileStartForm.value.repeat.length > 0;
    }
  }
  disableCheck() {
    const flag = true;
    if (this.sceduleProfileStartForm &&
      this.sceduleProfileStartForm.valid &&
      this.showEnd() &&
      this.sceduleProfileEndForm.valid && this.isDateCorrect !== 1 && this.isDateCorrect !== 2 && this.timeVerify()
    ) {
      return false;
    } else if (this.sceduleProfileStartForm && this.sceduleProfileStartForm.valid && !this.showEnd() &&
    this.isDateCorrect !== 1 && this.isDateCorrect !== 2 &&  this.timeVerify()) {
      return false;
    }

    return flag;
  }
  timeVerify(){
    this.wrongTime = 0;
    if(this.startDate && this.sceduleProfileStartForm.value.start_time){
      const date = (new Date (this.startDate + ' ' + this.convertTime(this.sceduleProfileStartForm.value.start_time)));
      if(date.getTime() < (new Date).getTime()){
       this.wrongTime = 1;
      }
      else {
        this.wrongTime = 0;
      }
      return (date.getTime() < (new Date).getTime()) ? false : true ;
    }
    return false;
  }
  cleanSchedule(){
    this.sceduleProfileEndForm = new FormGroup({
      end_date: new FormControl(null, [Validators.required]),
    });
    this.sceduleProfileStartForm.reset();
    this.startDate = null;
    this.endDate = null;
    this.isDateCorrect = 0;
    this.wrongTime = 0;
  }
  cleanDates(){
    this.sceduleProfileEndForm = new FormGroup({
      end_date: new FormControl(null, [Validators.required]),
    });
    this.sceduleProfileStartForm.reset();
    this.startDate = null;
    this.endDate = null;
  }
  initialiseForms(){
    this.sceduleProfileStartForm = new FormGroup({
      start_date: new FormControl(null, [Validators.required]),
      start_time: new FormControl(null, [Validators.required]),
      timezoneOffset: new FormControl(null, [Validators.required]),
      repeat: new FormControl([])
    });
    this.sceduleProfileEndForm = new FormGroup({
      end_date: new FormControl(null, [Validators.required]),
    });
  }
  getTimeOne(startdate, time, offset) {
    const date = (new Date (startdate + ' ' + time));
    const fair = new Date (date.getTime() + (offset * 60000));
    const format = 'MM/dd/yyyy HH:mm zzzz';
    const result = this.datePipe.transform(fair, format);
    console.log(JSON.stringify(result));
    const d = JSON.stringify(result).split(' ')[0].substr(1) ;
    const t = JSON.stringify(result).split(' ')[1] ;
    const obj = {};
    obj['d'] = d;
    obj['t'] = t;
   return obj;
  }
}
