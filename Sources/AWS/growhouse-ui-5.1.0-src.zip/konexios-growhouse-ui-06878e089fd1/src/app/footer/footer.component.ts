import { Component, OnInit } from "@angular/core";
import { FooterService } from "../services/footer-service";
import { HttpErrorResponse } from "@angular/common/http";

@Component({
  selector: "app-footer",
  templateUrl: "./footer.component.html",
  styleUrls: ["./footer.component.css"],
})
export class FooterComponent implements OnInit {
  public version: string;
  public currentYear: string;

  constructor(private footerService: FooterService) {}

  ngOnInit() {
    this.getReleaseVersion();
    this.currentYear = new Date().getFullYear().toString();
  }
  getReleaseVersion() {
    this.footerService.getReleaseVersion().subscribe(
      (response: any) => {
        this.version = response.releaseVersion;
      },
      (errorResponse: HttpErrorResponse) => {}
    );
  }
}
