import { Container } from "./container.model";
import { Facility } from "./facility.model";

export class GrowArea {
  public id: number;
  public grow_area_name: string;
  public grow_area_type: GrowAreaType;
  public mac_id: string;
  public container: Container;
  public description: string;
  public layout: number;
  public grow_area_hid: string;
  public latest_heartbeat_timestamp: string;
  public facility: Facility;

  constructor(
    id: number,
    grow_area_name: string,
    grow_area_type: GrowAreaType,
    layout: number,
    mac_id: string,
    container: Container,
    description: string,
    grow_area_hid: string,
    latest_heartbeat_timestamp: string,
    facility: Facility
  ) {
    this.id = id;
    this.grow_area_name = grow_area_name;
    this.grow_area_type = grow_area_type;
    this.layout = layout;
    this.mac_id = mac_id;
    this.container = container;
    this.description = description;
    this.grow_area_hid = grow_area_hid;
    this.latest_heartbeat_timestamp = latest_heartbeat_timestamp;
    this.facility = facility;
  }
}

export class GrowAreaType {
  public id: number;
  public grow_area_type_name: string;

  constructor(id: number, grow_area_type_name: string) {
    this.id = id;
    this.grow_area_type_name = grow_area_type_name;
  }
}
