import { User } from "./user.model";

export class Country {
  public id: number;
  public name: string;
  public sort_name: string;
  constructor(id: number, name: string, sort_name: string) {
    this.name = name;
    this.sort_name = sort_name;
    this.id = id;
  }
}

export class State {
  public id: number;
  public name: string;
  public country: Country;
  constructor(id: number, name: string, country: Country) {
    this.name = name;
    this.country = country;
    this.id = id;
  }
}

export class Locality {
  public id: number;
  public name: string;
  public state: State;
  constructor(id: number, name: string, state: State) {
    this.name = name;
    this.state = state;
    this.id = id;
  }
}

export class Account {
  public id: number;
  public account_name: string;
  public admin: User;
  constructor(id: number, account_name: string, admin: User) {
    this.id = id;
    this.account_name = account_name;
    this.admin = admin;
  }
}

export class Grid {
  public layout: number;
  public cols: number;
  public rowHeight: string;
  public url: string;
  constructor(layout: number, cols: number, rowHeight: string, url: string) {
    this.layout = layout;
    this.cols = cols;
    this.url = url;
    this.url = url;
  }
}
