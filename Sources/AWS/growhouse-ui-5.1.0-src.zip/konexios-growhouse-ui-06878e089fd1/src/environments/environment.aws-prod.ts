export const environment = {
  production: true,
  appServerURL: "https://growhouse-api-aws.arrowconnect.io/api/",
  websocketServerURL:
    "https://growhouse-ws-aws.arrowconnect.io/growhouse-websocket",
};
