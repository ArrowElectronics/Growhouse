export const environment = {
  production: false,
  appServerURL: "http://growhouse-api-aws-dev.arrowconnect.io/api/",
  websocketServerURL:
    "http://growhouse-ws-aws-dev.arrowconnect.io/growhouse-websocket",
};
