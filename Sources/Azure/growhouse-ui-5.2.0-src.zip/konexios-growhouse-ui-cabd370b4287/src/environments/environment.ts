export const environment = {
  production: false,
  appServerURL: "https://growhouse-api-dev1.konexios.io/api/",
  websocketServerURL:
    "https://growhouse-ws-dev1.konexios.io/growhouse-websocket",
};
