export const environment = {
  production: true,
  appServerURL: "https://growhouse-api-arrow.arrowconnect.io/api/",
  websocketServerURL:
    "https://growhouse-ws-arrow.arrowconnect.io/growhouse-websocket",
};
