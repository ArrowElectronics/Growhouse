export const environment = {
    production: true,
    appServerURL: "https://growhouse-api-azure.arrowconnect.io/api/",
    websocketServerURL:
      "https://growhouse-ws-azure.arrowconnect.io/growhouse-websocket",
  };
  