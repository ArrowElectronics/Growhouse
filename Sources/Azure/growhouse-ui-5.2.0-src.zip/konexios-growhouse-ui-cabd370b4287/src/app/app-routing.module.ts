import { NgModule } from "@angular/core";
import { Routes, RouterModule, ChildActivationEnd } from "@angular/router";
import { LoginComponent } from "./login/login.component";
import { DashboardComponent } from "./dashboard/dashboard.component";
import { FacilitiesComponent } from "./facilities/facilities.component";
import { ContainersComponent } from "./containers/containers.component";
import { UsersComponent } from "./users/users.component";
import { GrowAreasComponent } from "./grow-areas/grow-areas.component";
import { GrowSectionsComponent } from "./grow-sections/grow-sections.component";
import { FacilityComponent } from "./facility/facility.component";
import { ContainerComponent } from "./container/container.component";
import { GrowAreaComponent } from "./grow-area/grow-area.component";
import { GrowSectionComponent } from "./grow-section/grow-section.component";
import { DevicesComponent } from "./devices/devices.component";
import { DeviceComponent } from "./device/device.component";
import { AccountsComponent } from "./accounts/accounts.component";
import { ProfilesComponent } from "./profiles/profiles.component";
// import { AuthGuard } from './services/auth-guard.service';

import { ProfileComponent } from "./profile/profile.component";
import { AlertsComponent } from "./alerts/alerts.component";
import { AuthGuard } from "./services/auth-guard.service";
import { DeviceTypesComponent } from "./device-types/device-types.component";
import { DeviceTypeComponent } from "./device-type/device-type.component";
import { GroupsComponent } from "./groups/groups.component";
import { GroupComponent } from "./group/group.component";
import { LedProfilesComponent } from "./led-profiles/led-profiles.component";
import { LedProfileComponent } from "./led-profile/led-profile.component";
import { EventsComponent } from "./events/events.component";

const appRoutes: Routes = [
  {
    path: "dashboard",
    component: DashboardComponent,
    canActivate: [AuthGuard],
  },
  {
    path: "accounts",
    component: AccountsComponent,
    data: {
      breadcrumb: "Accounts",
    },
    canActivate: [AuthGuard],
  },
  {
    path: "alerts",
    component: AlertsComponent,
    data: {
      breadcrumb: "Alerts",
    },
    canActivate: [AuthGuard],
  },
  {
    path: "profiles",
    component: ProfilesComponent,
    data: {
      breadcrumb: "Profiles",
    },
    canActivate: [AuthGuard],
    children: [
      {
        path: ":profileId",
        component: ProfileComponent,
      },
    ],
  },
  {
    path: "facilities",
    component: FacilitiesComponent,
    data: {
      breadcrumb: "Facilities",
    },
    canActivate: [AuthGuard],
    children: [
      {
        path: ":facilityId",
        component: FacilityComponent,
      },
    ],
  },
  {
    path: "facilities/:facilityId/profiles",
    component: ProfilesComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: ":profileId",
        component: ProfileComponent,
      },
    ],
  },
  {
    path:
      "facilities/:facilityId/containers/:containerId/grow-areas/:growareaId/profiles",
    component: ProfilesComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: ":profileId",
        component: ProfileComponent,
      },
    ],
  },
  {
    path:
      "facilities/:facilityId/containers/:containerId/grow-areas/:growareaId/deviceType/:deviceType",
    component: DeviceTypesComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: ":deviceId",
        component: DeviceTypeComponent,
      },
    ],
  },
  {
    path: "facilities/:facilityId/containers",
    component: ContainersComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: ":containerId",
        component: ContainerComponent,
      },
    ],
  },
  {
    path: "facilities/:facilityId/containers/:containerId/grow-areas",
    component: GrowAreasComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: ":growareaId",
        component: GrowAreaComponent,
      },
    ],
  },
  {
    path: "facilities/:facilityId/containers/:containerId/devices",
    component: DevicesComponent,
    canActivate: [AuthGuard],
    // runGuardsAndResolvers: 'always',
    children: [
      {
        path: ":deviceId",
        component: DeviceComponent,
      },
    ],
  },
  {
    path:
      "facilities/:facilityId/containers/:containerId/grow-areas/:growareaId/grow-sections",
    component: GrowSectionsComponent,
    canActivate: [AuthGuard],
  },
  {
    path:
      "facilities/:facilityId/containers/:containerId/grow-areas/:growareaId/grow-sections/:growsectionId",
    component: GrowSectionComponent,
    canActivate: [AuthGuard],
  },
  {
    path:
      "facilities/:facilityId/containers/:containerId/grow-areas/:growareaId/devices",
    component: DevicesComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: ":deviceId",
        component: DeviceComponent,
      },
    ],
  },
  {
    path: "facilities/:facilityId/grow-areas",
    component: GrowAreasComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: ":growareaId",
        component: GrowAreaComponent,
      },
    ],
  },
  {
    path: "facilities/:facilityId/grow-areas/:growareaId/grow-sections",
    component: GrowSectionsComponent,
    canActivate: [AuthGuard],
  },
  {
    path: "facilities/:facilityId/grow-areas/:growareaId/profiles",
    component: ProfilesComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: ":profileId",
        component: ProfileComponent,
      },
    ],
  },
  {
    path:
      "facilities/:facilityId/grow-areas/:growareaId/deviceType/:deviceType",
    component: DeviceTypesComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: ":deviceId",
        component: DeviceTypeComponent,
      },
    ],
  },
  {
    path: "containers/:containerId/grow-areas/:growareaId/profiles",
    component: ProfilesComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: ":profileId",
        component: ProfileComponent,
      },
    ],
  },
  {
    path:
      "containers/:containerId/grow-areas/:growareaId/deviceType/:deviceType",
    component: DeviceTypesComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: ":deviceId",
        component: DeviceTypeComponent,
      },
    ],
  },
  {
    path:
      "facilities/:facilityId/grow-areas/:growareaId/grow-sections/:growsectionId",
    component: GrowSectionComponent,
    canActivate: [AuthGuard],
  },
  {
    path: "facilities/:facilityId/grow-areas/:growareaId/devices",
    component: DevicesComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: ":deviceId",
        component: DeviceComponent,
      },
    ],
  },

  {
    path: "facilities/:facilityId/grow-sections",
    component: GrowSectionsComponent,
    canActivate: [AuthGuard],
  },
  {
    path: "facilities/:facilityId/grow-sections/:growsectionId",
    component: GrowSectionComponent,
    canActivate: [AuthGuard],
  },
  {
    path: "facilities/:facilityId/devices",
    component: DevicesComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: ":deviceId",
        component: DeviceComponent,
      },
    ],
  },
  {
    path: "containers",
    component: ContainersComponent,
    canActivate: [AuthGuard],
    data: {
      breadcrumb: "Containers",
    },
    children: [
      {
        path: ":containerId",
        component: ContainerComponent,
      },
    ],
  },
  {
    path: "containers/:containerId/profiles",
    component: ProfilesComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: ":profileId",
        component: ProfileComponent,
      },
    ],
  },
  {
    path: "containers/:containerId/grow-areas",
    component: GrowAreasComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: ":growareaId",
        component: GrowAreaComponent,
      },
    ],
  },
  {
    path: "containers/:containerId/grow-sections",
    component: GrowSectionsComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: ":growsectionId",
        component: GrowSectionComponent,
      },
    ],
  },
  {
    path: "containers/:containerId/devices",
    component: DevicesComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: ":deviceId",
        component: DeviceComponent,
      },
    ],
  },
  {
    path: "containers/:containerId/grow-areas/:growareaId/grow-sections",
    component: GrowSectionsComponent,
    canActivate: [AuthGuard],
  },
  {
    path:
      "containers/:containerId/grow-areas/:growareaId/grow-sections/:growsectionId",
    component: GrowSectionComponent,
    canActivate: [AuthGuard],
  },
  {
    path: "containers/:containerId/grow-areas/:growareaId/devices",
    component: DevicesComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: ":deviceId",
        component: DeviceComponent,
      },
    ],
  },
  {
    path: "grow-areas",
    component: GrowAreasComponent,
    canActivate: [AuthGuard],
    data: {
      breadcrumb: "Grow Areas",
    },
    children: [
      {
        path: ":growareaId",
        component: GrowAreaComponent,
      },
    ],
  },
  {
    path: "grow-areas/:growareaId/profiles",
    component: ProfilesComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: ":profileId",
        component: ProfileComponent,
      },
    ],
  },
  // {
  //   path: 'growareas/:growareaId/devicetype/:deviceTypeId',
  //   component: DevicesComponent,
  //   canActivate: [AuthGuard]
  // },
  {
    path: "grow-areas/:growareaId/devices",
    component: DevicesComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: ":deviceId",
        component: DeviceComponent,
      },
    ],
  },
  {
    path: "grow-areas/:growareaId/deviceType/:deviceType",
    component: DeviceTypesComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: ":deviceId",
        component: DeviceTypeComponent,
      },
    ],
  },
  {
    path: "grow-areas/:growareaId/grow-sections/view",
    component: GrowSectionComponent,
    canActivate: [AuthGuard],
  },
  {
    path: "grow-areas/:growareaId/grow-sections/add",
    component: GrowSectionComponent,
    canActivate: [AuthGuard],
  },
  {
    path: "grow-sections",
    component: GrowSectionsComponent,
    canActivate: [AuthGuard],
    data: {
      breadcrumb: "Grow Sections",
    },
  },
  {
    path: "grow-sections/:growsectionId",
    component: GrowSectionComponent,
    canActivate: [AuthGuard],
  },
  {
    path: "devices",
    component: DevicesComponent,
    canActivate: [AuthGuard],
    data: {
      breadcrumb: "Devices",
    },
    children: [
      {
        path: ":deviceId",
        component: DeviceComponent,
      },
    ],
  },
  {
    path: "users",
    component: UsersComponent,
    canActivate: [AuthGuard],
    data: {
      breadcrumb: "Users",
    },
  },
  {
    path:
      "facilities/:facilityId/containers/:containerId/grow-areas/:growareaId/groups",
    component: GroupsComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: ":groupId",
        component: GroupComponent,
      },
    ],
  },
  {
    path: "facilities/:facilityId/grow-areas/:growareaId/groups",
    component: GroupsComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: ":groupId",
        component: GroupComponent,
      },
    ],
  },
  {
    path: "containers/:containerId/grow-areas/:growareaId/groups",
    component: GroupsComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: ":groupId",
        component: GroupComponent,
      },
    ],
  },
  {
    path: "grow-areas/:growareaId/groups",
    component: GroupsComponent,
    canActivate: [AuthGuard],
    data: {
      breadcrumb: "Groups",
    },
    children: [
      {
        path: ":groupId",
        component: GroupComponent,
      },
    ],
  },
  {
    path: "groups",
    component: GroupsComponent,
    canActivate: [AuthGuard],
    data: {
      breadcrumb: "groups",
    },
    children: [
      {
        path: ":groupId",
        component: GroupComponent,
      },
    ],
  },
  {
    path:
      "facilities/:facilityId/containers/:containerId/grow-areas/:growareaId/groups/:groupId/profiles",
    component: LedProfilesComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: ":profileId",
        component: LedProfileComponent,
      },
    ],
  },
  {
    path:
      "facilities/:facilityId/grow-areas/:growareaId/groups/:groupId/profiles",
    component: LedProfilesComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: ":profileId",
        component: LedProfileComponent,
      },
    ],
  },
  {
    path:
      "containers/:containerId/grow-areas/:growareaId/groups/:groupId/profiles",
    component: LedProfilesComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: ":profileId",
        component: LedProfileComponent,
      },
    ],
  },
  {
    path: "grow-areas/:growareaId/groups/:groupId/profiles",
    component: LedProfilesComponent,
    canActivate: [AuthGuard],
    data: {
      breadcrumb: "Profiles",
    },
    children: [
      {
        path: ":profileId",
        component: LedProfileComponent,
      },
    ],
  },
  {
    path: "profiles",
    component: LedProfilesComponent,
    canActivate: [AuthGuard],
    data: {
      breadcrumb: "Profiles",
    },
    children: [
      {
        path: ":profileId",
        component: LedProfileComponent,
      },
    ],
  },
  {
    path:
      "facilities/:facilityId/containers/:containerId/grow-areas/:growareaId/groups/:groupId/events",
    component: EventsComponent,
    canActivate: [AuthGuard],
  },
  {
    path:
      "facilities/:facilityId/grow-areas/:growareaId/groups/:groupId/events",
    component: EventsComponent,
    canActivate: [AuthGuard],
  },
  {
    path:
      "containers/:containerId/grow-areas/:growareaId/groups/:groupId/events",
    component: EventsComponent,
    canActivate: [AuthGuard],
  },
  {
    path: "grow-areas/:growareaId/groups/:groupId/events",
    component: EventsComponent,
    canActivate: [AuthGuard],
    data: {
      breadcrumb: "Events",
    },
  },
  {
    path: "events",
    component: EventsComponent,
    canActivate: [AuthGuard],
    data: {
      breadcrumb: "Events",
    },
  },
  { path: "", component: LoginComponent, pathMatch: "full" },
  { path: "change-password", component: LoginComponent, pathMatch: "full" },
];

@NgModule({
  imports: [RouterModule.forRoot(appRoutes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
