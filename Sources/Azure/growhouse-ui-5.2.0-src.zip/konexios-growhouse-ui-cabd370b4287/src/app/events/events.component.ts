import { Component, OnInit, ViewChild } from '@angular/core';
import { GrowAreaService } from '../services/growarea-service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { GlobalService } from '../services/global-service';
import { ContainerService } from '../services/container-service';
import { FacilityService } from '../services/facility-service';
import { GroupService } from '../services/group-service';

import { ActivatedRoute, Router, Params } from '@angular/router';
import { BreadcrumbsService } from 'ng6-breadcrumbs';
import { Subject } from 'rxjs';
import { DataTableDirective } from 'angular-datatables';
import { GrowArea } from '../models/growarea.model';
import { Facility } from '../models/facility.model';
import { User } from '../models/user.model';
import { Container } from '../models/container.model';
import { Group } from '../models/group.model';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { toDate } from '@angular/common/src/i18n/format_date';
declare var $: any;
@Component({
  selector: 'app-events',
  templateUrl: './events.component.html',
  styleUrls: ['./events.component.css']
})
export class EventsComponent implements OnInit {
  dtOptions: any = {};
  dtTrigger: Subject<any> = new Subject();
  @ViewChild(DataTableDirective)
  private datatableElement: DataTableDirective;
  loggedInUser: User;
  selectedGrowArea: GrowArea;
  selectedFacility: Facility;
  selectedContainer: Container;
  selectedGroup: Group;
  isEventLoad = false;
  isAPILoading = false;
  delete =false;
  deleteEvent;
events = [];
  constructor(
    private growareaService: GrowAreaService,
    private toastrService: ToastrService,
    private groupService: GroupService,
    private containerService: ContainerService,
    private facilityService: FacilityService,
    private route: ActivatedRoute,
    private breadcrumbService: BreadcrumbsService,
    private router: Router,
    private globalService: GlobalService
  ) { }

  ngOnInit() {
    this.breadcrumbService.store([
      { label: 'Events', url: '/events', params: [] }
    ]);
    const elem = document.getElementById('headerMenuCollapse');
    if (elem) {
      elem.classList.remove('show');
    }
    // datatable options for facility table
    this.loggedInUser = JSON.parse(localStorage.getItem('loggedInUser'));
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 10,
      info: false,
      order: [],
      lengthChange: false,
      select: true,
      language: {
        zeroRecords: 'No Events to display',
        paginate: {
          next: '>', // or '→'
          previous: '<', // or '←',
        }
      }
    };
    this.groupService.selectedGroup.subscribe((group: Group) => {
      this.selectedGroup = group;
    });
    this.route.params.subscribe((params: Params) => {
      console.log(params);
      if (
        params.facilityId &&
        params.containerId &&
        params.growareaId &&
        params.groupId
      ) {
        console.log('Params' + JSON.stringify(params));
        this.getFacilityById(
          params.facilityId,
          params.containerId,
          params.growareaId,
          params.groupId
        );
        this.getEvents(params.groupId);
      } else if (params.facilityId && params.growareaId && params.groupId) {
        console.log('Params' + JSON.stringify(params));
        this.getFacilityById(
          params.facilityId,
          undefined,
          params.growareaId,
          params.groupId
        );
        this.getEvents(params.groupId);
      } else if (params.containerId && params.growareaId && params.groupId) {
        console.log('Params' + JSON.stringify(params));
        this.getContainerById(
          params.containerId,
          params.growareaId,
          params.groupId
        );
        this.getEvents(params.groupId);
      } else if (params.growareaId && params.groupId) {
        console.log('Params' + JSON.stringify(params));
        this.getGrowareaById(params.growareaId, params.groupId);
        this.getEvents(params.groupId);
      } else {
        console.log('Params' + JSON.stringify(params));
        this.getEvents(params.groupId);
      }
    });
  }
  getEvents(groupId) {
    this.isEventLoad = true;
    this.events = [];
    console.log(groupId);
    this.groupService.getEventsByGroupId(groupId).subscribe(
      (response: any[]) => {
        setTimeout(() => {
          console.log(response);
          this.events = response;
          this.dtTrigger.next();

        }, 500);
        this.isEventLoad = false;
      }, error =>{
        this.isEventLoad = false;
      }
      );

  }
  onDeletChanges(event) {
    this.delete = true;
    console.log('OnDeletChanges called');
    this.deleteEvent = event;
  }
  onDeleteEve() {
    this.isAPILoading = true;
    this.groupService.deleteEvent(this.deleteEvent.job_name).subscribe(
      response => {
        console.log(response);
        this.datatableElement.dtInstance.then((dtInstance: DataTables.Api) => {
          dtInstance.destroy();
        });
        this.toastrService.success(
          'Event deleted successfully',
          'Delete Event'
        );
        this.isAPILoading = false;
        if (this.selectedGroup) {
          this.router.navigate(['/grow-areas/' + this.selectedGroup.growarea_id + '/groups/' + this.selectedGroup.id + '/events' ]);
        }
        this.getEvents(this.selectedGroup.id);
      },
      (error) => {
        this.deleteEvent = null;
        this.isAPILoading = false;
      });
  }
  getFacilityById(id, containerId, growareaId, groupId) {
    this.facilityService.getFacilityById(id).subscribe((response: Facility) => {
      this.selectedFacility = response;
      if (containerId && growareaId && groupId) {
        this.getContainerById(containerId, growareaId, groupId);
      } else if (containerId) {
        this.getContainerById(containerId, undefined, undefined);
      } else {
        this.getGrowareaById(growareaId, groupId);
      }
    });
  }
  getContainerById(containerId, growareaId, groupId) {
    this.containerService
      .getContainerById(containerId)
      .subscribe((response: Container) => {
        this.selectedContainer = response;
        this.getGrowareaById(growareaId, groupId);
      });
  }
  getGrowareaById(growareaId, groupId) {
    this.growareaService
      .getGrowAreaById(growareaId)
      .subscribe((response: GrowArea) => {
        this.selectedGrowArea = response;
        this.getGroupByGroupId(groupId);
      });
  }
  getGroupByGroupId(groupId) {
    this.groupService
      .getGroupByGroupId(groupId)
      .subscribe((response: Group) => {
        this.selectedGroup = response;
        console.log(this.selectedGrowArea);
        this.groupService.selectedGroup.emit(this.selectedGroup);
        if (
          this.selectedFacility &&
          this.selectedContainer &&
          this.selectedGrowArea &&
          this.selectedGroup
        ) {
          this.breadcrumbService.store([
            { label: 'Facilities', url: '/facilities', params: [] },
            {
              label: this.selectedFacility.facility_name,
              url: '/facilities/' + this.selectedFacility.id,
              params: []
            },
            {
              label: 'Containers',
              url: '/facilities/' + this.selectedFacility.id + '/containers',
              params: []
            },
            {
              label: this.selectedContainer.container_name + '',
              url:
                '/facilities/' +
                this.selectedFacility.id +
                '/containers/' +
                this.selectedContainer.id,
              params: []
            },
            {
              label: 'Grow Areas',
              url:
                '/facilities/' +
                this.selectedFacility.id +
                '/containers/' +
                this.selectedContainer.id +
                '/grow-areas',
              params: []
            },
            {
              label: this.selectedGrowArea.grow_area_name + '',
              url:
                '/facilities/' +
                this.selectedFacility.id +
                '/containers/' +
                this.selectedContainer.id +
                '/grow-areas/' +
                this.selectedGrowArea.id,
              params: []
            },
            {
              label: 'Groups',
              url:
                '/facilities/' +
                this.selectedFacility.id +
                '/containers/' +
                this.selectedContainer.id +
                '/grow-areas/' +
                this.selectedGrowArea.id +
                '/groups',
              params: []
            },
            {
              label: this.selectedGroup.group_name + '',
              url:
                '/facilities/' +
                this.selectedFacility.id +
                '/containers/' +
                this.selectedContainer.id +
                '/grow-areas/' +
                this.selectedGrowArea.id +
                '/groups/' +
                this.selectedGroup.id,
              params: []
            },
            { label: 'Events', url: '', params: [] }
          ]);
        } else if (
          this.selectedFacility &&
          this.selectedGrowArea &&
          this.selectedGroup
        ) {
          this.breadcrumbService.store([
            { label: 'Facilities', url: '/facilities', params: [] },
            {
              label: this.selectedFacility.facility_name,
              url: '/facilities/' + this.selectedFacility.id,
              params: []
            },
            {
              label: 'Grow Areas',
              url: '/facilities/' + this.selectedFacility.id + '/grow-areas',
              params: []
            },
            {
              label: this.selectedGrowArea.grow_area_name + '',
              url:
                '/facilities/' +
                this.selectedFacility.id +
                '/grow-areas/' +
                this.selectedGrowArea.id,
              params: []
            },
            {
              label: 'Groups',
              url:
                '/facilities/' +
                this.selectedFacility.id +
                '/grow-areas/' +
                this.selectedGrowArea.id +
                '/groups',
              params: []
            },
            {
              label: this.selectedGroup.group_name + '',
              url:
                '/facilities/' +
                this.selectedFacility.id +
                '/grow-areas/' +
                this.selectedGrowArea.id +
                '/groups/' +
                this.selectedGroup.id,
              params: []
            },
            { label: 'Events', url: '', params: [] }
          ]);
        } else if (
          this.selectedContainer &&
          this.selectedGrowArea &&
          this.selectedGroup
        ) {
          this.breadcrumbService.store([
            { label: 'Containers', url: '/containers', params: [] },
            {
              label: this.selectedContainer.container_name + '',
              url: '/containers/' + this.selectedContainer.id,
              params: []
            },
            {
              label: 'Grow Areas',
              url: '/containers/' + this.selectedContainer.id + '/grow-areas',
              params: []
            },
            {
              label: this.selectedGrowArea.grow_area_name + '',
              url:
                '/containers/' +
                this.selectedContainer.id +
                '/grow-areas/' +
                this.selectedGrowArea.id,
              params: []
            },
            {
              label: 'Groups',
              url:
                '/containers/' +
                this.selectedContainer.id +
                '/grow-areas/' +
                this.selectedGrowArea.id +
                '/groups',
              params: []
            },
            {
              label: this.selectedGroup.group_name + '',
              url:
                '/containers/' +
                this.selectedContainer.id +
                '/grow-areas/' +
                this.selectedGrowArea.id +
                '/groups/' +
                this.selectedGroup.id,
              params: []
            },
            { label: 'Events', url: '', params: [] }
          ]);
        } else if (this.selectedGrowArea && this.selectedGroup) {
          this.breadcrumbService.store([
            {
              label: 'Grow Areas',
              url: '/grow-areas',
              params: []
            },
            {
              label: this.selectedGrowArea.grow_area_name + '',
              url: '/grow-areas/' + this.selectedGrowArea.id,
              params: []
            },
            {
              label: 'Groups',
              url: '/grow-areas/' + this.selectedGrowArea.id + '/groups',
              params: []
            },
            {
              label: this.selectedGroup.group_name + '',
              url:
                '/grow-areas/' +
                this.selectedGrowArea.id +
                '/groups/' +
                this.selectedGroup.id,
              params: []
            },
            { label: 'Events', url: '', params: [] }
          ]);
        } else {
          this.breadcrumbService.store([
            { label: 'Events', url: '', params: [] },
          ]);
        }
        this.addReloadEventToBreadcrumb();
      });
  }
  // getTime(startdate, time, offset) {
  //   const date = (new Date (startdate + ' ' + time));
  //   return (date.getTime() + (offset * 60000)) + (date.getTimezoneOffset() * -60000);
  // }
  addReloadEventToBreadcrumb() {
    setTimeout(() => {
      const elems = document.querySelectorAll('.breadcrumb-item a');
      console.log(elems);
      console.log('length     ', elems.length);
      for (let i = 0; i < elems.length; i++) {
        elems[i].addEventListener('click', this.globalService.handleClick);
      }
    }, 100);
  }
  getTime(startdate, time) {
    const date = (new Date (startdate + ' ' + time));
    return date.getTime() + (date.getTimezoneOffset() * -60000);
  }
}
