import { Container } from './container.model';


export class Group {
  public id: number;
  public growarea_id: number;
  public group_name: string;
  public generated_group_name: string;
  public description: string;
  public channel_configuration: ChannelConfiguration;
  constructor(
    id: number,
    growarea_id: number,
    group_name: string,
    generated_group_name: string,
    channel_configuration: ChannelConfiguration,
    description: string
  ) {
    this.id = id;
    growarea_id = growarea_id,
    this.group_name = group_name;
    this.generated_group_name = generated_group_name;
    this.channel_configuration = channel_configuration;
    this.description = description;
  }
}

export class ChannelConfiguration {
  public CH1: string;
  public CH2: string;
  public CH3: string;
  public CH4: string;
  public CH5: string;
  public CH6: string;

  constructor(CH1: string, CH2: string,CH3: string,CH4: string,CH5: string,CH6: string) {
    this.CH1 = CH1;
    this.CH2 = CH2;
    this.CH3 = CH3;
    this.CH4 = CH4;
    this.CH5 = CH5;
    this.CH6 = CH6;

  }
}
