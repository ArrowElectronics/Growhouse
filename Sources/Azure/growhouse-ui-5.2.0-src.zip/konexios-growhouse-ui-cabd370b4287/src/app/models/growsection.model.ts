import { GrowArea } from './growarea.model';
import { Device } from './device.model';
export class GrowSection {
  public id: number;
  public grow_section_name: string;
  public size: string;
  public grow_area: GrowArea;
  public devices: Device[];

  constructor(
    id: number,
    grow_section_name: string,
    grow_area: GrowArea,
    size: string,
    devices: Device[]
  ) {
    this.id = id;
    this.grow_section_name = grow_section_name;
    this.grow_area = grow_area;
    this.size = size;
    this.devices = devices;
  }
}
