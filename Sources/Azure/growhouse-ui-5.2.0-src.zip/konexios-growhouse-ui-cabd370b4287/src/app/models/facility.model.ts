import { User } from './user.model';
import { Locality } from './global.model';



export class Facility {

    public id: number;
    public facility_name: string;
    public admin: User;
    public zip: number;
    public locality: Locality;
    public description: string;
    public latitude: number;
    public longitude: number;

    constructor( id: number,
              facility_name: string,
              admin: User,
              zip: number,
              locality: Locality,
              description: string,
              latitude: number,
              longitude: number
              ) {

        this.id = id;
        this.facility_name = facility_name;
        this.admin = admin;
        this.zip = zip;
        this.locality = locality;
        this.description = description;
        this.latitude = latitude;
        this.longitude = longitude;
    }
}
