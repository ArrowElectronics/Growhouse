import { Component, OnDestroy, OnInit } from "@angular/core";
import { ActivatedRoute, Params, Router } from "@angular/router";
import { BreadcrumbsService } from "ng6-breadcrumbs";
import { ProfileMessage } from "src/app/global";
import { Facility } from "../models/facility.model";
import { AlertsService } from "../services/alerts-service";
import { FacilityService } from "../services/facility-service";
import { GlobalService } from "../services/global-service";

@Component({
  selector: "app-facility",
  templateUrl: "./facility.component.html",
  styleUrls: ["./facility.component.css"],
})
export class FacilityComponent implements OnInit, OnDestroy {
  model: any = {
    onColor: "primary",
    offColor: "secondary",
    offText: "Off",
    disabled: false,
    size: "",
    value: null,
  };
  ALL_OK = ProfileMessage.ALL_OK;
  NEED_WATER = ProfileMessage.NEED_WATER;
  NEED_SUN = ProfileMessage.NEED_SUN;
  MORE_SUN = ProfileMessage.MORE_SUN;
  selectedFacility: Facility;
  facilitycountObj;
  // boolean values
  redPlant = false;
  bluePlant = false;
  yellowPlant = false;
  greenPlant = false;
  isHistoricAlertButton = true;
  isLiveAlertButton = false;
  alerts: any[] = [];
  liveAlerts: any[] = [];
  ws: any = {};
  topic: string[] = [];
  profiles: any[] = [];
  alertsOfProfileLoad = false;

  constructor(
    private facilityService: FacilityService,
    private globalService: GlobalService,
    private router: Router,
    private route: ActivatedRoute,
    private breadcrumService: BreadcrumbsService,
    private alertsService: AlertsService
  ) {}

  ngOnInit() {
    this.route.params.subscribe((params: Params) => {
      if (params.facilityId) {
        this.getFacilityById(params.facilityId);
        this.getCountsById(params.facilityId);
        this.getProfilesByFacilityId(params.facilityId);
      }
    });
    this.facilityService.ediFacility.subscribe((response: Number) => {
      console.log(response);
      this.getFacilityById(response);
    });
  }

  getCountsById(id) {
    this.facilityService.getCountByFacilityId(id).subscribe((response) => {
      console.log(response);
      this.facilitycountObj = response;
    });
  }

  getFacilityById(id) {
    //
    this.facilityService.getFacilityById(id).subscribe(
      (response: Facility) => {
        this.selectedFacility = response;
        console.log(this.selectedFacility);
        this.facilityService.selectedFacility.emit(this.selectedFacility);
        this.breadcrumService.store([
          { label: "Facilities", url: "/facilities", params: [] },
          {
            label: this.selectedFacility.facility_name + "",
            url: "/facilities/" + this.selectedFacility.id,
            params: [],
          },
        ]);
        this.addReloadEventToBreadcrumb();
      },
      (error) => {
        console.log("Error" + JSON.stringify(error));
      }
    );
  }
  addReloadEventToBreadcrumb() {
    setTimeout(() => {
      const elems = document.querySelectorAll(".breadcrumb-item a");
      console.log(elems);
      console.log("length     ", elems.length);
      for (let i = 0; i < elems.length; i++) {
        elems[i].addEventListener("click", this.globalService.handleClick);
      }
    }, 100);
  }
  getProfilesByFacilityId(facilityId) {
    this.globalService
      .getProfileAlertsByFacilityId(facilityId)
      .subscribe((response: any[]) => {
        this.profiles = response;
        for (let i = 0; i < this.profiles.length; i++) {
          let properties;
          const properties_arr = [];
          properties = JSON.parse(this.profiles[i].properties);
          // tslint:disable-next-line:forin
          for (const key in properties) {
            properties_arr.push({ name: key, value: properties[key] });
          }

          this.profiles[i].properties = properties_arr.sort((a, b) =>
            a.name > b.name ? 1 : -1
          );
        }
      });
  }

  onLoadAllProfile() {
    this.router.navigate(["profiles"], { relativeTo: this.route });
  }

  onClickOfContainer() {
    // tslint:disable-next-line:max-line-length
    this.router.navigate(["containers"], { relativeTo: this.route });
  }

  onClickOfGrowArea() {
    this.router.navigate(["grow-areas"], { relativeTo: this.route });
  }

  onClickOfGrowSection() {
    this.router.navigate(["grow-sections"], { relativeTo: this.route });
  }

  onClickOfDevice() {
    this.router.navigate(["devices"], { relativeTo: this.route });
  }

  ngOnDestroy(): void {
    this.facilityService.selectedFacility.emit(undefined);
  }

  onClickViewAllAlerts() {
    this.alerts = [];
    this.alertsOfProfileLoad = true;
    let prop_arr = [];
    let properties;
    this.alertsService
      .getAllProfileAlertsByFacilityId(this.selectedFacility.id)
      .subscribe(
        (response: any) => {
          console.log(response);
          if (response) {
            this.alerts = response;
            for (let i = 0; i < this.alerts.length; i++) {
              properties = this.alerts[i].properties
                ? JSON.parse(this.alerts[i].properties)
                : {};
              console.log(properties);
              // tslint:disable-next-line:forin
              prop_arr = [];
              for (const key in properties) {
                prop_arr.push({ name: key, value: properties[key] });
              }
              this.alerts[i].properties = prop_arr;
            }
            // this.alerts.sort((val1, val2) => {
            //   const date1 = parseInt(val2.created_date, 10);
            //   const date2 = parseInt(val1.created_date, 10);
            //   return date1 - date2;
            // });
          }
          console.log(this.alerts);
          this.alertsOfProfileLoad = false;
        },
        (error) => {
          this.alertsOfProfileLoad = false;
        }
      );
  }
}
