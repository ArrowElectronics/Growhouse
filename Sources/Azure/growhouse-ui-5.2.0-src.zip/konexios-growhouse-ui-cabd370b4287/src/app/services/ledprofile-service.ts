import { HttpClient } from "@angular/common/http";
import { EventEmitter, Injectable } from "@angular/core";
import { String } from "typescript-string-operations";
import { environment } from "../../environments/environment";
import { appConfig } from "../global";

@Injectable({
  providedIn: "root",
})
export class LedProfileService {
  private url: string = environment.appServerURL;
  selectedProfile = new EventEmitter<any>();
  ediProfile = new EventEmitter<any>();

  constructor(private http: HttpClient) {}

  getProfilesByGroupId(groupId: number) {
    return this.http.get(
      this.url + String.Format(appConfig.getProfiles, groupId)
    );
  }
  createProfile(profile) {
    return this.http.post(this.url + appConfig.createLedProfile, profile);
  }
  updateProfile(profile) {
    return this.http.put(this.url + appConfig.createLedProfile, profile);
  }
  deleteProfile(profileId) {
    return this.http.delete(
      String.Format(this.url + appConfig.deleteLedProfile, profileId)
    );
  }
  getProfileByProfileId(profileId) {
    return this.http.get(
      String.Format(this.url + appConfig.getProfileByProfileId, profileId)
    );
  }
  applyProfile(event) {
    return this.http.post(this.url + appConfig.applyProfile, event);
  }
  applyProfileNow(event) {
    return this.http.post(this.url + appConfig.applyNow, event);
  }
}
