import { HttpClient } from "@angular/common/http";
import { EventEmitter, Injectable } from "@angular/core";
import { environment } from "../../environments/environment";
import { appConfig } from "../global";
import { Container } from "../models/container.model";
import { User } from "../models/user.model";

@Injectable({
  providedIn: "root",
})
export class UserService {
  private url: string = environment.appServerURL;
  selectedContainer = new EventEmitter<Container>();
  constructor(private http: HttpClient) {}

  getUsers() {
    return this.http.get(this.url + appConfig.users);
  }

  getAdminUsers() {
    return this.http.get(this.url + appConfig.getAdminUsers);
  }

  getUserRoles() {
    return this.http.get(this.url + appConfig.userRoles);
  }

  createUser(user: User) {
    return this.http.post(this.url + appConfig.users, user);
  }

  updateUser(user: User, userId: number) {
    return this.http.put(this.url + appConfig.users + "/" + userId, user);
  }

  deleteUser(userId: number) {
    return this.http.delete(this.url + appConfig.users + "/" + userId);
  }

  verifyUser() {
    return this.http.get(this.url + appConfig.verifyUser);
  }
}
