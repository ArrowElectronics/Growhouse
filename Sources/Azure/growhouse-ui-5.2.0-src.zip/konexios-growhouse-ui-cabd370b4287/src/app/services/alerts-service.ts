import { HttpClient, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { environment } from "../../environments/environment";
import { appConfig } from "../global";
import { User } from "../models/user.model";

@Injectable({
  providedIn: "root",
})
export class AlertsService {
  private url: string = environment.appServerURL;
  constructor(private http: HttpClient) {}

  getAllProfileAlerts() {
    return this.http.get(this.url + appConfig.allAlerts);
  }

  getAllProfileAlertsByFacilityId(facilityId: number) {
    return this.http.get(
      this.url + appConfig.allAlertsByFacilityId + facilityId
    );
  }
  getAllProfileAlertsByContainerId(containerId: number) {
    return this.http.get(
      this.url + appConfig.allAlertsByContainerId + containerId
    );
  }
  getAllProfileAlertsByGrowAreaId(growAreaId: number) {
    return this.http.get(
      this.url + appConfig.allAlertsByGrowareaId + growAreaId
    );
  }
  getAllAlertsByFilter(fromTimestamp, toTimestamp, alertmessage) {
    const params = new HttpParams()
      .set("fromTimestamp", fromTimestamp)
      .set("toTimestamp", toTimestamp)
      .set("alertmessage", alertmessage);
    return this.http.get(this.url + appConfig.allAlertsByFilter, { params });
  }
  getUserRoles() {
    return this.http.get(this.url + appConfig.userRoles);
  }

  createUser(user: User) {
    return this.http.post(this.url + appConfig.users, user);
  }

  updateUser(user: User, userId: number) {
    return this.http.put(this.url + appConfig.users + "/" + userId, user);
  }

  deleteUser(userId: number) {
    return this.http.delete(this.url + appConfig.users + "/" + userId);
  }

  verifyUser() {
    return this.http.get(this.url + appConfig.verifyUser);
  }

  // changePassword(passwordData) {
  //   return this.http.post(this.url + appConfig.changePassword, passwordData);
  // }
}
