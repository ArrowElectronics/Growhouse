import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { environment } from "../../environments/environment";
import { appConfig } from "../global";

@Injectable({
  providedIn: "root",
})
export class FooterService {
  constructor(private http: HttpClient) {}
  private url: string = environment.appServerURL;

  getReleaseVersion() {
    return this.http.get(this.url + appConfig.releaseVersion);
  }
}
