import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { environment } from "../../environments/environment";
import { appConfig } from "../global";

@Injectable({
  providedIn: "root",
})
export class AccountService {
  private url: string = environment.appServerURL;
  constructor(private http: HttpClient) {}

  getAccounts() {
    return this.http.get(this.url + appConfig.accounts);
  }

  createAccount(account) {
    return this.http.post(this.url + appConfig.accounts, account);
  }

  updateAccount(account: Account, accountId: number) {
    return this.http.put(
      this.url + appConfig.accounts + "/" + accountId,
      account
    );
  }

  deleteAccount(accountId: number) {
    return this.http.delete(this.url + appConfig.accounts + "/" + accountId);
  }
}
