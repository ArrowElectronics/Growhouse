import { HttpClient, HttpParams } from "@angular/common/http";
import { EventEmitter, Injectable } from "@angular/core";
import { String } from "typescript-string-operations";
import { environment } from "../../environments/environment";
import { appConfig } from "../global";
import { Device, DeviceType } from "../models/device.model";

@Injectable({
  providedIn: "root",
})
export class DeviceService {
  private url: string = environment.appServerURL;
  selectedDevice = new EventEmitter<Device>();
  selectedDeviceType = new EventEmitter<DeviceType>();

  constructor(private http: HttpClient) {}

  getPropertiesHistoryByDate(
    deviceId,
    fromTimestamp,
    toTimestamp,
    propertyName
  ) {
    const params = new HttpParams()
      .set("fromTimestamp", fromTimestamp)
      .set("toTimestamp", toTimestamp)
      .set("propertyName", propertyName);
    return this.http.get(
      this.url + appConfig.propertiesHistory + "/" + deviceId,
      { params }
    );
  }
  getDevicesByType(growareaId, deviceTypeId) {
    // return this.http.get(this.url + appConfig.devicesByGrowareaIDNDeviceType);
    return this.http.get(
      this.url +
        String.Format(
          appConfig.devicesByGrowareaIDNDeviceType,
          growareaId,
          deviceTypeId
        )
    );
  }
  getOutOfNetworkCountOfAllDevices(growareaId) {
    return this.http.get(
      this.url + String.Format(appConfig.outOfNetworkAllDevices, growareaId)
    );
  }
  getOutOfNetworkCountOfDevicesByType(growareaId, deviceType) {
    return this.http.get(
      this.url +
        String.Format(
          appConfig.outOfNetworkDevicesByType,
          growareaId,
          deviceType
        )
    );
  }
  getDevices() {
    return this.http.get(this.url + appConfig.devices);
  }

  getRGBLightNode(deviceId) {
    return this.http.get(
      this.url +
        appConfig.ledNodeRGBValue +
        "/" +
        deviceId +
        "/channelconfiguration"
    );
  }

  setRGBLightNodeValue(channelData: any) {
    return this.http.post(this.url + appConfig.ledNodeSetRGBValue, channelData);
  }

  setLedNodeProfile(profileData: any) {
    return this.http.post(
      this.url + appConfig.ledNodeRGBValue + "/profile",
      profileData
    );
  }

  getProfileData(deviceId) {
    return this.http.get(
      this.url + appConfig.ledNodeRGBValue + "/" + deviceId + "/profile"
    );
  }

  getPropertiesByDeviceId(deviceId) {
    return this.http.get(
      this.url + appConfig.propertiesByDevice + "/" + deviceId
    );
  }

  getDevicesByFacility(facilityId: number) {
    return this.http.get(
      this.url + appConfig.devicesByFacility + "/" + facilityId
    );
  }

  getDevicesByContainer(containerId: number) {
    return this.http.get(
      this.url + appConfig.devicesByContainer + "/" + containerId
    );
  }

  getDevicesByGrowarea(growareaId: number) {
    return this.http.get(
      this.url + appConfig.devicesByGrowarea + "/" + growareaId
    );
  }

  getDeviceById(deviceId: number) {
    return this.http.get(this.url + appConfig.devices + "/" + deviceId);
  }

  deleteDeviceById(deviceId: number) {
    return this.http.delete(this.url + appConfig.devices + "/" + deviceId);
  }

  getDeviceTypes() {
    return this.http.get(this.url + appConfig.devicetypes);
  }

  getDevicesByGrowareaAndDeviceType(growareaId, devicetypeId) {
    return this.http.get(
      this.url +
        appConfig.devicesByGrowarea +
        "/" +
        growareaId +
        "/devicetype/" +
        devicetypeId
    );
  }

  getDevicePropertiesByGrowSectionId(sectionId) {
    return this.http.get(
      this.url + appConfig.propertiesBySectionId + "/" + sectionId
    );
  }

  getDevicePropertiesByGrowAreaId(growareaId) {
    return this.http.get(
      this.url + appConfig.propertiesByGrowsection + "/" + growareaId
    );
  }

  getLastTelemetry(deviceHid) {
    return this.http.get(
      this.url + appConfig.devices + "/" + deviceHid + "/telemtry/last"
    );
  }
  deleteIndividualProfile(ProfileId) {
    return this.http.delete(
      this.url + String.Format(appConfig.deleteIndividualProfile, ProfileId)
    );
  }
}
