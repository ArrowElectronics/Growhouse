import { HttpClient } from "@angular/common/http";
import { EventEmitter, Injectable } from "@angular/core";
import { environment } from "../../environments/environment";
import { appConfig } from "../global";
import { Container } from "../models/container.model";

@Injectable({
  providedIn: "root",
})
export class ContainerService {
  private url: string = environment.appServerURL;
  selectedContainer = new EventEmitter<Container>();
  ediContainer = new EventEmitter<Container>();
  constructor(private http: HttpClient) {}

  getContainers() {
    return this.http.get(this.url + appConfig.containers);
  }

  getContainerTypes() {
    return this.http.get(this.url + appConfig.containertypes);
  }

  getCountByContainerId(containerId: number) {
    return this.http.get(
      this.url + appConfig.countByContainer + "/" + containerId
    );
  }

  createContainer(container: Container) {
    return this.http.post(this.url + appConfig.containers, container);
  }

  editContainer(container: Container, containerId: number) {
    return this.http.put(
      this.url + appConfig.containers + "/" + containerId,
      container
    );
  }

  deleteConatiner(containerId: number) {
    return this.http.delete(
      this.url + appConfig.containers + "/" + containerId
    );
  }

  getContainerById(containerId: number) {
    return this.http.get(this.url + appConfig.containers + "/" + containerId);
  }

  getContainersByFacilityId(facilityId: number) {
    return this.http.get(
      this.url + appConfig.conatinersByFacility + "/" + facilityId
    );
  }
}
