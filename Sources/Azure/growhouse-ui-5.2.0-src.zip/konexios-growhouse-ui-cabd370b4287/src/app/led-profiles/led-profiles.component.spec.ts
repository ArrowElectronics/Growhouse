import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LedProfilesComponent } from './led-profiles.component';

describe('LedProfilesComponent', () => {
  let component: LedProfilesComponent;
  let fixture: ComponentFixture<LedProfilesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LedProfilesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LedProfilesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
