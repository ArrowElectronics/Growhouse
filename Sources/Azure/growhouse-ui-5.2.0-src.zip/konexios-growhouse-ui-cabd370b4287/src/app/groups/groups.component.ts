import { Component, OnInit, ViewChild } from "@angular/core";
import { FormControl, FormGroup, Validators } from "@angular/forms";
import { ActivatedRoute, Params, Router } from "@angular/router";
import { DataTableDirective } from "angular-datatables";
import { BreadcrumbsService } from "ng6-breadcrumbs";
import { ToastrService } from "ngx-toastr";
import { Subject } from "rxjs";
import { ValidationPatterns } from "src/app/global";
import { Container } from "../models/container.model";
import { Facility } from "../models/facility.model";
import { Group } from "../models/group.model";
import { GrowArea } from "../models/growarea.model";
import { User } from "../models/user.model";
import { ContainerService } from "../services/container-service";
import { FacilityService } from "../services/facility-service";
import { GlobalService } from "../services/global-service";
import { GroupService } from "../services/group-service";
import { GrowAreaService } from "../services/growarea-service";

declare var $: any;

@Component({
  selector: "app-groups",
  templateUrl: "./groups.component.html",
  styleUrls: ["./groups.component.css"],
})
export class GroupsComponent implements OnInit {
  dtOptions: any = {};
  dtTrigger: Subject<any> = new Subject();
  @ViewChild(DataTableDirective)
  private datatableElement: DataTableDirective;
  selectedGrowArea: GrowArea;
  selectedFacility: Facility;
  selectedContainer: Container;
  selectedGroup: Group;
  loggedInUser: User;
  groups = [];
  isGroupsLoad = false;
  isApiLoading = false;
  selectedGroupFlag = false;
  delete = false;
  deleteGroup: Group;
  isEditGroup = false;
  addGroupForm: FormGroup;
  addChannelConfigurationForm: FormGroup;
  channelConfigs = [
    "CW",
    "NW",
    "WW",
    "UV A",
    "UV B",
    "UV C",
    "RB",
    "B",
    "G",
    "Y",
    "A",
    "O",
    "R",
    "DR",
    "FR",
    "IR",
    "NC",
  ];
  isFindDevices = false;
  devices = [];
  remainingDevices = [];
  addedDevices = [];
  selectedDevices = [];
  constructor(
    private growareaService: GrowAreaService,
    private toastrService: ToastrService,
    private groupService: GroupService,
    private containerService: ContainerService,
    private facilityService: FacilityService,
    private route: ActivatedRoute,
    private breadcrumbService: BreadcrumbsService,
    private router: Router,
    private globalService: GlobalService
  ) {}

  ngOnInit() {
    this.breadcrumbService.store([
      { label: "Groups", url: "/groups", params: [] },
    ]);
    const elem = document.getElementById("headerMenuCollapse");
    if (elem) {
      elem.classList.remove("show");
    }
    // datatable options for facility table
    this.loggedInUser = JSON.parse(localStorage.getItem("loggedInUser"));
    this.dtOptions = {
      pagingType: "full_numbers",
      pageLength: 10,
      info: false,
      order: [],
      lengthChange: false,
      select: true,
      language: {
        zeroRecords: "No Groups to display",
        paginate: {
          next: ">", // or '→'
          previous: "<", // or '←',
        },
      },
    };
    this.groupService.selectedGroup.subscribe((group: Group) => {
      this.selectedGroup = group;
    });
    this.route.params.subscribe((params: Params) => {
      console.log(params);
      if (params.facilityId && params.containerId && params.growareaId) {
        console.log("Params" + JSON.stringify(params));
        this.getFacilityById(
          params.facilityId,
          params.containerId,
          params.growareaId
        );
        this.getGroups(params.growareaId);
      } else if (params.facilityId && params.containerId) {
        console.log("Params" + JSON.stringify(params));
        this.getFacilityById(params.facilityId, params.containerId, undefined);
      } else if (params.facilityId && params.growareaId) {
        console.log("Params" + JSON.stringify(params));
        this.getFacilityById(params.facilityId, undefined, params.growareaId);
        this.getGroups(params.growareaId);
      } else if (params.containerId && params.growareaId) {
        console.log("Params" + JSON.stringify(params));
        this.getContainerById(params.containerId, params.growareaId);
        this.getGroups(params.growareaId);
      } else if (params.growareaId) {
        console.log("Params" + JSON.stringify(params));
        this.getGrowareaById(params.growareaId);
        this.getGroups(params.growareaId);
      } else if (params.containerId) {
        this.getContainerById(params.containerId, undefined);
      } else if (params.facilityId) {
        console.log("Params" + JSON.stringify(params));
        this.getFacilityById(params.facilityId, undefined, undefined);
      } else {
        console.log("Params" + JSON.stringify(params));
        this.getGroups(params.growAreaId);
      }
    });
    this.onNewGroup();
  }

  getGroups(growAreaId) {
    this.groups = [];
    this.isGroupsLoad = true;
    console.log(growAreaId);
    this.groupService.getGroupsByGrowarea(growAreaId).subscribe(
      (response: any[]) => {
        setTimeout(() => {
          console.log(response);
          this.groups = response;
          this.dtTrigger.next();
        }, 500);
        this.isGroupsLoad = false;
      },
      (error) => {
        console.log("Error" + JSON.stringify(error));
        this.isGroupsLoad = false;
      }
    );
  }
  onNewGroup() {
    console.log(this.channelConfigs);
    this.isFindDevices = false;
    this.isEditGroup = false;
    this.addGroupForm = new FormGroup({
      id: new FormControl(null, []),
      group_name: new FormControl(null, [
        Validators.required,
        Validators.maxLength(25),
        Validators.pattern(ValidationPatterns.username),
      ]),
      description: new FormControl(null, [Validators.maxLength(200)]),
    });
    this.addChannelConfigurationForm = new FormGroup({
      CH1: new FormControl(null, [Validators.required]),
      CH2: new FormControl(null, [Validators.required]),
      CH3: new FormControl(null, [Validators.required]),
      CH4: new FormControl(null, [Validators.required]),
      CH5: new FormControl(null, [Validators.required]),
      CH6: new FormControl(null, [Validators.required]),
    });
  }
  onEditGroup(group) {
    console.log(group);
    this.isEditGroup = true;
    this.isFindDevices = false;
    this.addGroupForm.patchValue({
      group_name: group.group_name,
      id: group.id,
      description: group.description ? group.description : "",
    });
    this.addChannelConfigurationForm.patchValue({
      CH1: group.channel_configuration.CH1,
      CH2: group.channel_configuration.CH2,
      CH3: group.channel_configuration.CH3,
      CH4: group.channel_configuration.CH4,
      CH5: group.channel_configuration.CH5,
      CH6: group.channel_configuration.CH6,
    });
    this.selectedDevices = JSON.parse(JSON.stringify(group.added_devices));
    this.addedDevices = JSON.parse(JSON.stringify(group.added_devices));
  }
  getFacilityById(id, containerId, growareaId) {
    this.facilityService.getFacilityById(id).subscribe((response: Facility) => {
      this.selectedFacility = response;

      if (growareaId === undefined && containerId === undefined) {
        this.breadcrumbService.store([
          { label: "Facilities", url: "/facilities", params: [] },
          {
            label: this.selectedFacility.facility_name + "",
            url: "/facilities/" + this.selectedFacility.id,
            params: [],
          },
          { label: "Groups", url: "", params: [] },
        ]);
        this.addReloadEventToBreadcrumb();
      } else {
        if (containerId && growareaId) {
          this.getContainerById(containerId, growareaId);
        } else if (containerId) {
          this.getContainerById(containerId, undefined);
        } else {
          this.getGrowareaById(growareaId);
        }
      }
    });
  }
  addReloadEventToBreadcrumb() {
    setTimeout(() => {
      const elems = document.querySelectorAll(".breadcrumb-item a");
      console.log(elems);
      console.log("length     ", elems.length);
      for (let i = 0; i < elems.length; i++) {
        elems[i].addEventListener("click", this.globalService.handleClick);
      }
    }, 100);
  }
  getContainerById(containerId, growareaId) {
    this.containerService
      .getContainerById(containerId)
      .subscribe((response: Container) => {
        this.selectedContainer = response;

        if (this.selectedFacility === undefined && growareaId === undefined) {
          this.breadcrumbService.store([
            { label: "Containers", url: "/containers", params: [] },
            {
              label: this.selectedContainer.container_name + "",
              url: "/containers/" + this.selectedContainer.id,
              params: [],
            },
            { label: "Groups", url: "", params: [] },
          ]);
          this.addReloadEventToBreadcrumb();
        } else if (this.selectedFacility && growareaId === undefined) {
          this.breadcrumbService.store([
            { label: "Facilities", url: "/facilities", params: [] },
            {
              label: this.selectedFacility.facility_name + "",
              url: "/facilities/" + this.selectedFacility.id,
              params: [],
            },
            {
              label: "Containers",
              url: "facilities/" + this.selectedFacility.id + "/containers",
              params: [],
            },
            {
              label: this.selectedContainer.container_name + "",
              url:
                "facilities/" +
                this.selectedFacility.id +
                "/containers/" +
                this.selectedContainer.id,
              params: [],
            },
            { label: "Groups", url: "", params: [] },
          ]);
          this.addReloadEventToBreadcrumb();
        } else {
          this.getGrowareaById(growareaId);
        }
      });
  }
  getGrowareaById(growareaId) {
    this.growareaService
      .getGrowAreaById(growareaId)
      .subscribe((response: GrowArea) => {
        this.selectedGrowArea = response;
        if (
          this.selectedFacility === undefined &&
          this.selectedContainer === undefined &&
          this.selectedGrowArea
        ) {
          this.breadcrumbService.store([
            { label: "Grow Areas", url: "/grow-areas", params: [] },
            {
              label: this.selectedGrowArea.grow_area_name + "",
              url: "/grow-areas/" + this.selectedGrowArea.id,
              params: [],
            },
            { label: "Groups", url: "", params: [] },
          ]);
        } else if (
          this.selectedFacility &&
          this.selectedContainer === undefined &&
          this.selectedGrowArea
        ) {
          this.breadcrumbService.store([
            { label: "Facilities", url: "/facilities", params: [] },
            {
              label: this.selectedFacility.facility_name + "",
              url: "/facilities/" + this.selectedFacility.id,
              params: [],
            },
            {
              label: "Grow Areas",
              url: "/facilities/" + this.selectedFacility.id + "/grow-areas",
              params: [],
            },
            {
              label: this.selectedGrowArea.grow_area_name + "",
              url:
                "/facilities/" +
                this.selectedFacility.id +
                "/grow-areas/" +
                this.selectedGrowArea.id,
              params: [],
            },
            { label: "Groups", url: "", params: [] },
          ]);
        } else if (
          this.selectedFacility === undefined &&
          this.selectedContainer &&
          this.selectedGrowArea
        ) {
          this.breadcrumbService.store([
            { label: "Containers", url: "/containers", params: [] },
            {
              label: this.selectedContainer.container_name + "",
              url: "/containers/" + this.selectedContainer.id,
              params: [],
            },
            {
              label: "Grow Areas",
              url: "/containers/" + this.selectedContainer.id + "/grow-areas",
              params: [],
            },
            {
              label: this.selectedGrowArea.grow_area_name + "",
              url:
                "/containers/" +
                this.selectedContainer.id +
                "/grow-areas/" +
                this.selectedGrowArea.id,
              params: [],
            },
            { label: "Groups", url: "", params: [] },
          ]);
        } else if (
          this.selectedFacility &&
          this.selectedContainer &&
          this.selectedGrowArea
        ) {
          this.breadcrumbService.store([
            { label: "Facilities", url: "/facilities", params: [] },
            {
              label: this.selectedFacility.facility_name + "",
              url: "/facilities/" + this.selectedFacility.id,
              params: [],
            },
            {
              label: "Containers",
              url: "/facilities/" + this.selectedFacility.id + "/containers",
              params: [],
            },
            {
              label: this.selectedContainer.container_name + "",
              url:
                "/facilities/" +
                this.selectedFacility.id +
                "/containers/" +
                this.selectedContainer.id,
              params: [],
            },
            {
              label: "Grow Areas",
              url:
                "/facilities/" +
                this.selectedFacility.id +
                "/containers/" +
                this.selectedContainer.id +
                "/grow-areas",
              params: [],
            },
            {
              label: this.selectedGrowArea.grow_area_name + "",
              url:
                "/facilities/" +
                this.selectedFacility.id +
                "/containers/" +
                this.selectedContainer.id +
                "/grow-areas/" +
                this.selectedGrowArea.id,
              params: [],
            },
            { label: "Groups", url: "", params: [] },
          ]);
        } else {
          this.breadcrumbService.store([
            { label: "Groups", url: "", params: [] },
          ]);
        }
        this.addReloadEventToBreadcrumb();
      });
  }
  onGroupRowSelected(group) {
    this.selectedGroupFlag = true;
    if (!this.isGroupsLoad) {
      this.selectedGroup = group;
      this.router.navigate([this.selectedGroup.id], { relativeTo: this.route });
    }
  }
  onDeletChanges(group) {
    this.delete = true;
    console.log("OnDeletChanges called");
    this.deleteGroup = group;
  }

  onDeleteGroup() {
    this.isApiLoading = true;
    this.groupService.deleteGroup(this.deleteGroup.id).subscribe(
      (response) => {
        console.log(response);
        this.toastrService.success(
          "Group deleted successfully",
          "Delete Group"
        );
        this.datatableElement.dtInstance.then((dtInstance: DataTables.Api) => {
          // Destroy the table first
          dtInstance.destroy();
        });
        console.log(this.deleteGroup.growarea_id);
        this.isApiLoading = false;
        if (this.selectedGroup) {
          this.selectedGroup = null;
          if (
            this.selectedFacility &&
            this.selectedContainer &&
            this.selectedGrowArea
          ) {
            this.router.navigate([
              "/facilities/" +
                this.selectedFacility.id +
                "/containers/" +
                this.selectedContainer.id +
                "/grow-areas/" +
                this.selectedGrowArea.id +
                "/groups",
            ]);
            this.getFacilityById(
              this.selectedFacility.id,
              this.selectedContainer.id,
              this.selectedGrowArea.id
            );
          } else if (this.selectedFacility && this.selectedGrowArea) {
            this.router.navigate([
              "/facilities/" +
                this.selectedFacility.id +
                "/grow-areas/" +
                this.selectedGrowArea.id +
                "/groups",
            ]);
            this.getFacilityById(
              this.selectedFacility.id,
              undefined,
              this.selectedGrowArea.id
            );
          } else if (this.selectedContainer && this.selectedGrowArea) {
            this.router.navigate([
              "/containers/" +
                this.selectedContainer.id +
                "/grow-areas/" +
                this.selectedGrowArea.id +
                "/groups",
            ]);
            this.getContainerById(
              this.selectedContainer.id,
              this.selectedGrowArea.id
            );
          } else {
            this.router.navigate([
              "/grow-areas/" + this.deleteGroup.growarea_id + "/groups",
            ]);
            this.getGrowareaById(this.deleteGroup.growarea_id);
          }
        }
        this.getGroups(this.deleteGroup.growarea_id);
      },
      (error) => {
        this.deleteGroup = null;
        this.isApiLoading = false;
      }
    );
  }
  compareFnChannel(obj1: any, obj2: any) {
    if (obj1 === undefined || obj2 === undefined) {
      return false;
    } else {
      return obj1 === obj2;
    }
  }

  disableSave() {
    const flag = true;
    if (this.addGroupForm && this.addChannelConfigurationForm) {
      if (!this.addGroupForm.valid || !this.addChannelConfigurationForm.valid) {
        return flag;
      } else {
        return false;
      }
    }
    return flag;
  }
  disableget() {
    const flag = true;
    if (this.addChannelConfigurationForm) {
      if (!this.addChannelConfigurationForm.valid) {
        return flag;
      } else {
        return false;
      }
    }
    return flag;
  }
  onAddGroupSubmit() {
    this.isApiLoading = true;
    console.log(this.addGroupForm.value);
    console.log(this.addChannelConfigurationForm.value);
    const obj = {};
    obj["growarea_id"] = this.selectedGrowArea.id;
    obj["group_name"] = this.addGroupForm.value.group_name;
    obj["channel_configuration"] = this.addChannelConfigurationForm.value;
    obj["added_devices"] = this.selectedDevices;
    obj["description"] = this.addGroupForm.value.description;

    console.log(obj);
    this.groupService.createGroup(obj).subscribe(
      (successResponse: Response) => {
        console.log(successResponse);
        this.toastrService.success(
          "Group created successfully.",
          "Create Group"
        );
        this.datatableElement.dtInstance.then((dtInstance: DataTables.Api) => {
          // Destroy the table first
          dtInstance.destroy();
        });
        this.addGroupForm.reset();
        this.addChannelConfigurationForm.reset();
        this.getGroups(this.selectedGrowArea.id);
        this.isApiLoading = false;
        $("#myModal").modal("hide");
        this.devices = [];
        this.addedDevices = [];
        this.selectedDevices = [];
        this.remainingDevices = [];
      },
      (error) => {
        this.addGroupForm.reset();
        this.addChannelConfigurationForm.reset();
        this.isApiLoading = false;
        this.devices = [];
        this.addedDevices = [];
        this.selectedDevices = [];
        this.remainingDevices = [];
        $("#myModal").modal("hide");
      }
    );
  }
  onEditGroupSubmit() {
    this.isApiLoading = true;
    console.log(this.addGroupForm.value);
    console.log(this.addChannelConfigurationForm.value);
    const obj = {};
    obj["id"] = this.addGroupForm.value.id;
    obj["growarea_id"] = this.selectedGrowArea.id;
    obj["group_name"] = this.addGroupForm.value.group_name;
    obj["description"] = this.addGroupForm.value.description;
    obj["channel_configuration"] = this.addChannelConfigurationForm.value;
    obj["added_devices"] = this.selectedDevices;

    console.log(obj);
    this.groupService.updateGroup(obj).subscribe(
      (Response: Group) => {
        this.toastrService.success(
          "Group updated successfully.",
          "Update Group"
        );
        this.datatableElement.dtInstance.then((dtInstance: DataTables.Api) => {
          // Destroy the table first
          dtInstance.destroy();
        });
        this.groupService.editedGroup.emit(this.addGroupForm.value.id);
        this.addGroupForm.reset();
        this.addChannelConfigurationForm.reset();
        this.isApiLoading = false;
        this.isEditGroup = false;
        $("#myModal").modal("hide");
        this.devices = [];
        this.addedDevices = [];
        this.selectedDevices = [];
        this.remainingDevices = [];
        this.getGroups(this.selectedGrowArea.id);
      },
      (error) => {
        this.addGroupForm.reset();
        this.addChannelConfigurationForm.reset();
        this.isApiLoading = false;
        this.isEditGroup = false;
        this.devices = [];
        this.addedDevices = [];
        this.selectedDevices = [];
        this.remainingDevices = [];
        $("#myModal").modal("hide");
      }
    );
  }
  removeData() {
    this.addGroupForm.reset();
    this.addChannelConfigurationForm.reset();
    this.isApiLoading = false;
    this.isEditGroup = false;
    // $('#myModal').modal('hide');
    this.devices = [];
    this.addedDevices = [];
    this.selectedDevices = [];
    this.remainingDevices = [];
  }
  onFindDevices() {
    this.devices = [];
    console.log(this.addChannelConfigurationForm.value);
    this.groupService
      .getDevicesByGroup(
        this.addChannelConfigurationForm.value,
        this.selectedGrowArea.id
      )
      .subscribe((response: any[]) => {
        this.devices = response;
        if (!this.isEditGroup) {
          this.selectedDevices = [];
          this.addedDevices = [];
        } else {
          for (let i = 0; i < this.selectedDevices.length; i++) {
            for (let j = 0; j < this.devices.length; j++) {
              if (this.selectedDevices[i].id === this.devices[j].id) {
                this.devices.splice(j, 1);
              }
            }
          }
        }
        this.remainingDevices = JSON.parse(JSON.stringify(this.devices));
        this.isFindDevices = true;
      });
  }
  getChannelAccess() {
    return this.isEditGroup;
  }
  onChangeOfAddDeviceCheckbox(deviceObj) {
    let index = -1;
    for (let i = 0; i < this.addedDevices.length; i++) {
      if (this.addedDevices[i].deviceUId === deviceObj.deviceUId) {
        index = i;
      }
    }
    console.log(index);
    if (index === -1) {
      this.addedDevices.push(deviceObj);
      this.remainingDevices.forEach((device) => {
        if (device.deviceUId === deviceObj.deviceUId) {
          this.remainingDevices.splice(
            this.remainingDevices.indexOf(device),
            1
          );
        }
      });
    } else {
      this.addedDevices.splice(index, 1);
      this.remainingDevices.push(deviceObj);
    }
    console.log(this.addedDevices);
    console.log(this.remainingDevices);
  }
  onChangeORemovefDeviceCheckbox(deviceObj) {
    let index = -1;
    for (let i = 0; i < this.remainingDevices.length; i++) {
      if (this.remainingDevices[i].deviceUId === deviceObj.deviceUId) {
        index = i;
      }
    }
    console.log(index);
    if (index === -1) {
      this.remainingDevices.push(deviceObj);
      this.addedDevices.forEach((device) => {
        if (device.deviceUId === deviceObj.deviceUId) {
          this.addedDevices.splice(this.addedDevices.indexOf(device), 1);
        }
      });
    } else {
      this.remainingDevices.splice(index, 1);
      this.addedDevices.push(deviceObj);
    }
    console.log(this.addedDevices);
    console.log(this.remainingDevices);
  }
  OnSetDevice() {
    this.selectedDevices = JSON.parse(JSON.stringify(this.addedDevices));
    this.devices = JSON.parse(JSON.stringify(this.remainingDevices));
  }

  onModalClose() {
    // $('#myApplyModal').modal('hide');
    this.selectedDevices = [];
    this.devices = [];
    this.addedDevices = [];
    this.remainingDevices = [];
  }
}
