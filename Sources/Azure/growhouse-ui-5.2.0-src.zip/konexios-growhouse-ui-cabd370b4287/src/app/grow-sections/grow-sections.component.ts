
import { Subject } from 'rxjs';
import { GrowArea } from '../models/growarea.model';

import { Facility } from '../models/facility.model';
import { GrowSection } from '../models/growsection.model';
import { GrowSectionService } from '../services/growsection-service';
import { GrowAreaService } from '../services/growarea-service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ContainerService } from '../services/container-service';
import { FacilityService } from '../services/facility-service';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { BreadcrumbsService } from 'ng6-breadcrumbs';
import { Container } from '../models/container.model';
import { OnDestroy, OnInit, Component } from '@angular/core';
import { GlobalService } from '../services/global-service';

@Component({
  selector: 'app-grow-sections',
  templateUrl: './grow-sections.component.html',
  styleUrls: ['./grow-sections.component.css']
})
export class GrowSectionsComponent implements OnInit, OnDestroy {
  dtOptions: any = {};
  dtTrigger: Subject<any> = new Subject();
  selectedGrowSection: GrowSection;
  growSections: GrowSection[] = [];
  selectedFacility: Facility;
  selectedContainer: Container;
  selectedGrowArea: GrowArea;
  totalGrowSectionCount: number;
  activeGrowSectionCount: number;
  constructor(
    private growsectionService: GrowSectionService,
    private growareaService: GrowAreaService,
    private spinner: NgxSpinnerService,
    private containerService: ContainerService,
    private facilityService: FacilityService,
    private route: ActivatedRoute,
    private breadcrumbService: BreadcrumbsService,
    private router: Router,
    private globalService: GlobalService
  ) { }

  ngOnInit() {
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 10,
      info: false,
      order: [],
      lengthChange: false,
      select: true,
      language: {
        zeroRecords: 'No Grow Sections to display',
        paginate: {
          next: '>', // or '→'
          previous: '<', // or '←',
        }
      }
    };
    // this.getGrowSections();
    this.route.params.subscribe((params: Params) => {
      console.log(params);
      if (params.facilityId && params.containerId && params.growareaId) {
        this.getFacilityById(
          params.facilityId,
          params.containerId,
          params.growareaId
        );
        this.getGrowSectionsByGrowareaId(params.growareaId);
      } else if (params.facilityId && params.containerId) {
        this.getFacilityById(params.facilityId, params.containerId, undefined);
        this.getGrowSectionsByConatinerId(params.containerId);
      } else if (params.facilityId && params.growareaId) {
        this.getFacilityById(params.facilityId, undefined, params.growareaId);
        this.getGrowSectionsByGrowareaId(params.growareaId);
      } else if (params.containerId && params.growareaId) {
        this.getContainerById(params.containerId, params.growareaId);
        this.getGrowSectionsByGrowareaId(params.growareaId);
      } else if (params.growareaId) {
        this.getGrowareaById(params.growareaId);
        this.getGrowSectionsByGrowareaId(params.growareaId);
      } else if (params.containerId) {
        this.getContainerById(params.containerId, undefined);
        this.getGrowSectionsByConatinerId(params.containerId);
      } else if (params.facilityId) {
        this.getFacilityById(params.facilityId, undefined, undefined);
        this.getGrowSectionsByFacilityId(params.facilityId);
      } else {
        this.getGrowSections();
      }
    });
  }

  getFacilityById(id, containerId, growareaId) {

    this.facilityService.getFacilityById(id).subscribe((response: Facility) => {
      this.selectedFacility = response;

      if (growareaId === undefined && containerId === undefined) {
        this.breadcrumbService.store([
          { label: 'Facilities', url: '/facilities', params: [] },
          {
            label: this.selectedFacility.facility_name + '',
            url: '/facilities/' + this.selectedFacility.id,
            params: []
          },
          { label: 'Grow Sections', url: '', params: [] }
        ]);
        this.addReloadEventToBreadcrumb();
      } else {
        if (containerId && growareaId) {
          this.getContainerById(containerId, growareaId);
        } else if (containerId) {
          this.getContainerById(containerId, undefined);
        } else {
          this.getGrowareaById(growareaId);
        }
      }
    });
  }
  addReloadEventToBreadcrumb() {
    setTimeout(() => {
      const elems = document.querySelectorAll('.breadcrumb-item a');
      console.log(elems);
      console.log('length     ', elems.length);
      for (let i = 0; i < elems.length; i++) {
        elems[i].addEventListener('click', this.globalService.handleClick);
      }
    }, 100);
  }
  getContainerById(containerId, growareaId) {

    this.containerService
      .getContainerById(containerId)
      .subscribe((response: Container) => {
        this.selectedContainer = response;

        if (this.selectedFacility === undefined && growareaId === undefined) {
          this.breadcrumbService.store([
            { label: 'Containers', url: '/containers', params: [] },
            { label: this.selectedContainer.container_name + '', url: '/containers/' + this.selectedContainer.id, params: [] },
            { label: 'Grow Sections', url: '', params: [] },
          ]);
          this.addReloadEventToBreadcrumb();
        } else if (this.selectedFacility && growareaId === undefined) {
          this.breadcrumbService.store([
            { label: 'Facilities', url: '/facilities', params: [] },
            { label: this.selectedFacility.facility_name + '', url: '/facilities/' + this.selectedFacility.id, params: [] },
            { label: 'Containers', url: 'facilities/' + this.selectedFacility.id + '/containers', params: [] },
            {
              label: this.selectedContainer.container_name + '',
              url: 'facilities/' + this.selectedFacility.id + '/containers/' + this.selectedContainer.id, params: []
            },
            { label: 'Grow Sections', url: '', params: [] },
          ]);
          this.addReloadEventToBreadcrumb();
        } else {
          this.getGrowareaById(growareaId);
        }
      });
  }

  getGrowareaById(growareaId) {

    this.growareaService
      .getGrowAreaById(growareaId)
      .subscribe((response: GrowArea) => {
        this.selectedGrowArea = response;

        if (this.selectedFacility === undefined && this.selectedContainer === undefined) {
          this.breadcrumbService.store([
            { label: 'Grow Areas', url: '/grow-areas', params: [] },
            { label: this.selectedGrowArea.grow_area_name + '', url: '/grow-areas/' + this.selectedGrowArea.id, params: [] },
            { label: 'Grow Sections', url: '', params: [] },
          ]);
        } else if (this.selectedFacility && this.selectedContainer === undefined) {
          this.breadcrumbService.store([
            { label: 'Facilities', url: '/facilities', params: [] },
            { label: this.selectedFacility.facility_name + '', url: '/facilities/' + this.selectedFacility.id, params: [] },
            { label: 'Grow Areas', url: '/facilities/' + this.selectedFacility.id + '/grow-areas', params: [] },
            {
              label: this.selectedGrowArea.grow_area_name + '',
              url: 'facilities/' + this.selectedFacility.id + '/grow-areas/' + this.selectedGrowArea.id, params: []
            },
            { label: 'Grow Sections', url: '', params: [] },
          ]);
        } else if (this.selectedFacility === undefined && this.selectedContainer) {
          this.breadcrumbService.store([
            { label: 'Containers', url: '/containers', params: [] },
            { label: this.selectedContainer.container_name + '', url: '/containers/' + this.selectedContainer.id, params: [] },
            { label: 'Grow Areas', url: '/containers/' + this.selectedContainer.id + '/grow-areas', params: [] },
            {
              label: this.selectedGrowArea.grow_area_name + '',
              url: '/containers/' + this.selectedContainer.id + '/grow-areas/' + this.selectedGrowArea.id, params: []
            },
            { label: 'Grow Sections', url: '', params: [] },
          ]);
        } else {
          this.breadcrumbService.store([
            { label: 'Facilities', url: '/facilities', params: [] },
            { label: this.selectedFacility.facility_name + '', url: '/facilities/' + this.selectedFacility.id, params: [] },
            { label: 'Containers', url: '/facilities/' + this.selectedFacility.id + '/containers', params: [] },
            {
              label: this.selectedContainer.container_name + '',
              url: '/facilities/' + this.selectedFacility.id + '/containers/' + this.selectedContainer.id, params: []
            },
            {
              label: 'Grow Areas',
              url: '/facilities/' + this.selectedFacility.id + '/containers/' + this.selectedContainer.id + '/grow-areas', params: []
            },
            {
              label: this.selectedGrowArea.grow_area_name + '',
              url: '/facilities/' + this.selectedFacility.id + '/containers/' + this.selectedContainer.id
                + '/grow-areas/' + this.selectedGrowArea.id,
              params: []
            },
            { label: 'Grow Sections', url: '', params: [] },
          ]);
        }
        this.addReloadEventToBreadcrumb();
      });
  }

  getGrowSections() {

    this.growSections = [];
    this.growsectionService
      .getGrowSections()
      .subscribe((response: GrowSection[]) => {
        this.growSections = response;
        if (this.growSections) {
          this.activeGrowSectionCount = this.growSections.length;
        } else {
          this.activeGrowSectionCount = 0;
        }
        this.dtTrigger.next();
      });
  }

  getGrowSectionsByFacilityId(facilityId) {

    this.growSections = [];
    this.growsectionService
      .getGrowSectionsByFacility(facilityId)
      .subscribe((response: GrowSection[]) => {
        this.growSections = response;
        if (this.growSections) {
          this.activeGrowSectionCount = this.growSections.length;
        } else {
          this.activeGrowSectionCount = 0;
        }
        this.dtTrigger.next();

      });
  }

  getGrowSectionsByConatinerId(conatinerId) {

    this.growSections = [];
    this.growsectionService
      .getGrowSectionsByContainer(conatinerId)
      .subscribe((response: GrowSection[]) => {
        this.growSections = response;
        if (this.growSections) {
          this.activeGrowSectionCount = this.growSections.length;
        } else {
          this.activeGrowSectionCount = 0;
        }
        this.dtTrigger.next();

      });
  }

  getGrowSectionsByGrowareaId(growareaId) {

    this.growSections = [];
    this.growsectionService
      .getGrowSectionsByGrowarea(growareaId)
      .subscribe((response: GrowSection[]) => {
        this.growSections = response;
        if (this.growSections) {
          this.activeGrowSectionCount = this.growSections.length;
        } else {
          this.activeGrowSectionCount = 0;
        }
        this.dtTrigger.next();

      });
  }

  onViewSection(growSection: GrowSection) {
    this.selectedGrowSection = growSection;
    this.router.navigate([this.selectedGrowSection.id], {
      relativeTo: this.route
    });
  }

  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }
}
