import { Location } from "@angular/common";
import { Component, OnInit } from "@angular/core";
import { FormArray, FormControl, FormGroup, Validators } from "@angular/forms";
import { ActivatedRoute, Params, Router } from "@angular/router";
import { BreadcrumbsService } from "ng6-breadcrumbs";
import { NgxSpinnerService } from "ngx-spinner";
import { ToastrService } from "ngx-toastr";
import { ProfileMessage } from "src/app/global";
import { Container } from "../models/container.model";
import { Device, DeviceType } from "../models/device.model";
import { Facility } from "../models/facility.model";
import { Grid } from "../models/global.model";
import { GrowArea } from "../models/growarea.model";
import { GrowSection } from "../models/growsection.model";
import { User } from "../models/user.model";
import { ContainerService } from "../services/container-service";
import { DeviceService } from "../services/device-service";
import { FacilityService } from "../services/facility-service";
import { GlobalService } from "../services/global-service";
import { GrowAreaService } from "../services/growarea-service";
import { GrowSectionService } from "../services/growsection-service";
@Component({
  selector: "app-grow-section",
  templateUrl: "./grow-section.component.html",
  styleUrls: ["./grow-section.component.css"],
})
export class GrowSectionComponent implements OnInit {
  gridCols = 1;
  gridRowHeights = "1:1";
  gridConfig: Grid[] = [];
  displayGridLayout = [];
  layoutList = [];
  layoutActiveFlag = false;
  selectedProfileButton = false;
  growSections: GrowSection[] = [];
  selectedGrowArea: GrowArea;
  selectedContainer: Container;
  selectedFacility: Facility;
  selectedGrowSection: GrowSection;
  deviceCountObj: any;
  devicetypes: DeviceType[] = [];
  devices: Device[] = [];
  sectionList = [];
  editSectionsList = [];
  stic = {};
  selectedDeviceTypeName: string;
  selectedGrowSectionLayout: any[] = [];
  isAddSection = false;
  isSelectedSection = false;
  isViewSection = false;
  isViewGrowSectionDevices = false;
  isViewGrowSectionProfiles = false;
  isAddGrowSectionProfiles = false;
  isSelectedProfile = false;
  selectedDefaultProperty = true;
  addProfileForm: FormGroup;
  addConditionForm: FormGroup;
  editProfileForm: FormGroup;
  editConditionForm: FormGroup;
  greenConditions: string;
  deviceList: any[] = [];
  propertyList: any = {};
  profiles: any[] = [];
  profileAlert: any = {};
  profile: any;
  deviceForProperty: any[] = [];
  profileName: string;
  loggedInUser: User;
  deviceHid: string;
  propertiesData: any = [];
  greenProperty: string;
  property1: string;
  property2: string;
  property3: string;
  property4: string;
  blueProperty: string;
  yellowProperty: string;
  redProperty: string;
  greenDevices: any[] = [];
  blueDevices: any[] = [];
  yellowDevices: any[] = [];
  redDevices: any = [];
  operatorGreen: string;
  count: string;
  conditionValueYellow: any[] = [];
  conditionValueBlue: any[] = [];
  conditionValueRed: any[] = [];
  conditionValueGreen: any[] = [];
  operatorBlue: string;
  operatorYellow: string;
  operatorRed: string;
  yellow: any = [];
  blue: any = [];
  red: any = [];
  green: any = [];
  conditions: any[] = [];
  devicesHidValues: any = [];
  editProfileName: string;
  editProfileValues = false;
  addProfile = true;
  isDeviceAvailable = false;
  conditionAll: any = {};
  editCondition = false;
  createSection = true;
  // enabledButton: boolean = false;
  countDevice: any = {};
  deviceIds = [];
  deleteSection = null;
  creatingProfile = false;
  deletingSection = false;
  deleteGrowSectionIndex = -1;
  selectedGrowSectionIndex;

  constructor(
    private growSectionService: GrowSectionService,
    private growareaService: GrowAreaService,
    private containerService: ContainerService,
    private facilityService: FacilityService,
    private spinner: NgxSpinnerService,
    private toastrService: ToastrService,
    private router: Router,
    private route: ActivatedRoute,
    private breadcrumService: BreadcrumbsService,
    private deviceService: DeviceService,
    private globalService: GlobalService,
    private location: Location
  ) {}

  ngOnInit() {
    this.stic["led1"] = "CH 1";
    this.stic["led2"] = "CH 2";
    this.stic["led3"] = "CH 3";
    this.stic["led4"] = "CH 4";
    this.stic["led5"] = "CH 5";
    this.stic["led6"] = "CH 6";

    this.loggedInUser = JSON.parse(localStorage.getItem("loggedInUser"));
    this.gridConfig = [
      {
        layout: 1,
        cols: 1,
        rowHeight: "300",
        url: "assets/images/layout-select-1.png",
      },
      {
        layout: 2,
        cols: 1,
        rowHeight: "300",
        url: "assets/images/layout-select-2.png",
      },
      {
        layout: 3,
        cols: 1,
        rowHeight: "300",
        url: "assets/images/layout-select-3.png",
      },
      {
        layout: 4,
        cols: 1,
        rowHeight: "300",
        url: "assets/images/layout-select-4.png",
      },
      {
        layout: 6,
        cols: 2,
        rowHeight: "1:1",
        url: "assets/images/layout-select-6.png",
      },
      {
        layout: 8,
        cols: 2,
        rowHeight: "1:1",
        url: "assets/images/layout-select-8.png",
      },
      {
        layout: 10,
        cols: 2,
        rowHeight: "1:1",
        url: "assets/images/layout-select-10.png",
      },
      {
        layout: 12,
        cols: 2,
        rowHeight: "1:1",
        url: "assets/images/layout-select-12.png",
      },
    ];

    let containerId, facilityId, growareaId;

    this.route.params.subscribe((parentParams: Params) => {
      console.log(parentParams);
      this.route.parent.params.subscribe((params: Params) => {
        if (parentParams.facilityId) {
          facilityId = parentParams.facilityId;
        }
        if (parentParams.containerId) {
          containerId = parentParams.containerId;
        }
        if (parentParams.growareaId) {
          growareaId = parentParams.growareaId;
        }

        if (facilityId) {
          this.getFacilityById(facilityId, containerId, growareaId);
          this.getCountsById(growareaId);
          this.getGrowSectionByGrowAreaId(growareaId);
        } else if (containerId) {
          this.getContainerById(containerId, growareaId);
          this.getCountsById(growareaId);
        } else if (growareaId) {
          this.getGrowAreaById(growareaId);
          this.getCountsById(growareaId);
          this.getGrowSectionByGrowAreaId(growareaId);
        }
      });
    });

    this.getGrowSectionByGrowAreaId(growareaId);

    console.log(this.router.url);
    if (this.router.url.indexOf("add") !== -1) {
      console.log("in if");
      this.isAddSection = true;
      this.isViewSection = false;
    } else {
      this.isAddSection = false;
      this.isViewSection = true;
    }
  }

  getProfilesBySectionId(sectionId) {
    this.globalService
      .getProfilesByGrowSectionId(sectionId)
      .subscribe((response: any[]) => {
        this.profiles = response;
      });
  }

  getDevicesBySectionId(sectionId) {
    this.deviceList = [];
    console.log(sectionId);
    this.deviceService
      .getDevicePropertiesByGrowSectionId(sectionId)
      .subscribe((response: any[]) => {
        this.deviceList = response;
        console.log("deviceList", this.deviceList);
      });
  }

  getPropertyList(deviceId, index, color) {
    console.log("dadfaf", typeof deviceId);
    console.log("deviceID:" + deviceId);
    console.log("deviceCalled");
    let device;
    for (let i = 0; i < this.deviceList.length; i++) {
      console.log(this.deviceList[i].device_hid, "===", deviceId, 10);
      if (this.deviceList[i].device_hid === deviceId) {
        device = this.deviceList[i];
        console.log("abcd" + JSON.stringify(device));
        const prop = [];
        console.log(color);

        if (color === "yellow") {
          console.log("in yellow");

          for (let i = 0; i < device.properties.length; i++) {
            if (device.properties[i].name === "batteryVoltage") {
              prop.push(device.properties[i]);
            }
          }
        }
        if (color === "blue") {
          console.log("in blue");
          for (let i = 0; i < device.properties.length; i++) {
            if (device.properties[i].name !== "batteryVoltage") {
              prop.push(device.properties[i]);
            }
          }
        }
        // this.propertyList[index] = device.properties.sort((a, b) => a.display_property_name > b.display_property_name ? 1 : -1);
        console.log(prop);

        this.propertyList[index] = prop;
        this.selectedDefaultProperty = true;
      } else {
        this.selectedDefaultProperty = false;
      }
      console.log(this.propertyList);
    }
    // const device = this.deviceList.filter(deviceObj => deviceObj.device_hid === parseInt(deviceId, 10))[0];
  }
  onClickDeleteSection(growSection, index) {
    console.log(growSection.grow_area.id);
    this.deleteSection = growSection;
    this.deleteGrowSectionIndex = index;
    console.log(this.gridCols);
    console.log(this.gridRowHeights);
  }
  onDeleteSection() {
    console.log(this.deleteSection);
    this.deletingSection = true;
    this.growSectionService
      .deleteGrowSectionById(this.deleteSection.id)
      .subscribe(
        (response) => {
          console.log(response);
          this.toastrService.success(
            "Grow Section Deleted Successfully",
            "Delete Grow Section"
          );
          this.selectedGrowArea.layout = this.selectedGrowArea.layout - 1;
          this.getGrowSectionByGrowAreaId(this.deleteSection.grow_area.id);
          this.deleteGrowSectionIndex = -1;
          this.deletingSection = false;
        },
        (error) => {
          // this.toastrService.error('Failed to delete Grow Section as Gateway is currently out of network.');
          this.deleteGrowSectionIndex = -1;
          this.deletingSection = false;
        }
      );
  }
  onClickOfLayout(grid: Grid) {
    console.log("grid 2", grid);
    // this.layoutList = [];
    this.gridCols = grid.cols;
    console.log("selected", this.selectedGrowArea);
    this.gridRowHeights = grid.rowHeight;
    const layout = grid.layout;
    console.log("layout" + layout);
    console.log("layout" + this.gridRowHeights);

    this.selectedGrowArea.layout = layout;
    this.layoutList = Array(layout)
      .fill(0, 0, layout)
      .map((x, i) => i);

    if (this.layoutList.length - this.growSections.length < 0) {
      this.growSections.length = layout;
    }

    console.log("list" + this.layoutList);

    this.layoutActiveFlag = true;
    for (let i = 0; i < this.layoutList.length; i++) {
      console.log("in fpr", this.growSections);

      if (!this.growSections[i]) {
        this.growSections.push(
          new GrowSection(0, "", this.selectedGrowArea, "", [])
        );
      }
    }
    console.log("growsection:" + this.growSections.length);
  }

  getCountsById(id) {
    this.growareaService.getCountByGrowAreaId(id).subscribe((response) => {
      this.deviceCountObj = response;
      console.log(this.deviceCountObj);
    });
  }

  getFacilityById(id, containerId, growareaId) {
    this.facilityService.getFacilityById(id).subscribe((response: Facility) => {
      this.selectedFacility = response;
      console.log(this.selectedFacility);
      this.facilityService.selectedFacility.emit(this.selectedFacility);
      if (containerId) {
        this.getContainerById(containerId, growareaId);
      } else if (growareaId) {
        this.getGrowAreaById(growareaId);
        this.getGrowSectionByGrowAreaId(growareaId);
      }
    });
  }

  getContainerById(id, growareaId) {
    this.containerService
      .getContainerById(id)
      .subscribe((response: Container) => {
        this.selectedContainer = response;
        if (growareaId) {
          this.getGrowAreaById(growareaId);
          this.getGrowSectionByGrowAreaId(growareaId);
        }
      });
  }

  getProfileAlertByProfileId(profileId) {
    this.globalService
      .getPropertiesByProfileId(profileId)
      .subscribe((response: any[]) => {
        this.profileAlert = response;
        this.editProfileName = this.profileAlert.profileName;
        this.setDevices(this.profileAlert.payload.conditions);
      });
  }

  setDevices(conditions) {
    this.editProfileForm = new FormGroup({});

    this.editConditionForm = new FormGroup({
      editcondition2: new FormArray([]),
      editcondition3: new FormArray([]),
      // editcondition4: new FormArray([

      // ])
    });
    //  this.onInitFormGroup();
    console.log("conditions" + JSON.stringify(conditions));

    if (this.profileAlert.payload.conditions.conditionYellow === undefined) {
    } else {
      this.yellowDevices = this.profileAlert.payload.conditions.conditionYellow;
      console.log(
        this.yellowDevices[0].property.split(".")[0].replace("_", "")
      );
      for (let i = 0; i < this.yellowDevices.length; i++) {
        this.deviceForProperty["editcondition2" + i] = this.yellowDevices[
          i
        ].property
          .split(".")[0]
          .replace("_", "");
        this.getPropertyList(
          this.deviceForProperty["editcondition2" + i],
          "editcondition2" + i,
          "yellow"
        );
        const controls = <FormArray>(
          this.editConditionForm.get("editcondition2")
        );
        console.log(controls);
        const propName =
          "_" +
          this.deviceForProperty["editcondition2" + i] +
          "." +
          this.yellowDevices[i].property.split(".")[1];
        let cOp;
        if (i !== 0) {
          cOp = this.yellowDevices[i - 1].combinationOperator;
        }
        if (cOp && cOp !== "") {
          console.log("cop" + cOp);
          this.addEditConditionOperator("editcondition2", i, cOp);
        }
        controls.push(
          new FormGroup({
            property: new FormControl(propName, Validators.required),
            value: new FormControl(this.yellowDevices[i].value),
            operator: new FormControl(
              this.yellowDevices[i].operator,
              Validators.required
            ),
            combinationOperator: new FormControl(
              this.yellowDevices[i].combinationOperator
            ),
          })
        );
      }
    }

    if (this.profileAlert.payload.conditions.conditionBlue === undefined) {
    } else {
      // blue Edit Profiles
      this.blueDevices = this.profileAlert.payload.conditions.conditionBlue;
      console.log(this.blueDevices[0].property.split(".")[0].replace("_", ""));
      for (let i = 0; i < this.blueDevices.length; i++) {
        console.log("i" + i);
        this.deviceForProperty["editcondition3" + i] = this.blueDevices[
          i
        ].property
          .split(".")[0]
          .replace("_", "");
        this.getPropertyList(
          this.deviceForProperty["editcondition3" + i],
          "editcondition3" + i,
          "blue"
        );
        const controls = <FormArray>(
          this.editConditionForm["controls"].editcondition3
        );
        console.log("controls", controls);
        const propName =
          "_" +
          this.deviceForProperty["editcondition3" + i] +
          "." +
          this.blueDevices[i].property.split(".")[1];
        console.log("propName" + propName);

        controls.push(
          new FormGroup({
            property: new FormControl(propName, Validators.required),
            value: new FormControl(
              this.blueDevices[i].value,
              Validators.required
            ),
            operator: new FormControl(
              this.blueDevices[i].operator,
              Validators.required
            ),
            combinationOperator: new FormControl(
              this.blueDevices[i].combinationOperator
            ),
          })
        );

        let cOp;

        if (i !== 0) {
          cOp = this.blueDevices[i - 1].combinationOperator;
        }

        if (cOp && cOp !== "") {
          console.log("cop" + cOp);
          this.addEditConditionOperator("editcondition3", i, cOp);
        }
        console.log("i" + i);
        console.log(this.deviceForProperty);
        console.log(this.editConditionForm);
        console.log("bbbbbbbbbbbbbbbbb ", this.editConditionForm["controls"]);
      }

      console.log(this.redDevices.length);
    }

    // red Edit Profiles
    // if (this.profileAlert.payload.conditions.conditionRed === undefined) {

    // } else {
    //   this.redDevices = this.profileAlert.payload.conditions.conditionRed;
    //   console.log(this.redDevices);
    //   console.log(this.redDevices[0].property.split('.')[0].replace('_', ''));
    //   for (let i = 0; i < this.redDevices.length; i++) {
    //     console.log('i' + i);
    //     this.deviceForProperty['editcondition4' + i] = this.redDevices[i].property.split('.')[0].replace('_', '');
    //     this.getPropertyList(this.deviceForProperty['editcondition4' + i], 'editcondition4' + i);
    //     const controls = <FormArray>this.editConditionForm['controls'].editcondition4;
    //     console.log('controls' + controls);
    //     const propName = '_' + this.deviceForProperty['editcondition4' + i] + '.' + this.redDevices[i].property.split('.')[1];
    //     console.log('propName' + propName);

    //     controls.push(new FormGroup({
    //       property: new FormControl(propName, Validators.required),
    //       value: new FormControl(this.redDevices[i].value, Validators.required),
    //       operator: new FormControl(this.redDevices[i].operator, Validators.required),
    //       combinationOperator: new FormControl(this.redDevices[i].combinationOperator)
    //     }));

    //     let cOp;
    //     if (i !== 0) {
    //       cOp = this.redDevices[i - 1].combinationOperator;
    //     }
    //     if (cOp && cOp !== '') {
    //       console.log('cop' + cOp);
    //       this.addEditConditionOperator('editcondition4', i, cOp);
    //     }
    //     console.log('i' + i);
    //     console.log(this.deviceForProperty);
    //     console.log('conditonformvalues', this.editConditionForm);
    //   }
    // }
  }

  getGrowAreaById(id) {
    this.growareaService.getGrowAreaById(id).subscribe((response: GrowArea) => {
      this.selectedGrowArea = response;
      console.log(response);
      for (let i = 0; i < this.gridConfig.length; i++) {
        console.log(
          this.gridConfig[i].layout,
          " === ",
          this.selectedGrowArea.layout
        );
        if (this.gridConfig[i].layout === this.selectedGrowArea.layout) {
          console.log("on click of layout");
          this.onClickOfLayout(this.gridConfig[i]);
        }
      }
      console.log(this.selectedGrowArea);
      this.getGrowSectionByGrowAreaId(id);
    });
  }
  setRowSize() {
    let max = 0;
    for (let i = 0; i < this.growSections.length; i++) {
      if (max < this.growSections[i].devices.length) {
        max = this.growSections[i].devices.length;
      }
    }
    console.log(max);
    if (this.selectedGrowArea) {
      if (this.selectedGrowArea.layout < 5) {
        this.gridCols = 1;
        if (max < 7) {
          this.gridRowHeights = "300";
        } else if (max > 6 && max < 13) {
          this.gridRowHeights = "400";
        } else if (max > 12 && max < 19) {
          this.gridRowHeights = "550";
        } else if (max > 18 && max < 25) {
          this.gridRowHeights = "700";
        }
      } else {
        this.gridCols = 2;
        this.gridRowHeights = "1:3";
        if (max < 7) {
          this.gridRowHeights = "1:1";
        } else if (max > 6 && max < 13) {
          this.gridRowHeights = "1:1.5";
        } else if (max > 12 && max < 19) {
          this.gridRowHeights = "1:2";
        } else if (max > 18 && max < 25) {
          this.gridRowHeights = "1:2.5";
        }
      }
    }
  }
  getRowHeight() {
    let max = 0;
    let rowht = "320";
    for (let i = 0; i < this.growSections.length; i++) {
      if (max < this.growSections[i].devices.length) {
        max = this.growSections[i].devices.length;
      }
    }
    console.log(max);
    if (max < 7) {
      rowht = "400";
    } else if (max > 6 && max < 13) {
      rowht = "600";
    } else if (max > 12 && max < 25) {
      rowht = "750";
    }
    return rowht;
  }
  getGrowSectionByGrowAreaId(id) {
    console.log(id);
    // if (this.selectedGrowArea) {
    //   if (this.selectedGrowArea.layout < 5) {
    //     this.gridCols = 1;
    //     this.gridRowHeights = '300';
    //   } else {
    //     this.gridCols = 2;
    //     this.gridRowHeights = '1:1';
    //   }
    // }
    this.growSectionService
      .getGrowSectionsByGrowarea(id)
      .subscribe((response: GrowSection[]) => {
        if (response === null || response === undefined) {
          response = [];
        }
        this.setRowSize();
        console.log(this.gridCols);
        console.log(this.gridRowHeights);
        this.growSections = response;
        this.deletingSection = false;
        if (
          this.selectedFacility &&
          this.selectedContainer &&
          this.selectedGrowArea
        ) {
          this.breadcrumService.store([
            { label: "Facilities", url: "/facilities", params: [] },
            {
              label: this.selectedFacility.facility_name,
              url: "/facilities/" + this.selectedFacility.id,
              params: [],
            },
            {
              label: "Containers",
              url: "/facilities/" + this.selectedFacility.id + "/containers",
              params: [],
            },
            {
              label: this.selectedContainer.container_name + "",
              url:
                "/facilities/" +
                this.selectedFacility.id +
                "/containers/" +
                this.selectedContainer.id,
              params: [],
            },
            {
              label: "Grow Areas",
              url:
                "/facilities/" +
                this.selectedFacility.id +
                "/containers/" +
                this.selectedContainer.id +
                "/grow-areas",
              params: [],
            },
            {
              label: this.selectedGrowArea.grow_area_name + "",
              url:
                "/facilities/" +
                this.selectedFacility.id +
                "/containers/" +
                this.selectedContainer.id +
                "/grow-areas/" +
                this.selectedGrowArea.id,
              params: [],
            },
            {
              label: "Grow Sections",
              url:
                "/facilities/" +
                this.selectedFacility.id +
                "/containers/" +
                this.selectedContainer.id +
                "/grow-areas/" +
                this.selectedGrowArea.id +
                "/grow-sections",
              params: [],
            },
          ]);
        } else if (this.selectedFacility && this.selectedContainer) {
          this.breadcrumService.store([
            { label: "Facilities", url: "/facilities", params: [] },
            {
              label: this.selectedFacility.facility_name,
              url: "/facilities/" + this.selectedFacility.id,
              params: [],
            },
            {
              label: "Containers",
              url: "/facilities/" + this.selectedFacility.id + "/containers",
              params: [],
            },
            {
              label: this.selectedContainer.container_name + "",
              url:
                "/facilities/" +
                this.selectedFacility.id +
                "/containers/" +
                this.selectedContainer.id,
              params: [],
            },
            {
              label: "Grow Sections",
              url:
                "/facilities/" +
                this.selectedFacility.id +
                "/containers/" +
                this.selectedContainer.id +
                "/grow-sections",
              params: [],
            },
          ]);
        } else if (this.selectedFacility && this.selectedGrowArea) {
          this.breadcrumService.store([
            { label: "Facilities", url: "/facilities", params: [] },
            {
              label: this.selectedFacility.facility_name,
              url: "/facilities/" + this.selectedFacility.id,
              params: [],
            },
            {
              label: "Grow Areas",
              url: "/facilities/" + this.selectedFacility.id + "/grow-areas",
              params: [],
            },
            {
              label: this.selectedGrowArea.grow_area_name + "",
              url:
                "/facilities/" +
                this.selectedFacility.id +
                "/grow-areas/" +
                this.selectedGrowArea.id,
              params: [],
            },
            {
              label: "Grow Sections",
              url:
                "/facilities/" +
                this.selectedFacility.id +
                "/grow-areas/" +
                this.selectedGrowArea.id +
                "/grow-sections",
              params: [],
            },
          ]);
        } else if (this.selectedContainer && this.selectedGrowArea) {
          this.breadcrumService.store([
            { label: "Containers", url: "/containers", params: [] },
            {
              label: this.selectedContainer.container_name + "",
              url: "/containers/" + this.selectedContainer.id,
              params: [],
            },
            {
              label: "Grow Areas",
              url: "/containers/" + this.selectedContainer.id + "/grow-areas",
              params: [],
            },
            {
              label: this.selectedGrowArea.grow_area_name + "",
              url:
                "/containers/" +
                this.selectedContainer.id +
                "/grow-areas/" +
                this.selectedGrowArea.id,
              params: [],
            },
            {
              label: "Grow Sections",
              url:
                "/containers/" +
                this.selectedContainer.id +
                "/grow-areas/" +
                this.selectedGrowArea.id +
                "/grow-sections",
              params: [],
            },
          ]);
        } else if (this.selectedFacility) {
          this.breadcrumService.store([
            { label: "Facilities", url: "/facilities", params: [] },
            {
              label: this.selectedFacility.facility_name,
              url: "/facilities/" + this.selectedFacility.id,
              params: [],
            },
            {
              label: "Grow Sections",
              url: "/facilities/" + this.selectedFacility.id + "/grow-sections",
              params: [],
            },
          ]);
        } else if (this.selectedContainer) {
          this.breadcrumService.store([
            { label: "Containers", url: "/containers", params: [] },
            {
              label: this.selectedContainer.container_name + "",
              url: "/containers/" + this.selectedContainer.id,
              params: [],
            },
            {
              label: "Grow Sections",
              url:
                "/containers/" + this.selectedContainer.id + "/grow-sections",
              params: [],
            },
          ]);
        } else if (this.selectedGrowArea) {
          this.breadcrumService.store([
            {
              label: "Grow Areas",
              url: "/grow-areas",
              params: [],
            },
            {
              label: this.selectedGrowArea.grow_area_name + "",
              url: "/grow-areas/" + this.selectedGrowArea.id,
              params: [],
            },
            {
              label: "Grow Sections",
              url: "/grow-areas/" + this.selectedGrowArea.id + "/grow-sections",
              params: [],
            },
          ]);
        }
        this.getDeviceTypes();
        this.addReloadEventToBreadcrumb();
      });
  }
  addReloadEventToBreadcrumb() {
    setTimeout(() => {
      const elems = document.querySelectorAll(".breadcrumb-item a");
      console.log(elems);
      console.log("length     ", elems.length);
      for (let i = 0; i < elems.length; i++) {
        elems[i].addEventListener("click", this.globalService.handleClick);
      }
    }, 100);
  }
  onCLickofViewSectionById(sectionId) {
    this.isAddGrowSectionProfiles = false;
    this.isViewGrowSectionProfiles = false;
    this.isViewGrowSectionDevices = false;
    console.log(sectionId);
    console.log(
      "sectionaaaaaaaaaaaa" + JSON.stringify(this.selectedGrowSection)
    );
    // this.getCountDeviceByGrowsectionselection(this.selectedGrowSection.id);
    this.getDevicesBySectionId(this.selectedGrowSection.id);
    this.isSelectedSection = true;
    this.growSectionService
      .getCountForDevicesInGrowsection(this.selectedGrowSection.id)
      .subscribe((response) => {
        this.countDevice = response;
        if (this.countDevice.count > 0) {
          // this.getProfileAlertByProfileId(this.selectedGrowSection.id);
          // this.getProfilesBySectionId(this.selectedGrowSection.id);
          this.getProfilesForSectionId(this.selectedGrowSection.id);
        } else {
          this.profiles = [];
        }
      });
  }

  addEditConditionOperator(condition, index, value) {
    index = index - 1;
    const controls = <FormArray>this.editConditionForm.controls[condition];
    const innerControl = <FormGroup>controls.controls[index];
    innerControl.value.combinationOperator = value;
    console.log(controls.controls[index]);
  }

  onEditConditionBlock(condition) {
    console.log(this.editConditionForm.controls[condition]);
    const controls = <FormArray>this.editConditionForm.controls[condition];
    controls.push(
      new FormGroup({
        property: new FormControl("", Validators.required),
        value: new FormControl("", Validators.required),
        operator: new FormControl("==", Validators.required),
        combinationOperator: new FormControl(""),
      })
    );
    console.log(this.editConditionForm.get(condition));
  }

  onRemoveEditConditionBlock(condition, index) {
    console.log("before", this.editConditionForm);
    const controls = <FormArray>this.editConditionForm.controls[condition];
    controls.removeAt(index);
    console.log(controls);
    console.log("after", this.editConditionForm);
    console.log(this.editConditionForm.get(condition));
    // this.setDevices(condition)
  }

  compareFn(obj1: any, obj2: any): boolean {
    if (obj1 === undefined || obj2 === undefined) {
      return false;
    } else {
      return obj1 && obj2 ? obj1.id === obj2.id : obj1 === obj2;
    }
  }

  getDeviceTypes() {
    this.deviceService.getDeviceTypes().subscribe((response: DeviceType[]) => {
      this.devicetypes = response;
      // this.getDevicesByType('SCMNode');
    });
  }

  getDevicesByType(deviceTypeName) {
    console.log(deviceTypeName);
    this.selectedDeviceTypeName = deviceTypeName;
    const selectedDeviceType = this.devicetypes.filter(
      (typeObj) => typeObj.device_type_name === deviceTypeName
    )[0];
    console.log("tfgujfgyhgkm", selectedDeviceType);
    this.deviceService
      .getDevicesByGrowareaAndDeviceType(
        this.selectedGrowArea.id,
        selectedDeviceType.id
      )
      .subscribe((response: Device[]) => {
        this.devices = response;
      });
  }

  onViewDevices() {
    this.isViewGrowSectionDevices = true;
    this.isAddGrowSectionProfiles = false;
    this.isViewGrowSectionProfiles = false;
  }

  onViewProfiles() {
    this.isViewGrowSectionDevices = false;
    this.isAddGrowSectionProfiles = false;
    this.isViewGrowSectionProfiles = true;
    console.log("details" + this.selectedGrowSection.id);
    this.growSectionService
      .getCountForDevicesInGrowsection(this.selectedGrowSection.id)
      .subscribe((response) => {
        console.log("data" + JSON.stringify(response));
        this.countDevice = response;
        console.log("response" + JSON.stringify(this.countDevice));
        if (this.countDevice.count > 0) {
          console.log("response" + JSON.stringify(this.countDevice));
          // this.getProfileAlertByProfileId(this.selectedGrowSection.id);
          // this.getProfilesBySectionId(this.selectedGrowSection.id);
          this.getProfilesForSectionId(this.selectedGrowSection.id);
        } else {
          this.profiles = [];
        }
      });
  }

  onInitFormGroup() {
    this.deviceForProperty["condition10"] = "Device";
    this.deviceForProperty["condition20"] = "Device";
    // this.deviceForProperty['condition40'] = 'Device';
    this.deviceForProperty["condition30"] = "Device";

    this.addProfileForm = new FormGroup({
      conditions: new FormArray([
        // new FormGroup({
        //   actions: new FormArray([
        //     new FormGroup({
        //       alertMessage: new FormControl(ProfileMessage.ALL_OK),
        //       type: new FormControl('send_alarm')
        //     })
        //   ]),
        //   expression: new  FormControl('')
        // }),
        new FormGroup({
          actions: new FormArray([
            new FormGroup({
              alertMessage: new FormControl(ProfileMessage.NEED_SUN),
              type: new FormControl("send_alarm"),
            }),
          ]),
          expression: new FormControl(""),
        }),
        new FormGroup({
          actions: new FormArray([
            new FormGroup({
              alertMessage: new FormControl(ProfileMessage.NEED_WATER),
              type: new FormControl("send_alarm"),
            }),
          ]),
          expression: new FormControl(""),
        }),
        new FormGroup({
          actions: new FormArray([
            new FormGroup({
              alertMessage: new FormControl(ProfileMessage.MORE_SUN),
              type: new FormControl("send_alarm"),
            }),
          ]),
          expression: new FormControl(""),
        }),
      ]),
      monitors: new FormArray([
        new FormGroup({
          deviceHids: new FormArray([new FormControl("", Validators.required)]),
          gatewayHid: new FormControl(this.selectedGrowArea.grow_area_hid),
        }),
      ]),
      type: new FormControl("CREATE"),
      timeInterval: new FormControl(60),
      globalResponsePayload: new FormGroup({
        containerId: new FormControl(
          JSON.stringify(this.selectedGrowArea.container.id)
        ),
        containerName: new FormControl(
          this.selectedGrowArea.container.container_name
        ),
        facilityId: new FormControl(
          JSON.stringify(this.selectedGrowArea.container.facility.id)
        ),
        facilityName: new FormControl(
          this.selectedGrowArea.container.facility.facility_name
        ),
        gatewayId: new FormControl(JSON.stringify(this.selectedGrowArea.id)),
        gatewayName: new FormControl(this.selectedGrowArea.grow_area_name),
        growSectionId: new FormControl(
          this.selectedGrowSection
            ? JSON.stringify(this.selectedGrowSection.id)
            : null
        ),
        growSectionName: new FormControl(
          this.selectedGrowSection
            ? this.selectedGrowSection.grow_section_name
            : null
        ),
      }),
    });
    this.addConditionForm = new FormGroup({
      // condition1: new FormArray([
      //   new FormGroup({
      //     property: new FormControl('', Validators.required),
      //     value: new FormControl('', [Validators.required, Validators.pattern('^[0-9]*$')]),
      //     operator: new FormControl('==', Validators.required),
      //     combinationOperator: new FormControl('')
      //   })
      // ]),
      condition2: new FormArray([
        new FormGroup({
          property: new FormControl("", Validators.required),
          value: new FormControl("", [
            Validators.required,
            Validators.pattern("^[0-9]*$"),
          ]),
          operator: new FormControl("==", Validators.required),
          combinationOperator: new FormControl(""),
        }),
      ]),
      condition3: new FormArray([
        new FormGroup({
          property: new FormControl("", Validators.required),
          value: new FormControl("", [
            Validators.required,
            Validators.pattern("^[0-9]*$"),
          ]),
          operator: new FormControl("==", Validators.required),
          combinationOperator: new FormControl(""),
        }),
      ]),
      // condition4: new FormArray([
      //   new FormGroup({
      //     property: new FormControl('', Validators.required),
      //     value: new FormControl('', [Validators.required, Validators.pattern('^[0-9]*$')]),
      //     operator: new FormControl('==', Validators.required),
      //     combinationOperator: new FormControl('')
      //   })
      // ])
    });
    console.log(
      JSON.stringify("edit" + JSON.stringify(this.addConditionForm.value))
    );
    console.log("edit1", this.addProfileForm);
  }

  onAddProfiles() {
    this.isViewGrowSectionDevices = false;
    this.isAddGrowSectionProfiles = true;
    this.isViewGrowSectionProfiles = false;

    // this.deviceForProperty['condition10'] = "Device";
    this.deviceForProperty["condition20"] = "Device";
    this.deviceForProperty["condition30"] = "Device";
    // this.deviceForProperty['condition40'] = 'Device';

    this.profileName = "";

    console.log(this.selectedGrowSection.id);

    console.log(this.selectedGrowArea);
    this.addProfileForm = new FormGroup({
      conditions: new FormArray([
        // new FormGroup({
        //   actions: new FormArray([
        //     new FormGroup({
        //       alertMessage: new FormControl(ProfileMessage.ALL_OK),
        //       type: new FormControl('send_alarm')
        //     })
        //   ]),
        //   expression: new  FormControl('')
        // }),
        new FormGroup({
          actions: new FormArray([
            new FormGroup({
              alertMessage: new FormControl(ProfileMessage.NEED_SUN),
              type: new FormControl("send_alarm"),
            }),
          ]),
          expression: new FormControl(""),
        }),
        new FormGroup({
          actions: new FormArray([
            new FormGroup({
              alertMessage: new FormControl(ProfileMessage.NEED_WATER),
              type: new FormControl("send_alarm"),
            }),
          ]),
          expression: new FormControl(""),
        }),
        new FormGroup({
          actions: new FormArray([
            new FormGroup({
              alertMessage: new FormControl(ProfileMessage.MORE_SUN),
              type: new FormControl("send_alarm"),
            }),
          ]),
          expression: new FormControl(""),
        }),
      ]),
      monitors: new FormArray([
        new FormGroup({
          deviceHids: new FormArray([new FormControl("", Validators.required)]),
          gatewayHid: new FormControl(this.selectedGrowArea.grow_area_hid),
        }),
      ]),
      type: new FormControl("CREATE"),
      timeInterval: new FormControl(60),
      globalResponsePayload: new FormGroup({
        containerId: new FormControl(
          JSON.stringify(this.selectedGrowArea.container.id)
        ),
        containerName: new FormControl(
          this.selectedGrowArea.container.container_name
        ),
        facilityId: new FormControl(
          JSON.stringify(this.selectedGrowArea.container.facility.id)
        ),
        facilityName: new FormControl(
          this.selectedGrowArea.container.facility.facility_name
        ),
        gatewayId: new FormControl(JSON.stringify(this.selectedGrowArea.id)),
        gatewayName: new FormControl(this.selectedGrowArea.grow_area_name),
        growSectionId: new FormControl(
          JSON.stringify(this.selectedGrowSection.id)
        ),
        growSectionName: new FormControl(
          this.selectedGrowSection.grow_section_name
        ),
      }),
    });

    this.addConditionForm = new FormGroup({
      condition2: new FormArray([
        new FormGroup({
          property: new FormControl("", Validators.required),
          value: new FormControl("", [
            Validators.required,
            Validators.pattern("^[0-9.]*$"),
          ]),
          operator: new FormControl("==", Validators.required),
          combinationOperator: new FormControl(""),
        }),
      ]),
      condition3: new FormArray([
        new FormGroup({
          property: new FormControl("", Validators.required),
          value: new FormControl("", [
            Validators.required,
            Validators.pattern("^[0-9.]*$"),
          ]),
          operator: new FormControl("==", Validators.required),
          combinationOperator: new FormControl(""),
        }),
      ]),
      // condition4: new FormArray([
      //   new FormGroup({
      //     property: new FormControl('', Validators.required),
      //     value: new FormControl('', [Validators.required, Validators.pattern('^[0-9.]*$')]),
      //     operator: new FormControl('==', Validators.required),
      //     combinationOperator: new FormControl('')
      //   })
      // ])
    });
    console.log(JSON.stringify(this.addConditionForm.value));
    console.log(JSON.stringify(this.addProfileForm.value));
  }

  get editcondition2() {
    return this.editConditionForm.get("editcondition2") as FormArray;
  }

  get editcondition3() {
    return this.editConditionForm.get("editcondition3") as FormArray;
  }

  get editcondition4() {
    return this.editConditionForm.get("editcondition4") as FormArray;
  }

  get condition2() {
    return this.addConditionForm.get("condition2") as FormArray;
  }

  get condition3() {
    return this.addConditionForm.get("condition3") as FormArray;
  }

  get condition4() {
    return this.addConditionForm.get("condition4") as FormArray;
  }

  addConditionOperator(condition, index, value) {
    index = index - 1;
    const controls = <FormArray>this.addConditionForm.controls[condition];
    const innerControl = <FormGroup>controls.controls[index];
    innerControl.value.combinationOperator = value;
    console.log(controls.controls[index]);
  }

  onAddConditionBlock(condition, index) {
    console.log(this.addConditionForm.controls[condition]);
    const controls = <FormArray>this.addConditionForm.controls[condition];
    controls.push(
      new FormGroup({
        property: new FormControl("", Validators.required),
        value: new FormControl("", Validators.required),
        operator: new FormControl("==", Validators.required),
        combinationOperator: new FormControl(""),
      })
    );
    console.log(this.addConditionForm.get(condition));
  }

  onRemoveConditionBlock(condition, index) {
    const controls = <FormArray>this.addConditionForm.controls[condition];
    controls.removeAt(index);
    console.log(this.addConditionForm.get(condition));
  }

  // sortObjByOperator(obj) {
  //   obj.sort(function (a, b) {
  //     const operator1 = a.combinationOperator;
  //     const operator2 = b.combinationOperator;
  //     if (operator1 < operator2) {
  //       return 1;
  //     }
  //     if (operator1 > operator2) {
  //       return -1;
  //     }
  //     return 0;
  //   });
  //   console.log('584', obj);
  //   return obj;
  // }

  createExressionStringFromObj(conditionArr) {
    let expression = "";
    for (let i = 0; i < conditionArr.length; i++) {
      if (conditionArr[i].combinationOperator !== "") {
        expression =
          expression +
          conditionArr[i].property +
          conditionArr[i].operator +
          conditionArr[i].value +
          " " +
          conditionArr[i].combinationOperator +
          " ";
      } else {
        expression =
          expression +
          conditionArr[i].property +
          conditionArr[i].operator +
          conditionArr[i].value;
      }
    }
    console.log("598         ", expression);
    return expression;
  }

  createDeviceHidsFromObj(conditionArr) {
    console.log("conditionARRRR", conditionArr);

    const deviceHids: string[] = [];
    let proplist = [];

    for (let i = 0; i < conditionArr.length; i++) {
      proplist = conditionArr[i].property.split(".");
      proplist = proplist[0].split("_");
      console.log("propertuadfaf0" + proplist[0]);
      console.log("propertuadfaf1" + proplist[1]);
      console.log("asdfaf", deviceHids.indexOf(proplist[1]) === -1);
      if (proplist[1] === undefined || proplist[1] === null) {
      } else {
        if (deviceHids.indexOf(proplist[1]) === -1) {
          deviceHids.push(proplist[1]);
          console.log(" " + deviceHids);
        }
      }
      // }else{
      //   const index = deviceHids.indexOf(proplist[1]);
      //   console.log(index);
      //   deviceHids.splice(index, 1);
      //   console.log(deviceHids);
      // }
    }
    console.log("from fun 616      ", deviceHids);
    return deviceHids;
  }

  unique(arr) {
    const u = {},
      a = [];
    for (let i = 0, l = arr.length; i < l; ++i) {
      if (!u.hasOwnProperty(arr[i])) {
        a.push(arr[i]);
        u[arr[i]] = 1;
      }
    }
    return a;
  }

  // refresh() {
  //   this.router.routeReuseStrategy.shouldReuseRoute = function () {
  //     console.log('refresh');
  //     return false;
  //   };
  // }

  getCountDeviceByGrowsectionselection(growsectionId) {
    this.growSectionService
      .getCountForDevicesInGrowsection(growsectionId)
      .subscribe((response) => {
        console.log("data" + JSON.stringify(response));
        this.countDevice = response;
      });
  }

  getProfilesForSectionId(growsectionId) {
    this.growSectionService
      .getConditionsForDevicesInGrowSections(growsectionId)
      .subscribe((response) => {
        this.profiles = [];
        this.profile = response;
        for (let i = 0; i < this.profile.length; i++) {
          console.log(
            "responseeeeeeeeeeeeeeeee" + JSON.stringify(this.profile[i])
          );
          this.profiles.push(this.profile[i]);
          console.log("respponasdfffffff" + JSON.stringify(this.profiles));
        }
      });
  }

  getProfileIdForCondition(id, type) {
    console.log("id" + id + "\ntype:" + type);
    this.growSectionService
      .getConditionsForDevicesInGrowSections(this.selectedGrowSection.id)
      .subscribe((response) => {
        console.log("responseaaaaaaaaaaaaaaaaaaa" + JSON.stringify(response));
        this.conditionAll = response;
        for (let values = 0; values < this.conditionAll.length; values++) {
          if (
            type === "yellow" &&
            this.conditionAll[values].payload.globalResponsePayload
              .profileId === id
          ) {
            this.yellow = [];
            if (
              this.conditionAll[values].payload.conditions.conditionYellow ===
              undefined
            ) {
            } else {
              console.log(this.conditionAll[values].payload.conditions);
              this.conditionValueYellow = this.conditionAll[
                values
              ].payload.conditions.conditionYellow;
              for (let i = 0; i < this.conditionValueYellow.length; i++) {
                this.yellow.push(this.conditionValueYellow[i]);
              }
              // console.log('wefwegerg',this.yellow);
            }
          }

          if (
            type === "green" &&
            this.conditionAll[values].payload.globalResponsePayload
              .profileId === id
          ) {
            this.green = [];
            if (
              this.conditionAll[values].payload.conditions.conditionGreen ===
              undefined
            ) {
            } else {
              this.conditionValueGreen = this.conditionAll[
                values
              ].payload.conditions.conditionGreen;
              for (let i = 0; i < this.conditionValueGreen.length; i++) {
                this.green.push(this.conditionValueGreen[i]);
              }
            }
          }

          if (
            type === "blue" &&
            this.conditionAll[values].payload.globalResponsePayload
              .profileId === id
          ) {
            this.blue = [];
            if (
              this.conditionAll[values].payload.conditions.conditionBlue ===
              undefined
            ) {
            } else {
              console.log(this.conditionAll[values].payload.conditions);

              this.conditionValueBlue = this.conditionAll[
                values
              ].payload.conditions.conditionBlue;
              for (let i = 0; i < this.conditionValueBlue.length; i++) {
                this.blue.push(this.conditionValueBlue[i]);
              }
            }
          }

          if (
            type === "red" &&
            this.conditionAll[values].payload.globalResponsePayload
              .profileId === id
          ) {
            this.red = [];
            if (
              this.conditionAll[values].payload.conditions.conditionRed ===
              undefined
            ) {
            } else {
              console.log(this.conditionAll[values].payload.conditions);

              this.conditionValueRed = this.conditionAll[
                values
              ].payload.conditions.conditionRed;
              for (let i = 0; i < this.conditionValueRed.length; i++) {
                this.red.push(this.conditionValueRed[i]);
              }
            }
          }
        }
      });
  }

  // getConditionByGrowSectionselection(growsectionId){
  //   this.growSectionService.getConditionsForDevicesInGrowSections(growsectionId).subscribe((response)=>{
  //       this.conditionAll = response;
  //       console.log('response'+JSON.stringify(this.conditionAll));
  //       console.log('selected Profile'+JSON.stringify(this.profiles));
  //       this.conditionValueYellow = this.conditionAll[0].payload.conditions.conditionYellow;
  //       // console.log('selected Profile Alerts'+JSON.stringify(this.profileAlert));
  //       // for(let condition = 0; condition < this.profiles.length ; condition++){
  //       //     console.log('profiles'+ this.profiles[condition].id);
  //       //     // this.getDeviceConditionById(this.profiles[condition].id);
  //       // }
  //     });
  // }

  getproperties(property) {
    const abc: any = [];
    let lmn: any = [];
    const pqr = property.split(".")[1];
    lmn = pqr.match(/[A-Z][a-z]+/g);
    if (lmn !== null && lmn !== undefined && lmn.length > 0) {
      const xyz = pqr.split(lmn[0]);
      let wef,
        gh = "";
      if (lmn[0] === "Ph") {
        wef = lmn[0].charAt(0).toLowerCase() + lmn[0].slice(1);
        gh = wef.charAt(0) + wef.charAt(1).toUpperCase();
      } else {
        gh = lmn[0];
      }
      abc.push(xyz[0].charAt(0).toUpperCase() + xyz[0].slice(1));
      abc.push(gh);
      return abc;
    } else {
      abc.push(this.stic[pqr]);
      abc.push("");
      return abc;
    }
  }

  getProfileForProfileId(id) {
    console.log("yellow" + this.conditionAll);
    this.conditionValueYellow = this.conditionAll[0].payload.conditions.conditionYellow;
    console.log(
      "condition" +
        this.conditionValueYellow[id].property.split(".")[1].replace("_", "") +
        " " +
        this.conditionValueYellow[id].operator +
        " " +
        this.conditionValueYellow[id].value
    );
  }

  onEditProfile() {
    console.log("afdssdfdsf", this.profileAlert);
    this.editProfileForm = new FormGroup({
      conditions: new FormArray([
        new FormGroup({
          actions: new FormArray([
            new FormGroup({
              alertMessage: new FormControl(ProfileMessage.NEED_SUN),
              type: new FormControl("send_alarm"),
            }),
          ]),
          expression: new FormControl(""),
        }),
        new FormGroup({
          actions: new FormArray([
            new FormGroup({
              alertMessage: new FormControl(ProfileMessage.NEED_WATER),
              type: new FormControl("send_alarm"),
            }),
          ]),
          expression: new FormControl(""),
        }),
        new FormGroup({
          actions: new FormArray([
            new FormGroup({
              alertMessage: new FormControl(ProfileMessage.MORE_SUN),
              type: new FormControl("send_alarm"),
            }),
          ]),
          expression: new FormControl(""),
        }),
      ]),
      monitors: new FormArray([
        new FormGroup({
          deviceHids: new FormArray([new FormControl("", Validators.required)]),
          gatewayHid: new FormControl(this.selectedGrowArea.grow_area_hid),
        }),
      ]),
      type: new FormControl("UPDATE"),
      timeInterval: new FormControl(60),
      name: new FormControl(
        this.profileAlert.payload.globalResponsePayload.profileName
      ),
      ruleHid: new FormControl(this.profileAlert.payload.name),
      id: new FormControl(this.profileAlert.payload.id),
      globalResponsePayload: new FormGroup({
        id: new FormControl(this.profileAlert.payload.globalResponsePayload.id),
        containerId: new FormControl(
          JSON.stringify(this.selectedGrowArea.container.id)
        ),
        containerName: new FormControl(
          this.selectedGrowArea.container.container_name
        ),
        facilityId: new FormControl(
          JSON.stringify(this.selectedGrowArea.container.facility.id)
        ),
        facilityName: new FormControl(
          this.selectedGrowArea.container.facility.facility_name
        ),
        gatewayId: new FormControl(JSON.stringify(this.selectedGrowArea.id)),
        gatewayName: new FormControl(this.selectedGrowArea.grow_area_name),
        growSectionId: new FormControl(
          JSON.stringify(this.selectedGrowSection.id)
        ),
        growSectionName: new FormControl(
          this.selectedGrowSection.grow_section_name
        ),
        profileId: new FormControl(
          this.profileAlert.payload.globalResponsePayload.profileId
        ),
        profileName: new FormControl(
          this.profileAlert.payload.globalResponsePayload.profileName
        ),
      }),
    });

    let validFlag = true;

    if (validFlag) {
      for (
        let i = 0;
        i < this.editConditionForm.value.editcondition2.length;
        i++
      ) {
        const obj = this.editConditionForm.value.editcondition2;
        if (obj[i + 1]) {
          if (obj[i].combinationOperator !== "") {
            if (!validFlag) {
              validFlag = true;
            }
          } else {
            validFlag = false;
          }
        }
      }
    }

    if (validFlag) {
      for (
        let i = 0;
        i < this.editConditionForm.value.editcondition3.length;
        i++
      ) {
        const obj = this.editConditionForm.value.editcondition3;
        if (obj[i + 1]) {
          if (obj[i].combinationOperator !== "") {
            if (!validFlag) {
              validFlag = true;
            }
          } else {
            validFlag = false;
          }
        }
      }
    }

    // if (validFlag) {
    //   for (let i = 0; i < this.editConditionForm.value.editcondition4.length; i++) {
    //     const obj = this.editConditionForm.value.editcondition4;
    //     if (obj[i + 1]) {
    //       if (obj[i].combinationOperator !== '') {
    //         if (!validFlag) {
    //           validFlag = true;
    //         }
    //       } else {
    //         validFlag = false;
    //       }
    //     }
    //   }
    // }

    console.log(validFlag);
    if (!validFlag) {
      this.toastrService.error("Please provide all details", "Update Rule");
    } else {
      let deviceHids = [];
      const mainObj = [];
      console.log("123", this.editConditionForm.controls);
      console.log("1231", this.editConditionForm.value.editcondition2);
      console.log("12312", this.editConditionForm.value.editcondition3);

      if (this.editConditionForm.value.editcondition2 === []) {
      } else {
        this.editConditionForm.value.editcondition2 = this.editConditionForm.value.editcondition2;
      }
      if (this.editConditionForm.value.editcondition3 === []) {
      } else {
        this.editConditionForm.value.editcondition3 = this.editConditionForm.value.editcondition3;
      }

      // if (this.editConditionForm.value.editcondition4 === []) {

      // } else {
      //   this.editConditionForm.value.editcondition4 = this.editConditionForm.value.editcondition4;
      // }
      console.log("adfasfds", this.editProfileForm.value.conditions[0]);
      console.log("aaaaaa", this.editProfileForm.value.conditions[1]);

      let expression2;
      let expression3;
      let expression4;

      // let expression1 = JSON.stringify(this.editProfileForm.value.conditions[0].expression);
      if (this.editProfileForm.value.conditions[0] === undefined) {
      } else {
        this.editProfileForm.value.conditions[0].expression = this.createExressionStringFromObj(
          this.editConditionForm.value.editcondition2
        );
        expression2 = JSON.stringify(
          this.editProfileForm.value.conditions[0].expression
        );
        if (
          JSON.stringify(
            this.editProfileForm.value.conditions[0].expression
          ).slice(-4, -2) === "||" ||
          JSON.stringify(
            this.editProfileForm.value.conditions[0].expression
          ).slice(-4, -2) === "&&"
        ) {
          console.log("condition20");
          this.editProfileForm.value.conditions[0].expression = JSON.stringify(
            this.editProfileForm.value.conditions[0].expression
          ).slice(1, expression2.length - 5);
          console.log(
            "profilesvalue" +
              JSON.stringify(
                this.editProfileForm.value.conditions[0].expression
              )
          );
        } else {
          console.log("condition21");
          this.editProfileForm.value.conditions[0].expression = this.editProfileForm.value.conditions[0].expression;
          console.log(
            "profilesvalue" +
              JSON.stringify(
                this.editProfileForm.value.conditions[0].expression
              )
          );
        }
      }
      if (this.editProfileForm.value.conditions[1] === undefined) {
      } else {
        this.editProfileForm.value.conditions[1].expression = this.createExressionStringFromObj(
          this.editConditionForm.value.editcondition3
        );
        expression3 = JSON.stringify(
          this.editProfileForm.value.conditions[1].expression
        );
        if (
          JSON.stringify(
            this.editProfileForm.value.conditions[1].expression
          ).slice(-4, -2) === "||" ||
          JSON.stringify(
            this.editProfileForm.value.conditions[1].expression
          ).slice(-4, -2) === "&&"
        ) {
          console.log("condition30");
          this.editProfileForm.value.conditions[1].expression = JSON.stringify(
            this.editProfileForm.value.conditions[1].expression
          ).slice(1, expression3.length - 5);
          console.log(
            "profilesvalue" +
              JSON.stringify(
                this.editProfileForm.value.conditions[1].expression
              )
          );
        } else {
          console.log("condition31");
          this.editProfileForm.value.conditions[1].expression = this.editProfileForm.value.conditions[1].expression;
          console.log(
            "profilesvalue" +
              JSON.stringify(
                this.editProfileForm.value.conditions[1].expression
              )
          );
        }
      }
      // if (this.editProfileForm.value.conditions[2] === undefined) {

      // } else {
      //   this.editProfileForm.value.conditions[2].expression =
      //     this.createExressionStringFromObj(this.editConditionForm.value.editcondition4);
      //   expression4 = JSON.stringify(this.editProfileForm.value.conditions[2].expression);
      //   if (JSON.stringify(this.editProfileForm.value.conditions[2].expression).slice(-4, -2) === '||' ||
      //     JSON.stringify(this.editProfileForm.value.conditions[2].expression).slice(-4, -2) === '&&') {
      //     console.log('condition40');
      //     this.editProfileForm.value.conditions[2].expression =
      //       JSON.stringify(this.editProfileForm.value.conditions[3].expression).slice(1, expression4.length - 5);
      //     console.log('profilesvalue' + JSON.stringify(this.editProfileForm.value.conditions[3].expression));
      //   } else {
      //     console.log('condition41');
      //     this.editProfileForm.value.conditions[2].expression = this.editProfileForm.value.conditions[2].expression;
      //     console.log('profilesvalue' + JSON.stringify(this.editProfileForm.value.conditions[2].expression));
      //   }
      // }

      // deviceHids = this.createDeviceHidsFromObj(this.editConditionForm.value.editcondition1);
      // this.editProfileForm.value.monitors[0].deviceHids = deviceHids;
      // deviceHids = this.createDeviceHidsFromObj(this.editConditionForm.value.editcondition2);
      // this.editProfileForm.value.monitors[0].deviceHids = this.editProfileForm.value.monitors[0].deviceHids.concat(deviceHids);
      // deviceHids = this.createDeviceHidsFromObj(this.editConditionForm.value.editcondition3);
      // this.editProfileForm.value.monitors[0].deviceHids = this.editProfileForm.value.monitors[0].deviceHids.concat(deviceHids);
      // deviceHids = this.createDeviceHidsFromObj(this.editConditionForm.value.editcondition4);
      // this.editProfileForm.value.monitors[0].deviceHids = this.editProfileForm.value.monitors[0].deviceHids.concat(deviceHids);

      //  this.addProfileForm.value.conditions = JSON.stringify(this.addProfileForm.value.conditions);
      //  this.addProfileForm.value.monitors = JSON.stringify(this.addProfileForm.value.monitors);

      console.log("llll", this.editProfileForm.value.conditions);
      for (let i = 0; i < this.editProfileForm.value.conditions.length; i++) {
        // this.addProfileForm.value.conditions[i].expression === '' ||
        //  this.addProfileForm.value.conditions[i].expression.slice(0, 1) === '!' ||
        //  this.addProfileForm.value.conditions[i].expression.slice(-1) === '<' ||
        //  this.addProfileForm.value.conditions[i].expression.slice(-1) === '>' ||
        //   this.addProfileForm.value.conditions[i].expression.slice(-1) === '=' ||
        //    this.addProfileForm.value.conditions[i].expression.slice(0, 1) === '=' ||
        //     this.addProfileForm.value.conditions[i].expression.slice(0, 1) === '<' ||
        //      this.addProfileForm.value.conditions[i].expression.slice(0, 1) === '>' ||
        //       this.addProfileForm.value.conditions[i].expression.endsWith('null') ||
        //        this.addProfileForm.value.conditions[i].expression.startsWith('_Device') ||
        //         this.addProfileForm.value.conditions[i].expression.slice(-7,-4) === '&& ' ||
        //          this.addProfileForm.value.conditions[i].expression.slice(-7,-4) === '|| '

        if (
          this.editProfileForm.value.conditions[i].expression === "" ||
          this.editProfileForm.value.conditions[i].expression === "=="
        ) {
        } else {
          console.log("aaaa", this.editConditionForm.value.editcondition2);
          deviceHids = this.createDeviceHidsFromObj(
            this.editConditionForm.value.editcondition2
          );
          this.editProfileForm.value.monitors[0].deviceHids = deviceHids;
          deviceHids = this.createDeviceHidsFromObj(
            this.editConditionForm.value.editcondition3
          );
          this.editProfileForm.value.monitors[0].deviceHids = this.editProfileForm.value.monitors[0].deviceHids.concat(
            deviceHids
          );
          // deviceHids = this.createDeviceHidsFromObj(this.editConditionForm.value.editcondition4);
          // this.editProfileForm.value.monitors[0].deviceHids = this.editProfileForm.value.monitors[0].deviceHids.concat(deviceHids);
          console.log("lefndll", JSON.stringify(this.editProfileForm.value));
          mainObj.push(this.editProfileForm.value.conditions[i]);
        }
      }
      this.editProfileForm.value.monitors[0].deviceHids = this.unique(
        this.editProfileForm.value.monitors[0].deviceHids
      );
      this.editProfileForm.value.profileName = this.editProfileName;
      this.editProfileForm.value.conditions = mainObj;
      console.log(this.editProfileForm.value);
      console.log("editProfile" + JSON.stringify(this.editProfileForm.value));
      this.globalService
        .updateProfile(
          this.profileAlert.payload.globalResponsePayload.profileId,
          this.selectedGrowSection.id,
          this.editProfileForm.value
        )
        .subscribe((response) => {
          console.log("Response:" + JSON.stringify(response));
          this.toastrService.success(
            "Rule update request sent successfully.",
            "Update Rule"
          );
        });
    }
  }

  onCreateProfile() {
    if (this.selectedGrowArea.latest_heartbeat_timestamp === "false") {
      this.toastrService.error(
        "Selected Grow Area is currently out of network. Please try later.",
        "Create Rule"
      );
      this.addConditionForm.reset();
      this.addProfileForm.reset();
      this.profileName = "";
      this.deviceForProperty["condition20"] = "Device";
      this.deviceForProperty["condition30"] = "Device";
      this.deviceForProperty["condition40"] = "Device";
      this.onInitFormGroup();
      this.isAddGrowSectionProfiles = false;
      this.creatingProfile = false;

      return;
    }
    this.creatingProfile = true;
    console.log(this.addConditionForm.value);
    let validFlag = true;

    if (validFlag) {
      for (let i = 0; i < this.addConditionForm.value.condition2.length; i++) {
        const obj = this.addConditionForm.value.condition2;
        if (obj[i + 1]) {
          if (obj[i].combinationOperator !== "") {
            if (!validFlag) {
              validFlag = true;
            }
          } else {
            validFlag = false;
          }
        }
      }
    }
    if (validFlag) {
      for (let i = 0; i < this.addConditionForm.value.condition3.length; i++) {
        const obj = this.addConditionForm.value.condition3;
        if (obj[i + 1]) {
          if (obj[i].combinationOperator !== "") {
            if (!validFlag) {
              validFlag = true;
            }
          } else {
            validFlag = false;
          }
        }
      }
    }
    // if (validFlag) {
    //   for (let i = 0; i < this.addConditionForm.value.condition4.length; i++) {
    //     const obj = this.addConditionForm.value.condition4;
    //     if (obj[i + 1]) {
    //       if (obj[i].combinationOperator !== '') {
    //         if (!validFlag) {
    //           validFlag = true;
    //         }
    //       } else {
    //         validFlag = false;
    //       }
    //     }
    //   }
    // }
    console.log(validFlag);
    if (!validFlag) {
      this.toastrService.error("Please provide all details", "Create Rule");
      this.addConditionForm.reset();
      this.addProfileForm.reset();
      this.profileName = "";
      this.deviceForProperty["condition20"] = "Device";
      this.deviceForProperty["condition30"] = "Device";
      this.deviceForProperty["condition40"] = "Device";
      this.onInitFormGroup();
      this.isAddGrowSectionProfiles = false;
      this.creatingProfile = false;
    } else {
      let deviceHids = [];
      const mainObj = [];

      // this.addConditionForm.value.condition2 = this.addConditionForm.value.condition2;
      // this.addConditionForm.value.condition3 = this.addConditionForm.value.condition3;
      // this.addConditionForm.value.condition4 = this.addConditionForm.value.condition4;

      console.log("asasdfdfdsfdfdf", this.addProfileForm.value.conditions[0]);

      // for (let i = 0; i < this.addConditionForm.value.condition2.length; i++) {
      //   console.log('this.profile',this.addConditionForm.value.condition2[i].property);
      //   if (this.addConditionForm.value.condition2[i].property === '') {
      //     this.toastrService.error('Please provide one condition');
      //   } else {
      //     this.addProfileForm.value.conditions[0] ? this.addProfileForm.value.conditions[0].expression =
      //  this.createExressionStringFromObj(this.addConditionForm.value.condition2) : '';
      //     console.log('true');
      //   }
      // }

      this.addProfileForm.value.conditions[0]
        ? (this.addProfileForm.value.conditions[0].expression = this.createExressionStringFromObj(
            this.addConditionForm.value.condition2
          ))
        : "";
      this.addProfileForm.value.conditions[1]
        ? (this.addProfileForm.value.conditions[1].expression = this.createExressionStringFromObj(
            this.addConditionForm.value.condition3
          ))
        : "";
      // this.addProfileForm.value.conditions[2] ? this.addProfileForm.value.conditions[2].expression =
      //  this.createExressionStringFromObj(this.addConditionForm.value.condition4) : '';

      // for (let i = 0; i < this.addConditionForm.value.condition3.length; i++) {
      //   if (this.addConditionForm.value.condition3[i].property === '') {
      //     this.toastrService.error('Please provide one condition');
      //   } else {
      //     console.log('true');
      //     this.addProfileForm.value.conditions[1] ? this.addProfileForm.value.conditions[1].expression =
      //  this.createExressionStringFromObj(this.addConditionForm.value.condition3) : '';
      //   }
      // }

      // for (let i = 0; i < this.addConditionForm.value.condition4.length; i++) {
      //   if (this.addConditionForm.value.condition4[i].property === '') {
      //     this.toastrService.error('Please provide one condition');
      //   } else {
      //     console.log('true');
      //     this.addProfileForm.value.conditions[2] ? this.addProfileForm.value.conditions[2].expression =
      //  this.createExressionStringFromObj(this.addConditionForm.value.condition4) : '';
      //   }
      // }
      this.addProfileForm.value.profileName = this.profileName;

      for (let i = 0; i < this.addProfileForm.value.conditions.length; i++) {
        console.log("adfafds", this.addConditionForm.value.condition2.length);
        // console.log('adaf'+JSON.stringify(this.addConditionForm.value.condition2[i].value));
        console.log(
          "hello harshad",
          this.addProfileForm.value.conditions[i].expression.slice(-7, -3)
        );
        console.log(
          "addddddddddcontrjioado",
          this.addProfileForm.value.conditions[i].expression.slice(-3, -1)
        );

        let expressionValue;
        expressionValue = this.addProfileForm.value.conditions[i].expression;

        if (
          expressionValue.slice(-3, -1) === "&&" ||
          expressionValue.slice(-3, -1) === "||"
        ) {
          this.addProfileForm.value.conditions[
            i
          ].expression = this.addProfileForm.value.conditions[
            i
          ].expression.slice(0, expressionValue.length - 4);
          console.log(
            "expressionValues123",
            this.addProfileForm.value.conditions[i].expression
          );
        } else {
          this.addProfileForm.value.conditions[
            i
          ].expression = this.addProfileForm.value.conditions[i].expression;
        }
        // if(this.addProfileForm.value.conditons[i].expression.endsWith('&& ') ||
        //  this.addProfileForm.value.conditon[i].expression.endsWith('|| ')){
        //    console.log('addddddddddcontrjioado',this.addConditionForm.value.conditions[i]);
        // }else{

        // }
        if (
          this.addProfileForm.value.conditions[i].expression === "" ||
          this.addProfileForm.value.conditions[i].expression.slice(0, 1) ===
            "!" ||
          this.addProfileForm.value.conditions[i].expression.slice(-1) ===
            "<" ||
          this.addProfileForm.value.conditions[i].expression.slice(-1) ===
            ">" ||
          this.addProfileForm.value.conditions[i].expression.slice(-1) ===
            "=" ||
          this.addProfileForm.value.conditions[i].expression.slice(0, 1) ===
            "=" ||
          this.addProfileForm.value.conditions[i].expression.slice(0, 1) ===
            "<" ||
          this.addProfileForm.value.conditions[i].expression.slice(0, 1) ===
            ">" ||
          this.addProfileForm.value.conditions[i].expression.endsWith("null") ||
          this.addProfileForm.value.conditions[i].expression.startsWith(
            "_Device"
          ) ||
          this.addProfileForm.value.conditions[i].expression.slice(-7, -4) ===
            "&& " ||
          this.addProfileForm.value.conditions[i].expression.slice(-7, -4) ===
            "|| "
        ) {
          // doing nothing
        } else {
          console.log("aftererererer", deviceHids);
          console.log("vadfasdf", this.addConditionForm.value.condition2);
          deviceHids = this.createDeviceHidsFromObj(
            this.addConditionForm.value.condition2
          );
          this.addProfileForm.value.monitors[0].deviceHids = deviceHids;
          console.log(
            "ssdfgf",
            this.addProfileForm.value.monitors[0].deviceHids
          );
          deviceHids = this.createDeviceHidsFromObj(
            this.addConditionForm.value.condition3
          );
          this.addProfileForm.value.monitors[0].deviceHids = this.addProfileForm.value.monitors[0].deviceHids.concat(
            deviceHids
          );
          // deviceHids = this.createDeviceHidsFromObj(this.addConditionForm.value.condition4);
          // this.addProfileForm.value.monitors[0].deviceHids = this.addProfileForm.value.monitors[0].deviceHids.concat(deviceHids);
          console.log("lefndll" + JSON.stringify(this.addProfileForm.value));
          console.log("adadfas2", deviceHids);
          mainObj.push(this.addProfileForm.value.conditions[i]);
        }
      }
      this.addProfileForm.value.conditions = mainObj;
      console.log("sfdf11232" + this.addProfileForm.value);
      if (this.addProfileForm.value.conditions.length === 0) {
        this.toastrService.error(
          "Please Provide minimum one condition",
          "Create Rule"
        );
        this.addConditionForm.reset();
        this.addProfileForm.reset();
        this.profileName = "";
        this.deviceForProperty["condition20"] = "Device";
        this.deviceForProperty["condition30"] = "Device";
        this.deviceForProperty["condition40"] = "Device";
        this.onInitFormGroup();
        this.isAddGrowSectionProfiles = false;
      } else {
        console.log(
          " before monitorssss" +
            JSON.stringify(
              this.addProfileForm.value.monitors[0].deviceHids.length
            )
        );
        for (
          let i = 0;
          i < this.addProfileForm.value.monitors[0].deviceHids.length;
          i++
        ) {
          console.log(this.addProfileForm.value.monitors[0].deviceHids[i]);
          if (
            this.addProfileForm.value.monitors[0].deviceHids[i] !== "" &&
            this.addProfileForm.value.monitors[0].deviceHids[i] !== undefined &&
            this.addProfileForm.value.monitors[0].deviceHids[i] !== null
          ) {
            this.deviceIds.push(
              this.addProfileForm.value.monitors[0].deviceHids[i]
            );
          }
        }
        console.log("sectionID" + this.selectedGrowSection.id);
        this.addProfileForm.value.monitors[0].deviceHids = this.unique(
          this.deviceIds
        );
        console.log(
          " after monitorssss" +
            JSON.stringify(this.addProfileForm.value.monitors[0])
        );
        console.log("addddadsfa" + JSON.stringify(this.addProfileForm.value));

        this.globalService
          .createProfile(this.selectedGrowSection.id, this.addProfileForm.value)
          .subscribe(
            (response) => {
              console.log("Response:" + JSON.stringify(response));
              this.toastrService.success(
                "Rule creation request sent successfully.",
                "Create Rule"
              );
              this.isAddGrowSectionProfiles = false;
              this.isViewGrowSectionDevices = false;
              this.isViewGrowSectionProfiles = false;
              this.getProfilesForSectionId(this.selectedGrowSection.id);
              this.addProfileForm.reset();
              this.addConditionForm.reset();
              this.onInitFormGroup();
              deviceHids = [];
              this.deviceForProperty["condition20"] = "Device";
              this.deviceForProperty["condition30"] = "Device";
              this.deviceForProperty["condition40"] = "Device";
              this.profileName = "";
              this.creatingProfile = false;
              this.propertyList = [];
            },
            (error) => {
              this.addConditionForm.reset();
              this.addProfileForm.reset();
              this.profileName = "";
              this.deviceForProperty["condition20"] = "Device";
              this.deviceForProperty["condition30"] = "Device";
              this.deviceForProperty["condition40"] = "Device";
              this.onInitFormGroup();
              this.isAddGrowSectionProfiles = false;
              this.creatingProfile = false;
              this.propertyList = [];
            }
          );
        // console.log(deviceIds);
      }
    }
  }

  clearData() {
    this.profileName = "";
    this.addProfileForm.reset();
    this.addConditionForm.reset();
    this.onInitFormGroup();
    this.propertyList = [];
    this.deviceForProperty["condition20"] = "Device";
    this.deviceForProperty["condition30"] = "Device";
    this.deviceForProperty["condition40"] = "Device";
  }

  clearEditData() {
    this.profileName = "";
    this.editProfileForm.reset();
  }
  onSelectGrowSection(index, type) {
    this.selectedGrowSectionIndex = index;
    if (this.selectedGrowSectionLayout[index]) {
      this.selectedGrowSectionLayout[index] = false;
    } else {
      this.selectedGrowSectionLayout = [];
      this.selectedGrowSectionLayout[index] = true;
    }
    this.selectedGrowSection = this.growSections[index];
    console.log(this.selectedGrowSection);
    console.log(this.selectedGrowArea.id);
    if (type !== "add") {
      this.onCLickofViewSectionById(this.selectedGrowSection.id);
    }
  }

  attachDeviceToSection(device: Device) {
    console.log("devices", device);
    if (this.selectedGrowSection) {
      // if(device.device_type.device_type_name === "LedNode"){
      //   this.toastrService.error('Le')
      // }
      if (this.selectedGrowSection.devices.length >= 24) {
        this.toastrService.error(
          "You have already added maximum number of device"
        );
        return;
      } else {
        console.log(this.selectedGrowSection.devices.length);
        let isDeviceFound = false;
        for (let i = 0; i < this.selectedGrowSection.devices.length; i++) {
          console.log(this.selectedGrowSection.devices);
          if (
            this.selectedGrowSection.devices[i].deviceHId === device.deviceHId
          ) {
            console.log(device.deviceHId);
            isDeviceFound = isDeviceFound || true;
          }
        }
        if (isDeviceFound) {
          this.toastrService.error(
            "This device is already attached with selected Grow Section. Try to attach with another Grow Section."
          );
          return;
        } else {
          this.growSections[this.selectedGrowSectionIndex].devices.push(device);
          this.selectedGrowSection = this.growSections[
            this.selectedGrowSectionIndex
          ];
        }
      }
    } else {
      this.toastrService.error("Please First Select Any GrowSection.");
    }
  }

  removeDeviceFromSection(index) {
    console.log(this.selectedGrowSection);
    if (this.selectedGrowSection) {
      this.selectedGrowSection.devices.splice(index, 1);
    } else {
      this.toastrService.error(
        "Please Select Grow Section first.",
        "Remove Device"
      );
    }
  }

  onClickOfAddSections() {
    this.displayGridLayout = [];

    this.isAddSection = true;
    this.isViewSection = false;
    this.isSelectedSection = true;
    console.log(this.selectedGrowArea.layout);

    if (this.selectedGrowArea.layout === 0) {
      for (
        let i = this.selectedGrowArea.layout;
        i < this.gridConfig.length;
        i++
      ) {
        console.log(this.gridConfig[i]);
        this.displayGridLayout.push(this.gridConfig[i]);
        console.log(this.growSections);
      }
    } else if (this.selectedGrowArea.layout < 5) {
      for (
        let i = this.selectedGrowArea.layout - 1;
        i < this.gridConfig.length;
        i++
      ) {
        console.log(this.gridConfig[i]);
        this.displayGridLayout.push(this.gridConfig[i]);
        console.log(this.displayGridLayout);
      }
    } else {
      for (
        let i = this.selectedGrowArea.layout - 2;
        i < this.gridConfig.length;
        i++
      ) {
        console.log(this.gridConfig[i]);
        this.displayGridLayout.push(this.gridConfig[i]);
        console.log(this.displayGridLayout);
      }
    }
    // this.router.navigate(['grow-sections', 'add'], {relativeTo: this.route});
  }

  createGrowSections() {
    console.log(this.growSections);

    this.sectionList = [];
    this.editSectionsList = [];

    let validFlag = false;
    for (let i = 0; i < this.growSections.length; i++) {
      console.log("growsection length " + this.layoutList.length);
      console.log("growsection2 length ", this.growSections);

      // if(this.layoutList.length <= this.growSections.length){

      if (this.growSections[i].grow_section_name !== "") {
        if (!validFlag) {
          validFlag = true;
          console.log("validate flag");
        }
        console.log("growsection2", this.growSections[i].id);
        // this.sectionList = [];
        // console.log(this.growSections[i].id === 0);
        // console.log(this.growSections[i].id > 0);
        if (this.growSections[i].id === 0) {
          // delete this.growSections[i].id;
          this.sectionList.push(this.growSections[i]);
          console.log("entered into growsections", this.sectionList);
        }

        if (this.growSections[i].id > 0) {
          this.editSectionsList.push(this.growSections[i]);
        }
      } else {
        validFlag = false;
      }
    }
    console.log("editsection list", this.editSectionsList);

    console.log(validFlag);

    // console.log('sectionList', this.sectionList);
    if (!validFlag) {
      this.toastrService.error(
        "Please provide all details",
        "Create GrowSection"
      );
      this.isViewSection = false;
      this.isSelectedSection = false;
      this.isAddSection = true;
      // this.sectionList=[];
      // this.editSectionsList=[];
      // return;
    } else {
      console.log("this.sectionList", this.sectionList.length);
      console.log("this.sectionList", this.sectionList);
      if (this.sectionList.length > 0) {
        console.log("section list" + this.sectionList.length);
        console.log("values" + JSON.stringify(this.sectionList));
        this.growSectionService.createGrowSection(this.sectionList).subscribe(
          (response) => {
            this.growareaService
              .editGrowArea(this.selectedGrowArea, this.selectedGrowArea.id)
              .subscribe();
            // this.toastrService.success('Grow Sections created successfully', 'Create GrowSection');
            //  this.location.back();
            if (this.editSectionsList.length === 0) {
              this.toastrService.success(
                "Grow Sections created successfully",
                "Create GrowSection"
              );
            }
            // this.toastrService.success('Grow Sections updated successfully', 'Update GrowSection');
            this.isAddSection = false;
            this.isViewSection = true;
            this.selectedGrowSection = undefined;
            this.isSelectedSection = false;
            this.getGrowSectionByGrowAreaId(this.selectedGrowArea.id);
            this.profileName = "";
            if (this.addProfileForm) {
              this.addProfileForm.reset();
            }
            if (this.addConditionForm) {
              this.addConditionForm.reset();
            }
            this.onInitFormGroup();
            this.deviceForProperty["condition20"] = "Device";
            this.deviceForProperty["condition30"] = "Device";
            this.deviceForProperty["condition40"] = "Device";
          },
          (error) => {
            this.toastrService.error("Something went wrong");
          }
        );
      }
      if (this.editSectionsList.length > 0) {
        console.log("editsectionlist" + JSON.stringify(this.editSectionsList));
        this.growSectionService
          .editGrowSection(this.editSectionsList)
          .subscribe(
            (response) => {
              // this.growareaService.editGrowArea(this.selectedGrowArea, this.selectedGrowArea.id).subscribe();
              this.toastrService.success(
                "Grow Sections updated successfully",
                "Update GrowSection"
              );
              // this.location.back();
              this.isViewSection = true;
              this.selectedGrowSection = undefined;
              this.isSelectedSection = false;
              this.isAddSection = false;
              this.getGrowSectionByGrowAreaId(this.selectedGrowArea.id);
              this.profileName = "";
              if (this.addProfileForm) {
                this.addProfileForm.reset();
              }
              if (this.addConditionForm) {
                this.addConditionForm.reset();
              }
              this.onInitFormGroup();
              this.deviceForProperty["condition20"] = "Device";
              this.deviceForProperty["condition30"] = "Device";
              this.deviceForProperty["condition40"] = "Device";
            },
            (error) => {
              this.toastrService.error("Something went wrong");
            }
          );
      }
    }
  }

  checkGrowSectionNames() {
    const pattern = new RegExp("^[a-zA-Z][a-zA-Z_.]{0,1}[ a-z|A-Z|0-9|_.]*$");
    let invalidGrowSectionFlag = false;
    for (const growSection of this.growSections) {
      if (!pattern.test(growSection.grow_section_name)) {
        invalidGrowSectionFlag = true;
      }
    }
    console.log(invalidGrowSectionFlag);
    return invalidGrowSectionFlag;
  }
}
