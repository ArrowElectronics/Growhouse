import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'matchesCountry'
})
export class MathcesCountryPipe implements PipeTransform {
    transform(items: Array<any>, country: string, state: string): Array<any> {
        console.log(items);
        console.log(country);
        return items.filter(item => item.name === country);
    }
}
