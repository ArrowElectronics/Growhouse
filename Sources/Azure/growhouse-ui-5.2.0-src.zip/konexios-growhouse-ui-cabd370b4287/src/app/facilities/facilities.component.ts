import {
  AfterViewInit,
  Component,
  OnDestroy,
  OnInit,
  ViewChild,
} from "@angular/core";
import {
  FormArray,
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { DataTableDirective } from "angular-datatables";
import { BreadcrumbsService } from "ng6-breadcrumbs";
import { NgxSpinnerService } from "ngx-spinner";
import { ToastrService } from "ngx-toastr";
import { Subject } from "rxjs";
import { slideInAnimation } from "src/app/annimations";
import { ValidationPatterns } from "src/app/global";
import * as postalCode from "../../assets/js/postal-codes.js";
import { ContainerType } from "../models/container.model";
import { Facility } from "../models/facility.model";
import { Country, Locality, State } from "../models/global.model";
import { User } from "../models/user.model";
import { ContainerService } from "../services/container-service";
import { FacilityService } from "../services/facility-service";
import { GlobalService } from "../services/global-service";
import { UserService } from "../services/user-service";
declare var $: any;

@Component({
  selector: "app-facilities",
  templateUrl: "./facilities.component.html",
  styleUrls: ["./facilities.component.css"],
  animations: [slideInAnimation],
})
export class FacilitiesComponent implements OnInit, OnDestroy, AfterViewInit {
  dtOptions: any = {};
  dtTrigger: Subject<any> = new Subject();
  @ViewChild(DataTableDirective)
  private datatableElement: DataTableDirective;
  facilities: Facility[] = [];
  users: User[] = [];
  countryList: Country[] = [];
  stateList: State[] = [];
  delet = false;
  changecountry = false;
  deletFacility: Facility;
  localityList: Locality[];
  filteredStates: State[] = [];
  filteredLocalities: Locality[] = [];
  isEditFacility: Boolean = true;
  selectedFacility: Facility;
  selectedCountry: Country;
  selectedState: State;
  totalFacilityCount = 0;
  activeFacilityCount = 0;
  currentFacility: any;
  addContainerFlag;
  editFacility: Facility;
  conatinerTypes: ContainerType[] = [];
  @ViewChild("gmap")
  gmapElement: any;
  mapProp: any;
  map: google.maps.Map;
  marker;
  isFacilityLoad = false;
  addFacilityForm: FormGroup;
  facilityFlag = false;
  countryError = false;
  geocoder;
  showModal = false;
  loggedInUser: User;
  apiLoading = false;
  constructor(
    private facilityService: FacilityService,
    private containerService: ContainerService,
    private userService: UserService,
    private spinner: NgxSpinnerService,
    private toastrService: ToastrService,
    private router: Router,
    private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private breadcrumService: BreadcrumbsService,
    private globalService: GlobalService
  ) {}

  removeData() {
    this.addFacilityForm.reset();
    $("#myModal").modal("hide");
  }

  ngOnInit() {
    // i18nIsoCountries.registerLocale(require('i18n-iso-countries/langs/en.json'));

    this.breadcrumService.store([
      { label: "Facilities", url: "/facilities", params: [] },
    ]);
    const elem = document.getElementById("headerMenuCollapse");
    if (elem) {
      elem.classList.remove("show");
    }
    this.loggedInUser = JSON.parse(localStorage.getItem("loggedInUser"));
    // datatable options for facility table
    this.dtOptions = {
      pagingType: "full_numbers",
      pageLength: 10,
      destroy: true,
      order: [],
      info: false,
      lengthChange: false,
      select: true,
      language: {
        zeroRecords: "No Facilities to display",
        paginate: {
          next: ">", // or '→'
          previous: "<", // or '←',
        },
      },
    };
    // if (this.loggedInUser && this.loggedInUser.user_role.role_name.toLowerCase() === 'admin') {
    //   let intervalId = setInterval(
    //     () => {
    //       if (typeof google === 'object' && typeof google.maps === 'object') {
    //         clearInterval(intervalId);
    //         intervalId = null;
    //         this.mapProp = {
    //           center: new google.maps.LatLng(18.5793, 73.8143),
    //           zoom: 15,
    //           mapTypeId: google.maps.MapTypeId.ROADMAP
    //         };
    //         this.geocoder = new google.maps.Geocoder();

    //   if (this.marker) {
    //     this.marker.setMap(null);
    //   }

    // this.map = new google.maps.Map(
    //   this.gmapElement.nativeElement,
    //   this.mapProp
    // );
    // google.maps.event.addListener(this.map, 'click', (event) => {
    //   console.log('map clicked', this.map);
    //   alert('Latitude: ' + event.latLng.lat() + ' ' + ', longitude: ' + event.latLng.lng());

    //   if (this.marker) {
    //     this.marker.setMap(null);
    //   }

    //   this.addFacilityForm.patchValue({
    //     latitude: event.latLng.lat(),
    //     longitude: event.latLng.lng()
    //   });

    //   this.geocoder.geocode({ 'latLng': event.latLng }, function (results, status) {
    //     if (status === google.maps.GeocoderStatus.OK) {
    //       if (results[0]) {
    //         alert(results[0].formatted_address);
    //       } else {
    //         alert('No results found');
    //       }
    //     } else {
    //       alert('Geocoder failed due to: ' + status);
    //     }
    //   });
    //   this.marker = new google.maps.Marker({
    //     position: new google.maps.LatLng(event.latLng.lat(), event.latLng.lng()),
    //     map: this.map
    //   });
    //   console.log('aa', this.addFacilityForm.value);
    // });
    //       }
    //     },
    //     50);
    // }

    this.facilityService.selectedFacility.subscribe((facility: Facility) => {
      this.selectedFacility = facility;
    });
    // get list of facilities
    this.getFacilities();
    this.getCountryList();
    // this.getStatesList();
    // this.getLocalitiesList();
    this.getUsers();
    this.getContainerTypes();

    // initializing the add facility form group
    this.addFacilityForm = new FormGroup({
      facility_name: new FormControl(null, [
        Validators.required,
        Validators.maxLength(25),
        Validators.pattern(ValidationPatterns.username),
      ]),
      locality: new FormControl(null, [Validators.required]),
      zip: new FormControl(null, [Validators.required]),
      latitude: new FormControl(0),
      longitude: new FormControl(0),
      description: new FormControl(null, [Validators.maxLength(200)]),
      admin: new FormControl("", [Validators.required]),
    });
  }

  validateZip() {
    if (this.selectedCountry !== null && this.selectedCountry !== undefined) {
      // console.log(this.addFacilityForm);
      // console.log((!this.addFacilityForm.valid && (this.addFacilityForm.touched || !this.addFacilityForm.touched)));
      return postalCode.validate(
        this.addFacilityForm.value.zip,
        this.selectedCountry.sort_name
      );
    }
  }

  disableSave() {
    // let flag = false;
    // console.log('dsafswefgdegdagsdg', !this.addFacilityForm.valid && (this.addFacilityForm.touched || !this.addFacilityForm.touched));

    // if (!this.addFacilityForm.valid && (this.addFacilityForm.touched || !this.addFacilityForm.touched)) {
    //   flag = true;
    // }
    // console.log('dsafsagsdg', this.validateZip());
    // if (!this.validateZip()) {
    //   flag = true;
    // }
    // console.log('inactive', flag);

    // return flag;

    const flag = true;

    if (!this.addFacilityForm.valid) {
      console.log("in invalid");
      return flag;
    } else {
      if (!this.validateZip()) {
        console.log("in zip");
        return flag;
      } else {
        return false;
      }
    }
  }

  ngAfterViewInit(): void {
    // for map initialization
    console.log(typeof google);
  }

  refreshData(facilities) {
    console.log("refreshData" + JSON.stringify(facilities));
  }

  // selectRow(event: any, item: any) {
  //   console.log('refresh' + item.facility_name);
  //   this.currentFacility = item.facility_name;
  // }

  // on Map Click for location details
  // onMapClick(event) {
  //   this.marker = {
  //     lat: event.coords.lat,
  //     lng: event.coords.lng
  //   };
  //   console.log(event);
  // }

  onNewFacility() {
    // initializing the add facility form group
    this.isEditFacility = false;
    this.selectedCountry = null;
    this.selectedState = null;
    this.localityList = null;
    this.addFacilityForm.reset();
    // this.conatinerTypes=[];
    this.addFacilityForm = new FormGroup({
      facility_name: new FormControl(null, [
        Validators.required,
        Validators.maxLength(25),
        Validators.pattern(ValidationPatterns.username),
      ]),
      locality: new FormControl(null, [Validators.required]),
      zip: new FormControl(null, [Validators.required]),
      latitude: new FormControl(0),
      longitude: new FormControl(0),
      description: new FormControl(null, [Validators.maxLength(200)]),
      admin: new FormControl("", [Validators.required]),
    });
  }

  // uses to get all the facilities list
  getFacilities() {
    this.isFacilityLoad = true;

    this.facilities = [];

    this.facilityService.getFacility().subscribe(
      (response: Facility[]) => {
        setTimeout(() => {
          this.facilities = response;
          if (this.facilities) {
            this.activeFacilityCount = this.facilities.length;
          } else {
            this.activeFacilityCount = 0;
          }
          this.dtTrigger.next();
        }, 500);
        this.isFacilityLoad = false;
      },
      (error) => {
        this.isFacilityLoad = false;
        console.log("error" + JSON.stringify(error));
      }
    );
  }

  onChangeOfAddContainer() {
    if (this.addContainerFlag) {
      console.log(this.addFacilityForm);
      //  const control = <FormArray>this.addFacilityForm.controls.containers;
      //  control.push( new FormGroup({
      //   container_name: this.formBuilder.control(''),
      //   container_type: this.formBuilder.control('')
      // }));
      this.addFacilityForm.addControl(
        "containers",
        new FormArray([
          new FormGroup({
            // container_name: this.formBuilder.control(''),
            container_name: new FormControl("", [
              Validators.required,
              Validators.maxLength(25),
              Validators.pattern(ValidationPatterns.username),
            ]),
            container_type: new FormControl("", [Validators.required]),
            // container_type: this.formBuilder.control('')
          }),
        ])
      );
      console.log(this.addFacilityForm);
    } else {
      this.addContainerFlag = false;
      this.addFacilityForm.removeControl("containers");
    }
  }

  getUsers() {
    this.users = [];
    this.userService.getAdminUsers().subscribe((response: User[]) => {
      this.users = response;
    });
  }

  getCountryList() {
    this.countryList = [];
    this.facilityService.getCountrys().subscribe((response: Country[]) => {
      this.countryList = response;
    });
  }

  // getStatesList() {
  //   this.stateList = [];
  //   this.facilityService.getStates().subscribe(
  //     (response: State[]) => {
  //       this.stateList = response;
  //     }
  //   );
  // }

  // getLocalitiesList() {

  //   this.localityList = [];
  //   this.facilityService.getLocalities().subscribe(
  //     (response: Locality[]) => {
  //       this.localityList = response;
  //     }
  //   );
  // }

  getContainerTypes() {
    this.conatinerTypes = [];
    this.containerService
      .getContainerTypes()
      .subscribe((response: ContainerType[]) => {
        this.conatinerTypes = response;
      });
  }

  // on click of any facilities row
  onFacilityRowClick(facility: Facility) {
    this.selectedFacility = facility;
    this.router.navigate([this.selectedFacility.id], {
      relativeTo: this.route,
    });
  }

  // in add edit facility on change of country
  onCountryChange(country) {
    console.log(country);
    this.stateList = [];
    this.addFacilityForm.controls["locality"].reset();
    this.addFacilityForm.controls["zip"].reset();
    this.filteredLocalities = [];
    this.filteredStates = [];
    this.selectedState = null;
    this.facilityService
      .getStates(country.id)
      .subscribe((response: State[]) => {
        console.log(response);
        this.filteredStates = response;
      });
  }

  // calls on change of state in add edit modal
  onStateChange(state) {
    console.log(state);
    this.addFacilityForm.controls["locality"].reset();
    // if (state.id) {
    //   this.filteredLocalities  = this.localityList
    //   .filter(locality => locality.state.id === state.id);
    //   console.log(this.filteredLocalities);
    this.facilityService
      .getLocalities(state.id)
      .subscribe((response: Locality[]) => {
        console.log(response);
        this.filteredLocalities = response;
      });
  }

  // on create facility in modal
  onAddFacilitySubmit() {
    console.log(this.addFacilityForm.value);
    // if(this.addFacilityForm.value.locality === 'NA'){
    //   const obj = {};
    //   obj['state'] = this.selectedState;
    //   obj['id'] = 0;
    //   obj['name'] = 'NA';
    //   this.addFacilityForm.controls['locality'].setValue(obj);
    // }
    this.apiLoading = true;
    this.facilityService.createFacility(this.addFacilityForm.value).subscribe(
      (successResponse: Response) => {
        console.log(successResponse);
        this.toastrService.success(
          "Facility created successfully.",
          "Create Facility"
        );
        this.addContainerFlag = false;
        this.addFacilityForm.removeControl("containers");
        this.datatableElement.dtInstance.then((dtInstance: DataTables.Api) => {
          // Destroy the table first
          dtInstance.destroy();
        });
        this.filteredLocalities = [];
        this.filteredStates = [];
        this.addFacilityForm.reset();
        this.apiLoading = false;
        $("#myModal").modal("hide");
        this.getFacilities();
      },
      (error) => {
        this.addFacilityForm.reset();
        this.addContainerFlag = false;
        this.apiLoading = false;
        this.addFacilityForm.removeControl("containers");
      }
    );
  }

  // on click of edit facility in table
  onEditFacility(facility: Facility) {
    this.isEditFacility = true;
    // this.onCountryChange(facility.locality.state.country);
    // this.onStateChange(facility.locality.state);
    this.editFacility = facility;
    this.selectedCountry = facility.locality.state.country;
    this.onCountryChange(this.selectedCountry);
    this.selectedState = facility.locality.state;
    this.onStateChange(this.selectedState);
    console.log(this.selectedCountry);
    console.log(this.selectedState);
    this.addFacilityForm.patchValue({
      facility_name: facility.facility_name,
      locality: facility.locality,
      zip: facility.zip,
      description: facility.description,
      longitude: facility.longitude !== null ? facility.longitude : null,
      latitude: facility.latitude !== null ? facility.latitude : null,
      admin: facility.admin,
    });
    this.addFacilityForm.controls["admin"].setValue(facility.admin, {
      onlySelf: true,
    });
  }

  compareFn(obj1: any, obj2: any): boolean {
    if (obj1 === undefined || obj2 === undefined) {
      return false;
    } else {
      return obj1 && obj2 ? obj1.id === obj2.id : obj1 === obj2;
    }
  }

  // on edit facility in modal
  onEditFacilitySubmit() {
    this.apiLoading = true;
    console.log(JSON.stringify(this.addFacilityForm.value));
    this.addFacilityForm.value.id = this.editFacility.id;
    this.facilityService
      .editFacility(this.editFacility.id, this.addFacilityForm.value)
      .subscribe(
        (successResponse: Response) => {
          this.toastrService.success(
            "Facility updated successfully.",
            "Update Facility"
          );

          this.datatableElement.dtInstance.then(
            (dtInstance: DataTables.Api) => {
              // Destroy the table first
              dtInstance.destroy();
            }
          );
          this.facilityService.ediFacility.emit(this.addFacilityForm.value.id);

          this.isEditFacility = false;
          this.getFacilities();
          // this.getFacilityById(this.editFacility.id);
          this.filteredLocalities = [];
          // this.countryList = [];
          // this.getCountryList();
          // this.countryList = [];
          this.filteredStates = [];
          // this.selectedCountry = null;
          this.apiLoading = false;
        },
        (errorResponse) => {
          this.isEditFacility = false;
          this.apiLoading = false;
        }
      );
  }

  getFacilityById(id) {
    //
    this.facilityService.getFacilityById(id).subscribe(
      (response: Facility) => {
        this.selectedFacility = response;
        console.log(this.selectedFacility);
        this.facilityService.selectedFacility.emit(this.selectedFacility);
        this.breadcrumService.store([
          { label: "Facilities", url: "/facilities", params: [] },
          {
            label: this.selectedFacility.facility_name + "",
            url: "/facilities/" + this.selectedFacility.id,
            params: [],
          },
        ]);
        this.addReloadEventToBreadcrumb();
      },
      (error) => {
        console.log("Error" + JSON.stringify(error));
      }
    );
  }
  onDeletChanges(facilityId: Facility) {
    this.delet = true;
    console.log("OnDeletChanges called");
    this.deletFacility = facilityId;
  }

  addReloadEventToBreadcrumb() {
    setTimeout(() => {
      const elems = document.querySelectorAll(".breadcrumb-item a");
      console.log(elems);
      console.log("length     ", elems.length);
      for (let i = 0; i < elems.length; i++) {
        elems[i].addEventListener("click", this.globalService.handleClick);
      }
    }, 100);
  }

  // on delete facility in table
  onDeleteFacility() {
    this.apiLoading = true;

    this.facilityService.deleteFacility(this.deletFacility.id).subscribe(
      (response) => {
        console.log(response);
        this.datatableElement.dtInstance.then((dtInstance: DataTables.Api) => {
          // Destroy the table first
          dtInstance.destroy();
        });
        this.toastrService.success(
          "Facility deleted successfully",
          "Delete Facility"
        );
        this.getFacilities();
        this.router.navigate(["/facilities"]);
        this.apiLoading = false;
      },
      (error) => {
        console.log("Error" + JSON.stringify(error));
        this.apiLoading = false;
      }
    );
  }

  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }
}

interface Marker {
  lat: number;
  lng: number;
}
