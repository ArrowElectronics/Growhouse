import { trigger, transition, style, animateChild, animate, query, group } from '@angular/animations';


export const slideInAnimation =
  trigger('routeAnimations', [
    // transition('* => *', [
    //   style({ position: 'relative' }),
    //   query( ':enter, :leave', [
    //     style({
    //       position: 'absolute',
    //       top: 0,
    //       left: 0,
    //       width: '100%'
    //     })
    //   ]),
    //   query(':enter', [
    //     style({ left: '-100%'})
    //   ]),
    //   query(':leave', animateChild()),
    //   group([
    //     query(':leave', [
    //       animate('1500ms ease-out', style({ left: '100%'}))
    //     ]),
    //     query(':enter', [
    //       animate('1500ms ease-out', style({ left: '0%'}))
    //     ])
    //   ]),
    //   query(':enter', animateChild()),
    // ])
    transition('* => *', [
      style({ height: '!' }),
      query( ':enter, :leave',
        style({
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
        })
      ),
      query(':enter',
        style({ transform: 'translateX(100%)'})
      ),
      group([
        query(':leave', [
          animate('60s cubic-bezier(.35, 0, .25, 1)', style({ transform: 'translateX(-100%)'}))
        ]),
        query(':enter', [
          animate('60s cubic-bezier(.35, 0, .25, 1)', style({ transform: 'translateX(0%)'}))
        ])
      ])
    ]),
  ]);
