import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { DataTablesModule } from "angular-datatables";
import { ToastrModule } from "ngx-toastr";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { NgxSpinnerModule } from "ngx-spinner";
import { BreadcrumbsModule } from "ng6-breadcrumbs";
import { MatGridListModule } from "@angular/material/grid-list";
import { AppComponent } from "./app.component";
import { LoginComponent } from "./login/login.component";
import { AppRoutingModule } from "./app-routing.module";
import { DashboardComponent } from "./dashboard/dashboard.component";
import { HeaderComponent } from "./header/header.component";
import { FooterComponent } from "./footer/footer.component";
import { FacilitiesComponent } from "./facilities/facilities.component";
import { ContainersComponent } from "./containers/containers.component";
import { UsersComponent } from "./users/users.component";
import { GrowAreasComponent } from "./grow-areas/grow-areas.component";
import { GrowSectionsComponent } from "./grow-sections/grow-sections.component";
import { httpInterceptorProviders } from "src/app/http-interceptors";
import { HttpClientModule } from "@angular/common/http";
import { MathcesCountryPipe } from "./Pipes/matchesCountry.pipe";
import { FacilityComponent } from "./facility/facility.component";
import { ContainerComponent } from "./container/container.component";
import { GrowAreaComponent } from "./grow-area/grow-area.component";
import { GrowSectionComponent } from "./grow-section/grow-section.component";
import { environment } from "src/environments/environment";
import { DevicesComponent } from "./devices/devices.component";
import { DeviceComponent } from "./device/device.component";
import { AccountsComponent } from "./accounts/accounts.component";
import { enableProdMode } from "@angular/core";
import { ProfilesComponent } from "./profiles/profiles.component";
import { ProfileComponent } from "./profile/profile.component";
import { MatSliderModule } from "@angular/material/slider";
import { DatePipe } from "@angular/common";
import { NgxDaterangepickerMd } from "ngx-daterangepicker-material";
import { PagerService } from "./services/pager.service";
import { NgxPaginationModule } from "ngx-pagination";
import { PopoverModule } from "ngx-popover";
import { AlertsComponent } from "./alerts/alerts.component";
import { HAMMER_GESTURE_CONFIG } from "@angular/platform-browser";
import { GestureConfig, MatPaginator } from "@angular/material";
import { DeviceTypesComponent } from "./device-types/device-types.component";
import { DeviceTypeComponent } from "./device-type/device-type.component";
import { GroupsComponent } from "./groups/groups.component";
import { GroupComponent } from "./group/group.component";
import { LedProfilesComponent } from "./led-profiles/led-profiles.component";
import { LedProfileComponent } from "./led-profile/led-profile.component";
import { IntlModule } from "@progress/kendo-angular-intl";
import { DateInputsModule } from "@progress/kendo-angular-dateinputs";
import { EventsComponent } from "./events/events.component";
import { NgMultiSelectDropDownModule } from "ng-multiselect-dropdown";
import {
  MatTableModule,
  MatFormFieldModule,
  MatInputModule,
  MatSortModule,
  MatPaginatorModule,
} from "@angular/material";

// export function getAuthServiceConfigs() {
//   const signin_config = new AuthServiceConfig([
//     {
//       id: GoogleLoginProvider.PROVIDER_ID,
//       provider: new GoogleLoginProvider(environment.googleLoginProvider),
//     },
//   ]);
//   return signin_config;
// }

enableProdMode();
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DashboardComponent,
    HeaderComponent,
    FooterComponent,
    FacilitiesComponent,
    ContainersComponent,
    UsersComponent,
    GrowAreasComponent,
    GrowSectionsComponent,
    MathcesCountryPipe,
    FacilityComponent,
    ContainerComponent,
    GrowAreaComponent,
    GrowSectionComponent,
    DevicesComponent,
    DeviceComponent,
    AccountsComponent,
    ProfilesComponent,
    ProfileComponent,
    // ResetPasswordComponent,
    AlertsComponent,
    DeviceTypesComponent,
    DeviceTypeComponent,
    GroupsComponent,
    GroupComponent,
    LedProfilesComponent,
    LedProfileComponent,
    EventsComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    BreadcrumbsModule,
    HttpClientModule,
    AppRoutingModule,
    DataTablesModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot(),
    NgxSpinnerModule,
    MatGridListModule,
    MatSliderModule,
    NgxDaterangepickerMd,
    NgxPaginationModule,
    PopoverModule,
    IntlModule,
    DateInputsModule,
    NgMultiSelectDropDownModule.forRoot(),
    MatTableModule,
    MatFormFieldModule,
    MatInputModule,
    MatSortModule,
    MatPaginatorModule,
  ],
  providers: [
    httpInterceptorProviders,
    // {
    //   provide: AuthServiceConfig,
    //   // useFactory: getAuthServiceConfigs,
    // },
    DatePipe,
    PagerService,
    { provide: HAMMER_GESTURE_CONFIG, useClass: GestureConfig },
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
