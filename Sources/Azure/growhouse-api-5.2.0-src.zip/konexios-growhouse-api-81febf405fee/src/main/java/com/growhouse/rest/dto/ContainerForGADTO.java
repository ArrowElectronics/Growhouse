package com.growhouse.rest.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ContainerForGADTO {

	private Integer id;
	@JsonProperty("container_name")
	private String containerName;

	private FacilityForGADTO facility;
	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the containerName
	 */
	public String getContainerName() {
		return containerName;
	}

	/**
	 * @param containerName
	 *            the containerName to set
	 */
	public void setContainerName(String containerName) {
		this.containerName = containerName;
	}

	public FacilityForGADTO getFacility() {
		return facility;
	}

	public void setFacility(FacilityForGADTO facility) {
		this.facility = facility;
	}

}
