/**
 * 
 */
package com.growhouse.rest.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.growhouse.rest.entity.Container;

/**
 * @author dharita.chokshi
 *
 */
@Repository
public interface ContainerRepository extends JpaRepository<Container, Integer> {
	@Query
	public List<Container> findByIsActiveTrue();

	public List<Container> findByFacilityIdAndIsActiveTrue(int facilityId);
	
	public List<Container> findByFacilityIdAndIsActiveTrueOrderByCreatedTimestampDesc(int facilityId);

	public int countByFacilityIdAndIsActiveTrue(int facilityId); 
	
	public int countByIsActiveTrueAndFacilityIsActiveTrueAndAccountIsActiveTrue();
	
	public List<Container> findByAccountIdAndFacilityIsActiveTrueAndIsActiveTrue(int accountId);
	
	public List<Container> findByAccountIdAndFacilityIsActiveTrueAndIsActiveTrueOrderByCreatedTimestampDesc(int accountId);

	public int countByAccountIdAndIsActiveTrueAndFacilityIsActiveTrue(int accountId);
	
	public Optional<Container> findByIdAndIsActiveTrue(int id);
	
	public Container findByContainerNameAndIsActiveTrueAndFacilityIsActiveTrueAndAccountId(String containerName,int accountId);
	
}
