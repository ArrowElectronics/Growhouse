/**
 * 
 */
package com.growhouse.rest.services;

import java.util.List;

import com.growhouse.rest.entity.GrowSectionDevice;

/**
 * @author dharita.chokshi
 *
 */
public interface IGrowSectionDeviceService {

	public List<GrowSectionDevice> getActiveByGrowSectionId(int growSectionId);

	public List<GrowSectionDevice> getAllGrowSectionDevices();
	
	public List<GrowSectionDevice> getActiveByDeviceId(int deviceId);
	
	public GrowSectionDevice createGrowSectionDevice(GrowSectionDevice growSectionDevice);
	
	public List<GrowSectionDevice> createGrowSectionDevicesInBatch(List<GrowSectionDevice> growSectionDevices);
	
	public GrowSectionDevice updateGrowSectionDevice(GrowSectionDevice growSectionDevice);

	public GrowSectionDevice deleteGrowSectionDevice(int id);
	
	public void deleteGrowSectionDevicesInBatch(List<GrowSectionDevice> growSectionDevices);
	
	public int countGrowSectionDevicesByGrowSectionId(int growSectionId);

}
