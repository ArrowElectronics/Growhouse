package com.growhouse.rest.dto;

import com.fasterxml.jackson.annotation.JsonProperty;


public class LedNodeProfileEventNowDTO {

	private Integer id;
	
	@JsonProperty("profile_details")
	private LedNodeGroupProfileDTO profileDeatils;
	
	@JsonProperty("CH1")
	private Integer ch1;
	@JsonProperty("CH2")
	private Integer ch2;
	@JsonProperty("CH3")
	private Integer ch3;
	@JsonProperty("CH4")
	private Integer ch4;
	@JsonProperty("CH5")
	private Integer ch5;
	@JsonProperty("CH6")
	private Integer ch6;
	
	private Integer preset;
	
	@JsonProperty("facility_id")
	private Integer facilityId;
	
	@JsonProperty("facility_name")
	private String facilityName;
	
	@JsonProperty("container_id")
	private Integer containerId;
	
	@JsonProperty("container_name")
	private String containerName;
	
	@JsonProperty("growarea_id")
	private Integer growareaId;
	
	@JsonProperty("growarea_name")
	private String growareaName;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public LedNodeGroupProfileDTO getProfileDeatils() {
		return profileDeatils;
	}

	public void setProfileDeatils(LedNodeGroupProfileDTO profileDeatils) {
		this.profileDeatils = profileDeatils;
	}

	public Integer getCh1() {
		return ch1;
	}

	public void setCh1(Integer ch1) {
		this.ch1 = ch1;
	}

	public Integer getCh2() {
		return ch2;
	}

	public void setCh2(Integer ch2) {
		this.ch2 = ch2;
	}

	public Integer getCh3() {
		return ch3;
	}

	public void setCh3(Integer ch3) {
		this.ch3 = ch3;
	}

	public Integer getCh4() {
		return ch4;
	}

	public void setCh4(Integer ch4) {
		this.ch4 = ch4;
	}

	public Integer getCh5() {
		return ch5;
	}

	public void setCh5(Integer ch5) {
		this.ch5 = ch5;
	}

	public Integer getCh6() {
		return ch6;
	}

	public void setCh6(Integer ch6) {
		this.ch6 = ch6;
	}

	public Integer getPreset() {
		return preset;
	}

	public void setPreset(Integer preset) {
		this.preset = preset;
	}

	public Integer getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(Integer facilityId) {
		this.facilityId = facilityId;
	}

	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public Integer getContainerId() {
		return containerId;
	}

	public void setContainerId(Integer containerId) {
		this.containerId = containerId;
	}

	public String getContainerName() {
		return containerName;
	}

	public void setContainerName(String containerName) {
		this.containerName = containerName;
	}

	public Integer getGrowareaId() {
		return growareaId;
	}

	public void setGrowareaId(Integer growareaId) {
		this.growareaId = growareaId;
	}

	public String getGrowareaName() {
		return growareaName;
	}

	public void setGrowareaName(String growareaName) {
		this.growareaName = growareaName;
	}

	@Override
	public String toString() {
		return "LedNodeProfileEventNowDTO [id=" + id + ", profileDeatils=" + profileDeatils + ", ch1=" + ch1 + ", ch2="
				+ ch2 + ", ch3=" + ch3 + ", ch4=" + ch4 + ", ch5=" + ch5 + ", ch6=" + ch6 + ", preset=" + preset
				+ ", facilityId=" + facilityId + ", facilityName=" + facilityName + ", containerId=" + containerId
				+ ", containerName=" + containerName + ", growareaId=" + growareaId + ", growareaName=" + growareaName
				+ "]";
	}

	
	
}
