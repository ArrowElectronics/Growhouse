package com.growhouse.rest.dto;

public class ProfileAlertTimestampDTO {

	private String alertMessage;
	private String properties;
	private Long timestamp;
	
	public ProfileAlertTimestampDTO(){
		
	}
	
	public ProfileAlertTimestampDTO(String alertMessage, String properties, Long timestamp){
		this.alertMessage = alertMessage;
		this.properties = properties;
		this.timestamp = timestamp;
	}

	public String getAlertMessage() {
		return alertMessage;
	}

	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	public String getProperties() {
		return properties;
	}

	public void setProperties(String properties) {
		this.properties = properties;
	}

	public Long getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Long timestamp) {
		this.timestamp = timestamp;
	}

}
