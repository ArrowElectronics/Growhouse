/**
 * 
 */
package com.growhouse.rest.services.impl;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.growhouse.rest.entity.GrowAreaType;
import com.growhouse.rest.repository.GrowAreaTypeRepository;
import com.growhouse.rest.services.IGrowAreaTypeService;

/**
 * @author dharita.chokshi
 *
 */
@Service
public class GrowAreaTypeService implements IGrowAreaTypeService {

	@Autowired
	private GrowAreaTypeRepository growAreaTypeRepository;

	
	public List<GrowAreaType> getAllGrowAreaTypes() {
		return growAreaTypeRepository.findByIsActiveTrue();
	}

	
	public GrowAreaType getGrowAreaTypeById(int id) {
		 Optional<GrowAreaType> optional = growAreaTypeRepository.findByIdAndIsActiveTrue(id);
	        return optional.isPresent() ? optional.get() : null;
	}

}
