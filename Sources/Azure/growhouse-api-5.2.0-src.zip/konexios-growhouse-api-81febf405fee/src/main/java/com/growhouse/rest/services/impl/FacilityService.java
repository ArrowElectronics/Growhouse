/**
 * 
 */
package com.growhouse.rest.services.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;

import com.growhouse.rest.entity.Facility;
import com.growhouse.rest.repository.FacilityRepository;
import com.growhouse.rest.services.IFacilityService;
import com.growhouse.rest.utils.Constants;

/**
 * @author dharita.chokshi
 *
 */
@Service
public class FacilityService implements IFacilityService {

	@Autowired
	private FacilityRepository facilityRepository;

	
	public List<Facility> getActiveFacilities() {
		return facilityRepository.findByIsActiveTrue();
	}

	
	public List<Facility> getActiveFacilitiesByAccountId(int accountId) {
		return facilityRepository.findByAccountIdAndIsActiveTrueOrderByCreatedTimestampDesc(accountId);
	}
	
	public int getActiveFacilityCount()
    {
        return facilityRepository.countByIsActiveTrueAndAccountIsActiveTrue();
    }
	
	public Facility getFacilityByFacilityName(String facilityName,int accountId)
	{
		return facilityRepository.findByFacilityNameAndIsActiveTrueAndAccountId(facilityName,accountId);
	}
	
	
	public List<Facility> getAllFacilities() {
		return facilityRepository.findAll();
	}

	
	public Facility getFacilityById(int id) {
		Optional<Facility> optional = facilityRepository.findByIdAndIsActiveTrue(id);
		return optional.isPresent() ? optional.get() : null;
	}

	
	public Facility createFacility(Facility facility) {
		return facilityRepository.save(facility);
	}

	
	public Facility updateFacility(Facility facility) {
		return facilityRepository.save(facility);
	}

	
	public Facility deleteFacility(int id) {

		Facility deletedFacility=null;
		Optional<Facility> optional = facilityRepository.findById(id);
		if (optional.isPresent() && optional.get().isActive()) {
			Facility facility = optional.get();
			facility.setActive(false);
			deletedFacility = facilityRepository.save(facility);
		} else {
			throw new HttpClientErrorException(HttpStatus.NOT_FOUND, Constants.FACILITY_NOT_FOUND_MESSAGE);
		}
		return deletedFacility;
	}
	
	@Override
	public FacilityRepository getFacilitiRepository() {
		return facilityRepository;
	}

}
