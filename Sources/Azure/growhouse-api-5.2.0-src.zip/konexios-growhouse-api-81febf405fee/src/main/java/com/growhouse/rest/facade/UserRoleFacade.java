/**
 * 
 */
package com.growhouse.rest.facade;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.growhouse.rest.dto.UserRoleDTO;
import com.growhouse.rest.entity.UserRole;
import com.growhouse.rest.services.IUserRoleService;

/**
 * @author dharita.chokshi
 *
 */
@Component
public class UserRoleFacade {

	public static final Logger LOGGER = LoggerFactory.getLogger(UserRoleFacade.class);

	@Autowired
	private IUserRoleService userRoleService;

	@Autowired
	private ModelMapper modelMapper;

	public List<UserRoleDTO> getUserRoles() {
		List<UserRoleDTO> userRoleDTOs = new ArrayList<>();
		List<UserRole> userRoles = userRoleService.getAllUserRoles();
		if (userRoles != null && !userRoles.isEmpty())
			userRoleDTOs = userRoles.stream().map(this::convertEntityToDTO)
					.collect(Collectors.toList());

		return userRoleDTOs;
	}

	public UserRoleDTO getUserRoleById(int userRoleId) {
		UserRoleDTO userRoleDTO = null;
		UserRole userRole = userRoleService.getUserRoleById(userRoleId);
		if (userRole != null) {
			userRoleDTO = convertEntityToDTO(userRole);
		}
		return userRoleDTO;
	}

	private UserRoleDTO convertEntityToDTO(UserRole userRole) {
		return modelMapper.map(userRole, UserRoleDTO.class);
	}

}
