package com.growhouse.rest.filter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.concurrent.TimeUnit;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.growhouse.rest.dto.UserSession;
import com.growhouse.rest.entity.User;
import com.growhouse.rest.services.impl.UserService;
import com.growhouse.rest.utils.Constants;

public class CustomAuthorizationFilter extends BasicAuthenticationFilter {
	public static final Logger LOGGER = LoggerFactory.getLogger(CustomAuthorizationFilter.class);

	private UserService userService;
	private StringRedisTemplate redis;
	private ObjectMapper mapper;

	public CustomAuthorizationFilter(AuthenticationManager authManager) {
		super(authManager);
	}

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
			throws IOException, ServletException {

		String token = request.getHeader(Constants.AUTHORIZATION);
		if (!StringUtils.isEmpty(token)) {
			LOGGER.info("token: " + token);
			try {
				String sessionStr = redis.opsForValue().get(token);
				if (!StringUtils.isEmpty(sessionStr)) {
					UserSession session = mapper.readValue(sessionStr, UserSession.class);

					// extend redis expiration
					redis.expire(session.getSessionId(), session.getTimeoutHours(), TimeUnit.HOURS);
					redis.expire(session.getUserDTO().getUsername(), session.getTimeoutHours(), TimeUnit.HOURS);

					SecurityContextHolder.getContext()
							.setAuthentication(getAuthentication(session.getUserDTO().getId()));
					chain.doFilter(request, response);
					return;
				} else {
					LOGGER.info("token not found in redis, session possibly timed out");
				}
			} catch (Exception exception) {
				LOGGER.info("Exception: " + exception.getClass().getName() + " / " + exception.getMessage());
			}
		} else {
			LOGGER.info("Authorization header not found");
		}
		SecurityContextHolder.clearContext();
		response.sendError(HttpStatus.UNAUTHORIZED.value(), "not authorized");
	}

	private UsernamePasswordAuthenticationToken getAuthentication(int userId) {
		User user = userService.getUserById(userId);
		if (user == null) {
			throw new UsernameNotFoundException("User " + userId + " was not found in the database");
		}
		LOGGER.info("Successfully fetched user from database: {}", user);
		Collection<GrantedAuthority> grantedAuthorities = new ArrayList<>();
		GrantedAuthority grantedAuthority = new SimpleGrantedAuthority(user.getUserRole().getRoleName());
		grantedAuthorities.add(grantedAuthority);
		return new UsernamePasswordAuthenticationToken(user, null, grantedAuthorities);
	}

	/**
	 * @return the userService
	 */
	public UserService getUserService() {
		return userService;
	}

	/**
	 * @param userService the userService to set
	 */
	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	/**
	 * @param redis the redis to set
	 */
	public void setRedis(StringRedisTemplate redis) {
		this.redis = redis;
	}

	/**
	 * @return the redis
	 */
	public StringRedisTemplate getRedis() {
		return redis;
	}

	/**
	 * @return the mapper
	 */
	public ObjectMapper getMapper() {
		return mapper;
	}

	/**
	 * @param mapper the mapper to set
	 */
	public void setMapper(ObjectMapper mapper) {
		this.mapper = mapper;
	}
}
