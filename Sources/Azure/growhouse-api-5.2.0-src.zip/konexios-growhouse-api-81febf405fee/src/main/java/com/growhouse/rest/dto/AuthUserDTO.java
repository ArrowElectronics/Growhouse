/**
 * 
 */
package com.growhouse.rest.dto;

/**
 * @author dharita.chokshi
 *
 */
public class AuthUserDTO {

	private String email;

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email
	 *            the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "AuthUserDTO [email=" + email + "]";
	}

}
