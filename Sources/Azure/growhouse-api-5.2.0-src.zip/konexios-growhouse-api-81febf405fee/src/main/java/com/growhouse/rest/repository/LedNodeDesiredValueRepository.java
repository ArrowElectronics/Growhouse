package com.growhouse.rest.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.growhouse.rest.entity.LedNodeHistory;

@Repository
public interface LedNodeDesiredValueRepository extends JpaRepository<LedNodeHistory, Integer> {

	@Transactional
    @Modifying
    @Query(value="Update lednode_desired_value_history p SET p.is_active=0 where p.device_id=?1 and p.is_active=1",nativeQuery = true)
    public void deleteLedNodeDesiredValueByDeviceId(int deviceId);
	
	@Transactional
	@Modifying
	public void  deleteByDeviceGrowAreaId(int gatewayId);
}
