/**
 * 
 */
package com.growhouse.rest.services;

import java.util.List;

import com.growhouse.rest.entity.Container;
import com.growhouse.rest.repository.ContainerRepository;

/**
 * @author dharita.chokshi
 *
 */
public interface IContainerService {

	public List<Container> getActiveContainers();

	public List<Container> getAllContainers();
	
	public List<Container> getContainersByFacilityId(int facilityId);

	public Container getContainerById(int id);
	
	public Container createContainer(Container container);
	
	public List<Container> createContainersInBatch(List<Container> containers);

	public Container updateContainer(Container container);

	public Container deleteContainer(int id);
	
	public int getCountActiveContainer();
	
	public int getCountOfContainersByFacilityId(int facilityId);
	
	public List<Container> getActiveContainersByAccount(int accountId);
	
	public ContainerRepository getContainerRepository();
	
	public Container getContainerByContainerName(String containerName,int facilityId);

}
