package com.growhouse.rest.dto;

public class UserSession {
	private UserDTO userDTO;
	private String sessionId;
	private long timeoutHours;

	public UserDTO getUserDTO() {
		return userDTO;
	}

	public void setUserDTO(UserDTO userDTO) {
		this.userDTO = userDTO;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public long getTimeoutHours() {
		return timeoutHours;
	}

	public void setTimeoutHours(long timeoutHours) {
		this.timeoutHours = timeoutHours;
	}
}
