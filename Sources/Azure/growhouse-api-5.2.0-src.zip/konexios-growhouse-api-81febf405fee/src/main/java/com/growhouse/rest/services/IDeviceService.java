/**
 * 
 */
package com.growhouse.rest.services;

import java.util.List;
import java.util.Map;

import com.growhouse.rest.dto.GroupChannelConfigurationDTO;
import com.growhouse.rest.entity.Device;
import com.growhouse.rest.entity.DevicePropertyMapping;
import com.growhouse.rest.entity.GrowSectionDevice;
import com.growhouse.rest.entity.LedNodeChannelConfiguration;
import com.growhouse.rest.entity.LedNodeHistory;
import com.growhouse.rest.entity.LedNodeProfile;
import com.growhouse.rest.entity.kronos.TelemetryItem;
import com.growhouse.rest.repository.DeviceRepository;

/**
 * @author dharita.chokshi
 *
 */
public interface IDeviceService {

	public List<Device> getActiveDevices();

	public List<Device> getAllDevices();

	public List<Device> getDevicesByGrowSectionId(int growSectionId);

	public List<Device> getDevicesByGrowAreaId(int growAreaId);

	public List<Device> getDevicesByContainerId(int containerId);

	public List<Device> getDevicesByFacilityId(int facilityId);

	public List<Device> getDevicesByDeviceTypeId(int deviceType);

	public List<Device> getDevicesByGrowAreaIdAndDeviceTypeId(int growAreaId, int deviceTypeId);

	public Device getDeviceById(int id);

	public DeviceRepository getDeviceRepository();

	public Device createDevice(Device device);

	public Device updateDevice(Device device);

	public Device deleteDevice(int id);

	public List<DevicePropertyMapping> getDevicePropertiesByDeviceId(int deviceId);

	public List<DevicePropertyMapping> getDevicePropertiesByGrowSectionId(int growSectionId,
			List<GrowSectionDevice> growSectionDevices);

	public List<TelemetryItem> getDeviceLastTelemetry(String deviceHId);

	public List<DevicePropertyMapping> getDevicePropertiesByGrowAreaId(List<Device> devices);

	public int getDevicesCountByContainerId(int containerId);

	public LedNodeHistory setLedNodedesiredValue(LedNodeHistory ledNodeHistory, Map<String, Object> map,
			String deviceHId);

	public LedNodeChannelConfiguration getLedNodeChannelConfiguration(Integer deviceId);

	public LedNodeChannelConfiguration setLedNodeChannelConfiguration(
			LedNodeChannelConfiguration ledNodeChannelConfiguration);

	public LedNodeProfile setLedNodeProfile(LedNodeProfile requestedLedNodeProfile);

	public List<LedNodeProfile> getLedNodeProfile(int deviceId);

	public Device getDeviceByUID(String uId);

	public void updateDeviceStatus(boolean status, String uid);

	public List<LedNodeChannelConfiguration> getDevicesBasedonConfiguration(GroupChannelConfigurationDTO confi,
			int gatewayId);

	public void setStateToArrowConnect(String deviceHId, Map<String, Object> deviceStatePayload);

}
