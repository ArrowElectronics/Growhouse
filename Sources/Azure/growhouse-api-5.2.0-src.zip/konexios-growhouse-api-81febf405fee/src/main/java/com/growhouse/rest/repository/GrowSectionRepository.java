/**
 * 
 */
package com.growhouse.rest.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.growhouse.rest.entity.GrowSection;

/**
 * @author dharita.chokshi
 *
 */
@Repository
public interface GrowSectionRepository extends JpaRepository<GrowSection, Integer> {

	public List<GrowSection> findByIsActiveTrue();

	public List<GrowSection> findByGrowAreaIdAndIsActiveTrue(int growAreaId);
	
	public List<GrowSection> findByIsActiveTrueAndGrowAreaIdIn(List<Integer> growAreaIdList);
	
	public int countByIsActiveTrueAndGrowAreaIdIn(List<Integer> growAreaIdList);
	
	@Transactional
    @Modifying
    @Query(value="Update grow_sections p SET p.is_active=0 where p.grow_area_id=?1 and p.is_active=1",nativeQuery = true)
    public void deleteGrowSectionByGatewayId(int gatewayId);

}
