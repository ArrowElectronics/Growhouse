/**
 * 
 */
package com.growhouse.rest.services;

import java.util.List;

import com.growhouse.rest.entity.UserRole;

/**
 * @author dharita.chokshi
 *
 */
public interface IUserRoleService {

	public List<UserRole> getAllUserRoles();

	public UserRole getUserRoleById(int userRoleId);

}
