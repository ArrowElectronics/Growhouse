/**
 * 
 */
package com.growhouse.rest.utils;

/**
 * @author dharita.chokshi
 *
 */
public enum DeviceType {
	
	SoilNode, LedNode ,LightShield, HumidityNode ,SCMNode

}
