/**
 * 
 */
package com.growhouse.rest.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.growhouse.rest.entity.Locality;

/**
 * @author dharita.chokshi
 *
 */
@Repository
public interface LocalityRepository extends JpaRepository<Locality, Integer> {

	@Query
	public List<Locality> findByStateId(int stateId);
	
}
