package com.growhouse.rest.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class GrowAreaDTO {

	private Integer id;
	@JsonProperty("grow_area_name")
	private String growAreaName;
	@JsonProperty("grow_area_type")
	private GrowAreaTypeDTO growAreaType;
	@JsonProperty("mac_id")
	private String macId;
	@JsonProperty("grow_area_hid")
	private String growAreaHId;
	@JsonProperty("grow_area_uid")
	private String growAreaUId;
	private ContainerForGADTO container;
	private String description;
	private Integer layout=0;
	private List<UserDTO> users;
	@JsonProperty("latest_heartbeat_timestamp")
	private String flag;
	private FacilityForGADTO facility;
	private Long latestHeartbeat;
	
	public Long getLatestHeartbeat() {
		return latestHeartbeat;
	}
	public void setLatestHeartbeat(Long latestHeartbeat) {
		this.latestHeartbeat = latestHeartbeat;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getGrowAreaName() {
		return growAreaName;
	}
	public void setGrowAreaName(String growAreaName) {
		this.growAreaName = growAreaName;
	}
	public GrowAreaTypeDTO getGrowAreaType() {
		return growAreaType;
	}
	public void setGrowAreaType(GrowAreaTypeDTO growAreaType) {
		this.growAreaType = growAreaType;
	}
	public String getMacId() {
		return macId;
	}
	public void setMacId(String macId) {
		this.macId = macId;
	}
	public String getGrowAreaHId() {
		return growAreaHId;
	}
	public void setGrowAreaHId(String growAreaHId) {
		this.growAreaHId = growAreaHId;
	}
	public String getGrowAreaUId() {
		return growAreaUId;
	}
	public void setGrowAreaUId(String growAreaUId) {
		this.growAreaUId = growAreaUId;
	}
	public ContainerForGADTO getContainer() {
		return container;
	}
	public void setContainer(ContainerForGADTO container) {
		this.container = container;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Integer getLayout() {
		return layout;
	}
	public void setLayout(Integer layout) {
		this.layout = layout;
	}
	public List<UserDTO> getUsers() {
		return users;
	}
	public void setUsers(List<UserDTO> users) {
		this.users = users;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	public FacilityForGADTO getFacility() {
		return facility;
	}
	public void setFacility(FacilityForGADTO facility) {
		this.facility = facility;
	}
	@Override
	public String toString() {
		return "GrowAreaDTO [id=" + id + ", growAreaName=" + growAreaName + ", growAreaType=" + growAreaType
				+ ", macId=" + macId + ", growAreaHId=" + growAreaHId + ", growAreaUId=" + growAreaUId + ", container="
				+ container + ", description=" + description + ", layout=" + layout + ", users=" + users + ", flag="
				+ flag + ", facility=" + facility + ", latestHeartbeat=" + latestHeartbeat + "]";
	}
	

	

}
