package com.growhouse.rest.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.growhouse.rest.entity.LedNodeGroupProfile;

@Repository
public interface LedNodeGroupProfileRepository extends JpaRepository<LedNodeGroupProfile, Integer> {

	public List<LedNodeGroupProfile> findByGroupIdAndIsActiveTrueOrderByCreatedTimestampDesc(int groupId);
	
	public LedNodeGroupProfile findByIdAndIsActiveTrue(int profileId);
	
	public LedNodeGroupProfile findByLedProfileNameAndGroupIdAndIsActiveTrue(String profileName,int groupId);
	
	@Modifying(clearAutomatically = true)
	@Transactional
	@Query(value = "update led_node_group_profile ga set ga.is_active = 0 where ga.group_id = ?1", nativeQuery = true)
	public void deleteLedNodeProfilesByGroupId(int groupId);
	
	@Modifying(clearAutomatically = true)
	@Transactional
	@Query(value = "update led_node_group_profile ga set ga.is_active = 0 where ga.id = ?1", nativeQuery = true)
	public void deleteLedProfileById(int profileId);
}
