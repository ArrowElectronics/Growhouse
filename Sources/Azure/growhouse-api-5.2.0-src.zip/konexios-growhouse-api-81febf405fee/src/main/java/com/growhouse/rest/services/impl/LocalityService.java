/**
 * 
 */
package com.growhouse.rest.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.growhouse.rest.entity.Locality;
import com.growhouse.rest.repository.LocalityRepository;
import com.growhouse.rest.services.ILocalityService;

/**
 * @author dharita.chokshi
 *
 */
@Service
public class LocalityService implements ILocalityService {

	@Autowired
	private LocalityRepository localityRepository;

	
	public List<Locality> findAll() {
		return localityRepository.findAll();
	}

	public List<Locality> findByStateId(int stateId) {
		return localityRepository.findByStateId(stateId);
	}

}
