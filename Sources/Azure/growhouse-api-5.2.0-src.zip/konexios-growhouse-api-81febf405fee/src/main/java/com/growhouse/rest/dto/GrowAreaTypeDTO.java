/**
 * 
 */
package com.growhouse.rest.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author dharita.chokshi
 *
 */
public class GrowAreaTypeDTO {

	private Integer id;
	@JsonProperty("grow_area_type_name")
	private String growAreaTypeName;

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the growAreaTypeName
	 */
	public String getGrowAreaTypeName() {
		return growAreaTypeName;
	}

	/**
	 * @param growAreaTypeName
	 *            the growAreaTypeName to set
	 */
	public void setGrowAreaTypeName(String growAreaTypeName) {
		this.growAreaTypeName = growAreaTypeName;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "GrowAreaTypeDTO [id=" + id + ", growAreaTypeName=" + growAreaTypeName + "]";
	}

}
