/**
 * 
 */
package com.growhouse.rest.services;

import java.util.List;

import com.growhouse.rest.entity.ContainerType;

/**
 * @author dharita.chokshi
 *
 */
public interface IContainerTypeService {

	public List<ContainerType> getAllContainerTypes();

	public ContainerType getContainerTypeById(int containerTypeId);

}
