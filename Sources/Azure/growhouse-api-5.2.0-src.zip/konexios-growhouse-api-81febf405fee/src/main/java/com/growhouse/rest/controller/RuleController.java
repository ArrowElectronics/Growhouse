/**
 * 
 */
package com.growhouse.rest.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;

import com.growhouse.rest.facade.RuleFacade;
import com.growhouse.rest.response.ResponseMessage;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author dharita.chokshi
 *
 */

@RestController
@RequestMapping("/api/rules")
@Transactional
public class RuleController {

	public static final Logger LOGGER = LoggerFactory.getLogger(RuleController.class);

	@Autowired
	private RuleFacade ruleFacade;

	@GetMapping(value = "/growareas/byfacility/{facilityId}")
	@ApiOperation(value = "View list of grow areas that are having alert rules based on facilityId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "List retrieved successfully"),
			@ApiResponse(code = 204, message = "No Content") })
	public ResponseEntity<?> getRuledGrowAreasByFacilityId(@PathVariable("facilityId") Integer facilityId) {
		ResponseEntity<?> responseEntity;
		try {
			List<String> hids = ruleFacade.ruledGrowAreaHIdsByFacilityId(facilityId);
			if (hids == null || hids.isEmpty())
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(hids, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@GetMapping(value = "/growareas/bycontainer/{containerId}")
	@ApiOperation(value = "View list of grow areas that are having alert rules based on containerId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "List retrieved successfully"),
			@ApiResponse(code = 204, message = "No Content") })
	public ResponseEntity<?> getRuledGrowAreasByContainerId(@PathVariable("containerId") Integer containerId) {
		ResponseEntity<?> responseEntity;
		try {
			List<String> hids = ruleFacade.ruledGrowAreaHIdsByContainerId(containerId);
			if (hids == null || hids.isEmpty())
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(hids, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@GetMapping(value = "/growareas/bygrowarea/{growAreaId}")
	@ApiOperation(value = "View list of grow areas that are having alert rules based on growAreaId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "List retrieved successfully"),
			@ApiResponse(code = 204, message = "No Content") })
	public ResponseEntity<?> getRuledGrowAreasByGrowAreaId(@PathVariable("growAreaId") Integer growAreaId) {
		ResponseEntity<?> responseEntity;
		try {
			List<String> hids = ruleFacade.ruledGrowAreaHIdsByGrowAreaId(growAreaId);
			if (hids == null || hids.isEmpty())
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(hids, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/**
	 * @param httpClientErrorException
	 * @return
	 */
	private ResponseEntity<ResponseMessage> setResponseMessage(HttpClientErrorException httpClientErrorException) {
		ResponseMessage responseMessage = new ResponseMessage();
		responseMessage.setMessage(httpClientErrorException.getStatusText());
		return new ResponseEntity<>(responseMessage, httpClientErrorException.getStatusCode());
	}

}
