package com.growhouse.rest.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class DeviceDTO {

	private Integer id;
	@JsonProperty("device_name")
	private String deviceName;
	@JsonProperty("grow_area")
	private GrowAreaDTO growArea;
	@JsonProperty("grow_section")
	private List<DeviceGrowSectionDTO> growSection;
	private String eui64;
	@JsonProperty("deviceUId")
	private String deviceUID;
	@JsonProperty("deviceHId")
	private String deviceHID;
	
	@JsonProperty("device_type")
	private DeviceTypeDTO deviceType;
	private String description;
	@JsonProperty("deviceSuffix")
	private String prefixKeyword;
	
	private LedNodeChannelConfigurationDTO ledconfiguration;

    private boolean status;
	
	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDeviceName() {
		return deviceName;
	}

	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}

	public GrowAreaDTO getGrowArea() {
		return growArea;
	}

	public void setGrowArea(GrowAreaDTO growArea) {
		this.growArea = growArea;
	}

	public List<DeviceGrowSectionDTO> getGrowSection() {
		return growSection;
	}

	public void setGrowSection(List<DeviceGrowSectionDTO> growSection) {
		this.growSection = growSection;
	}

	public String getEui64() {
		return eui64;
	}

	public void setEui64(String eui64) {
		this.eui64 = eui64;
	}

	public String getDeviceUID() {
		return deviceUID;
	}

	public void setDeviceUID(String deviceUID) {
		this.deviceUID = deviceUID;
	}

	public String getDeviceHID() {
		return deviceHID;
	}

	public void setDeviceHID(String deviceHID) {
		this.deviceHID = deviceHID;
	}

	public DeviceTypeDTO getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(DeviceTypeDTO deviceType) {
		this.deviceType = deviceType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPrefixKeyword() {
		return prefixKeyword;
	}

	public void setPrefixKeyword(String prefixKeyword) {
		this.prefixKeyword = prefixKeyword;
	}

	public LedNodeChannelConfigurationDTO getLedconfiguration() {
		return ledconfiguration;
	}

	public void setLedconfiguration(LedNodeChannelConfigurationDTO ledconfiguration) {
		this.ledconfiguration = ledconfiguration;
	}

	@Override
	public String toString() {
		return "DeviceDTO [id=" + id + ", deviceName=" + deviceName + ", growArea=" + growArea + ", growSection="
				+ growSection + ", eui64=" + eui64 + ", deviceUID=" + deviceUID + ", deviceHID=" + deviceHID
				+ ", deviceType=" + deviceType + ", description=" + description + ", prefixKeyword=" + prefixKeyword
				+ ", ledconfiguration=" + ledconfiguration + ", status=" + status + "]";
	}
	

}
