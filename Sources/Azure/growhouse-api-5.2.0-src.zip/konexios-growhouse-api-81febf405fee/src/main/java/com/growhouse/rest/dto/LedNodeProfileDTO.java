package com.growhouse.rest.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class LedNodeProfileDTO {
    
	private Integer id;
	
	private DeviceDTO device;
	
	@JsonProperty("device_type")
	private String deviceType="LedNode";
	
	@JsonProperty("profile_name")
	private String profileName;
	
	private String description;
	
	@JsonProperty("channel_configuration")
	private String channelConfiguration;
	
	

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public DeviceDTO getDevice() {
		return device;
	}

	public void setDevice(DeviceDTO device) {
		this.device = device;
	}

	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

	public String getProfileName() {
		return profileName;
	}

	public void setProfileName(String profileName) {
		this.profileName = profileName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getChannelConfiguration() {
		return channelConfiguration;
	}

	public void setChannelConfiguration(String channelConfiguration) {
		this.channelConfiguration = channelConfiguration;
	}

	@Override
	public String toString() {
		return "LedNodeProfileDTO [id=" + id + ", device=" + device + ", deviceType=" + deviceType + ", profileName="
				+ profileName + ", description=" + description + ", channelConfiguration=" + channelConfiguration + "]";
	}

	

}
