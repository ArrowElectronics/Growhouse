/**
 * 
 */
package com.growhouse.rest.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpServerErrorException;

import com.growhouse.rest.dto.GrowAreaTypeDTO;
import com.growhouse.rest.facade.GrowAreaTypeFacade;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author dharita.chokshi
 *
 */

@RestController
@RequestMapping("/api/growareatypes")
@Transactional
public class GrowAreaTypeController {

	public static final Logger LOGGER = LoggerFactory.getLogger(GrowAreaTypeController.class);

	@Autowired
	private GrowAreaTypeFacade growAreaTypeFacade;

	/* Query-- Select * from grow_area_type where is_active=true */
	@GetMapping(value = "")
	@ApiOperation(value = "View a list of active growArea types")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "List retrieved successfully"),
			@ApiResponse(code = 204, message = "Empty list") })
	public ResponseEntity<List<GrowAreaTypeDTO>> getGrowAreaTypes() {
		ResponseEntity<List<GrowAreaTypeDTO>> responseEntity;
		try {
			List<GrowAreaTypeDTO> growAreaTypeDTOs = growAreaTypeFacade.getGrowAreaTypes();
			if (growAreaTypeDTOs == null || growAreaTypeDTOs.isEmpty())
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(growAreaTypeDTOs, HttpStatus.OK);
		} catch (Exception exception) {
			throw new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/*
	 * Query-- Select * from grow_area_type where grow_area_types_id=? and
	 * is_active=true
	 */
	@GetMapping(value = "/{growAreaTypeId}")
	@ApiOperation(value = "View growArea type based on growAreaTypeId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Contianer type retrieved successfully"),
			@ApiResponse(code = 403, message = "Grow area type is inactive") })
	public ResponseEntity<GrowAreaTypeDTO> getGrowAreaTypeByGrowAreaTypeId(
			@PathVariable("growAreaTypeId") Integer growAreaTypeId) {
		ResponseEntity<GrowAreaTypeDTO> responseEntity;
		try {
			GrowAreaTypeDTO growAreaTypeDTO = growAreaTypeFacade.getGrowAreaTypeById(growAreaTypeId);
			if (growAreaTypeDTO == null)
				responseEntity = new ResponseEntity<>(HttpStatus.NOT_FOUND);
			else
				responseEntity = new ResponseEntity<>(growAreaTypeDTO, HttpStatus.OK);
		} catch (Exception exception) {
			throw new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}
}
