package com.growhouse.rest.dto;

import java.util.List;

public class TelemetryItemWithPagesDTO {

	private List<TelemetryItemDTO> telemetryItemDTOs;

	private Integer pages;

	public List<TelemetryItemDTO> getTelemetryItemDTOs() {
		return telemetryItemDTOs;
	}

	public void setTelemetryItemDTOs(List<TelemetryItemDTO> telemetryItemDTOs) {
		this.telemetryItemDTOs = telemetryItemDTOs;
	}

	public Integer getPages() {
		return pages;
	}

	public void setPages(Integer pages) {
		this.pages = pages;
	}

}
