package com.growhouse.rest.services;

import com.growhouse.rest.repository.GlobalResponseRepository;

public interface IGlobalResponseService {
	
	public GlobalResponseRepository getGlobalResponseRepository();
	
	public void updateSectionNameBySectionId(int id,String sectionName);

}
