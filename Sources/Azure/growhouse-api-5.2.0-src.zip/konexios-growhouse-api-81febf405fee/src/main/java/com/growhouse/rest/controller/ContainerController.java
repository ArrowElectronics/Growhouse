/**
 * 
 */
package com.growhouse.rest.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;

import com.growhouse.rest.dto.ContainerDTO;
import com.growhouse.rest.entity.Container;
import com.growhouse.rest.facade.ContainerFacade;
import com.growhouse.rest.response.ResponseMessage;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author dharita.chokshi
 *
 */

@RestController
@RequestMapping("/api/containers")
@Transactional
public class ContainerController {

	public static final Logger LOGGER = LoggerFactory.getLogger(ContainerController.class);

	@Autowired
	private ContainerFacade containerFacade;

	/*
	 * Query--Select * from container where account_id=? and
	 * container.is_active=true and container.facility.is_active=true
	 */
	@GetMapping(value = "")
	@ApiOperation(value = "View list of active containers")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "List retrieved successfully"),
			@ApiResponse(code = 204, message = "Empty list") })
	public ResponseEntity<List<ContainerDTO>> getActiveContainers() {
		ResponseEntity<List<ContainerDTO>> responseEntity;
		try {
			List<ContainerDTO> containers = containerFacade.getActiveContainers();
			if (containers == null || containers.isEmpty())
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(containers, HttpStatus.OK);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/* Query--Select * from container */
	@GetMapping(value = "/all")
	@ApiOperation(value = "View list of all (active and inactive) containers")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "List retrieved successfully"),
			@ApiResponse(code = 204, message = "Empty list.") })
	public ResponseEntity<List<ContainerDTO>> getAllContainers() {
		ResponseEntity<List<ContainerDTO>> responseEntity;
		try {
			List<ContainerDTO> containers = containerFacade.getAllContainers();
			if (containers == null || containers.isEmpty())
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(containers, HttpStatus.OK);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/*
	 * Query--Select * from container where facility_id=? and
	 * container.is_active=true
	 */
	@GetMapping(value = "/facilities/{facilityId}")
	@ApiOperation(value = "View list of containers based on facilityId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "List retrieved successfully"),
			@ApiResponse(code = 204, message = "Empty list") })
	public ResponseEntity<List<ContainerDTO>> getContainersByFacilityId(
			@PathVariable("facilityId") Integer facilityId) {
		ResponseEntity<List<ContainerDTO>> responseEntity;
		try {
			List<ContainerDTO> containers = containerFacade.getContainersByFacilityId(facilityId);
			if (containers == null || containers.isEmpty())
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(containers, HttpStatus.OK);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/* Query--Select * from container where container_id=? */
	@GetMapping(value = "/{containerId}")
	@ApiOperation(value = "View container based on containerId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Container retrieved successfully"),
			@ApiResponse(code = 403, message = "Container is inactive") })
	public ResponseEntity<?> getContainerByContainerId(@PathVariable("containerId") Integer containerId) {
		ResponseEntity<?> responseEntity;
		try {
			ContainerDTO containers = containerFacade.getContainerById(containerId);
			if (containers == null)
				responseEntity = new ResponseEntity<>(HttpStatus.NOT_FOUND);
			else
				responseEntity = new ResponseEntity<>(containers, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@PostMapping(value = "", consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Create new container")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Container created successfully"),
			@ApiResponse(code = 400, message = "Bad Request") })
	public ResponseEntity<?> createContainer(@RequestBody ContainerDTO containerDTO) {
		ResponseEntity<?> responseEntity;
		try {
			ContainerDTO createdContainers = containerFacade.createContainer(containerDTO);
			if (createdContainers == null)
				responseEntity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			else
				responseEntity = new ResponseEntity<>(createdContainers, HttpStatus.CREATED);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@PutMapping(value = "/{containerId}")
	@ApiOperation(value = "Update existing container")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Container updated successfully"),
			@ApiResponse(code = 403, message = "Container is inactive"),
			@ApiResponse(code = 400, message = "Bad Request"),
			@ApiResponse(code = 406, message = "ContainerId in URL doesnot match with containerId of Container object") })
	public ResponseEntity<?> updateContainer(@PathVariable("containerId") Integer containerId,
			@RequestBody ContainerDTO containerDTO) {
		ResponseEntity<?> responseEntity;
		try {
			ContainerDTO updatedContainers = containerFacade.updateContainer(containerId, containerDTO);
			if (updatedContainers == null)
				responseEntity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			else
				responseEntity = new ResponseEntity<>(updatedContainers, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/*
	 * Query--Update container SET container.is_active=false where container_id=?
	 */
	@DeleteMapping(value = "/{containerId}")
	@ApiOperation(value = "Delete container by containerId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Container deleted successfully"),
			@ApiResponse(code = 403, message = "Container is inactive") })
	public ResponseEntity<ResponseMessage> deleteContainer(@PathVariable("containerId") Integer containerId) {
		ResponseEntity<ResponseMessage> responseEntity;
		try {
			Container deletedContainer = containerFacade.deleteContainer(containerId);
			if (deletedContainer != null) {
				ResponseMessage responseMessage = new ResponseMessage();
				responseMessage.setMessage("Container deleted successfully");
				responseEntity = new ResponseEntity<>(responseMessage, HttpStatus.OK);
			} else {
				responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/**
	 * @param httpClientErrorException
	 * @return
	 */
	private ResponseEntity<ResponseMessage> setResponseMessage(HttpClientErrorException httpClientErrorException) {
		ResponseMessage responseMessage = new ResponseMessage();
		responseMessage.setMessage(httpClientErrorException.getStatusText());
		return new ResponseEntity<>(responseMessage, httpClientErrorException.getStatusCode());
	}

}
