package com.growhouse.rest.services.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.growhouse.rest.entity.Profile;
import com.growhouse.rest.repository.ProfileRepository;
import com.growhouse.rest.services.IProfileService;

@Service
public class ProfileService implements IProfileService {

	@Autowired
	private ProfileRepository profileRepository;

	@Override
	public Profile createProfile(Profile profile) {
		return profileRepository.saveAndFlush(profile);
	}
	
	
	
	@Override
	public ProfileRepository getProfileRepository() {
		return profileRepository;
	}
	
	
	@Override
	public Profile updateProfile(Profile profile) {
		return profileRepository.save(profile);
	}
	

	public List<Profile> getProfileByFacilityId() {
		return profileRepository.findAll();
	}
	
	public List<Profile> getProfileByGrowSectionId(String growSectionId)
	{
		return profileRepository.findByPayloadIsActiveTrueAndPayloadGlobalResponsePayloadGrowSectionIdAndIsActiveTrueOrderByCreatedTimestampDesc(growSectionId);
	}
	
	public List<Profile> getProfileByGatewayId(String gatewayId)
	{
		return profileRepository.findByPayloadIsActiveTrueAndPayloadGlobalResponsePayloadGatewayIdAndIsActiveTrueOrderByCreatedTimestampDesc(gatewayId);
	}
	
}
