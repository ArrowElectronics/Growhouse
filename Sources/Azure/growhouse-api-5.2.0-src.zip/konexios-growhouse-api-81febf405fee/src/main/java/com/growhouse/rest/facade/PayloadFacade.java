package com.growhouse.rest.facade;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.growhouse.rest.dto.PayloadDTO;
import com.growhouse.rest.entity.Payload;
import com.growhouse.rest.services.impl.PayloadService;

@Component
public class PayloadFacade {

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private PayloadService payloadService;

	public PayloadDTO createPayload(PayloadDTO requestedPayloadDTO) {
		PayloadDTO createdPayloadDTO = null;
		Payload requestedPayload = convertDTOToEntity(requestedPayloadDTO);
		Payload createdPayload = payloadService.createPayload(requestedPayload);
		if (createdPayload != null) {
			createdPayloadDTO = convertEntityToDTO(createdPayload);
		}
		return createdPayloadDTO;
	}

	public PayloadDTO convertEntityToDTO(Payload payload) {
		return modelMapper.map(payload, PayloadDTO.class);
	}

	public Payload convertDTOToEntity(PayloadDTO payloadDTO) {
		return modelMapper.map(payloadDTO, Payload.class);
	}
}
