/**
 * 
 */
package com.growhouse.rest.services;

import java.util.List;

import com.growhouse.rest.entity.Country;

/**
 * @author dharita.chokshi
 *
 */
public interface ICountryService {
	public List<Country> getAllCountries();
}
