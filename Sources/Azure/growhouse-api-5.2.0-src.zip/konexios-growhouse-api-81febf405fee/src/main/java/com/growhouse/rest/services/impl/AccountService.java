/**
 * 
 */
package com.growhouse.rest.services.impl;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.HttpClientErrorException;

import com.growhouse.rest.entity.Account;
import com.growhouse.rest.entity.User;
import com.growhouse.rest.entity.UserRole;
import com.growhouse.rest.repository.AccountRepository;
import com.growhouse.rest.repository.UserRepository;
import com.growhouse.rest.services.IAccountService;
import com.growhouse.rest.services.IUserRoleService;
import com.growhouse.rest.services.IUserService;

/**
 * @author dharita.chokshi
 *
 */
@Service
public class AccountService implements IAccountService {

	private static final Logger LOGGER = LoggerFactory.getLogger(AccountService.class);

	@Autowired
	private AccountRepository accountRepository;

	@Autowired
	private IUserRoleService userRoleService;

	@Autowired
	private IUserService userService;

	@Autowired
	private UserRepository userRepository;

	public List<Account> getActiveAccounts() {
		return accountRepository.findByIsActiveTrueAndAdminIdIsNotNullOrderByCreatedTimestampDesc();
	}

	public int getActiveAccountCount() {
		return accountRepository.countByIsActiveTrueAndAdminIdIsNotNull();
	}

	public List<Account> getAllAccounts() {
		return accountRepository.findAll();
	}

	public Account getAccountById(int id) {
		Optional<Account> optional = accountRepository.findByIdAndIsActiveTrue(id);
		return optional.isPresent() ? optional.get() : null;
	}

	public Account getAccountByName(String name) {
		return accountRepository.findByAccountNameAndIsActiveTrue(name);
	}

	@Transactional(rollbackFor = { HttpClientErrorException.class })
	public Account createAccount(Account account, User admin) {
		Account createdAccount = accountRepository.save(account);

		admin.setAccount(createdAccount);
		createAccountAdmin(admin);

		account.setAdminId(admin.getId());
		updateAccount(createdAccount);

		return createdAccount;
	}

	private User createAccountAdmin(User admin) {
		User createdUser = null;
		try {
			UserRole userRole = userRoleService.getUserRoleById(2);
			admin.setUserRole(userRole);
			createdUser = userService.createUser(admin);
			if (createdUser == null)
				throw new HttpClientErrorException(HttpStatus.BAD_REQUEST, "Error creating account admin.");
		} catch (HttpClientErrorException httpClientErrorException) {
			throw new HttpClientErrorException(httpClientErrorException.getStatusCode(),
					httpClientErrorException.getStatusText());
		} catch (Exception exception) {
			throw new HttpClientErrorException(HttpStatus.BAD_REQUEST, "Error creating account admin.");
		}
		return createdUser;
	}

	public Account updateAccount(Account account) {
		return accountRepository.save(account);
	}

	public Account deleteAccount(int id) {
		Account deletedAccount = null;
		Optional<Account> optional = accountRepository.findById(id);
		if (optional.isPresent() && optional.get().isActive()) {
			Account account = optional.get();
			account.setActive(false);
			deletedAccount = accountRepository.save(account);
			userRepository.updateUsersByAccountId(id);
		} else {
			throw new HttpClientErrorException(HttpStatus.NOT_FOUND, "Requested account not found");
		}
		return deletedAccount;
	}

}
