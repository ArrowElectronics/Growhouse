package com.growhouse.rest.dto;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;

public class NormalUserDeviceTypeCount {

	@JsonProperty("devicetype_count")
	private Map<String, Long> devicesTypeCount;

	public Map<String, Long> getDevicesTypeCount() {
		return devicesTypeCount;
	}

	public void setDevicesTypeCount(Map<String, Long> devicesTypeCount) {
		this.devicesTypeCount = devicesTypeCount;
	}

}
