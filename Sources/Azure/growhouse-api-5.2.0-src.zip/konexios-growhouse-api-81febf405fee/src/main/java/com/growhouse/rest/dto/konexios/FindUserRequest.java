package com.growhouse.rest.dto.konexios;

public class FindUserRequest {
    private String hid;
    private String login;

    public FindUserRequest hid(String hid) {
        this.hid = hid;
        return this;
    }

    public FindUserRequest login(String login) {
        this.login = login;
        return this;
    }

    public String getHid() {
        return this.hid;
    }

    public void setHid(String hid) {
        this.hid = hid;
    }

    public String getLogin() {
        return this.login;
    }

    public void setLogin(String login) {
        this.login = login;
    }
}