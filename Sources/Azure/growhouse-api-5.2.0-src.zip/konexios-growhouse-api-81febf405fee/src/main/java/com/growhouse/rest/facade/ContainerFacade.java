/**
 * 
 */
package com.growhouse.rest.facade;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;

import com.growhouse.rest.dto.ContainerDTO;
import com.growhouse.rest.dto.FacilityDTO;
import com.growhouse.rest.entity.Container;
import com.growhouse.rest.entity.User;
import com.growhouse.rest.repository.FacilityRepository;
import com.growhouse.rest.services.IContainerService;
import com.growhouse.rest.utils.Constants;

/**
 * @author dharita.chokshi
 *
 */
@Component
public class ContainerFacade {

	public static final Logger LOGGER = LoggerFactory.getLogger(ContainerFacade.class);

	@Autowired
	private IContainerService containerService;

	@Autowired
	private FacilityRepository facilityRepo;

	@Autowired
	private ModelMapper modelMapper;

	public List<ContainerDTO> getAllContainers() {
		List<ContainerDTO> containerDTOs = new ArrayList<>();
		List<Container> containers = containerService.getAllContainers();
		if (containers != null && !containers.isEmpty()) {
			containerDTOs = containers.stream().map(this::convertEntityToDTO).collect(Collectors.toList());
		}
		return containerDTOs;
	}

	public int getCountActiveContainer() {
		return containerService.getCountActiveContainer();
	}

	public int getActiveContainerCountByAccountId(int accountId) {
		return containerService.getContainerRepository()
				.countByAccountIdAndIsActiveTrueAndFacilityIsActiveTrue(accountId);

	}

	public List<ContainerDTO> getActiveContainers() {
		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		List<ContainerDTO> containerDTOs = new ArrayList<>();
		List<Container> containers = containerService.getActiveContainersByAccount(user.getAccount().getId());
		if (containers != null && !containers.isEmpty()) {
			containerDTOs = containers.stream().map(this::convertEntityToDTO).collect(Collectors.toList());

		}
		return containerDTOs;
	}

	public List<ContainerDTO> getContainersByFacilityId(int facilityId) {
		List<ContainerDTO> containerDTOs = new ArrayList<>();
		List<Container> containers = containerService.getContainersByFacilityId(facilityId);
		if (containers != null && !containers.isEmpty()) {
			containerDTOs = containers.stream().filter(container -> container.getFacility().isActive())
					.map(this::convertEntityToDTO).collect(Collectors.toList());
		}
		return containerDTOs;
	}

	public int getCountOfContainersByFacilityId(int facilityId) {
		return containerService.getCountOfContainersByFacilityId(facilityId);
	}

	public ContainerDTO getContainerById(int containerId) {
		ContainerDTO containerDTO = null;
		Container container = containerService.getContainerById(containerId);
		if (container != null) {
			containerDTO = convertEntityToDTO(container);
		}
		return containerDTO;
	}

	public ContainerDTO createContainer(ContainerDTO requestedContainerDTO) {
		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		ContainerDTO createdContainerDTO = null;
		Container requestedContainer = convertDTOToEntity(requestedContainerDTO);
		requestedContainer.setAccount(user.getAccount());
		requestedContainer.setContainerName(requestedContainer.getContainerName().trim());
		Container existContainer = containerService.getContainerByContainerName(requestedContainer.getContainerName(),
				requestedContainer.getAccount().getId());
		if (existContainer == null) {
			Container createdContainer = containerService.createContainer(requestedContainer);
			if (createdContainer != null)
				createdContainerDTO = convertEntityToDTO(createdContainer);
		} else {
			throw new HttpClientErrorException(HttpStatus.BAD_REQUEST, "Container name already exist.");
		}
		return createdContainerDTO;
	}

	public List<ContainerDTO> createContainersInBatch(List<ContainerDTO> requestedContainerDTOs,
			FacilityDTO facilityDTO) {
		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		List<ContainerDTO> createdContainerDTOs = null;
		List<Container> containers = new ArrayList<>();
		requestedContainerDTOs.forEach(containerDTO -> {
			containerDTO.setFacility(facilityDTO);
			Container container = convertDTOToEntity(containerDTO);
			container.setAccount(user.getAccount());
			container.setContainerName(container.getContainerName().trim());
			containers.add(container);
		});

		List<Container> createdContainers = containerService.createContainersInBatch(containers);
		if (createdContainers != null && !createdContainers.isEmpty())
			createdContainerDTOs = createdContainers.stream().map(this::convertEntityToDTO)
					.collect(Collectors.toList());
		return createdContainerDTOs;
	}

	public ContainerDTO updateContainer(int containerId, ContainerDTO requestedContainerDTO) {
		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if (containerId != requestedContainerDTO.getId())
			throw new HttpClientErrorException(HttpStatus.NOT_ACCEPTABLE,
					"ContainerId in URL doesnot match with containerId of Container object");

		ContainerDTO updatedContainerDTO = null;
		Container requestedContainer = convertDTOToEntity(requestedContainerDTO);
		requestedContainer.setFacility(facilityRepo.findById(requestedContainer.getFacility().getId()).orElse(null));
		LOGGER.info("updateContainer, setting facility: " + requestedContainer.getFacility().getFacilityName());
		requestedContainer.setContainerName(requestedContainer.getContainerName().trim());
		Container existContainer = containerService.getContainerByContainerName(requestedContainer.getContainerName(),
				user.getAccount().getId());
		if (existContainer != null) {
			if (existContainer.getId().equals(containerId) == Constants.TRUE) {
				Container updatedContainer = containerService.updateContainer(requestedContainer);
				if (updatedContainer != null)
					updatedContainerDTO = convertEntityToDTO(updatedContainer);
			} else {
				throw new HttpClientErrorException(HttpStatus.BAD_REQUEST, "Container name already exist.");
			}
		} else {
			Container updatedContainer = containerService.updateContainer(requestedContainer);
			if (updatedContainer != null)
				updatedContainerDTO = convertEntityToDTO(updatedContainer);
		}

		return updatedContainerDTO;
	}

	public Container deleteContainer(int containerId) {
		return containerService.deleteContainer(containerId);
	}

	private ContainerDTO convertEntityToDTO(Container container) {
		return modelMapper.map(container, ContainerDTO.class);
	}

	private Container convertDTOToEntity(ContainerDTO containerDTO) {
		return modelMapper.map(containerDTO, Container.class);
	}

}
