/**
 * 
 */
package com.growhouse.rest.services.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.growhouse.rest.KonexiosConfig;
import com.growhouse.rest.entity.kronos.KronosData;
import com.growhouse.rest.entity.kronos.KronosResponse;
import com.growhouse.rest.services.IRuleService;

/**
 * @author dharita.chokshi
 *
 */
@Service
public class RuleService implements IRuleService {

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private KonexiosConfig config;

	@Override
	public List<KronosData> getRuleDevices() {
		List<KronosData> ruleDevices = new ArrayList<>();
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set(config.getAuthTokenKey(), config.getAuthToken());

			HttpEntity<String> entity = new HttpEntity<>(headers);
			ResponseEntity<KronosResponse> response = restTemplate.exchange(config.buildRuleTypeDevicesUrl(),
					HttpMethod.GET, entity, KronosResponse.class);
			if (response.getStatusCode() == HttpStatus.OK) {
				ruleDevices = response.getBody().getData();
			}
		} catch (Exception exception) {
			throw new HttpClientErrorException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to fetch Device HId");
		}
		return ruleDevices;
	}

}
