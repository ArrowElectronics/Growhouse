package com.growhouse.rest.facade;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.growhouse.rest.KonexiosConfig;
import com.growhouse.rest.dto.Condition;
import com.growhouse.rest.dto.Monitor;
import com.growhouse.rest.dto.ProfileAlertDTO;
import com.growhouse.rest.dto.ProfileConditionDTO;
import com.growhouse.rest.dto.ProfileDTO;
import com.growhouse.rest.dto.ProfileResponseDTO;
import com.growhouse.rest.dto.ProfileSubDTO;
import com.growhouse.rest.entity.Facility;
import com.growhouse.rest.entity.GlobalResponsePayload;
import com.growhouse.rest.entity.GrowArea;
import com.growhouse.rest.entity.GrowSection;
import com.growhouse.rest.entity.GrowSectionDevice;
import com.growhouse.rest.entity.Profile;
import com.growhouse.rest.entity.ProfileAlert;
import com.growhouse.rest.entity.User;
import com.growhouse.rest.entity.kronos.KronosResponse;
import com.growhouse.rest.repository.GlobalResponseRepository;
import com.growhouse.rest.repository.PayloadRepository;
import com.growhouse.rest.services.impl.FacilityService;
import com.growhouse.rest.services.impl.GlobalResponseService;
import com.growhouse.rest.services.impl.GrowAreaService;
import com.growhouse.rest.services.impl.GrowSectionDeviceService;
import com.growhouse.rest.services.impl.GrowSectionService;
import com.growhouse.rest.services.impl.ProfileAlertService;
import com.growhouse.rest.services.impl.ProfileService;
import com.growhouse.rest.utils.Command;
import com.growhouse.rest.utils.Constants;

@Component
public class ProfileFacade {

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private ProfileService profileService;

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private ProfileAsyncFacade profileAsyncFacade;

	@Autowired
	private GrowSectionService growSectionService;

	@Autowired
	private ProfileAlertService profileAlertService;

	@Autowired
	private FacilityService facilityService;

	@Autowired
	private GlobalResponseService globalResponseService;

	@Autowired
	private GrowAreaService growAreaService;

	@Autowired
	private ObjectMapper mapper;

	@Autowired
	private GlobalResponseRepository globalResponseRepository;

	@Autowired
	private PayloadRepository payloadRepository;

	@Autowired
	private GrowSectionDeviceService growSectionDeviceService;

	@Autowired
	private KonexiosConfig config;

	private static final Logger LOGGER = LogManager.getLogger(ProfileFacade.class);

	@SuppressWarnings("rawtypes")
	public ProfileDTO createProfile(Integer growSectionId, ProfileDTO requestedProfileDTO)
			throws JsonProcessingException {
		String gatewayHId = null;
		GrowSection growSection = growSectionService.getGrowSectionById(growSectionId);
		if (growSection != null) {
			gatewayHId = growSection.getGrowArea().getGrowAreaHId();
			if (growSection.getGrowArea().getGatewayDeviceHId() != null)
				requestedProfileDTO.setDeviceHid(growSection.getGrowArea().getGatewayDeviceHId());
			else {
				String gatewayDeviceHid = fetchgatewayDefaultDevice(gatewayHId);
				growSection.getGrowArea().setGatewayDeviceHId(gatewayDeviceHid);
				requestedProfileDTO.setDeviceHid(gatewayDeviceHid);
				GrowArea growArea = growSection.getGrowArea();
				growAreaService.updateGrowArea(growArea);
			}

		} else {
			throw new HttpClientErrorException(HttpStatus.BAD_REQUEST, "GrowSection for given id dosen't exists");
		}
		String url = config.buildDeviceCommandUrl(gatewayHId, requestedProfileDTO.getDeviceHid());
		ProfileDTO createdProfileDTO = null;
		Profile requestedProfile = convertDTOToEntity(requestedProfileDTO);
		requestedProfile.setProfileHid(null);
		GrowSection section = new GrowSection();
		section.setId(growSectionId);
		requestedProfile.setGrowSection(section);
		requestedProfile.getPayload()
				.setConditions(mapper.writeValueAsString(requestedProfileDTO.getPayload().getConditions()));
		requestedProfile.getPayload()
				.setMonitors(mapper.writeValueAsString(requestedProfileDTO.getPayload().getMonitors()));
		Profile createdProfile = profileService.createProfile(requestedProfile);
		String ruleName = growSection.getGrowSectionName() + "_profile_" + (createdProfile.getId() + 1);
		createdProfile.getPayload().setName(ruleName);
		createdProfile.getPayload().setRuleHid(ruleName);
		createdProfile.setName(ruleName);
		createdProfile.getPayload().getGlobalResponsePayload().setProfileId(createdProfile.getId());
		createdProfile.getPayload().getGlobalResponsePayload().setProfileName(ruleName);

		createdProfile = profileService.createProfile(createdProfile);
		requestedProfileDTO.getPayload().setRuleHid(ruleName);
		requestedProfileDTO.getPayload().setName(ruleName);
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set(config.getAuthTokenKey(), config.getAuthToken());
			requestedProfileDTO.setMessageExpiration(10);
			Map<String, Object> map = new HashMap<>();
			map.put(Constants.COMMAND, Command.createRule);
			map.put(Constants.DEVICE_HID, requestedProfileDTO.getDeviceHid());
			map.put(Constants.MESSAGE_EXPIRATION, 10);
			map.put(Constants.PAYLOAD, String.valueOf(mapper.writeValueAsString(requestedProfileDTO.getPayload())));
			HttpEntity<Map> entity = new HttpEntity<>(map, headers);
			ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
			if (response.getStatusCode() != HttpStatus.OK) {
				throw new HttpClientErrorException(response.getStatusCode(), response.getBody());
			} else {
				LOGGER.info("Profile Created request sent succesfully");
			}
		} catch (HttpStatusCodeException httpStatusCodeException) {
			throw new HttpClientErrorException(httpStatusCodeException.getStatusCode(),
					"Error occurred while creating profile");
		} catch (Exception exception) {
			LOGGER.info("Error occurred while creating profile", exception);
		}
		if (createdProfile != null) {
			createdProfileDTO = convertEntityToDTO(createdProfile);
			profileAsyncFacade.createRuleToArrowConnect(createdProfile);
		}
		return createdProfileDTO;
	}

	@SuppressWarnings("rawtypes")
	public ProfileDTO updateProfile(Integer growSectionId, ProfileDTO requestedProfileDTO)
			throws JsonProcessingException {
		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String gatewayHId = null;
		GrowSection growSection = growSectionService.getGrowSectionById(growSectionId);
		if (growSection != null) {
			gatewayHId = growSection.getGrowArea().getGrowAreaHId();
			if (growSection.getGrowArea().getGatewayDeviceHId() != null)
				requestedProfileDTO.setDeviceHid(growSection.getGrowArea().getGatewayDeviceHId());
			else {
				String gatewayDeviceHid = fetchgatewayDefaultDevice(gatewayHId);
				growSection.getGrowArea().setGatewayDeviceHId(gatewayDeviceHid);
				requestedProfileDTO.setDeviceHid(gatewayDeviceHid);
				GrowArea growArea = growSection.getGrowArea();
				growAreaService.updateGrowArea(growArea);
			}

		} else {
			throw new HttpClientErrorException(HttpStatus.BAD_REQUEST, "GrowSection for given id dosen't exists");
		}
		String url = config.buildDeviceCommandUrl(gatewayHId, requestedProfileDTO.getDeviceHid());

		ProfileDTO createdProfileDTO = null;
		Profile requestedProfile = convertDTOToEntity(requestedProfileDTO);
		requestedProfile.setCreatedBy(user);
		requestedProfile.setProfileHid(null);
		GrowSection section = new GrowSection();
		section.setId(growSectionId);
		requestedProfile.setGrowSection(section);
		requestedProfile.getPayload()
				.setConditions(mapper.writeValueAsString(requestedProfileDTO.getPayload().getConditions()));
		requestedProfile.getPayload()
				.setMonitors(mapper.writeValueAsString(requestedProfileDTO.getPayload().getMonitors()));
		requestedProfile.setName(requestedProfile.getPayload().getName());
		globalResponseRepository.saveAndFlush(requestedProfile.getPayload().getGlobalResponsePayload());
		payloadRepository.saveAndFlush(requestedProfile.getPayload());
		Profile createdProfile = profileService.updateProfile(requestedProfile);
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set(config.getAuthTokenKey(), config.getAuthToken());
			requestedProfileDTO.setMessageExpiration(10);
			Map<String, Object> map = new HashMap<>();
			map.put(Constants.COMMAND, Command.updateRule);
			map.put(Constants.DEVICE_HID, requestedProfileDTO.getDeviceHid());
			map.put(Constants.RULE_HID, requestedProfileDTO.getPayload().getRuleHid());
			map.put(Constants.MESSAGE_EXPIRATION, 10);
			map.put(Constants.PAYLOAD, String.valueOf(mapper.writeValueAsString(requestedProfileDTO.getPayload())));
			HttpEntity<Map> entity = new HttpEntity<>(map, headers);
			ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
			if (response.getStatusCode() != HttpStatus.OK) {
				throw new HttpClientErrorException(response.getStatusCode(), response.getBody());
			} else {
				LOGGER.info("Profile Updated request sent succesfully");
			}
		} catch (HttpStatusCodeException httpStatusCodeException) {
			throw new HttpClientErrorException(httpStatusCodeException.getStatusCode(),
					httpStatusCodeException.getStatusText());
		} catch (Exception exception) {
			LOGGER.info("Error occurred while updating profile.", exception);
		}
		if (createdProfile != null) {
			createdProfileDTO = convertEntityToDTO(createdProfile);
		}
		return createdProfileDTO;
	}

	private String fetchgatewayDefaultDevice(String gatewayHId) {
		UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(config.buildGatewayDevicesUrl())
				.queryParam("gatewayHid", gatewayHId);
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set(config.getAuthTokenKey(), config.getAuthToken());

			HttpEntity<String> entity = new HttpEntity<>(headers);
			ResponseEntity<KronosResponse> response = restTemplate.exchange(builder.toUriString(), HttpMethod.GET,
					entity, KronosResponse.class);
			if (response.getStatusCode() == HttpStatus.OK) {
				KronosResponse kronosResponse = response.getBody();
				return kronosResponse.getData().get(0).getHid();
			}
		} catch (HttpStatusCodeException httpStatusCodeException) {
			throw new HttpClientErrorException(httpStatusCodeException.getStatusCode(),
					httpStatusCodeException.getStatusText());
		} catch (Exception exception) {
			throw new HttpClientErrorException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to fetch gateway device HID");
		}
		return null;

	}

	@SuppressWarnings("rawtypes")
	public void deleteProfile(Integer profileId) {
		Optional<Profile> profileOptional = profileService.getProfileRepository().findById(profileId);
		if (!profileOptional.isPresent())
			throw new HttpClientErrorException(HttpStatus.NOT_FOUND, "No profile found for this profile Id");
		Profile profile = profileOptional.get();
		String url = config.buildDeviceCommandUrl(profile.getGrowSection().getGrowArea().getGrowAreaHId(),
				profile.getDeviceHid());
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set(config.getAuthTokenKey(), config.getAuthToken());
			Map<String, Object> map = new HashMap<>();
			map.put(Constants.COMMAND, Command.deleteRule);
			map.put(Constants.DEVICE_HID, profile.getDeviceHid());
			map.put(Constants.MESSAGE_EXPIRATION, 10);
			Map<String, String> payloadMap = new HashMap<>();
			payloadMap.put(Constants.RULE_HID, profile.getName());
			payloadMap.put(Constants.TYPE, Constants.DELETE);
			map.put(Constants.PAYLOAD, String.valueOf(mapper.writeValueAsString(payloadMap)));
			HttpEntity<Map> entity = new HttpEntity<>(map, headers);
			try {
				restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
			} catch (HttpClientErrorException e) {
				LOGGER.info("Exception while send request to saleni", e);
			}
			LOGGER.info("Profile deletion request sent successfully---{}" + profileId);
			profileService.getProfileRepository().delete(profile);
			profileAlertService.getProfileAlertRepository().deleteProfileAlertsByProfileId(profileId);

		} catch (HttpClientErrorException httpClientErrorException) {
			LOGGER.info("Profile does not exist on Arrow Portal.");
		} catch (Exception e) {
			throw new HttpClientErrorException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Error While deleting profile from arrow connect");
		}
	}

	public ProfileResponseDTO getSpecificProfileAlertByProfileId(Integer profileId) throws JsonProcessingException {

		Optional<Profile> profileCheck = profileService.getProfileRepository().findById(profileId);
		if (profileCheck.isPresent()) {
			Profile profile = profileCheck.get();
			ProfileResponseDTO profileResponseDTO = new ProfileResponseDTO();
			profileResponseDTO.setProfileId(profile.getId().toString());
			String profileName = profile.getName();
			String[] profileExp = profileName.split("_");
			profileResponseDTO.setProfileName(profileExp[0]);
			profileResponseDTO.setProfileVirtualName(profile.getProfileName());
			profileResponseDTO.setContainerName(profile.getPayload().getGlobalResponsePayload().getContainerName());
			profileResponseDTO.setFacilityName(profile.getPayload().getGlobalResponsePayload().getFacilityName());
			profileResponseDTO.setGrowAreaName(profile.getPayload().getGlobalResponsePayload().getGatewayName());
			profileResponseDTO.setGrowSectionName(profile.getPayload().getGlobalResponsePayload().getGrowSectionName());
			ProfileAlert profileAlert = profileAlertService.getProfileAlertRepository()
					.findProfileAlertUsingProfileId(profileId);
			if (profileAlert != null) {
				Map<String, String> propertyMap = new HashMap<>();
				propertyMap.put(Constants.SOILPH_KEY, Constants.SOILPH_VALUE);
				propertyMap.put(Constants.BATTERYVOLTAGE_KEY, Constants.BATTERYVOLTAGE_VALUE);
				propertyMap.put(Constants.SOILMOISTURE_KEY, Constants.SOILMOISTURE_VALUE);
				propertyMap.put(Constants.LED1_KEY, Constants.LED1_VALUE);
				propertyMap.put(Constants.LED2_KEY, Constants.LED2_VALUE);
				propertyMap.put(Constants.LED3_KEY, Constants.LED3_VALUE);
				propertyMap.put(Constants.LED4_KEY, Constants.LED4_VALUE);
				propertyMap.put(Constants.LED5_KEY, Constants.LED5_VALUE);
				propertyMap.put(Constants.LED6_KEY, Constants.LED6_VALUE);
				profileResponseDTO.setAlertMessage(profileAlert.getAlertMessage());
				String property = profileAlert.getProperties();
				JSONObject jsonObj = new JSONObject(property);
				Iterator<String> keysItr = jsonObj.keys();
				Map<String, Object> map = new HashMap<>();
				while (keysItr.hasNext()) {
					String key = keysItr.next();
					String putkey = propertyMap.get(key);
					Object value = jsonObj.get(key);
					map.put(putkey, value);
				}
				profileResponseDTO.setProperties(mapper.writeValueAsString(map));
				profileResponseDTO.setTimestamp(profileAlert.getTimestamp());
			}
			return profileResponseDTO;
		}
		return null;

	}

	public void createProfileAlert(ProfileAlertDTO profileAlertDTO) {
		Integer profileId = Integer
				.parseInt(profileAlertDTO.getRuleHid().substring(profileAlertDTO.getRuleHid().lastIndexOf('_') + 1));
		profileAlertDTO.setProfileId(profileId);
		ProfileAlert profileAlert = convertDTOToEntity(profileAlertDTO);
		profileAlert.setProfileId(profileId);
		profileAlert.setProfileName(profileAlertDTO.getRuleHid());
		profileAlert.setTimestamp(System.currentTimeMillis());
		profileAlertService.getProfileAlertRepository().save(profileAlert);
	}

	public List<GlobalResponsePayload> getProfileByUser() {
		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		List<Facility> facilities = facilityService.getFacilitiRepository()
				.findByIsActiveTrueAndCreatedByIdOrAdminIdAndIsActiveTrue(user.getId(), user.getId());
		List<String> facilityIds = facilities.stream().map(facility -> facility.getId().toString())
				.collect(Collectors.toList());
		List<GlobalResponsePayload> globalResponsePayloads = globalResponseService.getGlobalResponseRepository()
				.findByFacilityIdIn(facilityIds);
		globalResponsePayloads = checkProfileExists(globalResponsePayloads);
		return globalResponsePayloads;

	}

	public List<GlobalResponsePayload> getProfileByContainerId(String containerId) {
		List<GlobalResponsePayload> globalResponsePayloads = globalResponseService.getGlobalResponseRepository()
				.findByContainerId(containerId);
		if (globalResponsePayloads == null || globalResponsePayloads.isEmpty())
			return Arrays.asList();
		globalResponsePayloads = checkProfileExists(globalResponsePayloads);
		return globalResponsePayloads;
	}

	public List<GlobalResponsePayload> getProfileByFacilityId(String facilityId) {
		List<GlobalResponsePayload> globalResponsePayloads = globalResponseService.getGlobalResponseRepository()
				.findByFacilityId(facilityId);
		if (globalResponsePayloads == null || globalResponsePayloads.isEmpty())
			return Arrays.asList();
		globalResponsePayloads = checkProfileExists(globalResponsePayloads);
		return globalResponsePayloads;
	}

	public List<GlobalResponsePayload> getProfileByGrowAreaId(String growAreaId) {
		List<GlobalResponsePayload> globalResponsePayloads = globalResponseService.getGlobalResponseRepository()
				.findByGatewayId(growAreaId);
		if (globalResponsePayloads == null || globalResponsePayloads.isEmpty())
			return Arrays.asList();
		globalResponsePayloads = checkProfileExists(globalResponsePayloads);
		return globalResponsePayloads;
	}

	public List<ProfileDTO> getProfilesByGrowAreaId(String growAreaId) {
		List<ProfileDTO> profileDTOs = null;
		List<Profile> profiles = profileService.getProfileByGatewayId(growAreaId);
		if (profiles != null && !profiles.isEmpty()) {
			profileDTOs = profiles.stream().map(this::convertEntityToDTOGrowProfiles).collect(Collectors.toList());
		}
		return profileDTOs;
	}

	public void deleteProfileByGatewayId(int gatewayId) {
		String gatewayId1 = Integer.toString(gatewayId);
		List<GlobalResponsePayload> globalResponsePayloads = getProfileByGrowAreaId(gatewayId1);
		if (globalResponsePayloads != null && !globalResponsePayloads.isEmpty()) {
			for (GlobalResponsePayload globalResponsePayload : globalResponsePayloads) {
				try {
					deleteProfile(globalResponsePayload.getProfileId());
					Thread.sleep(5000);

				} catch (HttpClientErrorException httpClientErrorException) {
					throw new HttpClientErrorException(HttpStatus.INTERNAL_SERVER_ERROR,
							"Error occurred while deleting profile");
				} catch (InterruptedException e) {
					LOGGER.info("Interrupt exception occured ");
					Thread.currentThread().interrupt();
				}
			}
		}
	}

	public List<GlobalResponsePayload> getProfileByGrowSectionId(String growSectionId) {
		List<GlobalResponsePayload> globalResponsePayloads = globalResponseService.getGlobalResponseRepository()
				.findByGrowSectionId(growSectionId);
		if (globalResponsePayloads == null || globalResponsePayloads.isEmpty())
			return Arrays.asList();
		globalResponsePayloads = checkProfileExists(globalResponsePayloads);
		return globalResponsePayloads;
	}

	public void deleteProfileByGrowSectionId(int growSectionId) {
		String growSectionId1 = Integer.toString(growSectionId);
		List<GlobalResponsePayload> globalResponsePayloads = getProfileByGrowSectionId(growSectionId1);
		if (globalResponsePayloads != null && !globalResponsePayloads.isEmpty()) {
			for (GlobalResponsePayload globalResponsePayload : globalResponsePayloads) {
				try {
					deleteProfile(globalResponsePayload.getProfileId());
					Thread.sleep(5000);

				} catch (HttpClientErrorException httpClientErrorException) {
					throw new HttpClientErrorException(HttpStatus.INTERNAL_SERVER_ERROR,
							"Error occurred while deleting profile");
				} catch (InterruptedException e) {
					LOGGER.info("Interrupt exception occured ");
					Thread.currentThread().interrupt();
				}
			}
		}
	}

	public List<ProfileSubDTO> getProfileAlertsByGrowSectionId(String growSectionId) {
		List<Profile> profiles = profileService.getProfileByGrowSectionId(growSectionId);
		if (profiles != null && !profiles.isEmpty())
			return getListProfile(profiles, growSectionId);
		else
			return Arrays.asList();
	}

	private List<GlobalResponsePayload> checkProfileExists(List<GlobalResponsePayload> globalResponsePayloads) {
		return globalResponsePayloads.stream().map(globalResponsePayload -> {
			if (globalResponsePayload.getProfileId() == null)
				return null;
			Optional<Profile> optional = profileService.getProfileRepository()
					.findById(globalResponsePayload.getProfileId());
			if (optional.isPresent())
				return globalResponsePayload;
			else
				return null;
		}).filter(Objects::nonNull).collect(Collectors.toList());

	}

	@SuppressWarnings("unchecked")
	public ProfileSubDTO getProfileByProfileId(int profileId) {
		Profile profile = profileService.getProfileRepository().findByIdAndIsActiveTrue(profileId);
		Condition[] conditions = null;
		List<Monitor> monitorList = new ArrayList<>();
		try {
			conditions = mapper.readValue(profile.getPayload().getConditions(), Condition[].class);
			monitorList = mapper.readValue(profile.getPayload().getMonitors(), monitorList.getClass());
		} catch (IOException e) {
			LOGGER.info("Error occured in conversion of string to object");
		}
		ProfileSubDTO profileDTO = modelMapper.map(profile, ProfileSubDTO.class);
		Map<String, ArrayList<ProfileConditionDTO>> resultMap = new HashMap<>();
		for (Condition condition : conditions) {
			if (condition.getActions().get(0).getAlertMessage().equals("OK"))
				resultMap.put("conditionGreen", mapToExpression(condition.getExpression()));
			else if (condition.getActions().get(0).getAlertMessage().equals("Soil needs attention"))
				resultMap.put("conditionBlue", mapToExpression(condition.getExpression()));
			else if (condition.getActions().get(0).getAlertMessage().equals("Battery needs attention"))
				resultMap.put("conditionYellow", mapToExpression(condition.getExpression()));
			else if (condition.getActions().get(0).getAlertMessage().equals("Temperature needs attention"))
				resultMap.put("conditionRed", mapToExpression(condition.getExpression()));

		}
		profileDTO.getPayload().setConditions((resultMap));
		profileDTO.getPayload().setMonitors(monitorList);
		return profileDTO;
	}

	public List<ProfileSubDTO> getListProfile(List<Profile> profiles, String growSectionId) {
		List<GrowSectionDevice> growSectionDevices = growSectionDeviceService
				.getActiveByGrowSectionId(Integer.parseInt(growSectionId));
		List<String> deviceHids = growSectionDevices.stream().map(device -> device.getDevice().getDeviceHId())
				.collect(Collectors.toList());
		List<ProfileSubDTO> profileSubDTOs = new ArrayList<>();
		for (Profile profile : profiles) {
			boolean addProfileToUi = false;
			Condition[] conditions = null;
			Monitor[] monitors = null;
			try {
				List<String> updatedDeviceHids = new ArrayList<>(deviceHids);
				conditions = mapper.readValue(profile.getPayload().getConditions(), Condition[].class);
				monitors = mapper.readValue(profile.getPayload().getMonitors(), Monitor[].class);
				List<String> profileDeviceHids = monitors[0].getDeviceHids();
				int initialProfileDeviceHidSize = profileDeviceHids.size();
				int initialDeviceHidsSize = updatedDeviceHids.size();
				if (initialProfileDeviceHidSize > initialDeviceHidsSize) {
					profileDeviceHids.removeAll(updatedDeviceHids);
				} else {
					updatedDeviceHids.removeAll(profileDeviceHids);
				}
				if (profileDeviceHids.size() != initialProfileDeviceHidSize
						|| updatedDeviceHids.size() != initialDeviceHidsSize) {
					addProfileToUi = true;
				}
			} catch (IOException e) {
				LOGGER.info("Error occured in get profile");
			}
			if (addProfileToUi) {
				ProfileSubDTO profileSubDTO = addProfilesAccordingDevice(profile, conditions, monitors);
				profileSubDTOs.add(profileSubDTO);
			}
		}
		return profileSubDTOs;
	}

	public ProfileSubDTO addProfilesAccordingDevice(Profile profile, Condition[] conditions, Monitor[] monitors) {
		ProfileSubDTO profileDTO = modelMapper.map(profile, ProfileSubDTO.class);
		Map<String, ArrayList<ProfileConditionDTO>> resultMap = new HashMap<>();
		for (Condition condition : conditions) {
			if (condition.getActions().get(0).getAlertMessage().equals("OK"))
				resultMap.put("conditionGreen", mapToExpression(condition.getExpression()));
			else if (condition.getActions().get(0).getAlertMessage().equals("Soil needs attention"))
				resultMap.put("conditionBlue", mapToExpression(condition.getExpression()));
			else if (condition.getActions().get(0).getAlertMessage().equals("Battery needs attention"))
				resultMap.put("conditionYellow", mapToExpression(condition.getExpression()));
			else if (condition.getActions().get(0).getAlertMessage().equals("Temperature needs attention"))
				resultMap.put("conditionRed", mapToExpression(condition.getExpression()));
		}
		profileDTO.getPayload().setConditions((resultMap));
		profileDTO.getPayload().setMonitors(Arrays.asList(monitors));
		return profileDTO;
	}

	ArrayList<ProfileConditionDTO> mapToExpression(String expression) {
		ArrayList<ProfileConditionDTO> profileConditionDTOs = new ArrayList<>();
		if (expression.contains("||") || expression.contains("&&")) {

			Map<Integer, String> map = getMapOfOperators(expression);
			ArrayList<Integer> sortedKeys = new ArrayList<>(map.keySet());
			Collections.sort(sortedKeys);
			String[] splitedexpressions = expression.split("(\\|\\|)|(&&)");
			int arraySize = sortedKeys.size();
			int i = 0;
			for (String splitedExpression : splitedexpressions) {
				String[] expressionEvaluationResult = splitedExpression.split("(==)|(!=)|(<=)|(>=)|(>)|(<)");
				String operator = getOperator(splitedExpression);
				if (arraySize > 0) {
					profileConditionDTOs.add(new ProfileConditionDTO(expressionEvaluationResult[0].trim(),
							expressionEvaluationResult[1].trim(), operator, map.get(sortedKeys.get(i))));
					arraySize = arraySize - 1;
					i = i + 1;
				} else {
					profileConditionDTOs.add(new ProfileConditionDTO(expressionEvaluationResult[0].trim(),
							expressionEvaluationResult[1].trim(), operator, ""));
				}
			}

		} else {
			String[] expressionEvaluationResult = expression.split("(==)|(!=)|(<=)|(>=)|(>)|(<)");
			String operator = getOperator(expression);
			profileConditionDTOs.add(new ProfileConditionDTO(expressionEvaluationResult[0].trim(),
					expressionEvaluationResult[1].trim(), operator, ""));

		}
		return profileConditionDTOs;
	}

	Map<Integer, String> getMapOfOperators(String expression) {
		Map<Integer, String> map = new HashMap<>();
		int orFirstIndex = expression.indexOf("||");
		int andFirstIndex = expression.indexOf("&&");
		while (orFirstIndex > 0) {
			orFirstIndex = orFirstIndex + 1;
			map.put(orFirstIndex, "||");
			orFirstIndex = expression.indexOf("||", orFirstIndex);
		}
		while (andFirstIndex > 0) {
			andFirstIndex = andFirstIndex + 1;
			map.put(andFirstIndex, "&&");
			andFirstIndex = expression.indexOf("&&", andFirstIndex);
		}
		return map;
	}

	public ProfileDTO convertEntityToDTO(Profile profile) {
		return modelMapper.map(profile, ProfileDTO.class);
	}

	public ProfileDTO convertEntityToDTOGrowProfile(Profile profile) {
		String profileName = profile.getName();
		String[] profileExp = profileName.split("_");
		profile.setName(profileExp[0]);
		return modelMapper.map(profile, ProfileDTO.class);

	}

	public ProfileDTO convertEntityToDTOGrowProfiles(Profile profile) {
		String profileName = profile.getPayload().getName();
		String[] profileExp = profileName.split("_");
		profile.getPayload().setName(profileExp[0]);
		return modelMapper.map(profile, ProfileDTO.class);

	}

	public Profile convertDTOToEntity(ProfileDTO profileDTO) {
		return modelMapper.map(profileDTO, Profile.class);
	}

	public ProfileAlert convertDTOToEntity(ProfileAlertDTO profileAlertDTO) {
		return modelMapper.map(profileAlertDTO, ProfileAlert.class);
	}

	private String getOperator(String str) {

		if (str.contains("&&")) {
			return "&&";
		} else if (str.contains("||")) {
			return "||";
		} else if (str.contains("==")) {
			return "==";
		} else if (str.contains("!=")) {
			return "!=";

		} else if (str.contains("<=")) {
			return "<=";

		} else if (str.contains(">=")) {
			return ">=";

		} else if (str.contains(">")) {
			return ">";

		} else if (str.contains("<")) {
			return "<";

		}
		return str;

	}

}
