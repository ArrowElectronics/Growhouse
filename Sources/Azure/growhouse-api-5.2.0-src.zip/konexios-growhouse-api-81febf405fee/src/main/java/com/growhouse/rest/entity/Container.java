/**
 * 
 */
package com.growhouse.rest.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

/**
 * @author dharita.chokshi
 *
 */
@Entity
@Table(name = "containers")
public class Container extends DefaultModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4706564946304327246L;

	@Column(name = "container_name")
	@NotBlank
	private String containerName;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "container_type_id")
	private ContainerType containerType;

	@OneToOne(fetch = FetchType.EAGER, cascade = { CascadeType.MERGE })
	@JoinColumn(name = "facility_id")
	private Facility facility;

	private String description;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "account_id",updatable=false)
	private Account account;
	
	/**
	 * @return the containerName
	 */
	public String getContainerName() {
		return containerName;
	}

	/**
	 * @param containerName
	 *            the containerName to set
	 */
	public void setContainerName(String containerName) {
		this.containerName = containerName;
	}

	/**
	 * @return the containerType
	 */
	public ContainerType getContainerType() {
		return containerType;
	}

	/**
	 * @param containerType
	 *            the containerType to set
	 */
	public void setContainerType(ContainerType containerType) {
		this.containerType = containerType;
	}

	/**
	 * @return the facility
	 */
	public Facility getFacility() {
		return facility;
	}

	/**
	 * @param facility
	 *            the facility to set
	 */
	public void setFacility(Facility facility) {
		this.facility = facility;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description
	 *            the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	@Override
	public String toString() {
		return "Container [containerName=" + containerName + ", containerType=" + containerType + ", facility="
		        + facility + ", description=" + description + ", account=" + account + "]";
	}



	

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	

}
