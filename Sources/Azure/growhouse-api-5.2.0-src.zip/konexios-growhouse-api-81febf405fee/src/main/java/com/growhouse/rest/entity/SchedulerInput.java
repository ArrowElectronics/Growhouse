package com.growhouse.rest.entity;

public class SchedulerInput {

	private String startTime;
	private Integer groupId;
	public String getStartTme() {
		return startTime;
	}
	public void setStartTme(String startTime) {
		this.startTime = startTime;
	}
	public Integer getGroupId() {
		return groupId;
	}
	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}
	@Override
	public String toString() {
		return "SchedulerInput [startTime=" + startTime + ", groupId=" + groupId + "]";
	}
	
	
}
