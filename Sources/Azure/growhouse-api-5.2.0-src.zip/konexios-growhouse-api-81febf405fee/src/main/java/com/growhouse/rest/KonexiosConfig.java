package com.growhouse.rest;

import java.util.Arrays;
import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties("konexios.api")
public class KonexiosConfig {
	private final static String DEFAULT_URL = "https://api-dev1.konexios.io";
	private final static String DEFAULT_MQTT_URL = "ssl://mqtt-dev1.konexios.io";
	private final static String DEFAULT_MQTT_PREFIX = "/pegasus";
	private final static String DEFAULT_AUTH_TOKEN = "invalid";
	private final static String DEFAULT_SECRET_KEY = "invalid";
	private final static String DEFAULT_APPLICATION_HID = "invalid";
	private final static String DEFAULT_ROLE = "growhouse";
	private final static String DEFAULT_LOGIN_SUFFIX = "growhouse-arrow";
	private final static String DEFAULT_RESET_PASSWORD_URL = "https://please-fix-me";

	private String url = DEFAULT_URL;
	private String mqttUrl = DEFAULT_MQTT_URL;
	private String mqttPrefix = DEFAULT_MQTT_PREFIX;
	private String authToken = DEFAULT_AUTH_TOKEN;
	private String secretKey = DEFAULT_SECRET_KEY;
	private String applicationHid = DEFAULT_APPLICATION_HID;
	private String loginSuffix = DEFAULT_LOGIN_SUFFIX;
	private String resetPasswordUrl = DEFAULT_RESET_PASSWORD_URL;
	private List<String> roleNames = Arrays.asList(DEFAULT_ROLE);

	public String buildDeviceHidByUidUrl(final String uid) {
		return String.format("%s/devices?_page=0&_size=100&uid=%s", prefix(), uid);
	}

	public String buildGatewayHidByUidUrl(final String uid) {
		return String.format("%s/gateway?_page=0&_size=100&uids=%s", prefix(), uid);
	}

	public String buildRuleTypeDevicesUrl() {
		return String.format("%s/devices?_page=0&type=edge_rule", prefix());
	}

	public String buildGatewayDevicesUrl() {
		return String.format("%s/devices?_page=0&type=gateway", prefix());
	}

	public String buildDeviceLastTelemetryUrl(final String deviceHid) {
		return String.format("%s/telemetries/devices/%s/latest", prefix(), deviceHid);
	}

	public String buildDeviceCommandUrl(final String gatewayHid, final String deviceHid) {
		return String.format("%s/gateways/%s/devices/%s/actions/command", prefix(), gatewayHid, deviceHid);
	}

	public String buildCreateActionDeviceUrl(final String deviceHid) {
		return String.format("%s/devices/%s/actions", prefix(), deviceHid);
	}

	public String getAuthTokenKey() {
		return "x-auth-token";
	}

	public String buildTelemetryUrl(final String deviceHid) {
		return String.format("%s/telemetries/devices/%s", prefix(), deviceHid);
	}

	public String buildDevicePropertyUrl(final String deviceHid) {
		return String.format("%s/telemetries/devices/%s/latest", prefix(), deviceHid);
	}

	public String buildDeviceUrl(final String deviceHid) {
		return String.format("%s/devices/%s", prefix(), deviceHid);
	}

	public String buildSetDeviceStateUrl(final String deviceHid) {
		return String.format("%s/devices/%s/state/request", prefix(), deviceHid);
	}

	public String buildDeleteDeviceUrl(final String deviceHid) {
		return String.format("%s/devices/%s", prefix(), deviceHid);
	}

	public String buildDeleteGatewayUrl(final String gatewayHid) {
		return String.format("%s/gateways/%s", prefix(), gatewayHid);
	}

	public String buildUserAuthUrl() {
		return String.format("%s/users/auth", prefix());
	}

	public String buildUserCreateUrl() {
		return String.format("%s/users", prefix());
	}

	public String buildUserUpdateUrl(final String userHid) {
		return String.format("%s/users/%s", prefix(), userHid);
	}

	public String buildUserFindUrl() {
		return String.format("%s/users/find", prefix());
	}

	public String buildUserResetPasswordUrl(final String userHid) {
		return String.format("%s/users/%s/reset-password", prefix(), userHid);
	}

	public String buildUserChangePasswordUrl(final String userHid) {
		return String.format("%s/users/%s/change-password", prefix(), userHid);
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(final String url) {
		this.url = url;
	}

	public String getAuthToken() {
		return authToken;
	}

	public void setAuthToken(final String authToken) {
		this.authToken = authToken;
	}

	public List<String> getRoleNames() {
		return roleNames;
	}

	public void setRoleNames(List<String> roleNames) {
		this.roleNames = roleNames;
	}

	private String prefix() {
		return String.format("%s/api/v1/kronos", url);
	}

	public String getLoginSuffix() {
		return loginSuffix;
	}

	public void setLoginSuffix(String loginSuffix) {
		this.loginSuffix = loginSuffix;
	}

	public String getResetPasswordUrl() {
		return resetPasswordUrl;
	}

	public void setResetPasswordUrl(String resetPasswordUrl) {
		this.resetPasswordUrl = resetPasswordUrl;
	}

	public String getSecretKey() {
		return secretKey;
	}

	public void setSecretKey(String secretKey) {
		this.secretKey = secretKey;
	}

	public String getApplicationHid() {
		return applicationHid;
	}

	public void setApplicationHid(String applicationHid) {
		this.applicationHid = applicationHid;
	}

	public String getMqttUrl() {
		return mqttUrl;
	}

	public void setMqttUrl(String mqttUrl) {
		this.mqttUrl = mqttUrl;
	}

	public String getMqttPrefix() {
		return mqttPrefix;
	}

	public void setMqttPrefix(String mqttPrefix) {
		this.mqttPrefix = mqttPrefix;
	}

	public String toKonexiosLogin(String login) {
		if (!login.endsWith(loginSuffix)) {
			login = login + loginSuffix;
		}
		return login;
	}

	public String toGrowhouseLogin(String login) {
		if (login.endsWith(loginSuffix)) {
			login = login.substring(0, login.length() - loginSuffix.length());
		}
		return login;
	}
}
