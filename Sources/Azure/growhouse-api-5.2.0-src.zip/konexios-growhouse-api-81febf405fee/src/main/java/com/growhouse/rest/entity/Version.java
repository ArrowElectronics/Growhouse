package com.growhouse.rest.entity;

public class Version {

	private String releaseVersion;

	public String getReleaseVersion() {
		return releaseVersion;
	}

	public void setReleaseVersion(String releaseVersion) {
		this.releaseVersion = releaseVersion;
	}

	
	
	
}
