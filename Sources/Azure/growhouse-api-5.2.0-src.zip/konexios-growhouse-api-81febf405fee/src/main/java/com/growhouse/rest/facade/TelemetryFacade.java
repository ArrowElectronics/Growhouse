package com.growhouse.rest.facade;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.growhouse.rest.KonexiosConfig;
import com.growhouse.rest.dto.TelemetryItemDTO;
import com.growhouse.rest.dto.TelemetryItemWithPagesDTO;
import com.growhouse.rest.entity.kronos.TelemetryItem;
import com.growhouse.rest.utils.Constants;

@Component
public class TelemetryFacade {

	private static final Logger LOGGER = LogManager.getLogger(TelemetryFacade.class);

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private KonexiosConfig config;

	@SuppressWarnings("unchecked")
	public TelemetryItemWithPagesDTO fetchTelemetryFromArrowConnect(String deviceHId, String fromTimestamp,
			String toTimestamp, String propertyName, Integer pageNumber) {
		String url = config.buildTelemetryUrl(deviceHId);

		List<TelemetryItem> telemetry = new ArrayList<>();
		List<TelemetryItemDTO> telemetryItemDTOs = new ArrayList<>();
		TelemetryItemWithPagesDTO telemetryItemWithPagesDTO = new TelemetryItemWithPagesDTO();

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set(config.getAuthTokenKey(), config.getAuthToken());

		UriComponentsBuilder builder = null;
		if (pageNumber == null) {
			builder = UriComponentsBuilder.fromHttpUrl(url).queryParam(Constants.FROM_TIMESTAMP, fromTimestamp)
					.queryParam(Constants.TO_TIMESTAMP, toTimestamp)
					.queryParam(Constants.TELEMETRY_NAMES, propertyName);

		} else {
			builder = UriComponentsBuilder.fromHttpUrl(url).queryParam(Constants.FROM_TIMESTAMP, fromTimestamp)
					.queryParam(Constants.TO_TIMESTAMP, toTimestamp).queryParam(Constants.TELEMETRY_NAMES, propertyName)
					.queryParam(Constants.PAGE, pageNumber);

		}
		HttpEntity<String> entity = new HttpEntity<>(headers);
		try {
			ResponseEntity<Map> response = restTemplate.exchange(builder.toUriString(), HttpMethod.GET, entity,
					Map.class);
			if (response.getStatusCode() == HttpStatus.OK) {
				telemetry = (List<TelemetryItem>) response.getBody().get("data");

				int pages = Integer.parseInt(response.getBody().get("totalPages").toString());
				telemetryItemWithPagesDTO.setPages(pages);
			}
		} catch (HttpClientErrorException exception) {
			LOGGER.info("unable to get profileHid :" + exception);
		}
		if (telemetry != null && !telemetry.isEmpty()) {

			List<TelemetryItem> telemetryItems = objectMapper.convertValue(telemetry,
					new TypeReference<List<TelemetryItem>>() {
					});

			for (TelemetryItem telemetryItem : telemetryItems) {
				TelemetryItemDTO telemetryItemDTO = modelMapper.map(telemetryItem, TelemetryItemDTO.class);
				telemetryItemDTO.setValue(telemetryItem.value().toString());
				telemetryItemDTOs.add(telemetryItemDTO);
			}
		}
		telemetryItemWithPagesDTO.setTelemetryItemDTOs(telemetryItemDTOs);
		return telemetryItemWithPagesDTO;
	}

}
