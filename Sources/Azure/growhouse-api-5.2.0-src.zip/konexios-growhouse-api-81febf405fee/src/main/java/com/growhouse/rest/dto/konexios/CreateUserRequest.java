package com.growhouse.rest.dto.konexios;

import java.util.List;

/**
 * CreateUserRequest
 */
public class CreateUserRequest {
    private String login;
    private String password;
    private Contact contact;
    private List<String> roleNames;

    public CreateUserRequest login(String login) {
        this.login = login;
        return this;
    }

    public CreateUserRequest password(String password) {
        this.password = password;
        return this;
    }

    public CreateUserRequest contact(Contact contact) {
        this.contact = contact;
        return this;
    }

    public CreateUserRequest roleNames(List<String> roleNames) {
        this.roleNames = roleNames;
        return this;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Contact getContact() {
        return contact;
    }

    public void setContact(Contact contact) {
        this.contact = contact;
    }

    public List<String> getRoleNames() {
        return roleNames;
    }

    public void setRoleNames(List<String> roleNames) {
        this.roleNames = roleNames;
    }
}