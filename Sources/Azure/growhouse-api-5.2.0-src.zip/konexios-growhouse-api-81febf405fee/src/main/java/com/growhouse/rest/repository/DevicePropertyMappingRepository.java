package com.growhouse.rest.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;

import com.growhouse.rest.entity.DevicePropertyMapping;

public interface DevicePropertyMappingRepository extends JpaRepository<DevicePropertyMapping, Integer>{

	public List<DevicePropertyMapping> findByDeviceId(int deviceId);
	
	@Transactional
	@Modifying
	public void deleteByDeviceId(int deviceId);
	
	
	@Transactional
	@Modifying
	public void  deleteByDeviceGrowAreaId(int gatewayId);
}
