/**
 * 
 */
package com.growhouse.rest.facade;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.growhouse.rest.entity.GrowArea;
import com.growhouse.rest.entity.kronos.KronosData;
import com.growhouse.rest.services.IRuleService;
import com.growhouse.rest.services.IGrowAreaService;

/**
 * @author dharita.chokshi
 *
 */
@Component
public class RuleFacade {

	public static final Logger LOGGER = LoggerFactory.getLogger(RuleFacade.class);

	@Autowired
	private IGrowAreaService growAreaService;

	@Autowired
	private IRuleService alertService;

	public List<String> ruledGrowAreaHIdsByFacilityId(int facilityId) {
		// get list of grow areas
		List<GrowArea> growAreas = growAreaService.getGrowAreasByFacilityId(facilityId);
		return getRuledGrowAreaList(growAreas);
	}

	public List<String> ruledGrowAreaHIdsByContainerId(int containerId) {
		// get list of grow areas
		List<GrowArea> growAreas = growAreaService.getGrowAreasByContainerId(containerId);
		return getRuledGrowAreaList(growAreas);
	}

	public List<String> ruledGrowAreaHIdsByGrowAreaId(int growAreaId) {
		// get list of grow areas
		GrowArea ga = growAreaService.getGrowAreaById(growAreaId);
		return getRuledGrowAreaList(Arrays.asList(ga));
	}

	private List<String> getRuledGrowAreaList(List<GrowArea> growAreas) {
		List<String> growAreaHIds = new ArrayList<>();
		if (growAreas != null && !growAreas.isEmpty()) {

			// get list devices which are having alert rules
			List<KronosData> ruleDevices = alertService.getRuleDevices();

			// get list of grow area hids that are matching with gateway hids of rule device
			if (ruleDevices != null) {
				growAreaHIds = ruleDevices.stream()
						.filter(ruleDevice -> (growAreas.stream()
								.filter(ga -> ga.getGrowAreaHId().equals(ruleDevice.getGatewayHid())).count()) > 0)
						.map(KronosData::getGatewayHid).distinct().collect(Collectors.toList());
			}
		}
		return growAreaHIds;
	}

}
