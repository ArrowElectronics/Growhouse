package com.growhouse.rest.smtp;

import java.util.Arrays;
import java.util.Properties;
import java.util.stream.Collectors;

import javax.mail.Authenticator;
import javax.mail.Message.RecipientType;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

@Component
public class EmailSender {
	public static final Logger LOGGER = LoggerFactory.getLogger(EmailSender.class);

	@Autowired
	private SmtpProperties properties;

	public void send(String[] to, String[] cc, String subject, String body, boolean isHtml) {
		Assert.notEmpty(to, "to addresses is empty");
		Assert.hasText(subject, "subject is empty");
		Assert.hasText(body, "body is empty");

		Properties props = new Properties();
		props.put("mail.smtp.auth", properties.getAuth());
		props.put("mail.smtp.starttls.enable", properties.getStarttls());
		props.put("mail.smtp.host", properties.getHost());
		props.put("mail.smtp.port", properties.getPort());

		Session session = null;
		if (StringUtils.isNotEmpty(properties.getUserName()) && StringUtils.isNotEmpty(properties.getPassword())) {
			session = Session.getInstance(props, new Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(properties.getUserName(), properties.getPassword());
				}
			});
		} else {
			session = Session.getDefaultInstance(props);
		}

		try {
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(properties.getFrom()));
			message.setRecipients(RecipientType.TO, convert(to));
			if (cc != null && cc.length > 0) {
				message.setRecipients(RecipientType.CC, convert(cc));
			}
			message.setSubject(subject);
			if (!isHtml) {
				message.setText(body, "utf-8");
			} else {
				message.setContent(body, "text/html;charset=utf-8");
			}

			LOGGER.info("sending email to[0]: " + to[0]);
			Transport.send(message);
		} catch (MessagingException t) {
			throw new RuntimeException("Error sending email", t);
		}
	}

	private InternetAddress[] convert(String[] addresses) throws AddressException {
		if (addresses != null && addresses.length > 0) {
			return InternetAddress.parse(Arrays.stream(addresses).collect(Collectors.joining(",")));
		} else {
			return new InternetAddress[0];
		}
	}
}