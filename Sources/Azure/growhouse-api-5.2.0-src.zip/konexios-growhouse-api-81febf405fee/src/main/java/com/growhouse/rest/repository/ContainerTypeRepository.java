/**
 * 
 */
package com.growhouse.rest.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.growhouse.rest.entity.ContainerType;

/**
 * @author dharita.chokshi
 *
 */
@Repository
public interface ContainerTypeRepository extends JpaRepository<ContainerType, Integer> {

	public List<ContainerType> findByIsActiveTrue();

}
