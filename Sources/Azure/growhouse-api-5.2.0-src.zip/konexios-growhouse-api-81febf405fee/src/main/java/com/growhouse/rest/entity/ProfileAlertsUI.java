package com.growhouse.rest.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class ProfileAlertsUI implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8269651165413838838L;

	@Column(name = "id")
	@Id
	private Integer id;

	@Column(name = "alert_message")
	private String alertMessage;

	@Column(name = "container_id")
	private String containerId;

	@Column(name = "container_name")
	private String containerName;

	@Column(name = "facility_id")
	private String facilityId;

	@Column(name = "facility_name")
	private String facilityName;

	@Column(name = "gateway_id")
	private String gatewayId;

	@Column(name = "gateway_name")
	private String gatewayName;

	@Column(name = "grow_section_id")
	private Integer growSectionId;

	@Column(name = "grow_section_name")
	private String growSectionName;

	@Column(name = "profile_id")
	private Integer profileId;

	@Column(name = "profile_name")
	private String profileName;

	@Column(name = "properties")
	private String properties;

	@Column(name = "timestamp")
	private Long timestamp;

	@Column(name = "profile_virtual_name")
	private String profileVirtualName;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getAlertMessage() {
		return alertMessage;
	}

	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	public String getContainerId() {
		return containerId;
	}

	public void setContainerId(String containerId) {
		this.containerId = containerId;
	}

	public String getContainerName() {
		return containerName;
	}

	public void setContainerName(String containerName) {
		this.containerName = containerName;
	}

	public String getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(String facilityId) {
		this.facilityId = facilityId;
	}

	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public String getGatewayId() {
		return gatewayId;
	}

	public void setGatewayId(String gatewayId) {
		this.gatewayId = gatewayId;
	}

	public String getGatewayName() {
		return gatewayName;
	}

	public void setGatewayName(String gatewayName) {
		this.gatewayName = gatewayName;
	}

	public Integer getGrowSectionId() {
		return growSectionId;
	}

	public void setGrowSectionId(Integer growSectionId) {
		this.growSectionId = growSectionId;
	}

	public String getGrowSectionName() {
		return growSectionName;
	}

	public void setGrowSectionName(String growSectionName) {
		this.growSectionName = growSectionName;
	}

	public Integer getProfileId() {
		return profileId;
	}

	public void setProfileId(Integer profileId) {
		this.profileId = profileId;
	}

	public String getProfileName() {
		return profileName;
	}

	public void setProfileName(String profileName) {
		this.profileName = profileName;
	}

	public String getProperties() {
		return properties;
	}

	public void setProperties(String properties) {
		this.properties = properties;
	}

	public Long getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Long timestamp) {
		this.timestamp = timestamp;
	}

	public String getProfileVirtualName() {
		return profileVirtualName;
	}

	public void setProfileVirtualName(String profileVirtualName) {
		this.profileVirtualName = profileVirtualName;
	}

	@Override
	public String toString() {
		return "ProfileAlertsUI [id=" + id + ", alertMessage=" + alertMessage + ", containerId=" + containerId
				+ ", containerName=" + containerName + ", facilityId=" + facilityId + ", facilityName=" + facilityName
				+ ", gatewayId=" + gatewayId + ", gatewayName=" + gatewayName + ", growSectionId=" + growSectionId
				+ ", growSectionName=" + growSectionName + ", profileId=" + profileId + ", profileName=" + profileName
				+ ", properties=" + properties + ", timestamp=" + timestamp + ", profileVirtualName="
				+ profileVirtualName + "]";
	}

}
