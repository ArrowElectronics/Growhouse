package com.growhouse.rest.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GrowAreaOutOfNetworkDTO {

	@JsonProperty("grow_area_id")
	private Integer id;
	
	@JsonProperty("grow_area_name")
	private String growAreaName;
	
	@JsonProperty("facility_id")
	private Integer facilityId;
	
	@JsonProperty("facility_name")
	private String facilityName;
	
	private Integer containerId;
	
	private String containerName;

	private Long latestHeartbeat;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getGrowAreaName() {
		return growAreaName;
	}

	public void setGrowAreaName(String growAreaName) {
		this.growAreaName = growAreaName;
	}

	public Integer getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(Integer facilityId) {
		this.facilityId = facilityId;
	}

	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public Integer getContainerId() {
		return containerId;
	}

	public void setContainerId(Integer containerId) {
		this.containerId = containerId;
	}

	public String getContainerName() {
		return containerName;
	}

	public void setContainerName(String containerName) {
		this.containerName = containerName;
	}

	public Long getLatestHeartbeat() {
		return latestHeartbeat;
	}

	public void setLatestHeartbeat(Long latestHeartbeat) {
		this.latestHeartbeat = latestHeartbeat;
	}

	@Override
	public String toString() {
		return "GrowAreaOutOfNetworkDTO [id=" + id + ", growAreaName=" + growAreaName + ", facilityId=" + facilityId
				+ ", facilityName=" + facilityName + ", containerId=" + containerId + ", containerName=" + containerName
				+ ", latestHeartbeat=" + latestHeartbeat + "]";
	}

	
}
