/**
 * 
 */
package com.growhouse.rest.facade;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.growhouse.rest.dto.CountryDTO;
import com.growhouse.rest.entity.Country;
import com.growhouse.rest.services.ICountryService;

/**
 * @author dharita.chokshi
 *
 */
@Component
public class CountryFacade {

	public static final Logger LOGGER = LoggerFactory.getLogger(CountryFacade.class);

	@Autowired
	private ICountryService countryService;

	@Autowired
	private ModelMapper modelMapper;

	public List<CountryDTO> getCountries() {
		List<CountryDTO> countryDTOs = new ArrayList<>();
		List<Country> countries = countryService.getAllCountries();
		if (countries != null && !countries.isEmpty()) {
			countryDTOs = countries.stream().map(this::convertEntityToDTO).collect(Collectors.toList());
		}
		return countryDTOs;
	}

	private CountryDTO convertEntityToDTO(Country country) {
		return modelMapper.map(country, CountryDTO.class);
	}

}
