/**
 * 
 */
package com.growhouse.rest.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.growhouse.rest.entity.Device;

/**
 * @author dharita.chokshi
 *
 */
@Repository
public interface DeviceRepository extends JpaRepository<Device, Integer> {

	public List<Device> findByIsActiveTrue();
	

	public List<Device> findByDeviceTypeIdAndIsActiveTrue(int deviceTypeId);
	
	public Optional<Device> findByIdAndIsActiveTrue(int deviceId);

	public List<Device> findByGrowAreaIdAndIsActiveTrue(int growAreaId);
	
	public List<Device> findByIsActiveTrueAndGrowAreaIsActiveTrueAndGrowAreaIdOrderByCreatedTimestampDesc(int growAreaId);
	
	public List<Device> findByIsActiveTrueAndGrowAreaIsActiveTrueAndGrowAreaContainerIsActiveTrueAndGrowAreaContainerIdAndGrowAreaContainerFacilityAdminIdOrIsActiveTrueAndGrowAreaIsActiveTrueAndGrowAreaContainerIsActiveTrueAndGrowAreaContainerIdAndGrowAreaContainerFacilityCreatedById(int containerId,int adminId,int containerId1,int userId);
	
	public List<Device> findByGrowSectionIdAndIsActiveTrue(int growSectionId);
	
	public List<Device> findByGrowAreaIdAndDeviceTypeIdAndIsActiveTrueOrderByCreatedTimestampDesc(int growAreaId, int deviceTypeId);

	public List<Device> findByIsActiveTrueAndGrowAreaIdIn(List<Integer> growareaIdList);
	
	public int countByIsActiveTrueAndGrowAreaIdIn(List<Integer> growareaIdList);
	
	public Device findByDeviceUIdAndIsActiveTrue(String deviceUID);
	
	public Device findByDeviceHIdAndIsActiveTrue(String deviceHID);
	
	@Modifying(clearAutomatically = true)
	@Transactional
	@Query(value = "update devices d set d.status = ?1 where d.deviceuid = ?2 and d.is_active=1", nativeQuery = true)
	public int updateDeviceLatestStatus(boolean status,String uid);
	
	@Modifying(clearAutomatically = true)
	@Transactional
	@Query(value = "update devices d set d.status = ?1 where d.grow_area = ?2 and d.is_active=1", nativeQuery = true)
	public int updateDeviceLatestStatusByGatewayId(boolean status,String gatewayId);
	
	public int countByIsActiveTrueAndGrowAreaIdAndStatus(int gatewayId,boolean status);
	
	public int countByIsActiveTrueAndGrowAreaIdAndStatusAndDeviceTypeId(int gatewayId,boolean status,int deviceType);
}
