package com.arrow.selene.service;

import java.util.List;

import org.apache.commons.lang3.Validate;

import com.arrow.selene.dao.RuleDao;
import com.arrow.selene.data.Rule;

public class RuleService extends ServiceAbstract {

	private static class SingletonHolder {
		private static final RuleService SINGLETON = new RuleService();
	}

	public static RuleService getInstance() {
		return SingletonHolder.SINGLETON;
	}

	private final RuleDao ruleDao;

	protected RuleService() {
		super();
		ruleDao = RuleDao.getInstance();
	}

	public Rule save(Rule rule) {
		Validate.notNull(rule, "rule is null");
		ruleDao.update(rule);
		return rule;
	}

	public void delete(String ruleHid) {
		Validate.notBlank(ruleHid, "ruleHid is blank");
		ruleDao.delete(ruleHid);
		logInfo("delete", "Rule deleted from database successfully...!");

	}

	public List<Rule> findAll() {
		return getRuleDao().findAll();
	}

	public Rule find(String ruleHid) {
		return getRuleDao().findByHid(ruleHid);
	}

	public boolean createRule(Rule rule) {
		try {
			getRuleDao().insert(rule);
		} catch (Exception e) {
			return false;
		}
		return true;
	}

	protected RuleDao getRuleDao() {
		return ruleDao;
	}
}
