package com.arrow.selene.data;

public class Azure extends BaseEntity {
	private static final long serialVersionUID = -3341445375601081508L;

    @Deprecated
    private String host = "";
    @Deprecated
    private String accessKey = "";

    private String connectionString;

    @Deprecated
    public String getHost() {
        return host;
    }

    @Deprecated
    public void setHost(String host) {
        this.host = host;
    }

    @Deprecated
    public String getAccessKey() {
        return accessKey;
    }

    @Deprecated
    public void setAccessKey(String accessKey) {
        this.accessKey = accessKey;
    }

    public String getConnectionString() {
        return connectionString;
    }

    public void setConnectionString(String connectionString) {
        this.connectionString = connectionString;
    }
}