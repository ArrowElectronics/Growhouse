package com.arrow.selene.databus;

import org.apache.commons.lang3.Validate;

import com.arrow.selene.SeleneException;

public class DatabusFactory {
	public static Databus createDatabus(String databusType) {
		Validate.notBlank(databusType, "databusType is empty");
		switch (databusType) {
			case Databus.REDIS: {
				return new RedisDatabus();
			}
			case Databus.RABBITMQ: {
				return new RabbitmqDatabus();
			}
			case Databus.FILE: {
				return FileDatabus.getInstance();
			}
			case Databus.MQTT: {
				return MqttDatabus.getInstance();
			}
			default: {
				throw new SeleneException("unsupported databus type: " + databusType);
			}
		}
	}
}
