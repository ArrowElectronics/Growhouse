package com.arrow.selene.edge.computing.models;

import java.io.Serializable;
import java.util.List;

public class MonitorModel implements Serializable{
	private static final long serialVersionUID = 541801795333784232L;

	private String gatewayHid;
	private List<String> deviceHids;

	public List<String> getDeviceHids() {
		return deviceHids;
	}

	public void setDeviceHids(List<String> deviceHids) {
		this.deviceHids = deviceHids;
	}

	public String getGatewayHid() {
		return gatewayHid;
	}

	public void setGatewayHid(String gatewayHid) {
		this.gatewayHid = gatewayHid;
	}

}
