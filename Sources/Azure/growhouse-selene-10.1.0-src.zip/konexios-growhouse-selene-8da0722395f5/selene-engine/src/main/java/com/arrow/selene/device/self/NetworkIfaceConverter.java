package com.arrow.selene.device.self;

import org.apache.commons.beanutils.converters.AbstractConverter;

import com.arrow.acs.JsonUtils;

public class NetworkIfaceConverter extends AbstractConverter {
	@Override
	protected <T> T convertToType(Class<T> type, Object value) throws Throwable {
		return type.cast(JsonUtils.fromJson(value.toString(), NetworkIfaceHolder.class));
	}

	@Override
	protected Class<?> getDefaultType() {
		return NetworkIfaceHolder.class;
	}
}
