package com.arrow.selene.engine.cloud;

import com.arrow.acn.client.cloud.azure.AzureConnector;
import com.arrow.acn.client.model.AzureConfigModel;
import com.arrow.acn.client.model.CloudPlatform;
import com.arrow.selene.data.Azure;
import com.arrow.selene.device.self.SelfModule;
import com.arrow.selene.engine.Engine;
import com.arrow.selene.engine.service.AzureService;
import com.arrow.selene.service.CryptoService;

public class AzureModule extends CloudModuleAbstract {
	private static class SingletonHolder {
		static final AzureModule SINGLETON = new AzureModule();
	}

	public static AzureModule getInstance() {
		return SingletonHolder.SINGLETON;
	}

	private AzureModule() {
		super(CloudPlatform.Azure);
	}

	@Override
	protected void startClient() {
		String method = "startClient";
		logInfo(method, "...");
		Azure azure = AzureService.getInstance().findOne();
		if (azure == null) {
			logInfo(method, "Azure profile not found");
		} else {
			if (azure.isEnabled()) {
				AzureConfigModel model = new AzureConfigModel();
				model.setConnectionString(CryptoService.getInstance().decrypt(azure.getConnectionString()));
				// CryptoService crypto = CryptoService.getInstance();
				// model.setHost(azure.getHost());
				// model.setAccessKey(crypto.decrypt(azure.getAccessKey()));
				logInfo(method, "starting azure connector ...");
				connector = new AzureConnector(Engine.getInstance().getAcnClient(),
						SelfModule.getInstance().getGateway().getHid(), model);
				connector.start();
			} else {
				logInfo(method, "WARNING: Azure profile is disabled");
			}
		}
		super.startClient();
		logInfo(method, "ready!");
	}

	@Override
	public void stop() {
		super.stop();
		if (connector != null) {
			connector.stop();
		}
	}
}
