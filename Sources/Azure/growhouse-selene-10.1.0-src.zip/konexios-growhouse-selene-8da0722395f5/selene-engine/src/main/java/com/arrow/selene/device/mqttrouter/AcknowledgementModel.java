package com.arrow.selene.device.mqttrouter;

public class AcknowledgementModel {

	private static final long serialVersionUID = 5339586104827426450L;

	private String type;
	private String deviceUid;
	private boolean result;

	public AcknowledgementModel() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void setType(String type) {
		this.type = type;
	}

	public void setDeviceUid(String deviceUid) {
		this.deviceUid = deviceUid;
	}

	public void setResult(boolean result) {
		this.result = result;
	}

}
