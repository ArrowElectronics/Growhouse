package com.arrow.selene.device.mqtt;

import com.arrow.selene.engine.DeviceInfo;

public class MqttDeviceInfo extends DeviceInfo {
	private static final long serialVersionUID = -2745289713252575643L;
}
