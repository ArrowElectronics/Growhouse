package com.arrow.selene.edge.computing;

import com.arrow.selene.device.edge.RuleEngineData;

public interface RuleAlertProcessor {
	void processAlert(RuleEngineData alertModel);
}
