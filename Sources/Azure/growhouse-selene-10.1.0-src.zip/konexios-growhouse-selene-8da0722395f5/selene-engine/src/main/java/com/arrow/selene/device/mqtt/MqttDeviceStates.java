package com.arrow.selene.device.mqtt;

import com.arrow.selene.engine.state.DeviceStates;

public class MqttDeviceStates extends DeviceStates {
	private static final long serialVersionUID = -6026441372893066565L;
}
