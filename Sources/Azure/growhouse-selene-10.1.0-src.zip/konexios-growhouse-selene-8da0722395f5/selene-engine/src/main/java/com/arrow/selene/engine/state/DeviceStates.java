package com.arrow.selene.engine.state;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.ConvertUtils;

import com.arrow.selene.SeleneException;

public class DeviceStates implements Serializable {
	private static final long serialVersionUID = -3959893515884572620L;

	static {
		ConvertUtils.register(new StatesConverter(null), State.class);
	}

	public Map<String, String> exportStates() {
		try {
			return BeanUtils.describe(this);
		} catch (Exception e) {
			throw new SeleneException("Error exporting states", e);
		}
	}

	public Map<String, String> importStates(Map<String, State> states) {
		Map<String, String> result = new HashMap<>();
		Map<String, String> currentStates = exportStates();
		for (Entry<String, ? extends State> entry : states.entrySet()) {
			if (!Objects.equals(currentStates.get(entry.getKey()), entry.getValue().toString())) {
				result.put(entry.getKey(), entry.getValue().getValue());
			}
		}
		try {
			BeanUtils.populate(this, states);
		} catch (Exception e) {
			throw new SeleneException("Error importing states", e);
		}
		return result;
	}
}
