package com.arrow.selene.edge.computing.models;

import java.io.Serializable;
import java.util.Map;

public class DevicesModel implements Serializable {
	private static final long serialVersionUID = 2157799281960581366L;

	private String deviceHid;
	private Map<String, Object> states;

	public String getDeviceHid() {
		return deviceHid;
	}

	public void setDeviceHid(String deviceHid) {
		this.deviceHid = deviceHid;
	}

	public Map<String, Object> getStates() {
		return states;
	}

	public void setStates(Map<String, Object> states) {
		this.states = states;
	}

}
