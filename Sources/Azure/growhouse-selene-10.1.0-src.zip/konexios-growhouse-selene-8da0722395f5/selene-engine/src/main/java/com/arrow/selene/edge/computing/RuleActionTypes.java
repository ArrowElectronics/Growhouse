package com.arrow.selene.edge.computing;

public interface RuleActionTypes {
	public String SET_DEVICE_STATE = "set_device_state";
	public String SEND_ALARM = "send_alarm";
}
