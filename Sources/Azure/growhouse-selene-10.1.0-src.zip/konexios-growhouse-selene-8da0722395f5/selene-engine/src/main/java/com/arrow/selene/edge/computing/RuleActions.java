package com.arrow.selene.edge.computing;

import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.arrow.selene.device.self.SelfModule;
import com.arrow.selene.edge.computing.models.ActionModel;
import com.arrow.selene.edge.computing.models.OperationModel;
import com.arrow.selene.engine.DeviceModule;
import com.arrow.selene.engine.service.ModuleService;
import com.arrow.selene.engine.state.State;

public class RuleActions {

	private static Map<String, String> predefinedKeys = new HashMap<>();

	public static void fillPredefinedKeys() {
		predefinedKeys.put("gatewayHid", SelfModule.getInstance().getGateway().getHid());
		predefinedKeys.put("timestamp", String.valueOf(Instant.now().toEpochMilli()));

	}

	public static void setDeviceState(ActionModel actionModel) {
		List<OperationModel> operations = actionModel.getOperations();
		operations.forEach(op -> {
			op.getDevices().forEach(dev -> {
				DeviceModule<?, ?, ?, ?> deviceModule = ModuleService.getInstance().findDevice(dev.getDeviceHid());
				Map<String, State> states = new HashMap<>();
				deviceModule.getShadow().entrySet().forEach(e -> {
					states.put(e.getKey(), new State().withValue(String.valueOf(e.getValue().getValue()))
					        .withTimestamp(Instant.now()));
				});
				ModuleService.getInstance().updateStates(deviceModule, states);
			});
			;
		});
	}

	public static void sendAlarm(String ruleHid, ActionModel actionModel) {
		prepareAlarmResponse(ruleHid, actionModel);

		// Call API to send the payload
	}

	public static String prepareAlarmResponse(String ruleHid, ActionModel actionModel) {
		String alertMessage = actionModel.getAlertMessage();
		// if (responsePayload == null)
		// responsePayload = new HashMap<>();
		// responsePayload.putAll(predefinedKeys);
		// return replaceTokens(responsePayload, keys);
		return alertMessage;
	}

	public static String replaceTokens(String text, Map<String, String> replacements) {
		Pattern pattern = Pattern.compile("\\{\\{(.+?)\\}\\}");
		Matcher matcher = pattern.matcher(text);
		StringBuffer buffer = new StringBuffer();

		while (matcher.find()) {
			String replacement = replacements.get(matcher.group(1));
			if (replacement != null) {
				matcher.appendReplacement(buffer, replacement);
				// // to allow a replacement keyword containing '#' char
				// matcher.appendReplacement(buffer, "");
				// buffer.append(replacement);
			}
		}
		matcher.appendTail(buffer);
		return buffer.toString();
	}
}
