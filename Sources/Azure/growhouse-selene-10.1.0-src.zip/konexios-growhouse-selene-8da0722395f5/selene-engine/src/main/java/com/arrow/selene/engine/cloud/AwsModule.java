package com.arrow.selene.engine.cloud;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

import com.arrow.acn.client.api.DeviceStateApi;
import com.arrow.acn.client.cloud.DeviceStateRequestListener;
import com.arrow.acn.client.cloud.aws.AwsConnector;
import com.arrow.acn.client.model.CloudPlatform;
import com.arrow.acn.client.model.DeviceStateRequestModel;
import com.arrow.acn.client.model.aws.ConfigModel;
import com.arrow.acs.AcsUtils;
import com.arrow.acs.JsonUtils;
import com.arrow.selene.SeleneException;
import com.arrow.selene.data.Aws;
import com.arrow.selene.device.self.SelfModule;
import com.arrow.selene.engine.DeviceModule;
import com.arrow.selene.engine.Engine;
import com.arrow.selene.engine.service.AwsService;
import com.arrow.selene.engine.service.ModuleService;
import com.arrow.selene.engine.state.State;
import com.arrow.selene.service.CryptoService;

public class AwsModule extends CloudModuleAbstract implements DeviceStateRequestListener {
	private static class SingletonHolder {
		static final AwsModule SINGLETON = new AwsModule();
	}

	public static AwsModule getInstance() {
		return SingletonHolder.SINGLETON;
	}

	public AwsModule() {
		super(CloudPlatform.Aws);
	}

	@Override
	protected void startClient() {
		String method = "startClient";
		Aws aws = AwsService.getInstance().findOne();
		if (aws == null) {
			logInfo(method, "AWS profile not found");
		} else {
			logInfo(method, "found AWS module, host: %s", aws.getHost());
			if (aws.isEnabled()) {
				ConfigModel model = new ConfigModel();
				CryptoService crypto = CryptoService.getInstance();
				model.setCaCert(crypto.decrypt(aws.getRootCert()));
				model.setClientCert(crypto.decrypt(aws.getClientCert()));
				model.setPrivateKey(crypto.decrypt(aws.getPrivateKey()));
				model.setHost(aws.getHost());

				logInfo(method, "instantiating AWSConnector ...");
				connector = new AwsConnector(Engine.getInstance().getAcnClient(),
						SelfModule.getInstance().getGateway().getHid(), model);
				connector.setDeviceStateRequestListener(this);

				connector.start();

				// sync up deviceHids
				getDeviceHids().forEach(deviceHid -> connector.addDeviceHid(deviceHid));

				logInfo(method, "AwsConnector started!");
			} else {
				logInfo(method, "WARNING: AWS profile is disabled");
			}
		}
		super.startClient();
		logInfo(method, "started successfully");
	}

	@Override
	public void stop() {
		super.stop();
		if (connector != null) {
			connector.stop();
		}
	}

	@Override
	protected boolean isBatchSendingMode() {
		return false;
	}

	@Override
	public void receive(String deviceHid, DeviceStateRequestModel model) {
		String method = "receive";

		logInfo(method, "deviceHid: %s, model: %s", deviceHid, JsonUtils.toJson(model));

		Instant timestamp = Instant.parse(model.getTimestamp());
		Map<String, String> states = model.getStates();
		String transHid = states.remove("transHid");
		DeviceStateApi deviceStateApi = Engine.getInstance().getAcnClient().getDeviceStateApi();
		DeviceModule<?, ?, ?, ?> deviceModule = ModuleService.getInstance().findDevice(deviceHid);
		if (deviceModule == null) {
			throw new SeleneException("Device not found: " + deviceHid);
		}

		if (!AcsUtils.isEmpty(transHid)) {
			deviceStateApi.transReceived(deviceHid, transHid);
		}

		try {
			Map<String, State> updateStates = new HashMap<>();
			states.forEach((name, value) -> {
				updateStates.put(name, new State().withValue(value).withTimestamp(timestamp));
			});
			logInfo(method, "updating states ...");
			if (ModuleService.getInstance().updateStates(deviceModule, updateStates)) {
				if (!AcsUtils.isEmpty(transHid)) {
					deviceStateApi.transSucceeded(deviceHid, transHid);
				}
			} else {
				if (!AcsUtils.isEmpty(transHid)) {
					deviceStateApi.transFailed(deviceHid, transHid, "Failed to update states");
				}
			}
		} catch (Exception e) {
			logError(method, e);
			if (!AcsUtils.isEmpty(transHid)) {
				deviceStateApi.transFailed(deviceHid, transHid, e.getMessage());
			}
		}

	}
}
