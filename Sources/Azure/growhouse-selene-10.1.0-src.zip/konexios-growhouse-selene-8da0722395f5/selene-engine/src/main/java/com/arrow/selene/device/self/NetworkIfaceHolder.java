package com.arrow.selene.device.self;

import java.io.Serializable;

import com.arrow.acs.JsonUtils;

public class NetworkIfaceHolder implements Serializable {
	private static final long serialVersionUID = 8982241306539268728L;
	private NetworkIface[] interfaces;

	public NetworkIface[] getInterfaces() {
		return interfaces;
	}

	public void setInterfaces(NetworkIface[] interfaces) {
		this.interfaces = interfaces;
	}

	@Override
	public String toString() {
		return JsonUtils.toJson(this);
	}
}
