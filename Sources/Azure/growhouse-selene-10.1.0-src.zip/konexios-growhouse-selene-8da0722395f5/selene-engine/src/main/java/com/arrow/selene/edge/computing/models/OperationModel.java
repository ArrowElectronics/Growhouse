package com.arrow.selene.edge.computing.models;

import java.io.Serializable;
import java.util.List;

public class OperationModel implements Serializable{
	private static final long serialVersionUID = 6483542949191322748L;

	private String gatewayHid;
	private List<DevicesModel> devices;

	public String getGatewayHid() {
		return gatewayHid;
	}

	public void setGatewayHid(String gatewayHid) {
		this.gatewayHid = gatewayHid;
	}

	public List<DevicesModel> getDevices() {
		return devices;
	}

	public void setDevices(List<DevicesModel> devices) {
		this.devices = devices;
	}

}
