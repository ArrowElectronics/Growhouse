package com.arrow.selene.edge.computing.models;

import java.io.Serializable;

public class AlertModel implements Serializable {
	private static final long serialVersionUID = -9035567374605860156L;
	private String alertMessage;
	private String containerId;
	private String containerName;
	private String facilityId;
	private String facilityName;
	private String gatewayHid;
	private String gatewayName;
	private String ruleHid;

	public String getAlertMessage() {
		return alertMessage;
	}

	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	public String getContainerId() {
		return containerId;
	}

	public void setContainerId(String containerId) {
		this.containerId = containerId;
	}

	public String getContainerName() {
		return containerName;
	}

	public void setContainerName(String containerName) {
		this.containerName = containerName;
	}

	public String getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(String facilityId) {
		this.facilityId = facilityId;
	}

	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public String getGatewayHid() {
		return gatewayHid;
	}

	public void setGatewayHid(String gatewayHid) {
		this.gatewayHid = gatewayHid;
	}

	public String getGatewayName() {
		return gatewayName;
	}

	public void setGatewayName(String gatewayName) {
		this.gatewayName = gatewayName;
	}

	public String getRuleHid() {
		return ruleHid;
	}

	public void setRuleHid(String ruleHid) {
		this.ruleHid = ruleHid;
	}

	public AlertModel withalertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
		return this;
	}

	public AlertModel withcontainerId(String containerId) {
		this.containerId = containerId;
		return this;
	}

	public AlertModel withcontainerName(String containerName) {
		this.containerName = containerName;
		return this;
	}

	public AlertModel withfacilityId(String facilityId) {
		this.facilityId = facilityId;
		return this;
	}

	public AlertModel withfacilityName(String facilityName) {
		this.facilityName = facilityName;
		return this;
	}

	public AlertModel withGatewayHid(String gatewayHid) {
		this.gatewayHid = gatewayHid;
		return this;
	}

	public AlertModel withgatewayName(String gatewayName) {
		this.gatewayName = gatewayName;
		return this;
	}

	public AlertModel withRuleHid(String ruleHid) {
		this.ruleHid = ruleHid;
		return this;
	}

}
