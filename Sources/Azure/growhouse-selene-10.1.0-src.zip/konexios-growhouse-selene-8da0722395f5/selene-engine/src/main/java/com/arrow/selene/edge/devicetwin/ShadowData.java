package com.arrow.selene.edge.devicetwin;

import java.time.Instant;

import com.arrow.acs.Loggable;
import com.arrow.selene.data.Telemetry;
import com.arrow.selene.device.sensor.FloatCubeSensorData;

public class ShadowData extends Loggable {
	private Object value;
	private long timestamp;

	public ShadowData(Telemetry telemetry) {

		value = telemetry.value();

		if (value == null) {
			switch (telemetry.getType()) {
			case Boolean:
				value = Boolean.valueOf(telemetry.getStrValue());
				break;
			case Float:
				value = Float.valueOf(telemetry.getStrValue());
				break;
			case Integer:
				value = Integer.valueOf(telemetry.getStrValue());
				break;
			default:
				value = telemetry.getStrValue();
			}
		}

		timestamp = telemetry.getTimestamp();
	}

	public ShadowData(String value) {
		this.value = value;
		timestamp = Instant.now().toEpochMilli();
	}

	public Object getValue() {
		return value;
	}

	public long getTimestamp() {
		return timestamp;
	}

}