package com.arrow.selene.device.self;

import com.arrow.selene.engine.DeviceData;

public interface SelfData extends DeviceData {
}
