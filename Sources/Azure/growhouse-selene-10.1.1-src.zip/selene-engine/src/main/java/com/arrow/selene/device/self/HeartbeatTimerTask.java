package com.arrow.selene.device.self;

import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.TimerTask;
import java.util.concurrent.atomic.AtomicBoolean;

import org.apache.commons.lang3.Validate;

import com.arrow.selene.Loggable;
import com.arrow.selene.data.Gateway;
import com.arrow.selene.engine.Engine;

class HeartbeatTimerTask extends TimerTask {
	private static final Loggable LOGGER = new Loggable();
	private Gateway gateway;
	private AtomicBoolean running = new AtomicBoolean(false);
	private URL url;
	private String abc;

	public HeartbeatTimerTask(Gateway gateway) {
		this.gateway = gateway;
		try {
			LOGGER.logInfo("HeartbeatTimerTask", "GrowhouseUrl : %s", gateway.getGrowhouseUrl());
			abc = gateway.getGrowhouseUrl() + "/growareas/heartbeat/" + gateway.getHid();
			// abc = "http://23.96.18.150:4200/api/growareas/heartbeat/" +
			// gateway.getHid();
			url = new URL(abc);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}

	}

	@Override
	public void run() {
		String method = "HeartbeatTimerTask.run";

		if (running.compareAndSet(false, true)) {
			Validate.notNull(gateway, "gateway is null");

			LOGGER.logInfo(method, "sending heartbeat...");
			try {
				Engine.getInstance().getAcnClient().getGatewayApi().heartbeat(gateway.getHid());
			} catch (Throwable throwable) {
				LOGGER.logError(method, "unable to send heartbeat", throwable);
				// LOGGER.logError(method, "failed to send heartbeat on
				// arrow-connect portal", throwable);
			}
			LOGGER.logInfo(method, "done!");
			try {
				LOGGER.logInfo(method, "url : %s", url);
				HttpURLConnection conn = (HttpURLConnection) url.openConnection();
				conn.setRequestMethod("PUT");
				conn.setDoOutput(true);
				OutputStreamWriter out = new OutputStreamWriter(conn.getOutputStream());
				out.close();
				conn.getInputStream();
				// int response = conn.getResponseCode();
				// LOGGER.logInfo(method, "Response code %d", response);
				conn.disconnect();
			} catch (Throwable throwable) {
				LOGGER.logError(method, "failed to send heartbeat on growhouse portal", throwable);
			}
			running.set(false);
		}
	}
}
