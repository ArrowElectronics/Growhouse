package com.arrow.selene.device.mqttrouter;

import com.arrow.selene.device.mqtt.MqttDeviceData;

public interface MqttRouterData extends MqttDeviceData {
}
