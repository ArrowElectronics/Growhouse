package com.arrow.selene.engine;

public enum ModuleStrategy {
    PROPERTIES, DATABASE, CLOUD
}
