package com.arrow.selene.engine.state;

import org.apache.commons.beanutils.converters.AbstractConverter;

import com.arrow.acs.JsonUtils;

public class StatesConverter extends AbstractConverter {
	StatesConverter(Object value) {
		super(value);
	}

	@Override
	protected <T> T convertToType(Class<T> type, Object value) throws Throwable {
		return type.cast(JsonUtils.fromJson(value.toString(), State.class));
	}

	@Override
	protected Class<?> getDefaultType() {
		return State.class;
	}
}
