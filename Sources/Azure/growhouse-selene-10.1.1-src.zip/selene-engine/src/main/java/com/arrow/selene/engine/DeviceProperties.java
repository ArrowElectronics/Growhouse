package com.arrow.selene.engine;

import java.io.Serializable;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;

import com.arrow.selene.SeleneException;

public class DeviceProperties implements Serializable {
	private static final long serialVersionUID = 8396960318239435598L;

	private boolean enabled = true;
	private boolean persistTelemetry = EngineConstants.DEFAULT_DEVICE_PERSIST_TELEMETRY;
	private int numThreads = 1;
	private long maxPollingIntervalMs = EngineConstants.DEFAULT_MAX_POLLING_INTERVAL_MS;
	private boolean publishLocal = EngineConstants.DEFAULT_PUBLISH_LOCAL;

	private String externalPropertyFile;
	private String externalIniFile;
	private String externalIniFileSection;

	// used by ScriptEngine
	private String dataParsingScriptFilename;

	public String getDataParsingScriptFilename() {
		return dataParsingScriptFilename;
	}

	public void setDataParsingScriptFilename(String dataParsingScriptFilename) {
		this.dataParsingScriptFilename = dataParsingScriptFilename;
	}

	public String getExternalIniFileSection() {
		return externalIniFileSection;
	}

	public void setExternalIniFileSection(String externalIniFileSection) {
		this.externalIniFileSection = externalIniFileSection;
	}

	public String getExternalPropertyFile() {
		return externalPropertyFile;
	}

	public void setExternalPropertyFile(String externalPropertyFile) {
		this.externalPropertyFile = externalPropertyFile;
	}

	public String getExternalIniFile() {
		return externalIniFile;
	}

	public void setExternalIniFile(String externalIniFile) {
		this.externalIniFile = externalIniFile;
	}

	public long getMaxPollingIntervalMs() {
		return maxPollingIntervalMs;
	}

	public void setMaxPollingIntervalMs(long maxPollingIntervalMs) {
		this.maxPollingIntervalMs = maxPollingIntervalMs;
	}

	public boolean isPersistTelemetry() {
		return persistTelemetry;
	}

	public void setPersistTelemetry(boolean persistTelemetry) {
		this.persistTelemetry = persistTelemetry;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public int getNumThreads() {
		return numThreads;
	}

	public void setNumThreads(int numThreads) {
		this.numThreads = numThreads;
	}

	public Map<String, String> exportProperties() {
		try {
			return BeanUtils.describe(this);
		} catch (Exception e) {
			throw new SeleneException("Error exporting properties", e);
		}
	}

	public void importProperties(Map<String, String> map) {
		try {
			BeanUtils.populate(this, map);
		} catch (Exception e) {
			throw new SeleneException("Error importing properties", e);
		}
	}

	public boolean isPublishLocal() {
		return publishLocal;
	}

	public void setPublishLocal(boolean publishLocal) {
		this.publishLocal = publishLocal;
	}
}
