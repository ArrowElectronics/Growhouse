package com.arrow.selene.device.mqtt;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttAsyncClient;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import com.arrow.acn.client.AcnClientException;
import com.arrow.acn.client.ClientConstants;
import com.arrow.acn.client.ClientConstants.Mqtt;
import com.arrow.acn.client.cloud.MessageListener;
import com.arrow.acn.client.utils.Utils;
import com.arrow.acs.AcsUtils;
import com.arrow.acs.Loggable;

public class CustomMqttClientNew extends Loggable {

	private String url;
	private String clientId;
	private MqttAsyncClient client;
	private String[] topics;
	private MqttConnectOptions options;
	private boolean cleanSession;

	// private Thread connectThread;
	// private boolean disconnected = false;

	private SubscriberCallback subscriberCallback = new SubscriberCallback();

	public CustomMqttClientNew(String url) {
		this(url, MqttClient.generateClientId(), true);
	}

	public CustomMqttClientNew(String url, String clientId) {
		this(url, clientId, false);
	}

	private CustomMqttClientNew(String url, String clientId, boolean cleanSession) {
		AcsUtils.notEmpty(url, "url is not set");
		this.url = url;
		this.clientId = clientId;
		this.cleanSession = cleanSession;
		this.options = new MqttConnectOptions();
		options.setMaxInflight(100);
	}

	public MqttConnectOptions getOptions() {
		return options;
	}

	public void setOptions(MqttConnectOptions options) {
		this.options = options;
	}

	public String[] getTopics() {
		return topics;
	}

	public void setTopics(String... topics) {
		this.topics = topics;
	}

	public void setListener(MessageListener listener) {
		subscriberCallback.setListener(listener);
	}

	public void connect(boolean checkConnectionLost) {
		String method = "connect";
		if (checkConnectionLost && client != null && client.isConnected()) {
			logInfo(method, "connectionLost is FALSE, possible already recovered!!!!!!");
			return;
		}

		// if (connectThread != null && connectThread.isAlive()) {
		// logInfo(method, "connectThread is still running!");
		// return;
		// }

		client = initClient(clientId, options);
		if (client.isConnected()) {
			if (topics != null) {
				logInfo(method, "subscribing to: %d topics", topics.length);
				subscribe(topics);
			}
		}
		// connectThread = new Thread(new Runnable() {
		// @Override
		// public void run() {
		// client = initClient(clientId, options);
		// if (client != null && topics != null) {
		// logInfo(method, "subscribing to: %d topics", topics.length);
		// subscribe(topics);
		// } else {
		// logWarn(method, "there's no topics to subscribe");
		// }
		// }
		// });
		// connectThread.start();
	}

	public void publish(String topic, byte[] data, int qos) {
		String method = "publish";
		// checkConnection();
		try {
			MqttMessage msg = new MqttMessage(data);
			msg.setQos(qos);
			logDebug(method, "sending message to topic: %s", topic);
			client.publish(topic, msg);
			logInfo(method, "sent message to topic: %s", topic);
		} catch (Exception e) {
			throw new AcnClientException("unable to send mqtt message", e);
		}
	}

	public void subscribe(String... topics) {
		String method = "createNewSubscriber";
		checkConnection();
		while (true) {
			try {
				int[] qos = new int[topics.length];
				for (int i = 0; i < qos.length; i++) {
					qos[i] = 1;
				}
				client.subscribe(topics, qos);
				logInfo(method, "subscribed to topic: %s", Arrays.deepToString(topics));
				break;
			} catch (Throwable t) {
				logError(method, "unable to subscribe to MQTT topic, retrying in "
				        + ClientConstants.DEFAULT_CLOUD_CONNECTION_RETRY_INTERVAL_MS, t);
				Utils.sleep(ClientConstants.DEFAULT_CLOUD_CONNECTION_RETRY_INTERVAL_MS);
			}
		}
	}

	public void checkConnection() {
		String method = "checkConnection";
		while (client == null || !client.isConnected()) {
			logError(method, "client is not ready: %s, check back in %d ...", this.url,
			        Mqtt.DEFAULT_CHECK_CONNECTION_RETRY_INTERVAL_MS);
			Utils.sleep(Mqtt.DEFAULT_CHECK_CONNECTION_RETRY_INTERVAL_MS);
			// connect(true);
			// com.arrow.acn.client.utils.Utils.sleep(20);

		}
	}

	public void disconnect() {
		String method = "disconnectClient";
		if (client != null && client.isConnected()) {
			try {
				if (topics != null) {
					client.unsubscribe(topics);
				}
				logInfo(method, "disconnecting client ...");
				client.disconnect();
				logInfo(method, "client disconnected");
			} catch (MqttException e) {
				try {
					logInfo(method, "cannot disconnect client, disconnecting client forcibly...");
					client.disconnectForcibly();
					logInfo(method, "client disconnected forcibly");
				} catch (MqttException e1) {
					logError(method, "cannot disconnect client");
				}
			}
		}

		// if (connectThread != null && connectThread.isAlive()) {
		// try {
		// disconnected = true;
		// logInfo(method, "waiting for connectThread to stop ...");
		// connectThread.join();
		// logInfo(method, "connectThread terminated");
		// } catch (Throwable t) {
		// }
		// }
	}

	private MqttAsyncClient initClient(String clientId, MqttConnectOptions options) {
		String method = "initClient new";
		logInfo(method, "creating client %s to %s", clientId, url);
		MqttAsyncClient client = null;
		try {
			client = new MqttAsyncClient(url, clientId, null);
		} catch (MqttException e) {
			e.printStackTrace();
		}
		while (!client.isConnected()) {
			try {
				client.setCallback(subscriberCallback);
				options.setCleanSession(cleanSession);
				client.connect(options);
				if (client.isConnected()) {
					logInfo(method, "client connected : %s", clientId);
					// disconnected = false;
					return client;
				} else {
					logError(method, "Connecting...");
					Utils.sleep(5000);
				}

			} catch (Throwable t) {
				logError(method, "unable to connect to MQTT server, retrying in 5000 ms");
				Utils.sleep(5000);
			}
		}
		logInfo(method, "done");
		return client;
	}

	private class SubscriberCallback implements MqttCallback {
		private MessageListener listener;

		SubscriberCallback() {
		}

		@Override
		public void messageArrived(String topic, MqttMessage message) throws Exception {
			String method = "messageArrived";
			byte[] payload = message.getPayload();
			logDebug(method, "topic: %s, payload: %s", topic, new String(payload, StandardCharsets.UTF_8));
			if (listener != null) {
				try {
					listener.processMessage(topic, payload);
				} catch (Throwable t) {
					logError(method, t);
				}
			}
		}

		@Override
		public void deliveryComplete(IMqttDeliveryToken token) {
			String method = "deliveryComplete";
			logDebug(method, "messageId: %s", token.getMessageId());
		}

		@Override
		public void connectionLost(Throwable cause) {
			String method = "connectionLost";
			logInfo(method, "cause: %s", cause.getMessage());
			// try {
			// connectThread.join();
			// } catch (InterruptedException e) {
			// // TODO Auto-generated catch block
			// e.printStackTrace();
			// }
			connect(true);
		}

		void setListener(MessageListener listener) {
			this.listener = listener;
		}
	}
}
