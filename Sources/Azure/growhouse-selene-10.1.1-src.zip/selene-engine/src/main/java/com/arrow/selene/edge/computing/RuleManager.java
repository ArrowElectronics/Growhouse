package com.arrow.selene.edge.computing;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Timer;
import java.util.TimerTask;

import org.apache.commons.lang3.Validate;

import com.arrow.acs.JsonUtils;
import com.arrow.acs.Loggable;
import com.arrow.selene.SeleneException;
import com.arrow.selene.data.Rule;
import com.arrow.selene.device.edge.RuleEngineData;
import com.arrow.selene.device.self.SelfModule;
import com.arrow.selene.edge.computing.models.ActionModel;
import com.arrow.selene.edge.computing.models.ConditionModel;
import com.arrow.selene.edge.computing.models.MonitorModel;
import com.arrow.selene.edge.computing.models.RuleModel;
import com.arrow.selene.engine.DeviceModule;
import com.arrow.selene.engine.service.ModuleService;
import com.arrow.selene.service.RuleService;

public class RuleManager extends Loggable {
	private Map<String, Timer> ruleTimers = new HashMap<>();
	private Map<String, RuleAlertProcessor> ruleDevice = new HashMap<>();
	private final RuleService ruleService = RuleService.getInstance();

	private static class SingletonHolder {
		static final RuleManager SINGLETON = new RuleManager();
	}

	public static RuleManager getInstance() {
		return SingletonHolder.SINGLETON;
	}

	public RuleManager() {
		logInfo("RuleManager", "Constructed ... ");
		List<Rule> rules = RuleService.getInstance().findAll();
		rules.stream().filter(r -> r.isEnabled()).forEach(r -> {
			logInfo("RuleManager", "Starting Rule ::: %s", r.getRuleModel());
			RuleModel ruleModel = JsonUtils.fromJson(r.getRuleModel(), RuleModel.class);
			startRuleTimer(ruleModel);
		});
	}

	public void processRule(RuleModel ruleModel) {
		String method = "processRule";
		Validate.notEmpty(ruleModel.getType());
		Validate.notEmpty(ruleModel.getRuleHid());

		try {

			switch (ruleModel.getType()) {
			case RuleTypes.CREATE:
				createRule(ruleModel);
				break;
			case RuleTypes.DELETE:
				deleteRule(ruleModel.getRuleHid());
				break;
			case RuleTypes.UPDATE:
				disableRule(ruleModel.getRuleHid());
				updateRule(ruleModel);
				break;
			case RuleTypes.ENABLE:
				enableRule(ruleModel.getRuleHid());
				break;
			case RuleTypes.DISABLE:
				disableRule(ruleModel.getRuleHid());
				break;
			default:
				throw new SeleneException("Unknown rule type : " + ruleModel.getType());
			}

		} catch (Exception e) {
			logError(method, e);
			throw e;
		}
	}

	private void createRule(RuleModel ruleModel) {
		Validate.notNull(ruleModel, "Rule model is null!");
		Validate.notNull(ruleModel.getMonitors());
		Validate.notNull(ruleModel.getConditions());
		String method = "createRule";
		List<MonitorModel> monitors = ruleModel.getMonitors();
		for (MonitorModel monitorModel : monitors) {
			if (!Objects.equals(monitorModel.getGatewayHid(), SelfModule.getInstance().getGateway().getHid())) {
				throw new SeleneException("Wrong gatewayHid..Cannot create rule!");
			}
		}
		// Check if the rule already exists?
		if (RuleService.getInstance().find(ruleModel.getRuleHid()) != null)
			throw new SeleneException("Rule (" + ruleModel.getRuleHid() + ") already exists!");

		try {
			// Store the received rule
			Rule rule = new Rule();
			rule.setRuleHid(ruleModel.getRuleHid());
			rule.setRuleModel(JsonUtils.toJson(ruleModel));
			logInfo(method, JsonUtils.toJson(ruleModel));
			ruleService.createRule(rule);

			startRuleTimer(ruleModel);
		} catch (Exception e) {
			logError(method, e);
			throw new SeleneException("Cannot create rule!");
		}
	}

	private void updateRule(RuleModel ruleModel) {
		Validate.notNull(ruleModel, "Rule model is null!");
		Validate.notNull(ruleModel.getMonitors());
		Validate.notNull(ruleModel.getConditions());
		String method = "updateRule";
		logInfo(method, "...");
		Rule preRule = RuleService.getInstance().find(ruleModel.getRuleHid());
		// Check if the rule already exists?
		if (preRule == null)
			throw new SeleneException("Rule (" + ruleModel.getRuleHid() + ") doesn't exists!");

		try {
			// Store the received rule
			Rule rule = new Rule();
			rule.setRuleHid(ruleModel.getRuleHid());
			rule.setRuleModel(JsonUtils.toJson(ruleModel));
			rule.setId(preRule.getId());
			logInfo(method, JsonUtils.toJson(ruleModel));
			ruleService.save(rule);

			startRuleTimer(ruleModel);
		} catch (Exception e) {
			logError(method, e);
			throw new SeleneException("Cannot update rule!");
		}
	}

	private void startRuleTimer(RuleModel ruleModel) {
		Validate.notNull(ruleModel, "Rule model is null!");
		if (!ruleTimers.containsKey(ruleModel.getRuleHid())) {
			Timer ruleTimer = new Timer();
			ruleTimer.schedule(new RuleTimerTask(ruleModel), 0L, ruleModel.getTimeInterval() * 1000);
			ruleTimers.put(ruleModel.getRuleHid(), ruleTimer);
		}
	}

	public void stopRuleProcessing() {
		ruleTimers.entrySet().forEach(e -> e.getValue().cancel());
	}

	private void deleteRule(String ruleHid) {
		Validate.notEmpty(ruleHid, "Rule hid is empty!");
		String method = "deleteRule";
		try {
			// Delete the stored rule
			ruleService.delete(ruleHid);
			if (ruleTimers.containsKey(ruleHid)) {
				// Stop the rule timer
				// ruleTimers.get(ruleHid).
				ruleTimers.get(ruleHid).cancel();
				ruleTimers.remove(ruleHid);
			}

			if (ruleDevice.containsKey(ruleHid)) {
				ruleDevice.remove(ruleHid);
			}

		} catch (Exception e) {
			logError(method, e);
			throw new SeleneException("Cannot delete rule!");
		}
	}

	private void enableRule(String ruleHid) {
		Validate.notEmpty(ruleHid, "Rule hid is empty!");
		String method = "enableRule";
		if (ruleTimers.containsKey(ruleHid)) {
			String msg = "Rule (" + ruleHid + ") already enabled!";
			logInfo(method, msg);
			throw new SeleneException(msg);
		}

		try {
			Rule rule = RuleService.getInstance().find(ruleHid);
			RuleModel ruleModel = JsonUtils.fromJson(rule.getRuleModel(), RuleModel.class);
			startRuleTimer(ruleModel);
			// Enable the rule in database
			rule.setEnabled(true);
			RuleService.getInstance().save(rule);
		} catch (Exception e) {
			logError(method, e);
			throw new SeleneException("Cannot enable rule!");
		}
	}

	private void disableRule(String ruleHid) {
		Validate.notEmpty(ruleHid, "Rule hid is empty!");
		String method = "disableRule";
		if (!ruleTimers.containsKey(ruleHid)) {
			String msg = "Rule (" + ruleHid + ") already disabled!";
			logInfo(method, msg);
			throw new SeleneException(msg);
		}

		try {
			// Stop the rule timer
			ruleTimers.get(ruleHid).cancel();
			ruleTimers.remove(ruleHid);

			// Disable the rule in database
			Rule rule = RuleService.getInstance().find(ruleHid);
			rule.setEnabled(false);
			RuleService.getInstance().save(rule);
		} catch (Exception e) {
			logError(method, e);
			throw new SeleneException("Cannot disable rule!");
		}
	}

	private class RuleTimerTask extends TimerTask {
		private RuleModel ruleModel;

		public RuleTimerTask(RuleModel ruleModel) {
			this.ruleModel = ruleModel;
			logInfo("RuleTimerTask", "Starting rule timer for rule ::: %s", JsonUtils.toJson(ruleModel));
		}

		@Override
		public void run() {
			String method = "RuleManager.RuleTimerTask.run";
			logInfo(method, "Processing Rule.... %s", ruleModel.getRuleHid());
			List<MonitorModel> monitors = ruleModel.getMonitors();
			Map<String, Object> parameterMap = new HashMap<>();
			try {
				boolean validMonitors = false;
				// First fetch monitors and prepare the parameter map
				for (MonitorModel monitorModel : monitors) {
					List<String> deviceHids = monitorModel.getDeviceHids();
					for (String deviceHid : deviceHids) {
						DeviceModule<?, ?, ?, ?> deviceModule = ModuleService.getInstance().findDevice(deviceHid);
						if (deviceModule != null) {
							deviceModule.getShadow().entrySet().forEach(e -> {
								if (e.getValue().getTimestamp() > (System.currentTimeMillis() - 900000)) {
									parameterMap.put("_" + deviceHid + "." + e.getKey(), e.getValue().getValue());
								}
							});
						} else {
							validMonitors |= true;
						}
					}
				}
				if (validMonitors) {
					List<String> alr1 = new ArrayList<String>();
					alr1.add("Device is not available");
					Map<String, Object> pro = new HashMap<>();
					String listString = String.join("@#$", alr1);
					processActionModel(listString, pro);
				} else {
					logInfo(method, "ParameterMap ---->>> %s", parameterMap.toString());
					// Next fetch conditions and evaluate the expressions
					List<ConditionModel> conditions = ruleModel.getConditions();
					List<ActionModel> actionModels = null;
					List<String> alerts = new ArrayList<String>();
					Map<String, Object> properties = new HashMap<>();
					Map<String, Object> propsForall = new HashMap<>();
					Boolean Finalstatus = false;
					Boolean noInfo = false;
					for (ConditionModel conditionModel : conditions) {
						Boolean status = false;
						try {
							status = ExpressionEvaluator.evaluate(conditionModel.getExpression(), parameterMap);
						} catch (Exception e) {
							noInfo |= true;
						}
						if (status) {
							actionModels = conditionModel.getActions();
							for (ActionModel actionModel : actionModels) {
								alerts.add(actionModel.getAlertMessage());
							}
							properties = getPropsWithValue(parameterMap, properties, conditionModel.getExpression());
						}
						propsForall = getPropsWithValue(parameterMap, propsForall, conditionModel.getExpression());
						Finalstatus |= status;
					}
					if (noInfo) {
						Map<String, Object> pro = new HashMap<>();
						List<String> alr2 = new ArrayList<String>();
						alr2.add("Latest device information is not available");
						String listString = String.join("@#$", alr2);
						processActionModel(listString, pro);
					} else if (Finalstatus) {
						String listString = String.join("@#$", alerts);
						processActionModel(listString, properties);
					} else {
						List<String> alr3 = new ArrayList<String>();
						alr3.add("OK");
						String listString = String.join("@#$", alr3);
						processActionModel(listString, propsForall);
					}
				}
			} catch (Exception e) {
				logError(method, e);
			}
		}

		private Map<String, Object> getPropsWithValue(Map<String, Object> parameterMap, Map<String, Object> properties,
		        String exp) {
			String[] bigString;
			// Map<String, Object> properties =
			if (exp.contains("&&") || exp.contains("||")) {

				bigString = exp.split("(\\|\\|)|(&&)");
				for (String s : bigString) {
					String exp1 = s.split("(==)|(!=)|(<=)|(>=)|(>)|(<)")[0].trim();
					String prop = exp1.split("\\.")[1];
					parameterMap.entrySet().forEach(e -> {
						if (Objects.equals(e.getKey(), exp1))
							properties.put(prop, e.getValue());
					});
				}
			} else {
				String exp1 = exp.split("(==)|(!=)|(<=)|(>=)|(>)|(<)")[0].trim();
				String prop = exp1.split("\\.")[1];
				parameterMap.entrySet().forEach(e -> {
					if (Objects.equals(e.getKey(), exp1))
						properties.put(prop, e.getValue());
				});
			}
			return properties;
		}

		public void processActionModel(String alertMessage, Map<String, Object> properties) {
			String method = "processActionModel";
			try {
				// for (ActionModel actionModel : actionModels) {
				// switch (actionModel.getType()) {
				// case RuleActionTypes.SEND_ALARM:

				// Map<String, Object> properties =
				// getPropsWithValue(parameterMap, exp);

				Map<String, String> globalResponsePayload = ruleModel.getGlobalResponsePayload();
				// String alertMessage =
				// RuleActions.prepareAlarmResponse(ruleModel.getRuleHid(),
				// actionModel);

				if (!ruleDevice.containsKey(ruleModel.getRuleHid())) {
					logError(method, "No processor is registered to process alerts!");
				} else {
					RuleEngineData alertModel = new RuleEngineData();

					if (globalResponsePayload.containsKey("containerId")) {
						alertModel = alertModel.withcontainerId(globalResponsePayload.get("containerId"));
					}
					if (globalResponsePayload.containsKey("containerName")) {
						alertModel = alertModel.withcontainerName(globalResponsePayload.get("containerName"));
					}
					if (globalResponsePayload.containsKey("facilityId")) {
						alertModel = alertModel.withfacilityId(globalResponsePayload.get("facilityId"));
					}
					if (globalResponsePayload.containsKey("facilityName")) {
						alertModel = alertModel.withfacilityName(globalResponsePayload.get("facilityName"));
					}
					if (globalResponsePayload.containsKey("growSectionId")) {
						alertModel = alertModel.withgrowSectionId(globalResponsePayload.get("growSectionId"));
					}
					if (globalResponsePayload.containsKey("growSectionName")) {
						alertModel = alertModel.withgrowSectionName(globalResponsePayload.get("growSectionName"));
					}
					if (globalResponsePayload.containsKey("gatewayId")) {
						alertModel = alertModel.withgatewayId(globalResponsePayload.get("gatewayId"));
					}

					alertModel = alertModel.withalertMessage(alertMessage)
					        .withGatewayHid(SelfModule.getInstance().getGateway().getHid())
					        .withgatewayName(SelfModule.getInstance().getGateway().getName())
					        .withRuleHid(ruleModel.getRuleHid()).withproperties(JsonUtils.toJson(properties));
					logInfo(method, "alertModel %s", alertMessage);
					ruleDevice.get(ruleModel.getRuleHid()).processAlert(alertModel);
				}

			} catch (Exception e) {
				throw new SeleneException(e.getMessage());
			}

		}

	}

	public void setAlertProcessor(RuleAlertProcessor alertProcessor, String ruleHid) {
		ruleDevice.put(ruleHid, alertProcessor);
		Rule rule = RuleService.getInstance().find(ruleHid);
		RuleModel ruleModel = JsonUtils.fromJson(rule.getRuleModel(), RuleModel.class);
		startRuleTimer(ruleModel);

	}

}
