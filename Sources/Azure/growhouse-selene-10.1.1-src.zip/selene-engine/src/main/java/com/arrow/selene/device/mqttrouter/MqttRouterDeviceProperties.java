package com.arrow.selene.device.mqttrouter;

import com.arrow.selene.engine.DeviceProperties;

public class MqttRouterDeviceProperties extends DeviceProperties {
	private static final long serialVersionUID = 5636203412225530328L;
}
