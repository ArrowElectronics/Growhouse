//package com.arrow.selene.engine.cloud;
//
//import java.nio.charset.StandardCharsets;
//import java.util.List;
//
//import com.rabbitmq.client.Channel;
//import com.rabbitmq.client.Connection;
//import com.rabbitmq.client.ConnectionFactory;
//
//import com.arrow.kronos.client.IotParameters;
//import com.arrow.kronos.client.model.CloudPlatform;
//import com.arrow.pegasus.JsonUtils;
//import com.arrow.selene.SeleneException;
//import com.arrow.selene.device.self.SelfModule;
//
//public class AmqpModuleAbstract extends CloudModuleAbstract {
//
//    private static class SingletonHolder {
//        private static final AmqpModuleAbstract SINGLETON = new AmqpModuleAbstract(CloudPlatform.IotConnect);
//    }
//
//    public static AmqpModuleAbstract getInstance() {
//        return SingletonHolder.SINGLETON;
//    }
//
//    private static final String DEFAULT_EXCHANGE_NAME = "selene.exchange";
//
//    private Connection connection;
//    private Channel channel;
//
//    public AmqpModuleAbstract(CloudPlatform cloudPlatform) {
//        super(cloudPlatform);
//    }
//
//    @Override
//    public void startClient() {
//        String method = "startClient";
//
//        // testing
//        try {
//            logInfo(method, "factory ...");
//            ConnectionFactory factory = new ConnectionFactory();
//            factory.setUsername("pegasus");
//            factory.setPassword("dBsAhZ2RGbxGJbcZKXLo9lvYWfFCW5S7");
//            factory.setVirtualHost("/themis.dev");
//            factory.setHost("pegasusqueue01-dev.cloudapp.net");
//            factory.setPort(46952);
//            connection = factory.newConnection();
//            channel = connection.createChannel();
//
//            logInfo(method, "exchangeDeclare ...");
//            channel.exchangeDeclare(DEFAULT_EXCHANGE_NAME, "direct", true);
//            String queueName = channel.queueDeclare().getQueue();
//            logInfo(method, "queueName: %s", queueName);
//
//            String routingKey = "gateway." + SelfModule.getInstance().getGateway().getHid();
//            channel.queueBind(queueName, DEFAULT_EXCHANGE_NAME, routingKey);
//            super.startClient();
//
//            logInfo(method, "ready!");
//        } catch (Exception e) {
//            throw new SeleneException("ERROR", e);
//        }
//    }
//
//    @Override
//    protected void send(IotParameters payload) {
//        String method = "send";
//        try {
//            String routingKey = "gateway." + SelfModule.getInstance().getGateway().getHid();
//            byte[] data = JsonUtils.toJson(payload).getBytes(StandardCharsets.UTF_8);
//            channel.basicPublish(DEFAULT_EXCHANGE_NAME, routingKey, null, data);
//            logInfo(method, "sent %d bytes", data.length);
//        } catch (Exception e) {
//            logError(method, e);
//        }
//    }
//
//    @Override
//    protected void sendBatch(List<IotParameters> batch) {
//        throw new SeleneException("method not implemented yet!");
//    }
//}
