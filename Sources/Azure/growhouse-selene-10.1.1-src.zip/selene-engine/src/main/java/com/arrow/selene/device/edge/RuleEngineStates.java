package com.arrow.selene.device.edge;

import com.arrow.selene.engine.state.DeviceStates;

public class RuleEngineStates extends DeviceStates {
	private static final long serialVersionUID = -436519396208032749L;
}
