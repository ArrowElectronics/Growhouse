package com.arrow.selene.engine.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.Validate;
import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;

import com.arrow.acn.client.api.SoftwareReleaseTransApi;
import com.arrow.acn.client.model.SoftwareReleaseCommandModel;
import com.arrow.acn.client.utils.MD5Util;
import com.arrow.acs.client.model.DownloadFileInfo;
import com.arrow.selene.Loggable;
import com.arrow.selene.SeleneException;
import com.arrow.selene.device.self.SelfModule;
import com.arrow.selene.engine.DeviceModule;
import com.arrow.selene.engine.DirectoryManager;
import com.arrow.selene.engine.Engine;

import net.minidev.json.JSONObject;
import net.minidev.json.parser.JSONParser;
import net.minidev.json.parser.ParseException;

public class UpdateService extends Loggable {
	private static final SimpleDateFormat SDF = new SimpleDateFormat("yyyyMMddHHmmss");
	private static final long DEFAULT_RESTART_SECONDS = 10;

	private static class SingletonHolder {
		static final UpdateService SINGLETON = new UpdateService();
	}

	public static UpdateService getInstance() {
		return SingletonHolder.SINGLETON;
	}

	private Runnable task;

	private UpdateService() {
	}

	public void updateGatewaySoftware(SoftwareReleaseCommandModel model) {
		String method = "updateGatewaySoftware";
		// if (task == null) {
		task = new UpdateGatewaySoftwareTask(model);
		new Thread(task).start();
		// } else {
		// logWarn(method, "UpdateGatewaySoftwareTask already running");
		// }
	}

	public void updateDeviceSoftware(SoftwareReleaseCommandModel model, DeviceModule<?, ?, ?, ?> device) {
		new Thread(new UpdateDeviceSoftwareTask(model, device)).start();
	}

	String downloadFileAndGetPath(SoftwareReleaseCommandModel model, String deviceUid) throws Exception {
		String method = "downloadFile";
		SoftwareReleaseTransApi softwareReleaseTransApi = Engine.getInstance().getAcnClient()
				.getSoftwareReleaseTransApi();
		logInfo(method, "downloading file ...");
		DownloadFileInfo downloadInfo = softwareReleaseTransApi.downloadFile(model.getSoftwareReleaseTransHid(),
				model.getTempToken());
		logInfo(method, "downloaded fileName: %s, size: %d, tempFile: %s", downloadInfo.getFileName(),
				downloadInfo.getSize(), downloadInfo.getTempFile().getAbsolutePath());
		File downloadFolder = new File(DirectoryManager.getInstance().getDownload(), deviceUid);
		if (Files.exists(downloadFolder.toPath())) {
			if (!Files.isDirectory(downloadFolder.toPath())) {
				throw new SeleneException(String.format("file found instead of destination directory: %s",
						downloadFolder.getAbsolutePath()));
			}
		} else {
			logInfo(method, "creation directory: '%s' for downloaded file ...", downloadFolder.getAbsolutePath());
			Files.createDirectory(downloadFolder.toPath());
		}
		File downloadFile = new File(downloadFolder,
				String.format("%s.%s", downloadInfo.getFileName(), SDF.format(new Date())));
		Files.move(downloadInfo.getTempFile().toPath(), downloadFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
		logInfo(method, "downloaded file renamed to: %s", downloadFile.getPath());
		checkMD5Sum(downloadFile, model.getMd5checksum());
		return downloadFile.getPath();
	}

	File downloadFile(SoftwareReleaseCommandModel model, String deviceUid) throws Exception {
		String method = "downloadFile";
		SoftwareReleaseTransApi softwareReleaseTransApi = Engine.getInstance().getAcnClient()
				.getSoftwareReleaseTransApi();
		logInfo(method, "downloading file ...");
		DownloadFileInfo downloadInfo = softwareReleaseTransApi.downloadFile(model.getSoftwareReleaseTransHid(),
				model.getTempToken());
		logInfo(method, "downloaded fileName: %s, size: %d, tempFile: %s", downloadInfo.getFileName(),
				downloadInfo.getSize(), downloadInfo.getTempFile().getAbsolutePath());
		File downloadFolder = new File(DirectoryManager.getInstance().getDownload(), deviceUid);
		if (Files.exists(downloadFolder.toPath())) {
			if (!Files.isDirectory(downloadFolder.toPath())) {
				throw new SeleneException(String.format("file found instead of destination directory: %s",
						downloadFolder.getAbsolutePath()));
			}
		} else {
			logInfo(method, "creation directory: '%s' for downloaded file ...", downloadFolder.getAbsolutePath());
			Files.createDirectory(downloadFolder.toPath());
		}
		File downloadFile = new File(downloadFolder,
				String.format("%s.%s", downloadInfo.getFileName(), SDF.format(new Date())));
		Files.move(downloadInfo.getTempFile().toPath(), downloadFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
		logInfo(method, "downloaded file renamed to: %s", downloadFile.getPath());
		checkMD5Sum(downloadFile, model.getMd5checksum());
		return downloadFile;
	}

	void upgradeGatewaySoftware(File file) throws IOException {
		String method = "updateGatewaySoftware";
		Validate.notNull(file, "file is null");
		logInfo(method, "updating new library ...");
		Files.copy(file.toPath(), new File("lib", file.getName()).toPath(), StandardCopyOption.REPLACE_EXISTING);
		logInfo(method, "software updated successfully");
	}

	void backupGatewaySoftware(File file, String timestamp) throws IOException {
		String method = "backupGatewaySoftware";
		Validate.notNull(file, "file is null");
		if (new File(DirectoryManager.getInstance().getLib(), file.getName()).exists()) {
			File backupFile = new File(DirectoryManager.getInstance().getBackup(),
					String.format("%s.%s", file.getName(), timestamp));
			logInfo(method, "backing up old file to: %s ...", backupFile.getPath());
			Files.copy(file.toPath(), backupFile.toPath());
		}
	}

	private void checkMD5Sum(File file, String md5Checksum) throws NoSuchAlgorithmException, IOException {
		String method = "checkMD5Sum";
		Validate.notNull(file, "file is null");
		Validate.notEmpty(md5Checksum, "md5Checksum is not defined");
		if (Objects.equals(MD5Util.calcMD5ChecksumString(file), md5Checksum)) {
			logInfo(method, "MD5 checksum is correct");
		} else {
			file.delete();
			throw new SeleneException("MD5 checksum is incorrect, removing the file downloaded");
		}
	}

	private class UpdateGatewaySoftwareTask implements Runnable {
		SoftwareReleaseCommandModel model;

		UpdateGatewaySoftwareTask(SoftwareReleaseCommandModel model) {
			this.model = model;
		}

		@Override
		public void run() {
			String method = "run";
			SoftwareReleaseTransApi softwareReleaseTransApi = Engine.getInstance().getAcnClient()
					.getSoftwareReleaseTransApi();
			try {

				SelfModule.getInstance().getInfo().setFOTARunning(true);
				softwareReleaseTransApi.received(model.getSoftwareReleaseTransHid());
				String timestamp = SDF.format(new Date());
				File downloadFile = downloadFile(model, timestamp);
				backupGatewaySoftware(downloadFile, timestamp);
				boolean status = downloadFileFromServer(downloadFile);
				logInfo(method, "status %s", status);
				if (status == true) {
					logInfo(method, "FTP File downloaded successfully");
					// upgradeGatewaySoftware(file1);
					softwareReleaseTransApi.succeeded(model.getSoftwareReleaseTransHid());
					logInfo(method, "Selene will be restarted in %d seconds ...", DEFAULT_RESTART_SECONDS);
					new Thread(() -> Engine.getInstance().shutdown()).start();

				} else {
					logError(method, "Failed to upgrade gateway");
					softwareReleaseTransApi.failed(model.getSoftwareReleaseTransHid(), "Failed to upgrade gateway");
					SelfModule.getInstance().getInfo().setFOTARunning(false);
				}

			} catch (Exception e) {
				logError(method, e);
				softwareReleaseTransApi.failed(model.getSoftwareReleaseTransHid(), e.getMessage());
			}
		}
	}

	private class UpdateDeviceSoftwareTask implements Runnable {
		SoftwareReleaseCommandModel model;
		DeviceModule<?, ?, ?, ?> device;

		UpdateDeviceSoftwareTask(SoftwareReleaseCommandModel model, DeviceModule<?, ?, ?, ?> device) {
			this.model = model;
			this.device = device;
		}

		@Override
		public void run() {
			String method = "run";
			SoftwareReleaseTransApi softwareReleaseTransApi = Engine.getInstance().getAcnClient()
					.getSoftwareReleaseTransApi();
			try {
				softwareReleaseTransApi.received(model.getSoftwareReleaseTransHid());
				device.upgradeDeviceSoftware(downloadFileAndGetPath(model, device.getInfo().getUid()),
						model.getSoftwareReleaseTransHid(), model.getToSoftwareVersion());
				// softwareReleaseTransApi.succeeded(model.getSoftwareReleaseTransHid());
			} catch (Exception e) {
				logError(method, e);
				softwareReleaseTransApi.failed(model.getSoftwareReleaseTransHid(), e.getMessage());
			}
		}

	}

	public boolean downloadFileFromServer(File jsonFile) {
		String method = "downloadFileFromServer";

		JSONParser parser = new JSONParser();
		try {
			Object obj = parser.parse(new FileReader(jsonFile.getAbsolutePath()));

			JSONObject jsonObject = (JSONObject) obj;

			String jarPath = (String) jsonObject.get("seleneJarPath");
			String host = (String) jsonObject.get("host");
			String username = (String) jsonObject.get("username");
			String password = (String) jsonObject.get("password");
			String to = jsonFile.getParent() + "/selene-engine.jar";
			String tolib = "/opt/selene/lib/selene-engine.jar";
			if (StringUtils.isBlank(jarPath) || StringUtils.isBlank(host) || StringUtils.isBlank(username)
					|| StringUtils.isBlank(password)) {
				throw new SeleneException("jarPath, host, username or password is empty");
			}

			FTPDownloader ftpDownloader = new FTPDownloader(host, username, password);
			boolean status = ftpDownloader.downloadFile(jarPath, to, tolib);
			ftpDownloader.disconnect();
			return status;
		} catch (FileNotFoundException e) {
			e.printStackTrace();

		} catch (ParseException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	private class FTPDownloader {
		FTPClient ftp = null;

		public FTPDownloader(String host, String user, String pwd) throws Exception {
			ftp = new FTPClient();
			ftp.setBufferSize(1024 * 1204);
			// ftp.addProtocolCommandListener(new PrintCommandListener(new
			// PrintWriter(System.out)));
			int reply;
			ftp.connect(host);
			reply = ftp.getReplyCode();
			if (!FTPReply.isPositiveCompletion(reply)) {
				ftp.disconnect();
				throw new Exception("Exception in connecting to FTP Server");
			}
			ftp.login(user, pwd);
			ftp.setFileType(FTP.BINARY_FILE_TYPE);
			ftp.enterLocalPassiveMode();

		}

		public boolean downloadFile(String remoteFilePath, String localFilePath, String localLibPath) {
			String method = "FTPDownloader.downloadFile";
			logInfo(method, "downloading jar ...");
			logInfo(method, "localFilePath %s ...", localFilePath);
			logInfo(method, "remoteFilePath %s ...", remoteFilePath);

			try (FileOutputStream fos = new FileOutputStream(localFilePath)) {
				boolean status = this.ftp.retrieveFile(remoteFilePath, fos);
				if (status == true) {
					Path from = Paths.get(localFilePath);
					Path to = Paths.get(localLibPath);
					logInfo(method, "Coping jar to lib...");
					Files.copy(from, to, StandardCopyOption.REPLACE_EXISTING);
				}
				return status;
			} catch (IOException e) {
				logError(method, "FTPDownloader.downloadFile");
			}
			return false;
		}

		public void disconnect() {
			if (this.ftp.isConnected()) {
				try {
					this.ftp.logout();
					this.ftp.disconnect();
					logInfo("disconnect", "disconnecting...");

				} catch (IOException f) {
					// do nothing as file is already downloaded from FTP
					// server
				}
			}
		}

	}
}
