package com.arrow.selene.device.mqtt;

import com.arrow.selene.engine.DeviceData;

public interface MqttDeviceData extends DeviceData {
}
