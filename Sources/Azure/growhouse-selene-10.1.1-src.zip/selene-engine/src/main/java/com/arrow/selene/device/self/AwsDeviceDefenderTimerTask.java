package com.arrow.selene.device.self;

import java.io.StringReader;
import java.util.List;
import java.util.TimerTask;
import java.util.concurrent.atomic.AtomicBoolean;

import org.apache.commons.io.IOUtils;
import org.apache.commons.text.StringTokenizer;

import com.arrow.acn.client.cloud.aws.defender.DeviceDefenderReport;
import com.arrow.acn.client.cloud.aws.defender.DeviceDefenderReport.Connection;
import com.arrow.acn.client.cloud.aws.defender.DeviceDefenderReport.Connections;
import com.arrow.acn.client.cloud.aws.defender.DeviceDefenderReport.NetworkStats;
import com.arrow.acn.client.cloud.aws.defender.DeviceDefenderReport.Port;
import com.arrow.acn.client.cloud.aws.defender.DeviceDefenderReport.Ports;
import com.arrow.acs.JsonUtils;
import com.arrow.acs.KeyValuePair;
import com.arrow.selene.Loggable;
import com.arrow.selene.SysUtils;
import com.arrow.selene.model.ProcessStatusModel;

class AwsDeviceDefenderTimerTask extends TimerTask {
	private static final Loggable LOGGER = new Loggable();
	private AtomicBoolean running = new AtomicBoolean(false);
	private NetworkStats lastStats = new NetworkStats();

	@Override
	public void run() {
		String method = "AwsDeviceDefenderTimerTask.run";

		if (running.compareAndSet(false, true)) {
			LOGGER.logInfo(method, "sending metrics...!");
			DeviceDefenderReport report = new DeviceDefenderReport();
			Ports tcpPorts = report.getMetrics().getListeningTcpPorts();
			Ports udpPorts = report.getMetrics().getListeningUdpPorts();
			Connections connections = report.getMetrics().getTcpConnections().getEstablishedConnections();

			ProcessStatusModel stat = SysUtils.executeCommandLine("/bin/netstat", "-an", "-tu");
			if (stat.getExitCode() == 0) {
				try {
					List<String> lines = IOUtils.readLines(new StringReader(stat.getOutput()));
					for (String line : lines) {
						if (line.startsWith("tcp") || line.startsWith("udp")) {
							String[] tokens = new StringTokenizer(line, " ").setIgnoreEmptyTokens(true).getTokenArray();
							int length = tokens.length;
							String protocol = tokens[0].trim();
							KeyValuePair<String, Integer> localAddress = splitAddress(tokens[3].trim());
							if (protocol.equals("tcp") && length == 6) {
								String type = tokens[5].trim();
								if (type.equals("LISTEN")) {
									tcpPorts.getPorts().add(new Port(localAddress.getKey(), localAddress.getValue()));
									tcpPorts.setTotal(tcpPorts.getTotal() + 1);
								} else if (type.equals("ESTABLISHED")) {
									String remote = tokens[4].trim();

									// AWS does not like remote address starting with ::1 :-(((
									if (!remote.startsWith("::1")) {
										connections.getConnections().add(
												new Connection(localAddress.getKey(), localAddress.getValue(), remote));
										connections.setTotal(connections.getTotal() + 1);
									} else {
										LOGGER.logWarn(method, "ignoring remoteAddress: %s", remote);
									}
								}
							} else if (protocol.equals("udp") && length == 5) {
								udpPorts.getPorts().add(new Port(localAddress.getKey(), localAddress.getValue()));
								udpPorts.setTotal(udpPorts.getTotal() + 1);
							}
						}
					}
				} catch (Throwable e) {
					LOGGER.logError(method, e);
				}
			} else {
				LOGGER.logError(method, "netstat exit code: %d, error: %s", stat.getExitCode(), stat.getError());
			}

			stat = SysUtils.executeCommandLine("/bin/cat", "/proc/net/dev");
			if (stat.getExitCode() == 0) {
				try {
					List<String> lines = IOUtils.readLines(new StringReader(stat.getOutput()));
					for (String line : lines) {
						line = line.trim();

						// growhouse gw has network config issue -> eth0 shows NO TRAFFIC, hence
						// use loopback for now for demo purpose!
						if (line.startsWith("lo:")) {
							String[] tokens = new StringTokenizer(line, " ").setIgnoreEmptyTokens(true).getTokenArray();
							int length = tokens.length;
							if (length == 17) {
								NetworkStats last = lastStats;
								NetworkStats current = new NetworkStats();
								current.setBytesIn(Long.parseLong(tokens[1].trim()));
								current.setPacketsIn(Long.parseLong(tokens[2].trim()));
								current.setBytesOut(Long.parseLong(tokens[9].trim()));
								current.setPacketsOut(Long.parseLong(tokens[10].trim()));
								if (!isEmpty(last)) {
									NetworkStats stats = report.getMetrics().getNetworkStats();
									stats.setBytesIn(current.getBytesIn() - last.getBytesIn());
									stats.setBytesOut(current.getBytesOut() - last.getBytesOut());
									stats.setPacketsIn(current.getPacketsIn() - last.getPacketsIn());
									stats.setPacketsOut(current.getPacketsOut() - last.getPacketsOut());
								}

								lastStats = current;
							} else {
								LOGGER.logError(method, "---> expected 17 tokens, found: %d", length);
							}

						}
					}
				} catch (Throwable e) {
					LOGGER.logError(method, e);
				}
			} else {
				LOGGER.logError(method, "cat exit code: %d, error: %s", stat.getExitCode(), stat.getError());
			}

			LOGGER.logInfo(method, "report: %s", JsonUtils.toJson(report));
			SelfModule.getInstance().queueAwsDeviceDefenderReportForSending(report);
			running.set(false);
		}
	}

	KeyValuePair<String, Integer> splitAddress(String address) {
		int idx = address.lastIndexOf(":");
		return new KeyValuePair<String, Integer>(address.substring(0, idx),
				Integer.valueOf(address.substring(idx + 1)));
	}

	boolean isEmpty(NetworkStats stats) {
		return stats.getBytesIn() == 0 && stats.getBytesOut() == 0 && stats.getPacketsIn() == 0
				&& stats.getPacketsOut() == 0;
	}
}
