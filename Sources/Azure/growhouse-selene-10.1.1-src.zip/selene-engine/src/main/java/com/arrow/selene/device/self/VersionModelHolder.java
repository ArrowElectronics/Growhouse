package com.arrow.selene.device.self;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.arrow.acs.JsonUtils;
import com.arrow.acs.client.model.VersionModel;

public class VersionModelHolder implements Serializable {
	private static final long serialVersionUID = 3046426757319972041L;

	private List<VersionModel> versionModels = new ArrayList<>();

	public List<VersionModel> getVersionModels() {
		return versionModels;
	}

	public void setVersionModels(List<VersionModel> versionModels) {
		this.versionModels = versionModels;
	}

	@Override
	public String toString() {
		return JsonUtils.toJson(this);
	}
}
