package com.arrow.selene.engine;

import java.io.Serializable;

import com.arrow.selene.engine.EngineConstants.RedisConfig;

public class EngineProperties implements Serializable {
	private static final long serialVersionUID = 5100033105980323285L;

	private String redisHost = RedisConfig.DEFAULT_HOST;
	private boolean enabled = true;
	private String scriptingEngine = EngineConstants.DEFAULT_SCRIPTING_ENGINE;
	private String restartScriptFilename = EngineConstants.DEFAULT_RESTART_SCRIPT_FILENAME;
	private String homeDirectory;

	private String moduleStrategy = ModuleStrategy.PROPERTIES.name();

	public String getRedisHost() {
		return redisHost;
	}

	public void setRedisHost(String redisHost) {
		this.redisHost = redisHost;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public String getModuleStrategy() {
		return moduleStrategy;
	}

	public void setModuleStrategy(String moduleStrategy) {
		this.moduleStrategy = moduleStrategy;
	}

	public String getScriptingEngine() {
		return scriptingEngine;
	}

	public void setScriptingEngine(String scriptingEngine) {
		this.scriptingEngine = scriptingEngine;
	}

	public String getRestartScriptFilename() {
		return restartScriptFilename;
	}

	public void setRestartScriptFilename(String restartScriptFilename) {
		this.restartScriptFilename = restartScriptFilename;
	}

	public String getHomeDirectory() {
		return homeDirectory;
	}

	public void setHomeDirectory(String homeDirectory) {
		this.homeDirectory = homeDirectory;
	}
}
