package com.arrow.selene.device.edge;

import java.util.ArrayList;
import java.util.List;

import com.arrow.acn.client.IotParameters;
import com.arrow.acn.client.model.TelemetryItemType;
import com.arrow.selene.data.Telemetry;
import com.arrow.selene.engine.DeviceDataAbstract;

public class RuleEngineData extends DeviceDataAbstract {
	private String alertMessage;
	private String containerId;
	private String containerName;
	private String facilityId;
	private String facilityName;
	private String growSectionId;
	private String growSectionName;
	private String gatewayHid;
	private String gatewayName;
	private String gatewayId;
	private String ruleHid;
	private String properties;

	public RuleEngineData() {
		// TODO Auto-generated constructor stub
	}

	public RuleEngineData withalertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
		return this;
	}

	public RuleEngineData withcontainerId(String containerId) {
		this.containerId = containerId;
		return this;
	}

	public RuleEngineData withcontainerName(String containerName) {
		this.containerName = containerName;
		return this;
	}

	public RuleEngineData withfacilityId(String facilityId) {
		this.facilityId = facilityId;
		return this;
	}

	public RuleEngineData withfacilityName(String facilityName) {
		this.facilityName = facilityName;
		return this;
	}

	public RuleEngineData withgrowSectionId(String growSectionId) {
		this.growSectionId = growSectionId;
		return this;
	}

	public RuleEngineData withgrowSectionName(String growSectionName) {
		this.growSectionName = growSectionName;
		return this;
	}

	public RuleEngineData withGatewayHid(String gatewayHid) {
		this.gatewayHid = gatewayHid;
		return this;
	}

	public RuleEngineData withgatewayName(String gatewayName) {
		this.gatewayName = gatewayName;
		return this;
	}

	public RuleEngineData withgatewayId(String gatewayId) {
		this.gatewayId = gatewayId;
		return this;
	}

	public RuleEngineData withRuleHid(String ruleHid) {
		this.ruleHid = ruleHid;
		return this;
	}

	public RuleEngineData withproperties(String properties) {
		this.properties = properties;
		return this;
	}

	@Override
	public IotParameters writeIoTParameters() {
		IotParameters result = new IotParameters();
		if (alertMessage != null) {
			result.setString("alertMessage", alertMessage);
		}
		if (containerId != null) {
			result.setString("containerId", containerId);
		}
		if (containerName != null) {
			result.setString("containerName", containerName);
		}
		if (facilityId != null) {
			result.setString("facilityId", facilityId);
		}
		if (facilityName != null) {
			result.setString("facilityName", facilityName);
		}
		if (growSectionId != null) {
			result.setString("growSectionId", growSectionId);
		}
		if (growSectionName != null) {
			result.setString("growSectionName", growSectionName);
		}
		if (gatewayHid != null) {
			result.setString("gatewayHid", gatewayHid);
		}
		if (gatewayName != null) {
			result.setString("gatewayName", gatewayName);
		}
		if (gatewayId != null) {
			result.setString("gatewayId", gatewayId);
		}
		if (ruleHid != null) {
			result.setString("ruleHid", ruleHid);
		}
		if (properties != null) {
			result.setString("properties", properties);
		}
		result.setDirty(true);
		return result;
	}

	@Override
	public List<Telemetry> writeTelemetries() {
		List<Telemetry> result = new ArrayList<>();
		if (alertMessage != null) {
			result.add(writeStringTelemetry(TelemetryItemType.String, "alertMessage", alertMessage));
		}
		if (containerId != null) {
			result.add(writeStringTelemetry(TelemetryItemType.String, "containerId", containerId));
		}
		if (containerName != null) {
			result.add(writeStringTelemetry(TelemetryItemType.String, "containerName", containerName));
		}
		if (facilityId != null) {
			result.add(writeStringTelemetry(TelemetryItemType.String, "facilityId", facilityId));
		}
		if (facilityName != null) {
			result.add(writeStringTelemetry(TelemetryItemType.String, "facilityName", facilityName));
		}
		if (growSectionId != null) {
			result.add(writeStringTelemetry(TelemetryItemType.String, "growSectionId", growSectionId));
		}
		if (growSectionName != null) {
			result.add(writeStringTelemetry(TelemetryItemType.String, "growSectionName", growSectionName));
		}
		if (gatewayHid != null) {
			result.add(writeStringTelemetry(TelemetryItemType.String, "gatewayHid", gatewayHid));
		}
		if (gatewayName != null) {
			result.add(writeStringTelemetry(TelemetryItemType.String, "gatewayName", gatewayName));
		}
		if (gatewayId != null) {
			result.add(writeStringTelemetry(TelemetryItemType.String, "gatewayId", gatewayId));
		}
		if (ruleHid != null) {
			result.add(writeStringTelemetry(TelemetryItemType.String, "ruleHid", ruleHid));
		}
		if (properties != null) {
			result.add(writeStringTelemetry(TelemetryItemType.String, "properties", properties));
		}
		return result;
	}

}
