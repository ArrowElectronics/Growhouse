package com.arrow.selene.device.self;

import com.arrow.selene.engine.DeviceInfo;

public class SelfInfo extends DeviceInfo {
	public static final String DEFAULT_DEVICE_TYPE = "gateway";
	private static final long serialVersionUID = -6586224013064209367L;

	// network info
	private NetworkIfaceHolder networkInterfaces;

	// version models
	private VersionModelHolder versionModels;

	private String logLevel;

	private boolean isFOTARunning = false;
	// public boolean isFOTAPerformed;
	private String growhouseUrl;

	public SelfInfo() {
		setType(DEFAULT_DEVICE_TYPE);
	}

	public NetworkIfaceHolder getNetworkInterfaces() {
		return networkInterfaces;
	}

	public void setNetworkInterfaces(NetworkIfaceHolder networkInterfaces) {
		this.networkInterfaces = networkInterfaces;
	}

	public String getLogLevel() {
		return logLevel;
	}

	public void setLogLevel(String logLevel) {
		this.logLevel = logLevel;
	}

	public VersionModelHolder getVersionModels() {
		return versionModels;
	}

	public void setVersionModels(VersionModelHolder versionModels) {
		this.versionModels = versionModels;
	}

	public boolean isFOTARunning() {
		return isFOTARunning;
	}

	public void setFOTARunning(boolean isFOTARunning) {
		this.isFOTARunning = isFOTARunning;
	}

	public String getGrowhouseUrl() {
		return growhouseUrl;
	}

	public void setGrowhouseUrl(String growhouseUrl) {
		this.growhouseUrl = growhouseUrl;
	}

}
