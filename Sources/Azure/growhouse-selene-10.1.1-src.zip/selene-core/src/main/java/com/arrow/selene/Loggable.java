package com.arrow.selene;

public class Loggable extends com.arrow.acs.Loggable {
}
