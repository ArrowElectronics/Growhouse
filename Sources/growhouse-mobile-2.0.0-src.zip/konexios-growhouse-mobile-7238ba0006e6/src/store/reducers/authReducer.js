import {
  AUTH_SAVE_USER,
  AUTH_REMOVE_USER,
  OCCURED401,
  RESET401,
} from '../actions/actionTypes';
import {Alert} from 'react-native';
import {Navigation} from 'react-native-navigation';

const initialState = {
  user: null,
  token: 'invalid',
  alertShown: false,
};
const authReducer = (state = initialState, action) => {
  switch (action.type) {
    case AUTH_SAVE_USER:
      return {
        ...state,
        user: action.user,
      };
    case AUTH_REMOVE_USER:
      return initialState;
    case OCCURED401:
      console.log('authReducer: OCCURED401');
      if (!state.alertShown) {
        Alert.alert(
          'Session Expired',
          'Please sign in again.',
          [
            {
              text: 'OK',
              onPress: async () => {
                Navigation.setRoot({
                  root: {
                    component: {
                      name: 'LoginScreen',
                    },
                  },
                });
              },
            },
          ],
          {cancelable: false},
        );
        return {...state, alertShown: true};
      } else {
        return {...state};
      }
    case RESET401:
      return {...state, alertShown: false};
    default:
      return state;
  }
};

export default authReducer;
