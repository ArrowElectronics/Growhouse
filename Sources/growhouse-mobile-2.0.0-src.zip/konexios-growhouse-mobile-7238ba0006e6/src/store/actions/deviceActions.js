/* eslint-disable no-undef */
/* eslint-disable no-alert */

import {
  SET_DEVICES,
  SET_DEVICES_BY_GROWSECTION_ID,
  SET_DEVICES_BY_GROWAREA_ID,
  IS_LED_PROFILE_DELETED,
  SET_DEVICE_TYPES,
  GET_DEVICE_PROPERTY,
  GET_HISTORICAL_DATA,
  UI_START_LOADING_INDEVICE,
  CLEAR_CURRENT_DATA,
  GET_LEDCHANNEL_DATA,
  GET_LED_PROFILE,
  GET_CURRENT_VALUE_OF_LEDNODE,
  SET_LED_INTENCITY,
  GET_RECENT_DATA,
  DELETE_DEVICES,
} from './actionTypes';
import {
  uiStartLoading,
  uiStopLoading,
  sessionExpired,
  sessionEstablished,
} from './rootActions';
import {AsyncStorage, Alert, Platform} from 'react-native';
import * as Urls from '../../Urls';

this.data = {};

export const setDevices = devices => {
  devices.sort(function(a, b) {
    return b.id - a.id;
  });
  return {
    type: SET_DEVICES,
    devices: devices,
  };
};

export const setDevicesByGrowSectionId = (
  growSectionId,
  devicesByGrowSectionId,
) => {
  devicesByGrowSectionId.sort(function(a, b) {
    return b.id - a.id;
  });
  return {
    type: SET_DEVICES_BY_GROWSECTION_ID,
    devicesByGrowSectionId: devicesByGrowSectionId,
    growSectionId: growSectionId,
  };
};

export const setDevicesByGrowAreaId = (growAreaId, devicesByGrowAreaId) => {
  devicesByGrowAreaId.sort(function(a, b) {
    return b.id - a.id;
  });
  return {
    type: SET_DEVICES_BY_GROWAREA_ID,
    devicesByGrowAreaId: devicesByGrowAreaId,
    growAreaId: growAreaId,
  };
};
export const getDevices = (growSectionId, growAreaId, inBackground) => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    let url = Urls.GET_ALL_DEVICES.replace(
      '{BASE_URL}',
      getState().root.environment.url,
    );
    if (growSectionId) {
      url = url + '/growsection/' + growSectionId;
    } else if (growAreaId) {
      url = url + '/growareas/' + growAreaId;
    }
    console.log('getDevices: ' + url);
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    fetch(url, {
      method: 'GET',
      headers,
    })
      .catch(error => {
        throw new Error('Network error!');
      })
      .then(res => {
        console.log(url);
        if (res.ok) {
          if (res.status === 204) {
            return [];
          }
          return res.json();
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else {
          throw new Error('getDevices failed:' + res.status);
        }
      })
      .then(parsedRes => {
        if (growSectionId) {
          dispatch(setDevicesByGrowSectionId(growSectionId, parsedRes));
        } else if (growAreaId) {
          dispatch(setDevicesByGrowAreaId(growAreaId, parsedRes));
        } else {
          dispatch(setDevices(parsedRes));
        }
        if (!inBackground) {
          dispatch(uiStopLoading());
        }
        dispatch(sessionEstablished());
      })
      .catch(async error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          if (!inBackground) {
            alert(error.message);
          }
          console.log(error);
        }
        if (!inBackground) {
          dispatch(uiStopLoading());
        }
      });
  };
};

export const setDeviceTypes = deviceTypes => {
  return {
    type: SET_DEVICE_TYPES,
    deviceTypes: deviceTypes,
  };
};

export const getDeviceTypes = inBackground => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url = Urls.GET_ALL_DEVICE_TYPES.replace(
      '{BASE_URL}',
      getState().root.environment.url,
    );
    console.log('getDeviceTypes: ' + url);
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    if (!inBackground) {
      dispatch(uiStartLoading());
    }
    fetch(url, {
      method: 'GET',
      headers,
    })
      .catch(error => {
        throw new Error('Network error!');
      })
      .then(res => {
        if (res.ok) {
          if (res.status === 204) {
            return [];
          }
          return res.json();
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else {
          throw new Error('getDeviceTypes failed:' + res.status);
        }
      })
      .then(parsedRes => {
        dispatch(setDeviceTypes(parsedRes));
        if (!inBackground) {
          dispatch(uiStopLoading());
        }
        dispatch(sessionEstablished());
      })
      .catch(async error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          if (!inBackground) {
            alert(error.message);
          }
          console.log(error);
        }
        if (!inBackground) {
          dispatch(uiStopLoading());
        }
      });
  };
};

//To fomate time string to maintain AM/PM consistency in both apps.
var formatStandardTime = date => {
  let time = date.toLocaleTimeString();
  time = time.split(':'); // convert to array

  // fetch
  var hours = Number(time[0]);
  var minutes = Number(time[1]);
  var seconds = Number(time[2]);

  // calculate
  var timeValue;

  if (hours > 0 && hours <= 12) {
    timeValue = '' + hours;
  } else if (hours > 12) {
    timeValue = '' + (hours - 12);
  } else if (hours == 0) {
    timeValue = '12';
  }
  timeValue += minutes < 10 ? ':0' + minutes : ':' + minutes; // get minutes
  timeValue +=
    Platform.OS === 'ios'
      ? ':' + time[2]
      : seconds < 10
      ? ':0' + seconds
      : ':' + seconds; // get seconds
  timeValue += Platform.OS === 'ios' ? '' : hours >= 12 ? ' PM' : ' AM'; // get AM/PM

  return timeValue;
};

formatDate = value => {
  return (
    value.getMonth() + 1 + '/' + value.getDate() + '/' + value.getFullYear()
  );
};

// diffrenciating response for chartjs to show
var gettingChartData = historicalData => {
  var labels = [];
  var dataList = [];

  historicalData.map(data => {
    var dateLable =
      this.formatDate(new Date(data.timestamp)) +
      ' ' +
      formatStandardTime(new Date(data.timestamp));
    labels.push(dateLable);
    dataList.push(parseFloat(data.value));
  });
  var response = [];
  response.push({labels: labels});
  response.push({dataList: dataList});
  console.log('SA NM, MS,CNS CASCNB ASCN ANC A', response[0], response[1]);

  return response;
};

// api for getting historical data for specific device
export const getHistoricalData = (toDate, fromDate, deviceHid, property) => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url =
      getState().root.environment.url +
      `/telemetry/device/${deviceHid}?fromTimestamp=${fromDate}&toTimestamp=${toDate}&propertyName=${property}`;
    console.log('getHistoricalData: ' + url);
    console.log('parameters', toDate, fromDate, property, deviceHid);
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    dispatch(isScreenLoading(true));
    fetch(url, {
      method: 'GET',
      headers,
    })
      .catch(error => {
        throw new Error('Network error!');
      })
      .then(res => {
        if (res.ok) {
          if (res.status === 204) {
            throw new Error('Device telementry not available');
          }
          return res.json();
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else {
          dispatch({
            type: GET_HISTORICAL_DATA,
            payload: [{statusCode: '500'}],
          });
          throw new Error('getHistoricalData failed:' + res.status);
        }
      })
      .then(async historicalData => {
        const chartData = await gettingChartData(historicalData);
        console.log('chartData', chartData.length, chartData[0], chartData[1]);
        dispatch({type: GET_HISTORICAL_DATA, payload: chartData});
        dispatch(isScreenLoading(false));
        dispatch(sessionEstablished());
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else if (error.message === 'Device telementry not available') {
          dispatch({
            type: GET_HISTORICAL_DATA,
            payload: [{statusCode: '204'}],
          });
        } else {
          alert(error.message);
        }
        dispatch(isScreenLoading(false));
      });
  };
};

// api for getting device property of specific device
export const getDeviceProperty = deviceId => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url =
      getState().root.environment.url +
      `/devices/properties/device/${deviceId}`;
    console.log('getDeviceProperty: ' + url);
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    fetch(url, {
      method: 'GET',
      headers,
    })
      .catch(error => {
        throw new Error('Network error!');
      })
      .then(res => {
        if (res.ok) {
          if (res.status === 204) {
            return [];
          }
          return res.json();
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else {
          throw new Error('getDeviceProperty failed:' + res.status);
        }
      })
      .then(propertyList => {
        dispatch({type: GET_DEVICE_PROPERTY, payload: propertyList});
        dispatch(sessionEstablished());
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          alert(error.message);
        }
        dispatch(isScreenLoading(false));
      });
  };
};

// api for getting  led profile for specific LED
export const getLedProfiles = deviceId => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url =
      getState().root.environment.url + `/devices/lednode/${deviceId}/profile`;
    console.log('getLedProfiles: ' + url);
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    fetch(url, {
      method: 'GET',
      headers,
    })
      .catch(error => {
        console.log('get profiled called5');
        throw new Error('Network error!');
      })
      .then(res => {
        if (res.ok) {
          if (res.status === 204) {
            return [];
          }
          return res.json();
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else {
          throw new Error('getLedProfiles failed:' + res.status);
        }
      })
      .then(profiles => {
        dispatch({type: GET_LED_PROFILE, payload: profiles});
        dispatch(isScreenLoading(false));
        dispatch(sessionEstablished());
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          alert(error.message);
        }
        dispatch(isScreenLoading(false));
      });
  };
};

// api for getting specific LED's channel
export const getLedChannels = deviceId => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url =
      getState().root.environment.url +
      `/devices/lednode/${deviceId}/channelconfiguration`;
    console.log('getLedChannels: ' + url);
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    fetch(url, {
      method: 'GET',
      headers,
    })
      .catch(error => {
        throw new Error('Network error!');
      })
      .then(res => {
        if (res.ok) {
          if (res.status === 204) {
            return [];
          }
          return res.json();
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else {
          throw new Error('getLedChannels failed:' + res.status);
        }
      })
      .then(ledChannels => {
        dispatch({type: GET_LEDCHANNEL_DATA, payload: ledChannels});
        dispatch(sessionEstablished());
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          alert(error.message);
        }
      });
  };
};
// api for set new channel configuration
export const setLedControls = reqData => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url =
      getState().root.environment.url + '/devices/lednodevalue/history';
    console.log('setLedControls: ' + url);
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    dispatch({type: UI_START_LOADING_INDEVICE, payload: true});
    fetch(url, {
      method: 'POST',
      headers,
      body: JSON.stringify(reqData),
    })
      .catch(error => {
        console.log('error', error);
        throw new Error('Network error!');
      })
      .then(res => {
        if (res.ok) {
          if (res.status === 204) {
            return [];
          }
          return res.json();
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else {
          throw new Error('setLedControls failed:' + res.status);
        }
      })
      .then(response => {
        console.log(response);
        console.log(JSON.stringify(response));
        var res = [
          {led1: response.ch1},
          {led2: response.ch2},
          {led3: response.ch3},
          {led4: response.ch4},
          {led5: response.ch5},
          {led6: response.ch6},
        ];
        dispatch({type: SET_LED_INTENCITY, payload: res});

        setTimeout(() => {
          Alert.alert(
            'Device set',
            'Set Channel Configuration Values Successfully',
          );
          dispatch(isScreenLoading(false));
        }, 500);
        dispatch(sessionEstablished());
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          alert(error.message);
        }
        dispatch(isScreenLoading(false));
      });
  };
};

// api for adding new profile for specific  profile
export const addProfile = payload => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url = getState().root.environment.url + '/devices/lednode/profile';
    console.log('addProfile: ' + url);
    const reqData = JSON.stringify(payload);
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    dispatch(isScreenLoading(true));
    fetch(url, {
      method: 'POST',
      headers,
      body: reqData,
    })
      .catch(error => {
        console.log('error', error);
        throw new Error('Network error!');
      })
      .then(async res => {
        console.log('addProfile response: ' + JSON.stringify(res));
        if (res.ok) {
          return;
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else if (res.status === 400) {
          let errorJson = await res.json();
          let message = await errorJson.message;
          throw new Error(`${message}`);
        } else {
          throw new Error('addProfile failed:' + res.status);
        }
      })
      .then(() => {
        dispatch(getLedProfiles(payload.device.id));
        dispatch(isScreenLoading(false));
        dispatch(sessionEstablished());
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          alert(error.message);
        }
        dispatch(isScreenLoading(false));
      });
  };
};

export const lastTelementry = (telemntry, lengthOfDevices, deviceHid) => {
  return dispatch => {
    this.data[deviceHid] = telemntry;
    if (Object.keys(this.data).length === lengthOfDevices) {
      console.log('in same length', lengthOfDevices);

      dispatch({type: GET_RECENT_DATA, payload: this.data});
      dispatch(uiStopLoading());
    }
  };
};

// api for get current value of intencity of specific device
export const getCurrentValue = (deviceHid, lengthOfDevices) => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url =
      getState().root.environment.url + `/devices/${deviceHid}/telemtry/last`;
    console.log('getCurrentValue: ' + url);
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    fetch(url, {
      method: 'GET',
      headers,
    })
      .catch(error => {
        console.log('error', error);
        throw new Error('Network error!');
      })
      .then(res => {
        if (res.ok) {
          if (res.status === 204) {
            return [];
          }
          return res.json();
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else {
          throw new Error('getCurrentValue failed:' + res.status);
        }
      })
      .then(currentValueOfLedNode => {
        if (lengthOfDevices) {
          return dispatch(
            lastTelementry(currentValueOfLedNode, lengthOfDevices, deviceHid),
          );
        } else {
          let currentValueOfLedNodeResponse = {};
          currentValueOfLedNode.map(channel => {
            if (channel.name === 'led1') {
              currentValueOfLedNodeResponse.led1 = channel.value;
            }
            if (channel.name === 'led2') {
              currentValueOfLedNodeResponse.led2 = channel.value;
            }
            if (channel.name === 'led3') {
              currentValueOfLedNodeResponse.led3 = channel.value;
            }
            if (channel.name === 'led4') {
              currentValueOfLedNodeResponse.led4 = channel.value;
            }
            if (channel.name === 'led5') {
              currentValueOfLedNodeResponse.led5 = channel.value;
            }
            if (channel.name === 'led6') {
              currentValueOfLedNodeResponse.led6 = channel.value;
            }
          });
          dispatch({
            type: GET_CURRENT_VALUE_OF_LEDNODE,
            payload: currentValueOfLedNodeResponse,
          });
          dispatch(sessionEstablished());
        }
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          if (lengthOfDevices) {
            return dispatch(lastTelementry([{}], lengthOfDevices, deviceHid));
          }
          alert(error.message);
        }
      });
  };
};

//code to start/stop loading
export const isScreenLoading = isLoading => {
  return {
    type: UI_START_LOADING_INDEVICE,
    payload: isLoading,
  };
};

export const getRecentData = devices => {
  return dispatch => {
    dispatch(uiStartLoading());
    devices.map(async (device, i) => {
      await dispatch(getCurrentValue(device.deviceHid, devices.length));
      console.log('deviceHid in devices', device.deviceHid);
    });
  };
};

export const deleteDevice = deviceId => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url =
      Urls.DELETE_DEVICE.replace(
        '{BASE_URL}',
        getState().root.environment.url,
      ) + `/${deviceId}`;
    console.log('deleteDevice: ' + url);
    dispatch(uiStartLoading());
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    fetch(url, {
      method: 'DELETE',
      headers,
    })
      .catch(error => {
        throw new Error('Network error!');
      })
      .then(res => {
        if (res.ok) {
          if (res.status === 204) {
            return {};
          }
          return res.json();
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else {
          throw new Error('deleteDevice failed:' + res.status);
        }
      })
      .then(res => {
        dispatch(uiStopLoading());
        dispatch(deleteDeviceResponse(true));
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          console.log('error in gateway deletion', error);
          setTimeout(() => {
            alert('Something went wrong while deleting Device');
          }, 200);
        }
        dispatch(uiStopLoading());
      });
  };
};

export const deleteDeviceResponse = flag => {
  return {
    type: DELETE_DEVICES,
    payload: flag,
  };
};

export const clearCurrentData = () => {
  return {
    type: CLEAR_CURRENT_DATA,
    payload: [],
  };
};

export const deleteProfile = id => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url =
      Urls.DELETE_DEVICE.replace(
        '{BASE_URL}',
        getState().root.environment.url,
      ) + `/lednode/profile/${id}`;
    console.log('deleteProfile: ' + url);
    dispatch(isScreenLoading(true));
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    fetch(url, {
      method: 'DELETE',
      headers,
    })
      .catch(error => {
        console.log('error --------> ', error, error.message);

        throw new Error('Network error!');
      })
      .then(res => {
        if (res.ok) {
          if (res.status === 204) {
            return {};
          }
          return {};
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else {
          throw new Error('deleteProfile failed:' + res.status);
        }
      })
      .then(res => {
        dispatch(isScreenLoading(false));
        dispatch(isProfileDeleted(true));
        dispatch(sessionEstablished());
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          console.log('error in LED Profile deletion', error, error.message);
          setTimeout(() => {
            alert('Something went wrong while deleting profile..');
          }, 200);
        }
        dispatch(uiStopLoading());
      });
  };
};

export const isProfileDeleted = flag => {
  return dispatch => {
    dispatch({type: IS_LED_PROFILE_DELETED, payload: flag});
  };
};
