import {SET_USERS, SET_USERS_BY_FACILITY_ID} from './actionTypes';
import {uiStartLoading, uiStopLoading, sessionEstablished} from './rootActions';
import * as Urls from '../../Urls';
import {sessionExpired} from './authActions';

export const setUsers = users => {
  users.sort(function(a, b) {
    return b.id - a.id;
  });
  return {
    type: SET_USERS,
    users: users,
  };
};

export const setUsersByFacilityId = (facilityId, usersByFacilityId) => {
  usersByFacilityId.sort(function(a, b) {
    return b.id - a.id;
  });
  return {
    type: SET_USERS_BY_FACILITY_ID,
    usersByFacilityId: usersByFacilityId,
    facilityId: facilityId,
  };
};

export const getUsers = inBackground => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url = Urls.GET_ALL_USERS.replace(
      '{BASE_URL}',
      getState().root.environment.url,
    );
    console.log('getUsers: ' + url);
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    if (!inBackground) {
      dispatch(uiStartLoading());
    }
    fetch(url, {
      method: 'GET',
      headers,
    })
      .catch(error => {
        throw new Error('Network error!');
      })
      .then(res => {
        if (res.ok) {
          if (res.status === 204) {
            return [];
          }
          return res.json();
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else {
          throw new Error('getUsers failed:' + res.status);
        }
      })
      .then(parsedRes => {
        dispatch(setUsers(parsedRes));
        if (!inBackground) {
          dispatch(uiStopLoading());
        }
        dispatch(sessionEstablished());
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          if (!inBackground) {
            console.log(error.message);
          }
          console.log(error);
        }
        if (!inBackground) {
          dispatch(uiStopLoading());
        }
      });
  };
};
