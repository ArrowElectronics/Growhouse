/* eslint-disable no-alert */
import {
  PROFILE_LIST_PROCEESSING,
  IS_GROUP_PROFILE_DETAILS_LOADING,
  GET_LEDNODE_GROUP_PROFILE_LIST,
  GET_GROUP_PROFILE_DETAILS,
  IS_LED_GROUP_PROFILE_LIST_LOADING,
} from './actionTypes';
import {sessionExpired, sessionEstablished} from './rootActions';
import * as Urls from '../../Urls';

export const getLEDGroupProfiles = groupId => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url =
      Urls.GET_LEDNODE_GROUP_PROFILE_LIST.replace(
        '{BASE_URL}',
        getState().root.environment.url,
      ) + `/${groupId}/profiles`;
    console.log('getLEDGroupProfiles: ' + url);
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    dispatch(isLEDGroupProfileLoading(true));
    fetch(url, {
      method: 'GET',
      headers,
    })
      .catch(error => {
        throw new Error('Network error!');
      })
      .then(res => {
        if (res.ok) {
          if (res.status === 204) {
            return [];
          }
          return res.json();
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else {
          throw new Error('getLEDGroupProfiles failed:' + res.status);
        }
      })
      .then(parsedRes => {
        dispatch({
          type: GET_LEDNODE_GROUP_PROFILE_LIST,
          payload: parsedRes,
        });
        dispatch(sessionEstablished());
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          alert(error.message);
        }
        dispatch(isLEDGroupProfileLoading(false));
      });
  };
};

export const createProfile = reqData => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url = Urls.CREATE_GROUP_PROFILE.replace(
      '{BASE_URL}',
      getState().root.environment.url,
    );
    console.log('createProfile: ' + url);
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    let payload = JSON.stringify(reqData);
    dispatch(isLEDGroupProfileLoading(true));
    fetch(url, {
      method: 'POST',
      headers,
      body: payload,
    })
      .catch(error => {
        throw new Error('Network error!');
      })
      .then(async res => {
        if (res.ok) {
          if (res.status === 204) {
            return [];
          }
          return res.json();
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else if (res.status === 400) {
          let errorJson = await res.json();
          dispatch({
            type: IS_GROUP_PROFILE_DETAILS_LOADING,
            payload: false,
          });
          let message = await errorJson.message;
          throw new Error(`${message}`);
        } else {
          throw new Error('createProfile failed:' + res.status);
        }
      })
      .then(parsedRes => {
        dispatch(stopProccessingForProfileList(true));
        dispatch(isLEDGroupProfileLoading(false));
        dispatch(sessionEstablished());
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          console.log('error in finding devices', error);
          setTimeout(() => {
            alert(error.message);
          }, 200);
        }
        dispatch(isLEDGroupProfileLoading(false));
      });
  };
};

export const updateProfile = reqData => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url = Urls.CREATE_GROUP_PROFILE.replace(
      '{BASE_URL}',
      getState().root.environment.url,
    );
    console.log('updateProfile: ' + url);
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    let payload = JSON.stringify(reqData);
    dispatch(isLEDGroupProfileLoading(true));
    fetch(url, {
      method: 'PUT',
      headers,
      body: payload,
    })
      .catch(error => {
        throw new Error('Network error!');
      })
      .then(async res => {
        if (res.ok) {
          if (res.status === 204) {
            return [];
          }
          return res.json();
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else if (res.status === 400) {
          let errorJson = await res.json();
          dispatch({
            type: IS_GROUP_PROFILE_DETAILS_LOADING,
            payload: false,
          });
          let message = await errorJson.message;
          throw new Error(`${message}`);
        } else {
          throw new Error('updateProfile failed:' + res.status);
        }
      })
      .then(parsedRes => {
        dispatch(stopProccessingForProfileList(true));
        dispatch(isLEDGroupProfileLoading(false));
        dispatch(sessionEstablished());
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          console.log('error in  updating LED group profile.', error);
          setTimeout(() => {
            alert(error.message);
          }, 200);
        }
        dispatch(isLEDGroupProfileLoading(false));
      });
  };
};

export const deleteGroupProfile = id => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url =
      Urls.CREATE_GROUP_PROFILE.replace(
        '{BASE_URL}',
        getState().root.environment.url,
      ) + `/${id}`;
    console.log('deleteGroupProfile: ' + url);
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    dispatch(isLEDGroupProfileLoading(true));
    fetch(url, {
      method: 'DELETE',
      headers,
    })
      .catch(error => {
        throw new Error('Network error!');
      })
      .then(res => {
        if (res.ok) {
          if (res.status === 204) {
            return [];
          }
          return res.json();
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else {
          throw new Error('deleteGroupProfile failed:' + res.status);
        }
      })
      .then(parsedRes => {
        dispatch(stopProccessingForProfileList(true));
        dispatch(isLEDGroupProfileLoading(false));
        dispatch(sessionEstablished());
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          console.log('error in  deleting LED group profile.', error);
          setTimeout(() => {
            alert(error.message);
          }, 200);
        }
        dispatch(isLEDGroupProfileLoading(false));
      });
  };
};

export const isLEDGroupProfileLoading = flag => {
  return {
    type: IS_LED_GROUP_PROFILE_LIST_LOADING,
    payload: flag,
  };
};

export const stopProccessingForProfileList = flag => {
  return {
    type: PROFILE_LIST_PROCEESSING,
    payload: flag,
  };
};

export const getProfileDetails = id => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url =
      Urls.CREATE_GROUP_PROFILE.replace(
        '{BASE_URL}',
        getState().root.environment.url,
      ) + `/${id}`;
    console.log('getProfileDetails: ' + url);
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    dispatch({type: IS_GROUP_PROFILE_DETAILS_LOADING, payload: true});
    fetch(url, {
      method: 'GET',
      headers,
    })
      .catch(error => {
        throw new Error('Network error!');
      })
      .then(res => {
        if (res.ok) {
          if (res.status === 204) {
            return [];
          }
          return res.json();
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else {
          throw new Error('getProfileDetails failed:' + res.status);
        }
      })
      .then(parsedRes => {
        dispatch({type: GET_GROUP_PROFILE_DETAILS, payload: parsedRes});
        setTimeout(() => {
          dispatch({
            type: IS_GROUP_PROFILE_DETAILS_LOADING,
            payload: false,
          });
        }, 5000);
        dispatch(sessionEstablished());
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          alert(error.message);
        }
        dispatch({type: IS_GROUP_PROFILE_DETAILS_LOADING, payload: false});
      });
  };
};

export const applyNowGroupProfile = reqData => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url =
      Urls.CREATE_GROUP_PROFILE.replace(
        '{BASE_URL}',
        getState().root.environment.url,
      ) + '/now';
    console.log('applyNowGroupProfile: ' + url);
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    dispatch({type: IS_GROUP_PROFILE_DETAILS_LOADING, payload: true});
    let payload = JSON.stringify(reqData);
    fetch(url, {
      method: 'POST',
      headers,
      body: payload,
    })
      .catch(error => {
        console.log('network error in apply now group profile', error);
        throw new Error('Network error!');
      })
      .then(async res => {
        if (res.ok) {
          if (res.status === 204) {
            return [];
          }
          return res;
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else if (res.status === 400) {
          let errorJson = await res.json();
          dispatch({
            type: IS_GROUP_PROFILE_DETAILS_LOADING,
            payload: false,
          });
          let message = await errorJson.message;
          throw new Error(`${message}`);
        } else {
          throw new Error('applyNowGroupProfile failed:' + res.status);
        }
      })
      .then(parsedRes => {
        dispatch({type: IS_GROUP_PROFILE_DETAILS_LOADING, payload: false});
        setTimeout(() => {
          Alert.alert('Apply Profile', 'Profile applied successfully!!');
        }, 500);
        dispatch(sessionEstablished());
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          console.log('error', error, error.message);
          alert(error.message);
        }
        dispatch({
          type: IS_GROUP_PROFILE_DETAILS_LOADING,
          payload: false,
        });
      });
  };
};

export const eventGroupProfile = reqData => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url =
      Urls.CREATE_GROUP_PROFILE.replace(
        '{BASE_URL}',
        getState().root.environment.url,
      ) + '/event';
    console.log('eventGroupProfile: ' + url);
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    dispatch({type: IS_GROUP_PROFILE_DETAILS_LOADING, payload: true});
    let payload = JSON.stringify(reqData);
    fetch(url, {
      method: 'POST',
      headers,
      body: payload,
    })
      .catch(error => {
        console.log('network error in apply event group profile', error);
        throw new Error('Network error!');
      })
      .then(async res => {
        if (res.ok) {
          if (res.status === 204) {
            return [];
          }
          return JSON.stringify(res.json());
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else if (res.status === 400) {
          let errorJson = await res.json();
          dispatch({
            type: IS_GROUP_PROFILE_DETAILS_LOADING,
            payload: false,
          });
          let message = await errorJson.message;
          throw new Error(`${message}`);
        } else {
          throw new Error('eventGroupProfile failed:' + res.status);
        }
      })
      .then(parsedRes => {
        dispatch({type: IS_GROUP_PROFILE_DETAILS_LOADING, payload: false});
        setTimeout(() => {
          Alert.alert('Apply Profile', 'Profile Scheduled successfully!!');
        }, 500);
        dispatch(sessionEstablished());
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          console.log('error', error, error.message);
          alert(error.message);
        }
        dispatch({
          type: IS_GROUP_PROFILE_DETAILS_LOADING,
          payload: false,
        });
      });
  };
};
