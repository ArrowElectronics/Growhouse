/* eslint-disable no-alert */
import * as Urls from '../../Urls';
import {GET_DASHBOARD_ALERT, GET_DASHBOARD_COUNT} from './actionTypes';
import {sessionEstablished, sessionExpired} from './rootActions';

export const getDashboardCount = () => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url = Urls.GET_DASHBOARD_COUNT.replace(
      '{BASE_URL}',
      getState().root.environment.url,
    );
    console.log('getDashboardCount: ' + url);
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
  };
    fetch(url, {
      method: 'GET',
      headers,
    })
      .catch(error => {
        throw new Error('Network error!');
      })
      .then(res => {
        if (res.ok) {
          if (res.status === 204) {
            return [];
          }
          return res.json();
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else {
          throw new Error('getDashboardCount failed: ' + res.status);
        }
      })
      .then(parsedRes => {
        dispatch({type: GET_DASHBOARD_COUNT, payload: parsedRes});
        dispatch(sessionEstablished());
      })
      .catch(async error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          alert(error.message);
          console.log(error);
        }
      });
  };
};

export const getAlerts = () => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url = Urls.GET_DASHBOARD_ALERT.replace(
      '{BASE_URL}',
      getState().root.environment.url,
    );
    console.log('getAlerts: ' + url);
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
  };
    fetch(url, {
      method: 'GET',
      headers,
    })
      .catch(error => {
        throw new Error('Network error!');
      })
      .then(res => {
        if (res.ok) {
          if (res.status === 204) {
            return [];
          }
          return res.json();
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else {
          throw new Error('getAlerts failed:' + res.status);
        }
      })
      .then(parsedRes => {
        dispatch({type: GET_DASHBOARD_ALERT, payload: parsedRes});
        dispatch(sessionEstablished());
      })
      .catch(async error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          alert(error.message);
          console.log(error);
        }
      });
  };
};
