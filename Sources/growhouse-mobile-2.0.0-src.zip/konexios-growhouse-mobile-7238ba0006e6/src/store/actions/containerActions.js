/* eslint-disable no-alert */
import {SET_CONTAINERS, SET_CONTAINERS_BY_FACILITY_ID} from './actionTypes';
import {
  uiStartLoading,
  uiStopLoading,
  sessionExpired,
  sessionEstablished,
} from './rootActions';
import * as Urls from '../../Urls';

export const setContainers = containers => {
  containers.sort(function(a, b) {
    return b.id - a.id;
  });
  return {
    type: SET_CONTAINERS,
    containers: containers,
  };
};

export const setContainersByFacilityId = (
  facilityId,
  containersByFacilityId,
  showAlertFlag,
) => {
  containersByFacilityId.sort(function(a, b) {
    return b.id - a.id;
  });
  console.log(
    'Setting ' +
      containersByFacilityId.length +
      ' containers in facility ' +
      facilityId,
    showAlertFlag,
  );
  return {
    type: SET_CONTAINERS_BY_FACILITY_ID,
    containersByFacilityId: containersByFacilityId,
    facilityId: facilityId,
    showAlert:
      containersByFacilityId.length === 0 && showAlertFlag ? true : false,
  };
};

export const getContainers = (facilityId, inBackground, showAlert) => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    let url = Urls.GET_ALL_CONTAINERS.replace(
      '{BASE_URL}',
      getState().root.environment.url,
    );
    if (facilityId) {
      url = url + '/facilities/' + facilityId;
    }
    console.log('getContainers: ' + url);
    if (!inBackground) {
      dispatch(uiStartLoading());
    }
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
  };
    fetch(url, {
      method: 'GET',
      headers,
    })
      .catch(error => {
        throw new Error('Network error!');
      })
      .then(res => {
        if (res.ok) {
          if (res.status === 204) {
            return [];
          }
          return res.json();
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else {
          throw new Error('getContainers failed!\nstatusCode:' + res.status);
        }
      })
      .then(parsedRes => {
        if (facilityId) {
          dispatch(setContainersByFacilityId(facilityId, parsedRes, showAlert));
        } else {
          dispatch(setContainers(parsedRes));
        }
        if (!inBackground) {
          dispatch(uiStopLoading());
        }
        dispatch(sessionEstablished());
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          if (!inBackground) {
            alert(error.message);
          }
          console.log(error);
        }
        if (!inBackground) {
          dispatch(uiStopLoading());
        }
      });
  };
};
