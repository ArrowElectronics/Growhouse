import {AsyncStorage, Alert} from 'react-native';
import {disconnectBleinDevice} from '../../screens/Devices';
import {disconnectBleinGrowarea} from '../../screens/GrowAreasIOS';
import * as Urls from '../../Urls';
import {
  AUTH_REMOVE_USER,
  OCCURED401,
  RESET401,
  AUTH_SET_TOKEN,
  SET_USER_DETAILS,
} from './actionTypes';
import {uiStartLoading, uiStopLoading} from './rootActions';
import App from '../../../App';

export const authLogin = (username, password) => {
  return (dispatch, getState) => {
    const url = Urls.USER_LOGIN.replace(
      '{BASE_URL}',
      getState().root.environment.url,
    );
    console.log('authLogin: ' + url);
    fetch(url, {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        login: username,
        password: password,
        mobileApp: true,
      }),
    })
      .then(response => {
        if (response.status === 200) {
          return response.json();
        } else {
          throw new Error('Sign-in failed!');
        }
      })
      .then(session => {
        const user = session.userDTO;
        console.log('>>>>> user: ' + JSON.stringify(user));
        if (
          user.user_role &&
          user.user_role.role_name &&
          user.user_role.role_name === 'Admin'
        ) {
          dispatch({type: AUTH_SET_TOKEN, token: session.sessionId});
          dispatch({type: SET_USER_DETAILS, currentUser: user});
          dispatch(getKonexiosConfig(session.sessionId));
          AsyncStorage.multiSet([
            ['token', session.sessionId],
            ['userEmail', user.email_id],
            ['userId', user.id.toString()],
            ['userName', user.username],
          ])
            .then(() => {
              App(0);
            })
            .catch(error => {
              console.log('error in saving name', error);
            });
          dispatch(sessionEstablished());
        } else {
          throw Error("You don't have access to use this application");
        }
      })
      .catch(error => {
        Alert.alert(error.message);
      });
  };
};

export const getKonexiosConfig = token => {
  return (dispatch, getState) => {
    const url = Urls.GET_KONEXIOS_CONFIG.replace(
      '{BASE_URL}',
      getState().root.environment.url,
    );
    console.log('getKonexiosConfig: ' + url);
    fetch(url, {
      method: 'GET',
      headers: {
        Authorization: token,
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
    })
      .then(response => {
        if (response.status === 200) {
          return response.json();
        } else {
          throw new Error('System Error!\nUnable to download configuration');
        }
      })
      .then(json => {
        AsyncStorage.setItem('konexiosConfig', JSON.stringify(json)).then(
          () => {
            console.log('persisted Konexios configuration');
          },
        );
      })
      .catch(error => {
        Alert.alert(error.message);
      });
  };
};

export const authLogout = inBackground => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    const url = Urls.USER_LOGOUT.replace(
      '{BASE_URL}',
      getState().root.environment.url,
    );
    console.log('authLogout: ' + url);
    dispatch(uiStartLoading());
    fetch(url, {
      method: 'POST',
      headers: {
        Authorization: token,
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
    })
      .then(res => {
        console.log(res);
      })
      .catch(e => {
        console.log('logout error: ' + e.message);
      });
    AsyncStorage.clear()
      .then(() => {
        if (!inBackground) {
          disconnectBleinDevice();
          disconnectBleinGrowarea();
        }
        dispatch(sessionEstablished());
        dispatch(uiStopLoading());
      })
      .catch(e => {
        console.log('error in deleting devices', e.message);
      });
    dispatch({
      type: AUTH_REMOVE_USER,
    });
  };
};

export const sessionExpired = () => {
  return {
    type: OCCURED401,
    payload: 1,
  };
};

export const sessionEstablished = () => {
  return {
    type: RESET401,
  };
};
