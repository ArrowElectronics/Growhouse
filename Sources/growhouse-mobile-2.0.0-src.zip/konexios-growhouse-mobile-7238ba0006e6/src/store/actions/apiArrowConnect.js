/* eslint-disable no-alert */
/* global payLoadForInternalCloud, internalCloudPayload */

import {
  SET_GATEWAY_CONFIG,
  SET_GATEWAY_HID,
  SENDING_PAYLOAD_TO_GATEWAY,
} from './actionTypes';
import {uiUpdateRegistrationState} from './rootActions';
import * as Urls from '../../Urls';
import * as RegistrationStates from '../../RegistrationStates';
import {selene as seleneVersion, softwareName} from './../../../app.json';
import {AsyncStorage} from 'react-native';

export const storeGatewayHId = gatewayHId => {
  return {
    type: SET_GATEWAY_HID,
    gatewayHId: gatewayHId,
  };
};

export const registerGatewayToArrow = (payload, bleDevice, SeleneVersion) => {
  return async (dispatch, getState) => {
    const konexiosConfig = JSON.parse(
      await AsyncStorage.getItem('konexiosConfig'),
    );
    console.log(
      'registerGatewayToArrow() applicationHid: ' +
        konexiosConfig.applicationHid,
    );

    let url = Urls.KONEXIOS_GATEWAY_REGISTRATION_URL.replace(
      '{BASE_URL}',
      konexiosConfig.apiUrl,
    );
    console.log('registerGatewayToArrow: ' + url);

    payload.applicationHid = konexiosConfig.applicationHid;

    payload.deviceType = 'Gateway';
    payload.softwareVersion =
      SeleneVersion !== '' ? SeleneVersion : seleneVersion; // selene version
    payload.softwareName = softwareName; // softwareName
    payload.type = 'Local';
    payload.growhouseUrl = getState().root.environment.url; //base url
    payload.uid = payload.gatewayMacId;
    payload = JSON.stringify(payload);

    dispatch(
      uiUpdateRegistrationState(
        RegistrationStates.REGISTRATION_STARTED_TO_ARROW,
      ),
    );
    fetch(url, {
      method: 'POST',
      headers: {
        'x-auth-token': konexiosConfig.apiKey,
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      body: payload,
    })
      .catch(error => {
        bleDevice.cancelConnection().catch(e => {
          console.log('error', e);
        });

        throw new Error('Network error!');
      })
      .then(res => {
        if (res.ok) {
          return res.json();
        } else {
          throw new Error(
            'Something went wrong while registering to Arrow: \nStatusCode:' +
              res.status,
          );
        }
      })
      .then(parsedRes => {
        console.log('parsedRes: ' + JSON.stringify(parsedRes));
        dispatch(storeGatewayHId(parsedRes.hid));
        dispatch(
          uiUpdateRegistrationState(
            RegistrationStates.REGISTRATION_SUCCESS_TO_ARROW,
          ),
        );
        payload = JSON.parse(payload);
        payLoadForInternalCloud = {
          description: payload.description,
          gatewayName: payload.name,
          gatewayHId: parsedRes.hid,
          growAreaTypeId: payload.growAreaTypeId,
          growAreaType: payload.growAreaType,
          macId: payload.gatewayMacId,
          containerId: payload.containerId,
          facilityId: payload.facilityId,
          uid: payload.uid,
          users: payload.users,
        };
        console.log(
          'Calling fetchConfig with ' + JSON.stringify(payLoadForInternalCloud),
        );
        dispatch(fetchingCloudConfig(payLoadForInternalCloud, bleDevice));
      })
      .catch(error => {
        alert('Error:' + error.message);
        console.log(error);
        bleDevice.cancelConnection().catch(e => {
          console.log('error', e);
        });
        dispatch(
          uiUpdateRegistrationState(
            RegistrationStates.REGISTRATION_FAILED_TO_ARROW,
          ),
        );
      });
  };
};

export const fetchingCloudConfig = (payload, bleDevice) => {
  return async dispatch => {
    const konexiosConfig = JSON.parse(
      await AsyncStorage.getItem('konexiosConfig'),
    );

    let url = Urls.KONEXIOS_GATEWAY_CONFIG_GET_URL.replace(
      '{BASE_URL}',
      konexiosConfig.apiUrl,
    );
    if (payload.gatewayHId) {
      url = url.replace('{0}', payload.gatewayHId);
    } else {
      dispatch(
        uiUpdateRegistrationState(
          RegistrationStates.REGISTRATION_FAILED_TO_INTERNAL_CLOUD,
        ),
      );
    }

    console.log('fetchingCloudConfig: ' + url);

    dispatch(
      uiUpdateRegistrationState(
        RegistrationStates.FETCHING_CONFIG_FROM_ARROW_STARTED,
      ),
    );
    fetch(url, {
      method: 'GET',
      headers: {
        'x-auth-token': konexiosConfig.apiKey,
        accept: 'application/json',
        'Content-Type': 'application/json',
      },
    })
      .catch(error => {
        bleDevice.cancelConnection().catch(e => {
          console.log('error', e);
        });
        throw new Error('Network error!');
      })
      .then(res => {
        console.log('fetchingCloudConfig status: ' + JSON.stringify(res));
        if (res.ok) {
          return res.json();
        } else {
          throw new Error(
            'Something went wrong while fetching Config from Arrow: \nStatusCode:' +
              res.status,
          );
        }
      })
      .then(parsedRes => {
        dispatch({type: SET_GATEWAY_CONFIG, gatewayConfig: parsedRes});
        internalCloudPayload = {
          description: payload.description,
          grow_area_name: payload.gatewayName,
          grow_area_hid: payload.gatewayHId,
          grow_area_type: payload.growAreaType,
          mac_id: payload.macId,
          grow_area_uid: payload.uid,
          container: {
            id: payload.containerId,
          },
          facility: {
            id: payload.facilityId,
          },
          users: payload.users,
        };
        dispatch({
          type: SENDING_PAYLOAD_TO_GATEWAY,
          payload: internalCloudPayload,
        });
        dispatch(
          uiUpdateRegistrationState(
            RegistrationStates.FETCHING_CONFIG_FROM_ARROW_SUCCESS,
          ),
        );
      })
      .catch(error => {
        alert('Error:' + error.message);
        bleDevice.cancelConnection();
        console.log(error);
        dispatch(
          uiUpdateRegistrationState(
            RegistrationStates.FETCHING_CONFIG_FROM_ARROW_FAILED,
          ),
        );
      });
  };
};
