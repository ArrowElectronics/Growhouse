/* eslint-disable no-alert */
import {SET_GROWSECTIONS, SET_GROWSECTIONS_BY_GROWAREA_ID} from './actionTypes';
import {
  uiStartLoading,
  uiStopLoading,
  sessionExpired,
  sessionEstablished,
} from './rootActions';
import * as Urls from '../../Urls';

export const setGrowSections = growsections => {
  growsections.sort(function(a, b) {
    return b.id - a.id;
  });
  return {
    type: SET_GROWSECTIONS,
    growsections: growsections,
  };
};

export const setGrowSectionsByGrowAreaId = (
  growAreaId,
  growsectionsByGrowAreaId,
) => {
  growsectionsByGrowAreaId.sort(function(a, b) {
    return b.id - a.id;
  });
  return {
    type: SET_GROWSECTIONS_BY_GROWAREA_ID,
    growsectionsByGrowAreaId: growsectionsByGrowAreaId,
    growAreaId: growAreaId,
  };
};

export const getGrowSections = (growAreaId, inBackground) => {
  return (dispatch, getState) => {
    const token = getState().root.token;
    let url = Urls.GET_ALL_GROW_SECTIONS.replace(
      '{BASE_URL}',
      getState().root.environment.url,
    );
    if (growAreaId) {
      url = url + '/growareas/' + growAreaId;
    }
    console.log('getGrowSections: ' + url);
    if (!inBackground) {
      dispatch(uiStartLoading());
    }
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    fetch(url, {
      method: 'GET',
      headers,
    })
      .catch(error => {
        throw new Error('Network error!');
      })
      .then(res => {
        if (res.ok) {
          if (res.status === 204) {
            return [];
          }
          console.log(url);
          return res.json();
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else {
          throw new Error('getGrowSections failed:' + res.status);
        }
      })
      .then(parsedRes => {
        if (growAreaId) {
          dispatch(setGrowSectionsByGrowAreaId(growAreaId, parsedRes));
        } else {
          dispatch(setGrowSections(parsedRes));
        }
        if (!inBackground) {
          dispatch(uiStopLoading());
        }
        dispatch(sessionEstablished());
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          if (!inBackground) {
            alert(error.message);
          }
          console.log(error);
        }
        if (!inBackground) {
          dispatch(uiStopLoading());
        }
      });
  };
};
