/* eslint-disable no-alert */
import * as Urls from '../../Urls';
import {SET_FACILITIES} from './actionTypes';
import {
  sessionEstablished,
  sessionExpired,
  uiStartLoading,
  uiStopLoading,
} from './rootActions';

export const setFacilities = facilities => {
  facilities.sort(function(a, b) {
    return b.id - a.id;
  });
  return {
    type: SET_FACILITIES,
    facilities: facilities,
  };
};

export const getFacilities = inBackground => {
  return async (dispatch, getState) => {
    let url = Urls.GET_ALL_FACILITIES.replace(
      '{BASE_URL}',
      getState().root.environment.url,
    );
    const token = getState().root.token;
    console.log('getFacilities: ' + url);
    let headers = {
      Authorization: token,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    if (!inBackground) {
      dispatch(uiStartLoading());
    }
    fetch(url, {
      method: 'GET',
      headers,
    })
      .catch(error => {
        throw new Error('Network error!');
      })
      .then(async res => {
        if (res.ok) {
          if (res.status === 204) {
            return [];
          }
          return res.json();
        } else if (res.status === 401 || res.status === 403) {
          throw new Error('SESSION_EXPIRED');
        } else {
          throw new Error('getFacilities() failed: ' + res.status);
        }
      })
      .then(parsedRes => {
        dispatch(setFacilities(parsedRes));
        if (!inBackground) {
          dispatch(uiStopLoading());
        }
        dispatch(sessionEstablished());
      })
      .catch(error => {
        if (error.message === 'SESSION_EXPIRED') {
          dispatch(sessionExpired());
        } else {
          if (!inBackground) {
            alert(error.message);
          }
          console.log(error);
        }
        if (!inBackground) {
          dispatch(uiStopLoading());
        }
      });
  };
};
