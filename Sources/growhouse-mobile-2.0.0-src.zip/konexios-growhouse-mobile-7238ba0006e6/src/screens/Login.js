import React, {Component} from 'react';
import {
  ActivityIndicator,
  Image,
  Platform,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  Alert,
} from 'react-native';
import {Navigation} from 'react-native-navigation';
import {connect} from 'react-redux';
import {version as appVersion} from '../../app.json';
import * as Constant from '../Constant';
import {
  authLogin,
  authLogout,
  uiStartLoading,
  uiStopLoading,
} from '../store/actions/rootActions';
import {normalize} from 'react-native-elements';
import {getEnvironments, selectEnvironment} from '../store/actions/envActions';
import RNPickerSelect from 'react-native-picker-select';

class Login extends Component {
  static navigatorStyle = {
    navBarHidden: true,
  };

  OS = Platform.OS;
  majorVersionIOS = parseInt(Platform.Version, 10);

  constructor(props) {
    super(props);
    Navigation.events().bindComponent(this);
    this.state = {
      proccesing: false,
      envOptions: [],
      username: null,
      password: null,
    };
  }

  async componentDidAppear() {
    this.props.onStartLoading();
    if (this.props.environments.length === 0) {
      await this.props.onGetEnvironments();
    }
    const envs = this.props.environments;
    for (let i = 0; i < envs.length; i++) {
      this.state.envOptions.push({
        value: envs[i].id,
        label: envs[i].name,
      });
    }
    this.props.onStopLoading();
  }

  signIn = async () => {
    if (!this.props.environment || !this.props.environment.id) {
      Alert.alert('Please select an Environment!');
      return;
    }
    if (!this.state.username || !this.state.password) {
      Alert.alert('Please type in Username and Password!');
      return;
    }
    this.props.onStartLoading();
    await this.props.onAuthLogin(this.state.username, this.state.password);
    this.props.onStopLoading();
  };

  renderLoginForm() {
    if (this.props.isLoading) {
      return (
        <View style={styles.loginContainer}>
          <Image
            source={require('../../assets/images/growhouse.png')}
            style={styles.logoImage}
          />
          <ActivityIndicator size="large" color={Constant.PRIMARY_COLOR} />
          <Text> Loading ... </Text>
        </View>
      );
    }
    return (
      <View style={styles.loginContainer}>
        <Image
          source={require('../../assets/images/growhouse.png')}
          style={styles.logoImage}
        />
        <View style={styles.inputView}>
          <RNPickerSelect
            style={{...styles}}
            placeholder={{
              label: 'Select an Environment',
              value: null,
            }}
            placeholderTextColor="red"
            value={this.props.environment ? this.props.environment.id : null}
            onValueChange={id => {
              if (id > 0) {
                const selected = this.props.environments.find(
                  env => env.id === id,
                );
                this.props.onSelectEnvironment(selected);
              }
            }}
            items={this.state.envOptions}
          />
        </View>
        <View style={styles.inputView}>
          <TextInput
            style={styles.inputText}
            placeholder="Username"
            placeholderTextColor="#aaa"
            autoCapitalize="none"
            onChangeText={text => this.setState({username: text})}
          />
        </View>
        <View style={styles.inputView}>
          <TextInput
            style={styles.inputText}
            placeholder="Password"
            placeholderTextColor="#aaa"
            secureTextEntry={true}
            onChangeText={text => this.setState({password: text})}
          />
        </View>
        <TouchableOpacity
          style={styles.loginBtn}
          onPress={this.signIn.bind(this)}>
          <Text style={styles.loginBtnText}>Sign in</Text>
        </TouchableOpacity>
      </View>
    );
  }

  render() {
    return (
      <View style={styles.mainContainer}>
        {this.renderLoginForm()}
        <View style={styles.versionContainer}>
          <Text style={styles.versionText}>Version {appVersion}</Text>
        </View>
        <View style={styles.bottomContainer} />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
  },
  bottomContainer: {
    height: 12.5,
    backgroundColor: '#FFBA00',
  },
  versionContainer: {
    height: 37.5,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'white',
  },
  loginContainer: {
    flex: 1,
    // justifyContent: 'center',
    alignItems: 'center',
    marginTop: 50,
    backgroundColor: '#F5FCFF',
  },
  versionText: {
    textAlign: 'center',
    color: Constant.DARK_GREY_COLOR,
  },
  logoImage: {
    width: '80%',
    height: '12%',
    resizeMode: 'contain',
    marginBottom: 30,
  },
  fullModalContainer: {
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#75757595',
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  inputView: {
    width: '70%',
    backgroundColor: 'white',
    borderRadius: 25,
    borderColor: 'darkgray',
    borderWidth: 1,
    height: 50,
    marginBottom: 20,
    justifyContent: 'center',
    padding: 10,
    color: 'black',
  },
  inputText: {
    height: 50,
    color: 'black',
  },
  loginBtn: {
    width: '70%',
    backgroundColor: '#F5BD41',
    borderRadius: 25,
    height: 50,
    alignItems: 'center',
    justifyContent: 'center',
  },
  loginBtnText: {
    color: 'white',
    fontSize: normalize(14),
    fontWeight: 'bold',
  },
  inputIOS: {
    // backgroundColor: 'white',
    color: 'black',
  },
  inputAndroid: {
    // backgroundColor: 'white',
    color: 'black',
  },
  placeholder: {
    color: '#aaa',
  },
});

const mapDispatchToProps = dispatch => {
  return {
    onInvalidUser: inBackground => dispatch(authLogout(inBackground)),
    onStartLoading: () => dispatch(uiStartLoading()),
    onStopLoading: () => dispatch(uiStopLoading()),
    onAuthLogin: (username, password) =>
      dispatch(authLogin(username, password)),
    onGetEnvironments: () => dispatch(getEnvironments()),
    onSelectEnvironment: environment =>
      dispatch(selectEnvironment(environment)),
  };
};

const mapStatesToProps = state => {
  return {
    currentUser: state.root.currentUser,
    isLoading: state.ui.isLoading,
    alertApeared: state.auth.alertApeared,
    environments: state.root.environments,
    environment: state.root.environment,
  };
};

export default connect(
  mapStatesToProps,
  mapDispatchToProps,
)(Login);
