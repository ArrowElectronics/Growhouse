package com.growhouse.rest.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="device_property_details")
public class DevicePropertyDetails extends DefaultModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3087886350788195256L;
	
	private String type;
	private String name;
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@Override
	public String toString() {
		return "DeviceProperties [type=" + type + ", name=" + name + "]";
	}
	
	

}
