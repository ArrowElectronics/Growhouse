package com.growhouse.rest.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.growhouse.rest.KonexiosConfig;
import com.growhouse.rest.dto.konexios.KonexiosConfigResponse;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/api/konexios")
@Transactional
public class KonexiosController {
	public static final Logger LOGGER = LoggerFactory.getLogger(KonexiosController.class);

	@Autowired
	private KonexiosConfig config;

	@GetMapping(value = "/config")
	@ApiOperation(value = "get konexios configuration", hidden = true)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "configuration retrieved successfully") })
	public ResponseEntity<KonexiosConfigResponse> getConfig() {
		KonexiosConfigResponse response = new KonexiosConfigResponse();
		response.setApiKey(config.getAuthToken());
		response.setApiUrl(config.getUrl());
		response.setApplicationHid(config.getApplicationHid());
		response.setMqttPrefix(config.getMqttPrefix());
		response.setMqttUrl(config.getMqttUrl());
		return new ResponseEntity<KonexiosConfigResponse>(response, HttpStatus.OK);
	}
}
