package com.growhouse.rest.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class DevicePropertyDetailsDTO {
	
	private String type;
	private String name;
	@JsonProperty("display_property_name")
	private String displayPropertyName;
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDisplayPropertyName() {
		return displayPropertyName;
	}
	public void setDisplayPropertyName(String displayPropertyName) {
		this.displayPropertyName = displayPropertyName;
	}
	
	

	
	

}
