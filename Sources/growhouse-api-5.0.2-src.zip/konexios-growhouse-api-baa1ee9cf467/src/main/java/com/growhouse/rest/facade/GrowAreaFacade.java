/**
 * 
 */
package com.growhouse.rest.facade;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.growhouse.rest.KonexiosConfig;
import com.growhouse.rest.dto.ContainerDTO;
import com.growhouse.rest.dto.ContainerForGADTO;
import com.growhouse.rest.dto.CountDTO;
import com.growhouse.rest.dto.DashBoardDTO;
import com.growhouse.rest.dto.FacilityDTO;
import com.growhouse.rest.dto.FacilityForGADTO;
import com.growhouse.rest.dto.GrowAreaDTO;
import com.growhouse.rest.dto.GrowAreaHeartbeatDTO;
import com.growhouse.rest.dto.GrowAreaOutOfNetworkDTO;
import com.growhouse.rest.dto.OutofNetworkCountDTO;
import com.growhouse.rest.dto.UserDTO;
import com.growhouse.rest.entity.Container;
import com.growhouse.rest.entity.Facility;
import com.growhouse.rest.entity.GrowArea;
import com.growhouse.rest.entity.GrowAreaAssignee;
import com.growhouse.rest.entity.GrowSection;
import com.growhouse.rest.entity.User;
import com.growhouse.rest.entity.kronos.KronosResponse;
import com.growhouse.rest.repository.DeviceRepository;
import com.growhouse.rest.services.IGrowAreaAssigneeService;
import com.growhouse.rest.services.IGrowAreaService;
import com.growhouse.rest.services.IGrowSectionService;
import com.growhouse.rest.services.impl.ContainerService;
import com.growhouse.rest.utils.Command;
import com.growhouse.rest.utils.Constants;
import com.growhouse.rest.utils.DeviceType;
import com.growhouse.rest.utils.DeviceTypeUIName;

/**
 * @author dharita.chokshi
 *
 */
@Component
public class GrowAreaFacade {

	public static final Logger LOGGER = LoggerFactory.getLogger(GrowAreaFacade.class);

	@Autowired
	private DeviceRepository deviceRepository;

	@Autowired
	private IGrowAreaService growAreaService;

	@Autowired
	private IGrowAreaAssigneeService growAreaAssigneeService;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private ObjectMapper mapper;

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private ContainerService containerService;

	@Autowired
	private ContainerFacade containerFacade;

	@Autowired
	private FacilityFacade facilityFacade;

	@Autowired
	private IGrowSectionService growSectionService;

	@Autowired
	private CountFacade countFacade;

	@Autowired
	private KonexiosConfig config;

	public List<GrowAreaDTO> getActiveGrowAreas() {
		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

		List<GrowAreaDTO> growAreaDTOs = new ArrayList<>();

		List<GrowAreaAssignee> growAreaAssignees = growAreaAssigneeService
				.getAllGrowAreaAssigneesByUserId(user.getId());
		if (growAreaAssignees != null && !growAreaAssignees.isEmpty()) {
			growAreaAssignees.sort((GrowAreaAssignee s1, GrowAreaAssignee s2) -> s2.getGrowArea().getCreatedTimestamp()
					.compareTo(s1.getGrowArea().getCreatedTimestamp()));
			growAreaDTOs = growAreaAssignees.stream().filter(growArea -> growArea.getGrowArea().isActive())
					.map(growArea -> convertGrowDeviceEntitytoDTO(growArea.getGrowArea())).collect(Collectors.toList());
		}
		return growAreaDTOs;

	}

	public List<DashBoardDTO> getActiveGrowAreasForDashboard() {
		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		List<DashBoardDTO> growAreaDTOs = null;
		List<DashBoardDTO> growAreafacilityDTOs = null;
		List<GrowAreaAssignee> growAreaAssignees = growAreaAssigneeService
				.getAllGrowAreaAssigneesByUserId(user.getId());
		if (growAreaAssignees != null && !growAreaAssignees.isEmpty()) {
			growAreaDTOs = getGrowAreaForDashboardSubFun(growAreaAssignees);
		} else {
			List<ContainerDTO> containers = containerFacade.getActiveContainers();
			List<Integer> facilityIds = containers.stream().map(container -> container.getFacility().getId())
					.collect(Collectors.toList());
			growAreaDTOs = containers.stream().map(this::convertContainerToDashboardDTO).collect(Collectors.toList());
			List<FacilityDTO> facilitys = facilityFacade.getActiveFacilitiesByAccount();
			growAreafacilityDTOs = facilitys.stream().map(this::convertfacilityToDashboardDTO)
					.collect(Collectors.toList());
			if (!facilityIds.isEmpty()) {
				for (DashBoardDTO facility : growAreafacilityDTOs) {
					if (!facilityIds.contains(facility.getFacility().getId())) {
						growAreaDTOs.add(facility);
					}
				}
			} else {
				growAreaDTOs = growAreafacilityDTOs;
			}
		}
		return growAreaDTOs;

	}

	public List<DashBoardDTO> getGrowAreaForDashboardSubFun(List<GrowAreaAssignee> growAreaAssignees) {
		List<DashBoardDTO> growAreaDTOs = null;
		List<DashBoardDTO> growAreawithoutDeviceDTOs = new ArrayList<>();
		List<DashBoardDTO> growAreawithDeviceDTOs = new ArrayList<>();
		growAreaDTOs = growAreaAssignees.stream().filter(growArea -> growArea.getGrowArea().isActive())
				.map(growArea -> convertGrowEntityToDashboardDTO(growArea.getGrowArea())).collect(Collectors.toList());
		growAreaDTOs = countFacade.getDevicesByGrowAreaId(growAreaDTOs);
		for (DashBoardDTO growarea : growAreaDTOs) {
			if (growarea.getDeviceCountDTO().getTotal() == 0) {
				growAreawithoutDeviceDTOs.add(growarea);
			} else {
				growAreawithDeviceDTOs.add(growarea);
			}
		}
		growAreawithDeviceDTOs.addAll(growAreawithoutDeviceDTOs);
		return growAreawithDeviceDTOs;
	}

	public int getCountActiveGrowArea() {
		return growAreaService.getCountActiveGrowArea();
	}

	public int getCountActiveGrowAreaByAccounts(List<Integer> accountIdList) {
		return growAreaService.getCountActiveGrowAreabyAccounts(accountIdList);
	}

	public List<GrowAreaDTO> getAllGrowAreas() {
		List<GrowAreaDTO> growAreaDTOs = new ArrayList<>();
		List<GrowArea> growAreas = growAreaService.getActiveGrowAreas();
		if (growAreas != null && !growAreas.isEmpty()) {
			growAreaDTOs = growAreas.stream().map(this::convertEntityToDTO).collect(Collectors.toList());
		}

		return growAreaDTOs;
	}

	public List<GrowAreaDTO> getGrowAreasByContainerId(int containerId) {
		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		List<GrowAreaDTO> growAreaDTOs = new ArrayList<>();
		List<GrowAreaAssignee> growAreaAssignees = growAreaAssigneeService
				.getAllGrowAreaAssigneesByContainerId(user.getId(), containerId);
		if (growAreaAssignees != null && !growAreaAssignees.isEmpty()) {
			growAreaDTOs = growAreaAssignees.stream().map(growArea -> convertGrowEntitytoDTO(growArea.getGrowArea()))
					.collect(Collectors.toList());
		}
		return growAreaDTOs;
	}

	public int getGrowAreaCountByContainerId(int containerId) {
		int count = 0;
		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		count = growAreaAssigneeService.countOfAllGrowAreaByContainerId(user.getId(), containerId);
		return count;
	}

	public List<GrowAreaDTO> getGrowAreasByFacilityId(int facilityId) {
		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		List<GrowAreaDTO> growAreaDTOs = new ArrayList<>();
		List<GrowAreaAssignee> growAreaAssignees = growAreaAssigneeService
				.getAllGrowAreaAssigneesByFacilityId(user.getId(), facilityId);
		if (growAreaAssignees != null && !growAreaAssignees.isEmpty()) {
			growAreaDTOs = growAreaAssignees.stream().map(growArea -> convertGrowEntitytoDTO(growArea.getGrowArea()))
					.collect(Collectors.toList());
		}
		return growAreaDTOs;
	}

	public int getGrowAreaCountByFacilityId(int facilityId) {
		int count = 0;

		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		List<GrowAreaAssignee> growAreaAssignees = growAreaAssigneeService
				.getAllGrowAreaAssigneesByFacilityId(user.getId(), facilityId);
		if (growAreaAssignees != null && !growAreaAssignees.isEmpty()) {
			count = growAreaAssignees.stream().map(growArea -> convertEntityToDTO(growArea.getGrowArea()))
					.collect(Collectors.toList()).size();
		}
		return count;
	}

	public int getCountOfGrowareaByFacilityId(int facilityId) {
		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		return growAreaAssigneeService.countOfAllGrowAreaAssigneesByFacilityId(user.getId(), facilityId);
	}

	public GrowAreaDTO getGrowAreaById(int growAreaId) {
		GrowAreaDTO growAreaDTO = null;
		GrowArea growArea = growAreaService.getGrowAreaById(growAreaId);
		if (growArea != null) {
			growAreaDTO = convertGrowEntitytoDTO(growArea);

			// set users (grow area assignees)
			List<GrowAreaAssignee> growAreaAssignees = growAreaAssigneeService
					.getAllGrowAreaAssigneesByGrowAreaId(growAreaId);
			if (growAreaAssignees != null) {
				List<UserDTO> userDTOs = new ArrayList<>();
				growAreaAssignees.forEach(gaa -> {
					UserDTO userDTO = modelMapper.map(gaa.getUser(), UserDTO.class);
					userDTOs.add(userDTO);
				});
				growAreaDTO.setUsers(userDTOs);
			}
		}
		return growAreaDTO;
	}

	public GrowAreaDTO createGrowArea(GrowAreaDTO requestedGrowAreaDTO) {
		GrowAreaDTO createdGrowAreaDTO = null;
		Long heartBeat = 0L;
		GrowSection growSection = new GrowSection();
		requestedGrowAreaDTO.setLatestHeartbeat(heartBeat);
		GrowArea requestedGrowArea = convertDTOToEntity(requestedGrowAreaDTO);
		GrowArea createdGrowArea = growAreaService.createGrowArea(requestedGrowArea);

		if (createdGrowArea != null) {
			createdGrowAreaDTO = convertEntityToDTO(createdGrowArea);
			if (requestedGrowAreaDTO.getUsers() != null) {
				List<GrowAreaAssignee> growAreaAssignees = createGrowAreaAssigneeModelList(requestedGrowAreaDTO,
						createdGrowArea);
				List<GrowAreaAssignee> createdGrowAreaAssignee = growAreaAssigneeService
						.createGrowAreaAssigneesInBatch(growAreaAssignees);
				List<UserDTO> userDTOs = createdGrowAreaAssignee.stream().map(GrowAreaAssignee::getUser)
						.collect(Collectors.toList()).stream().map(user -> modelMapper.map(user, UserDTO.class))
						.collect(Collectors.toList());
				createdGrowAreaDTO.setUsers(userDTOs);
			}
			growSection.setGrowArea(createdGrowArea);
			growSection.setGrowSectionName("Default");
			growSectionService.createGrowSection(growSection);
			createdGrowArea.setLayout(1);
			growAreaService.updateGrowArea(createdGrowArea);
		}
		return createdGrowAreaDTO;
	}

	private List<GrowAreaAssignee> createGrowAreaAssigneeModelList(GrowAreaDTO requestedGrowAreaDTO,
			GrowArea createdGrowArea) {

		List<GrowAreaAssignee> growAreaAssignees = new ArrayList<>();
		Map<Integer, User> userMap = new HashMap<>();
		Container container = containerService.getContainerById(requestedGrowAreaDTO.getContainer().getId());
		Container containerEntity = modelMapper.map(requestedGrowAreaDTO.getContainer(), Container.class);
		Facility facilityEntity = modelMapper.map(requestedGrowAreaDTO.getFacility(), Facility.class);
		userMap.put(container.getFacility().getAdmin().getId(), container.getFacility().getAdmin());
		if (!userMap.containsKey(container.getFacility().getCreatedBy().getId()))
			userMap.put(container.getFacility().getCreatedBy().getId(), container.getFacility().getCreatedBy());
		if (requestedGrowAreaDTO.getUsers() != null && !requestedGrowAreaDTO.getUsers().isEmpty()) {
			for (UserDTO userDTO : requestedGrowAreaDTO.getUsers()) {
				if (userMap.containsKey(userDTO.getId()))
					userMap.remove(userDTO.getId());
				GrowAreaAssignee growAreaAssignee = new GrowAreaAssignee();
				growAreaAssignee.setGrowArea(createdGrowArea);
				User user = modelMapper.map(userDTO, User.class);
				growAreaAssignee.setUser(user);
				growAreaAssignee.setContainer(containerEntity);
				growAreaAssignee.setFacility(facilityEntity);
				growAreaAssignees.add(growAreaAssignee);
			}
		}
		for (User userMap1 : userMap.values()) {
			GrowAreaAssignee growAreaAssignee = new GrowAreaAssignee();
			growAreaAssignee.setGrowArea(createdGrowArea);
			User user = modelMapper.map(userMap1, User.class);
			growAreaAssignee.setUser(user);
			growAreaAssignee.setContainer(containerEntity);
			growAreaAssignee.setFacility(facilityEntity);
			growAreaAssignees.add(growAreaAssignee);
		}
		return growAreaAssignees;
	}

	public GrowAreaDTO updateGrowArea(int growAreaId, GrowAreaDTO requestedGrowAreaDTO) {
		if (growAreaId != requestedGrowAreaDTO.getId())
			throw new HttpClientErrorException(HttpStatus.NOT_ACCEPTABLE,
					"GrowAreaId in URL doesnot match with growAreaId of GrowArea object");
		GrowAreaDTO updatedGrowAreaDTO = null;
		GrowArea requestedGrowArea = convertDTOToEntity(requestedGrowAreaDTO);
		GrowArea updatedGrowArea = growAreaService.updateGrowArea(requestedGrowArea);
		if (updatedGrowArea != null)
			updatedGrowAreaDTO = convertEntityToDTO(updatedGrowArea);
		return updatedGrowAreaDTO;
	}

	public void updateLatestGatewayHeartbeat(String growAreaHId, long date) {
		GrowArea growArea = growAreaService.getGrowAreaRepository().findByGrowAreaHIdAndIsActiveTrue(growAreaHId);
		if (growArea != null) {
			growArea.setLatestHeartbeat(date);
			growAreaService.getGrowAreaRepository().save(growArea);
			LOGGER.info("Grow area heartbeat updated successfully -----------{}", growAreaHId);
		}
	}

	public List<GrowAreaHeartbeatDTO> getLatestGrowAreaHeartbeatByUserId() {

		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		List<GrowAreaAssignee> growAreaAssignees = growAreaAssigneeService
				.getAllGrowAreaAssigneesByUserId(user.getId());
		return growAreaAssignees.stream().map(assignee -> {
			GrowAreaHeartbeatDTO growAreaHeartbeatDTO = new GrowAreaHeartbeatDTO();
			growAreaHeartbeatDTO.setGrowAreaName(assignee.getGrowArea().getGrowAreaName());
			growAreaHeartbeatDTO.setLastHeartbeatTimestamp(assignee.getGrowArea().getLatestHeartbeat());
			growAreaHeartbeatDTO.setContainerId(assignee.getGrowArea().getContainer().getId());
			growAreaHeartbeatDTO.setContainerName(assignee.getGrowArea().getContainer().getContainerName());
			growAreaHeartbeatDTO.setFacilityId(assignee.getGrowArea().getContainer().getFacility().getId());
			growAreaHeartbeatDTO.setFacilityName(assignee.getGrowArea().getContainer().getFacility().getFacilityName());
			return growAreaHeartbeatDTO;
		}).collect(Collectors.toList());
	}

	public List<GrowAreaOutOfNetworkDTO> getOutOfNetworkGrowAreas() {
		List<GrowAreaOutOfNetworkDTO> growAreaOutOfNetwork = new ArrayList<>();
		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		List<GrowAreaAssignee> growAreaAssignees = growAreaAssigneeService
				.getAllGrowAreaAssigneesByUserId(user.getId());
		if (growAreaAssignees != null && !growAreaAssignees.isEmpty()) {
			List<Integer> growAreaIdList = growAreaAssignees.stream()
					.map(growAreaAssinee -> growAreaAssinee.getGrowArea().getId()).collect(Collectors.toList());

			List<GrowArea> growAreas = growAreaService.getOutOfNetworkGrowArea(growAreaIdList);
			if (growAreas != null && !growAreas.isEmpty()) {
				growAreaOutOfNetwork = growAreas.stream().map(this::convertGrowAreaOutOfNetworkEntityToDTO)
						.collect(Collectors.toList());
			}

		}
		return growAreaOutOfNetwork;
	}

	public OutofNetworkCountDTO getcountOutOfNetworkGrowAreas() {
		int count = 0;
		OutofNetworkCountDTO outofNetworkCountDTO = new OutofNetworkCountDTO();
		outofNetworkCountDTO.setCount(count);
		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		List<GrowAreaAssignee> growAreaAssignees = growAreaAssigneeService
				.getAllGrowAreaAssigneesByUserId(user.getId());
		if (growAreaAssignees != null && !growAreaAssignees.isEmpty()) {
			List<Integer> growAreaIdList = growAreaAssignees.stream()
					.map(growAreaAssinee -> growAreaAssinee.getGrowArea().getId()).collect(Collectors.toList());
			count = growAreaService.getCountOutOfNetworkGrowArea(growAreaIdList);
			outofNetworkCountDTO.setCount(count);

		}
		return outofNetworkCountDTO;
	}

	public OutofNetworkCountDTO getcountOutOfNetworkGrowAreasByFacilityId(int facilityId) {
		int count = 0;
		OutofNetworkCountDTO outofNetworkCountDTO = new OutofNetworkCountDTO();
		outofNetworkCountDTO.setCount(count);
		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		List<GrowAreaAssignee> growAreaAssignees = growAreaAssigneeService
				.getAllGrowAreaAssigneesByFacilityId(user.getId(), facilityId);
		if (growAreaAssignees != null && !growAreaAssignees.isEmpty()) {
			List<Integer> growAreaIdList = growAreaAssignees.stream()
					.map(growAreaAssinee -> growAreaAssinee.getGrowArea().getId()).collect(Collectors.toList());
			count = growAreaService.getCountOutOfNetworkGrowArea(growAreaIdList);
			outofNetworkCountDTO.setCount(count);

		}
		return outofNetworkCountDTO;
	}

	public OutofNetworkCountDTO getcountOutOfNetworkGrowAreasByContainerId(int containerId) {
		int count = 0;
		OutofNetworkCountDTO outofNetworkCountDTO = new OutofNetworkCountDTO();
		outofNetworkCountDTO.setCount(count);
		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		List<GrowAreaAssignee> growAreaAssignees = growAreaAssigneeService
				.getAllGrowAreaAssigneesByContainerId(user.getId(), containerId);
		if (growAreaAssignees != null && !growAreaAssignees.isEmpty()) {
			List<Integer> growAreaIdList = growAreaAssignees.stream()
					.map(growAreaAssinee -> growAreaAssinee.getGrowArea().getId()).collect(Collectors.toList());
			count = growAreaService.getCountOutOfNetworkGrowArea(growAreaIdList);
			outofNetworkCountDTO.setCount(count);

		}
		return outofNetworkCountDTO;
	}

	public GrowArea deleteGrowArea(int growAreaId) {

		return deleteGrowAreatest(growAreaId);
	}

	public GrowAreaAssignee removeGrowAreaAssignee(int growAreaId, int userId) {
		return growAreaAssigneeService.deleteGrowAreaAssignee(growAreaId, userId);
	}

	public void deleteGrowAreaAssigneeByGatewayId(int gatewayId) {
		growAreaAssigneeService.deleteGrowAreaAssigneeByGatewayId(gatewayId);
	}

	private GrowAreaDTO convertEntityToDTO(GrowArea growArea) {

		return modelMapper.map(growArea, GrowAreaDTO.class);
	}

	private GrowAreaDTO convertGrowEntitytoDTO(GrowArea growArea) {
		long thrityAgo = System.currentTimeMillis() - Constants.THRITY_MINUTES;
		GrowAreaDTO growareaDTO = modelMapper.map(growArea, GrowAreaDTO.class);
		if (growArea.getLatestHeartbeat() < thrityAgo)
			growareaDTO.setFlag("false");
		else
			growareaDTO.setFlag("true");
		return growareaDTO;
	}

	private GrowAreaDTO convertGrowDeviceEntitytoDTO(GrowArea growArea) {
		String gatewayId = (growArea.getId()).toString();
		long thrityAgo = System.currentTimeMillis() - Constants.THRITY_MINUTES;
		GrowAreaDTO growareaDTO = modelMapper.map(growArea, GrowAreaDTO.class);
		if (growArea.getLatestHeartbeat() < thrityAgo) {
			growareaDTO.setFlag("false");
			deviceRepository.updateDeviceLatestStatusByGatewayId(false, gatewayId);
			LOGGER.info("This growarea devices updated successfully-----{}", gatewayId);
		} else {
			growareaDTO.setFlag("true");
		}
		return growareaDTO;

	}

	private DashBoardDTO convertContainerToDashboardDTO(ContainerDTO container) {
		DashBoardDTO dashboard = new DashBoardDTO();
		ContainerForGADTO containerDTO = new ContainerForGADTO();
		containerDTO.setContainerName(container.getContainerName());
		dashboard.setContainer(containerDTO);
		FacilityForGADTO facilityDTO = new FacilityForGADTO();
		facilityDTO.setId(container.getFacility().getId());
		facilityDTO.setFacilityName(container.getFacility().getFacilityName());
		facilityDTO.setLocality(container.getFacility().getLocality());
		dashboard.setFacility(facilityDTO);
		CountDTO countDetails = new CountDTO();
		setDefaultCountDetails(countDetails);
		dashboard.setDeviceCountDTO(countDetails.getDevicesCount());
		return dashboard;
	}

	private DashBoardDTO convertfacilityToDashboardDTO(FacilityDTO facility) {
		DashBoardDTO dashboard = new DashBoardDTO();
		FacilityForGADTO facilityDTO = new FacilityForGADTO();
		facilityDTO.setId(facility.getId());
		facilityDTO.setFacilityName(facility.getFacilityName());
		facilityDTO.setLocality(facility.getLocality());
		dashboard.setFacility(facilityDTO);
		CountDTO countDetails = new CountDTO();
		setDefaultCountDetails(countDetails);
		dashboard.setDeviceCountDTO(countDetails.getDevicesCount());
		return dashboard;
	}

	private DashBoardDTO convertGrowEntityToDashboardDTO(GrowArea growArea) {
		return modelMapper.map(growArea, DashBoardDTO.class);
	}

	private GrowArea convertDTOToEntity(GrowAreaDTO growAreaDTO) {
		return modelMapper.map(growAreaDTO, GrowArea.class);
	}

	private String fetchgatewayDefaultDevice(String gatewayHId) {
		UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(config.buildGatewayDevicesUrl())
				.queryParam("gatewayHid", gatewayHId);
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set(config.getAuthTokenKey(), config.getAuthToken());

			HttpEntity<String> entity = new HttpEntity<>(headers);
			ResponseEntity<KronosResponse> response = restTemplate.exchange(builder.toUriString(), HttpMethod.GET,
					entity, KronosResponse.class);
			if (response.getStatusCode() == HttpStatus.OK) {
				KronosResponse kronosResponse = response.getBody();
				return kronosResponse.getData().get(0).getHid();
			}
		} catch (HttpStatusCodeException httpStatusCodeException) {
			throw new HttpClientErrorException(httpStatusCodeException.getStatusCode(),
					httpStatusCodeException.getStatusText());
		} catch (Exception exception) {
			throw new HttpClientErrorException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Unable to fetch gateway device HID from Arrow Connect portal.");
		}
		return null;

	}

	private GrowAreaOutOfNetworkDTO convertGrowAreaOutOfNetworkEntityToDTO(GrowArea growArea) {
		GrowAreaOutOfNetworkDTO growAreaOutOfNetworkDTO = modelMapper.map(growArea, GrowAreaOutOfNetworkDTO.class);
		growAreaOutOfNetworkDTO.setContainerId(growArea.getContainer().getId());
		growAreaOutOfNetworkDTO.setContainerName(growArea.getContainer().getContainerName());
		growAreaOutOfNetworkDTO.setFacilityId(growArea.getContainer().getFacility().getId());
		growAreaOutOfNetworkDTO.setFacilityName(growArea.getContainer().getFacility().getFacilityName());
		return growAreaOutOfNetworkDTO;
	}

	public GrowArea deleteGrowAreatest(int growAreaId) {
		String gatewayHId = null;
		String gatewayDeviceHid = null;
		GrowArea deletedGrowArea = null;
		GrowArea growArea = growAreaService.getGrowAreaById(growAreaId);
		if (growArea != null) {
			gatewayHId = growArea.getGrowAreaHId();
			gatewayDeviceHid = growArea.getGatewayDeviceHId();
			if (growArea.getGatewayDeviceHId() == null) {
				try {
					gatewayDeviceHid = fetchgatewayDefaultDevice(gatewayHId);
					growArea.setGatewayDeviceHId(gatewayDeviceHid);
					growAreaService.updateGrowArea(growArea);
				} catch (HttpClientErrorException httpClientErrorException) {
					growArea.setActive(false);
					deletedGrowArea = growAreaService.updateGrowArea(growArea);
					return deletedGrowArea;
				}
			}
		} else {
			throw new HttpClientErrorException(HttpStatus.BAD_REQUEST, "GrowArea for given id dosen't exists");
		}
		try {
			String urlDeleteGatewaySaleni = config.buildDeviceCommandUrl(gatewayHId, gatewayDeviceHid);
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set(config.getAuthTokenKey(), config.getAuthToken());
			Map<String, Object> map = new HashMap<>();
			map.put(Constants.COMMAND, Command.deleteGateway);
			map.put(Constants.DEVICE_HID, gatewayDeviceHid);
			map.put(Constants.MESSAGE_EXPIRATION, 10);
			Map<String, String> payloadMap = new HashMap<>();
			payloadMap.put(Constants.DEVICE_HID, gatewayHId);
			map.put(Constants.PAYLOAD, String.valueOf(mapper.writeValueAsString(payloadMap)));
			HttpEntity<Map> entity = new HttpEntity<>(map, headers);
			try {
				restTemplate.exchange(urlDeleteGatewaySaleni, HttpMethod.POST, entity, String.class);
			} catch (HttpClientErrorException e) {
				LOGGER.info("Error occured while request proccessing to saleni. ");
			}

			growArea.setActive(false);
			deletedGrowArea = growAreaService.updateGrowArea(growArea);

		} catch (HttpStatusCodeException httpStatusCodeException) {
			throw new HttpClientErrorException(HttpStatus.BAD_REQUEST, "Error occurred while deleting GrowArea ");
		} catch (Exception exception) {
			throw new HttpClientErrorException(HttpStatus.INTERNAL_SERVER_ERROR, exception.getMessage());
		}
		return deletedGrowArea;
	}

	public void setDefaultCountDetails(CountDTO countDetails) {
		Map<String, Long> deviceTypeCount = new HashMap<>();
		deviceTypeCount.put(DeviceTypeUIName.valueOf(DeviceType.HumidityNode.toString()).showDevicePrefixValue(), 0L);
		deviceTypeCount.put(DeviceTypeUIName.valueOf(DeviceType.LightShield.toString()).showDevicePrefixValue(), 0L);
		deviceTypeCount.put(DeviceTypeUIName.valueOf(DeviceType.SCMNode.toString()).showDevicePrefixValue(), 0L);
		deviceTypeCount.put(DeviceTypeUIName.valueOf(DeviceType.SoilNode.toString()).showDevicePrefixValue(), 0L);
		deviceTypeCount.put(DeviceTypeUIName.valueOf(DeviceType.LedNode.toString()).showDevicePrefixValue(), 0L);
		countDetails.getDevicesCount().setDeviceTypeCount(deviceTypeCount);
	}

}
