package com.growhouse.rest.controller;

import org.apache.commons.lang.StringUtils;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import com.growhouse.rest.entity.User;
import com.growhouse.rest.entity.UserRole;

public abstract class ControllerAbstract {

	protected boolean isSuperAdmin() {
		return hasRole("SuperAdmin");
	}

	protected boolean isAdmin() {
		return hasRole("Admin");
	}

	protected boolean isNormalUser() {
		return hasRole("NormalUser");
	}

	private boolean hasRole(String roleName) {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if (authentication == null)
			return false;
		User user = (User) authentication.getPrincipal();
		if (user == null)
			return false;
		UserRole role = user.getUserRole();
		return role != null && StringUtils.equalsIgnoreCase(role.getRoleName(), roleName);
	}
}
