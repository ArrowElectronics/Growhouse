/**
 * 
 */
package com.growhouse.rest.services.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;

import com.growhouse.rest.entity.User;
import com.growhouse.rest.repository.UserRepository;
import com.growhouse.rest.services.IUserService;
import com.growhouse.rest.utils.Constants;

/**
 * @author dharita.chokshi
 *
 */
@Service
public class UserService implements IUserService {

	@Autowired
	private UserRepository userRepository;

	public User getUserByUsername(String username) {
		Optional<User> optional = userRepository.findByUsername(username);
		return optional.isPresent() ? optional.get() : null;
	}

	public List<User> getActiveUsers() {
		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		return userRepository.findByAccountIdAndIsActiveTrueOrderByCreatedTimestampDesc(user.getAccount().getId());
	}

	public List<User> getAllUsers() {
		return userRepository.findAll();
	}

	public User getUserById(int id) {
		Optional<User> optional = userRepository.findByIdAndIsActiveTrue(id);
		return optional.isPresent() ? optional.get() : null;
	}

	public User createUser(User user) {
		User existingUser = getUserByUsername(user.getUsername());
		if (existingUser != null)
			throw new HttpClientErrorException(HttpStatus.CONFLICT,
					String.format("Username already exists", user.getEmail(),
							existingUser.getAccount().getAccountName(), existingUser.getUserRole().getRoleName()));

		return userRepository.save(user);
	}

	public User updateUser(User user) {
		return userRepository.save(user);
	}

	public User deleteUser(int id) {
		User deletedUser = null;
		Optional<User> optional = userRepository.findById(id);
		if (optional.isPresent() && optional.get().isActive()) {
			User user = optional.get();
			user.setActive(false);
			deletedUser = userRepository.save(user);
		} else {
			throw new HttpClientErrorException(HttpStatus.NOT_FOUND, Constants.USER_NOT_FOUND_MESSAGE);
		}
		return deletedUser;
	}

	@Override
	public UserRepository getUserRepository() {
		return userRepository;
	}

}
