package com.growhouse.rest.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * @author dharita.chokshi
 *
 */
@Entity
@Table(name = "device_types")
public class DeviceType extends DefaultModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9085917756066175921L;

	@Column(name = "device_type_name")
	private String deviceTypeName;
	
	@Column(name="virtual_device_type_name")
	private String virtualDeviceTypeName;

	/**
	 * @return the deviceTypeName
	 */
	public String getDeviceTypeName() {
		return deviceTypeName;
	}

	/**
	 * @param deviceTypeName
	 *            the deviceTypeName to set
	 */
	public void setDeviceTypeName(String deviceTypeName) {
		this.deviceTypeName = deviceTypeName;
	}

	public String getVirtualDeviceTypeName() {
		return virtualDeviceTypeName;
	}

	public void setVirtualDeviceTypeName(String virtualDeviceTypeName) {
		this.virtualDeviceTypeName = virtualDeviceTypeName;
	}

	@Override
	public String toString() {
		return "DeviceType [deviceTypeName=" + deviceTypeName + ", virtualDeviceTypeName=" + virtualDeviceTypeName
				+ "]";
	}

	

}
