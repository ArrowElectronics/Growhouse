package com.growhouse.rest.dto;

import java.util.List;

public class DevicePropertiesDTO {

	private Integer size;
	
	private List<DevicePropertyDetailsDTO> data;

	public Integer getSize() {
		return size;
	}

	public void setSize(Integer size) {
		this.size = size;
	}

	public List<DevicePropertyDetailsDTO> getData() {
		return data;
	}

	public void setData(List<DevicePropertyDetailsDTO> data) {
		this.data = data;
	}

	@Override
	public String toString() {
		return "DevicePropertiesDTO [size=" + size + ", data=" + data + "]";
	}

	
	
	
}
