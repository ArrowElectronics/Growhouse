package com.growhouse.rest.dto.konexios;

public class AuthRequest {
	private String login;
	private String password;
	private boolean mobileApp = false;

	public AuthRequest login(String login) {
		this.login = login;
		return this;
	}

	public AuthRequest password(String password) {
		this.password = password;
		return this;
	}

	public AuthRequest mobileApp(boolean mobileApp) {
		setMobileApp(mobileApp);
		return this;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean isMobileApp() {
		return mobileApp;
	}

	public void setMobileApp(boolean mobileApp) {
		this.mobileApp = mobileApp;
	}
}
