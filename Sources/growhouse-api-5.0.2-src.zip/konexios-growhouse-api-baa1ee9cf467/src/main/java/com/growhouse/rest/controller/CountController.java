/**
 * 
 */
package com.growhouse.rest.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;

import com.growhouse.rest.dto.CountDTO;
import com.growhouse.rest.dto.DashBoardDTO;
import com.growhouse.rest.dto.DeviceCountDTO;
import com.growhouse.rest.dto.DeviceDTO;
import com.growhouse.rest.dto.NormalUserDashboardCountDTO;
import com.growhouse.rest.entity.User;
import com.growhouse.rest.facade.ContainerFacade;
import com.growhouse.rest.facade.CountFacade;
import com.growhouse.rest.facade.DeviceFacade;
import com.growhouse.rest.facade.FacilityFacade;
import com.growhouse.rest.facade.GrowAreaFacade;
import com.growhouse.rest.facade.GrowSectionFacade;
import com.growhouse.rest.facade.NormalUserFacade;
import com.growhouse.rest.response.ResponseMessage;
import com.growhouse.rest.services.impl.GrowAreaAssigneeService;
import com.growhouse.rest.utils.DeviceType;
import com.growhouse.rest.utils.DeviceTypeUIName;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author dharita.chokshi
 *
 */
@RestController
@RequestMapping("/api/count")
@Transactional
public class CountController {

	public static final Logger LOGGER = LoggerFactory.getLogger(CountController.class);

	@Autowired
	private FacilityFacade facilityFacade;

	@Autowired
	private ContainerFacade containerFacade;

	@Autowired
	private GrowAreaFacade growAreaFacade;

	@Autowired
	private GrowSectionFacade growSectionFacade;

	@Autowired
	private DeviceFacade deviceFacade;

	@Autowired
	private NormalUserFacade normalUserFacade;

	@Autowired
	private CountFacade countFacade;

	@Autowired
	private GrowAreaAssigneeService growAreaAssigneeService;

	@GetMapping(value = "")
	@ApiOperation(value = "View count of entities based on user")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Data retrieved successfully") })
	public ResponseEntity<?> getCountDetailsByUserId() {
		ResponseEntity<?> responseEntity = null;
		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		CountDTO countDTO = new CountDTO();
		int accountId = user.getAccount().getId();
		try {
			countDTO.setFacilityCount(facilityFacade.getActiveFacilityCountByAccountId(accountId));
			countDTO.setContainerCount(containerFacade.getActiveContainerCountByAccountId(accountId));
			NormalUserDashboardCountDTO normalUserDashboardCountDTO = normalUserFacade.getNormalUserCount();
			countDTO.setGrowAreaCount(normalUserDashboardCountDTO.getGrowAreaCount());
			countDTO.setGrowSectionCount(
					growSectionFacade.getGrowSectionCountByGrowAreaIds(normalUserDashboardCountDTO.getGrowAreaIds()));
			DeviceCountDTO devicesCount = new DeviceCountDTO();
			devicesCount.setDeviceTypeCount(normalUserDashboardCountDTO.getDevicesCount().getDevicesTypeCount());
			countDTO.setDevicesCount(devicesCount);
			responseEntity = new ResponseEntity<>(countDTO, HttpStatus.OK);
		} catch (Exception exception) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@GetMapping(value = "/dashboard")
	@ApiOperation(value = "View count of entities on dashboard")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Data retrieved successfully") })
	public ResponseEntity<?> getDashboardDetails() {
		ResponseEntity<?> responseEntity = null;

		try {
			List<DashBoardDTO> dashBoardDTOs = countFacade.getGrowAreaByUserId();
			if (dashBoardDTOs == null || dashBoardDTOs.isEmpty())
				responseEntity = new ResponseEntity<>(new ArrayList<>(), HttpStatus.OK);
			else {
				responseEntity = new ResponseEntity<>(dashBoardDTOs, HttpStatus.OK);
			}
		} catch (Exception exception) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@GetMapping(value = "/byfacility/{facilityId}")
	@ApiOperation(value = "View count of entities based on facilityId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Data retrieved successfully") })
	public ResponseEntity<?> getCountDetailsByFacilityId(@PathVariable("facilityId") Integer facilityId) {
		ResponseEntity<?> responseEntity;
		try {
			CountDTO countDetails = getAllCountByFacilityId(facilityId);
			responseEntity = new ResponseEntity<>(countDetails, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception exception) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/*
	 * Query-- Select COUNT(container.id) from container where facility_id=? Select
	 * COUNT(grow_area.id) from grow_area_assignee where user_id=? and facility_id=?
	 */
	private CountDTO getAllCountByFacilityId(Integer facilityId) {
		CountDTO countDetails = new CountDTO();
		try {
			countDetails.setContainerCount(containerFacade.getCountOfContainersByFacilityId(facilityId));
			countDetails.setGrowAreaCount(growAreaFacade.getCountOfGrowareaByFacilityId(facilityId));
		} catch (Exception exception) {
			LOGGER.error(exception.getMessage());
		}
		return countDetails;
	}

	/*
	 * Query-- Select COUNT(grow_area.id) from grow_area_assignee where user_id=?
	 * and container_id=?
	 */
	@GetMapping(value = "/bycontainer/{containerId}")
	@ApiOperation(value = "View count of entities based on containerId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Data retrieved successfully") })
	public ResponseEntity<?> getCountDetailsByContainerId(@PathVariable("containerId") Integer containerId) {
		ResponseEntity<?> responseEntity;
		CountDTO countDetails = new CountDTO();
		try {
			User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			countDetails.setGrowAreaCount(
					growAreaAssigneeService.countOfAllGrowAreaByContainerId(user.getId(), containerId));
			responseEntity = new ResponseEntity<>(countDetails, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception exception) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@GetMapping(value = "/bygrowarea/{growAreaId}")
	@ApiOperation(value = "View count of entities based on growAreaId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Data retrieved successfully") })
	public ResponseEntity<?> getCountDetailsByGrowAreaId(@PathVariable("growAreaId") Integer growAreaId) {
		ResponseEntity<?> responseEntity;
		CountDTO countDetails = new CountDTO();
		try {
			countDetails.setGrowSectionCount(growSectionFacade.getGrowSectionCountByGrowAreaId(growAreaId));
			List<DeviceDTO> deviceDTOs = deviceFacade.getDevicesByGrowAreaId(growAreaId);
			if (deviceDTOs != null && !deviceDTOs.isEmpty()) {
				setDeviceByTypeCount(countDetails, deviceDTOs);
			} else {
				setDefaultCountDetails(countDetails);
			}
			responseEntity = new ResponseEntity<>(countDetails, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception exception) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@GetMapping(value = "/bygrowsection/{growSectionId}")
	@ApiOperation(value = "View count of entities based on growSectionId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Data retrieved successfully") })
	public ResponseEntity<?> getCountDetailsByGrowSectionId(@PathVariable("growSectionId") Integer growSectionId) {
		ResponseEntity<?> responseEntity;
		CountDTO countDetails = new CountDTO();
		try {
			List<DeviceDTO> deviceDTOs = deviceFacade.getDevicesByGrowSectionId(growSectionId);
			if (deviceDTOs != null && !deviceDTOs.isEmpty()) {
				setDeviceByTypeCount(countDetails, deviceDTOs);
			} else {
				setDefaultCountDetails(countDetails);
			}
			responseEntity = new ResponseEntity<>(countDetails, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception exception) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	public void setDeviceByTypeCount(CountDTO countDetails, List<DeviceDTO> deviceDTOs) {
		DeviceCountDTO deviceCountDTO = new DeviceCountDTO();
		deviceCountDTO.setTotal(deviceDTOs.size());

		Map<String, Integer> deviceCountByType = new HashMap<>();
		for (DeviceType type : DeviceType.values()) {
			deviceCountByType.put(type.toString(), 0);
		}

		for (DeviceDTO deviceDTO : deviceDTOs) {
			String type = deviceDTO.getDeviceType().getDeviceTypeName();
			int count = 1;
			if (deviceCountByType.get(type) != null) {
				count = deviceCountByType.get(type) + 1;
			}
			deviceCountByType.put(type, count);
		}

		int scmCount = deviceCountByType.get(DeviceType.SCMNode.toString());
		int soilNodecount = deviceCountByType.get(DeviceType.SoilNode.toString());
		int lightShieldCount = deviceCountByType.get(DeviceType.LightShield.toString());
		int ledNodeCount = deviceCountByType.get(DeviceType.LedNode.toString());
		int humidityNodeCount = deviceCountByType.get(DeviceType.HumidityNode.toString());

		Map<String, Long> deviceTypeCount = new HashMap<>();
		deviceTypeCount.put(DeviceTypeUIName.valueOf(DeviceType.SCMNode.toString()).showDevicePrefixValue(),
				Long.valueOf(scmCount));
		deviceTypeCount.put(DeviceTypeUIName.valueOf(DeviceType.SoilNode.toString()).showDevicePrefixValue(),
				Long.valueOf(soilNodecount));
		deviceTypeCount.put(DeviceTypeUIName.valueOf(DeviceType.LightShield.toString()).showDevicePrefixValue(),
				Long.valueOf(lightShieldCount));
		deviceTypeCount.put(DeviceTypeUIName.valueOf(DeviceType.LedNode.toString()).showDevicePrefixValue(),
				Long.valueOf(ledNodeCount));
		deviceTypeCount.put(DeviceTypeUIName.valueOf(DeviceType.HumidityNode.toString()).showDevicePrefixValue(),
				Long.valueOf(humidityNodeCount));
		deviceCountDTO.setDeviceTypeCount(deviceTypeCount);
		countDetails.setDevicesCount(deviceCountDTO);
	}

	public void setDefaultCountDetails(CountDTO countDetails) {
		Map<String, Long> deviceTypeCount = new HashMap<>();
		deviceTypeCount.put(DeviceTypeUIName.valueOf(DeviceType.HumidityNode.toString()).showDevicePrefixValue(), 0L);
		deviceTypeCount.put(DeviceTypeUIName.valueOf(DeviceType.LightShield.toString()).showDevicePrefixValue(), 0L);
		deviceTypeCount.put(DeviceTypeUIName.valueOf(DeviceType.SCMNode.toString()).showDevicePrefixValue(), 0L);
		deviceTypeCount.put(DeviceTypeUIName.valueOf(DeviceType.SoilNode.toString()).showDevicePrefixValue(), 0L);
		deviceTypeCount.put(DeviceTypeUIName.valueOf(DeviceType.LedNode.toString()).showDevicePrefixValue(), 0L);
		countDetails.getDevicesCount().setDeviceTypeCount(deviceTypeCount);
	}

	/**
	 * @param httpClientErrorException
	 * @return
	 */
	private ResponseEntity<ResponseMessage> setResponseMessage(HttpClientErrorException httpClientErrorException) {
		ResponseMessage responseMessage = new ResponseMessage();
		responseMessage.setMessage(httpClientErrorException.getStatusText());
		return new ResponseEntity<>(responseMessage, httpClientErrorException.getStatusCode());
	}

}
