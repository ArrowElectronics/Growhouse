package com.growhouse.rest.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CheckDeviceStateDTO {

	private String command;
	@JsonProperty("device_hid")
	private String deviceHid;
	@JsonProperty("gateway_hid")
	private String gatewayHid;

	public String getDeviceHid() {
		return deviceHid;
	}

	public void setDeviceHid(String deviceHid) {
		this.deviceHid = deviceHid;
	}

	public String getGatewayHid() {
		return gatewayHid;
	}

	public void setGatewayHid(String gatewayHid) {
		this.gatewayHid = gatewayHid;
	}

	public String getCommand() {
		return command;
	}

	public void setCommand(String command) {
		this.command = command;
	}

}
