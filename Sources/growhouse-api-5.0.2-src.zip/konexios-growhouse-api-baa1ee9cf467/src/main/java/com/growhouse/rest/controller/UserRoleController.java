/**
 * 
 */
package com.growhouse.rest.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;

import com.growhouse.rest.dto.UserRoleDTO;
import com.growhouse.rest.facade.UserRoleFacade;
import com.growhouse.rest.response.ResponseMessage;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author dharita.chokshiπ
 *
 */

@RestController
@RequestMapping("/api/userroles")
@Transactional
public class UserRoleController {

	public static final Logger LOGGER = LoggerFactory.getLogger(UserRoleController.class);

	@Autowired
	private UserRoleFacade userRoleFacade;

	/* Query-- select * from user_roles where is_active=true */
	@GetMapping(value = "")
	@ApiOperation(value = "View a list of user roles")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "List retrieved successfully"),
			@ApiResponse(code = 204, message = "Empty list") })
	public ResponseEntity<List<UserRoleDTO>> getuserRoles() {
		ResponseEntity<List<UserRoleDTO>> responseEntity;
		try {
			List<UserRoleDTO> userRoleDTOs = userRoleFacade.getUserRoles();
			if (userRoleDTOs == null || userRoleDTOs.isEmpty())
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(userRoleDTOs, HttpStatus.OK);
		} catch (Exception exception) {
			throw new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/* Query-- select * from user_roles where user_roles_id=? */
	@GetMapping(value = "/{userRoleId}")
	@ApiOperation(value = "Retrive user role based on userRoleId")
	@ApiResponses(value = { @ApiResponse(code = 403, message = "User is inactive"),
			@ApiResponse(code = 404, message = "User not found"), })
	public ResponseEntity<?> getUserByUserId(@PathVariable("userRoleId") Integer userRoleId) {
		ResponseEntity<?> responseEntity;
		try {
			UserRoleDTO userRoleDTO = userRoleFacade.getUserRoleById(userRoleId);
			if (userRoleDTO == null) {
				ResponseMessage responseMessage = new ResponseMessage();
				responseMessage.setMessage("User role not found");
				responseEntity = new ResponseEntity<>(responseMessage, HttpStatus.NOT_FOUND);
			} else {
				responseEntity = new ResponseEntity<>(userRoleDTO, HttpStatus.OK);
			}
		} catch (HttpClientErrorException httpClientErrorException) {
			ResponseMessage responseMessage = new ResponseMessage();
			responseMessage.setMessage(httpClientErrorException.getStatusText());
			responseEntity = new ResponseEntity<>(responseMessage, httpClientErrorException.getStatusCode());
		} catch (Exception exception) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}
}
