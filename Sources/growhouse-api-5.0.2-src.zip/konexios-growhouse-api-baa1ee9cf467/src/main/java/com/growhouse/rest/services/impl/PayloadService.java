package com.growhouse.rest.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.growhouse.rest.entity.Payload;
import com.growhouse.rest.repository.GlobalResponseRepository;
import com.growhouse.rest.repository.PayloadRepository;
import com.growhouse.rest.services.IPayloadService;

@Service
public class PayloadService implements IPayloadService {

	@Autowired
	PayloadRepository payloadRepository;
	
	@Autowired
	GlobalResponseRepository globalResponseRepository;
	
	
	@Override
	public Payload createPayload(Payload payload)
	{
		return payloadRepository.save(payload);
	}
}
