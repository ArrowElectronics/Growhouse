/**
 * 
 */
package com.growhouse.rest.services;

import java.util.List;

import com.growhouse.rest.entity.kronos.KronosData;

/**
 * @author dharita.chokshi
 *
 */
public interface IAlertService {

	public List<KronosData> getAlertHistoryByDeviceId(int deviceId);

}
