package com.growhouse.rest.dto;

import com.fasterxml.jackson.annotation.JsonProperty;


public class LedNodeChannelConfigurationDTO {

	@JsonProperty("device_id")
	private DeviceDTO device;
	
	@JsonProperty("device_type")
	private String deviceType="LedNode";
	
	private String led1;
	
	private String led2;
	
	private String led3;
	
	private String led4;
	
	private String led5;
	
	private String led6;

	public DeviceDTO getDevice() {
		return device;
	}

	public void setDevice(DeviceDTO device) {
		this.device = device;
	}

	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

	public String getLed1() {
		return led1;
	}

	public void setLed1(String led1) {
		this.led1 = led1;
	}

	public String getLed2() {
		return led2;
	}

	public void setLed2(String led2) {
		this.led2 = led2;
	}

	public String getLed3() {
		return led3;
	}

	public void setLed3(String led3) {
		this.led3 = led3;
	}

	public String getLed4() {
		return led4;
	}

	public void setLed4(String led4) {
		this.led4 = led4;
	}

	public String getLed5() {
		return led5;
	}

	public void setLed5(String led5) {
		this.led5 = led5;
	}

	public String getLed6() {
		return led6;
	}

	public void setLed6(String led6) {
		this.led6 = led6;
	}

	@Override
	public String toString() {
		return "LedNodeChannelConfigurationDTO [device=" + device + ", deviceType=" + deviceType + ", led1=" + led1
		        + ", led2=" + led2 + ", led3=" + led3 + ", led4=" + led4 + ", led5=" + led5 + ", led6=" + led6 + "]";
	}

	
	

	
}
