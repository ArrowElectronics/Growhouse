package com.growhouse.rest.services;

public interface ICountService {

}
