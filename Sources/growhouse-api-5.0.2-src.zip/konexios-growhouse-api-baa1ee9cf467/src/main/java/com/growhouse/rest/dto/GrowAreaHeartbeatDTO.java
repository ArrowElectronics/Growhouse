package com.growhouse.rest.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GrowAreaHeartbeatDTO {

	@JsonProperty("container_id")
	private int containerId;
	@JsonProperty("facility_id")
	private int facilityId;
	@JsonProperty("container_name")
	private String containerName;
	@JsonProperty("facility_name")
	private String facilityName;
	@JsonProperty("grow_area_name")
	private String growAreaName;
	@JsonProperty("last_heartbeat_timestamp")
	private long lastHeartbeatTimestamp;

	public int getContainerId() {
		return containerId;
	}

	public void setContainerId(int containerId) {
		this.containerId = containerId;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public String getContainerName() {
		return containerName;
	}

	public void setContainerName(String containerName) {
		this.containerName = containerName;
	}

	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public String getGrowAreaName() {
		return growAreaName;
	}

	public void setGrowAreaName(String growAreaName) {
		this.growAreaName = growAreaName;
	}

	public long getLastHeartbeatTimestamp() {
		return lastHeartbeatTimestamp;
	}

	public void setLastHeartbeatTimestamp(long lastHeartbeatTimestamp) {
		this.lastHeartbeatTimestamp = lastHeartbeatTimestamp;
	}

}
