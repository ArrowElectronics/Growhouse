/**
 * 
 */
package com.growhouse.rest.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.growhouse.rest.entity.GrowSectionDevice;

/**
 * @author dharita.chokshi
 *
 */
@Repository
public interface GrowSectionDeviceRepository extends JpaRepository<GrowSectionDevice, Integer> {

	public List<GrowSectionDevice> findByCreatedByIdAndIsActiveTrue(int userId);

	public List<GrowSectionDevice> findByGrowSectionIdAndIsActiveTrue(int growSectionId);

	public List<GrowSectionDevice> findByDeviceIdAndIsActiveTrue(int deviceId);
	
	public int countByGrowSectionIdAndIsActiveTrue(int growSectionId);

	
	@Transactional
    @Modifying
    @Query(value="Update grow_section_device p SET p.is_active=0 where p.device_id=?1 and p.is_active=1",nativeQuery = true)
    public void deleteDeviceSectionByDeviceId(int deviceId);
	
	
	@Transactional
    @Modifying
    @Query(value="Update grow_section_device p SET p.is_active=0 where p.device_id IN ?1 and p.is_active=1",nativeQuery = true)
    public void deleteDeviceSectionByDeviceIdList(List<Integer> deviceId);
	
	@Transactional
    @Modifying
    @Query(value="Update grow_section_device p SET p.is_active=0 where p.grow_section_id=?1 and p.is_active=1",nativeQuery = true)
	public void deleteDeviceSectionBySectionId(int sectionId);
	
}
