package com.growhouse.rest.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "profile_alerts")
public class ProfileAlert implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2985410835303064333L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	@Column(name = "container_name")
	private String containerName;
	
	@Column(name = "container_id")
	private String containerId;
	
	@Column(name = "facility_name")
	private String facilityName;
	
	
	@Column(name = "facility_id")
	private String facilityId;
	
	@Column(name = "gateway_id")
	private String gatewayId;
	
	@Column(name = "gateway_name")
	private String gatewayName;
	
	@Column(name = "properties")
	private String properties;
	
	@Column(name= "alert_message")
	private String alertMessage;
	
	@Column(name = "profile_id")
	private Integer profileId;
	
	@Column(name = "profile_name")
	private String profileName;
	
	@Column(name = "grow_section_id")
	private Integer growSectionId;
	
	@Column(name = "grow_section_name")
	private String growSectionName;
	
	private Long timestamp;
	

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getContainerName() {
		return containerName;
	}

	public void setContainerName(String containerName) {
		this.containerName = containerName;
	}

	public String getContainerId() {
		return containerId;
	}

	public void setContainerId(String containerId) {
		this.containerId = containerId;
	}

	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public String getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(String facilityId) {
		this.facilityId = facilityId;
	}

	public String getGatewayId() {
		return gatewayId;
	}

	public void setGatewayId(String gatewayId) {
		this.gatewayId = gatewayId;
	}

	public String getGatewayName() {
		return gatewayName;
	}

	public void setGatewayName(String gatewayName) {
		this.gatewayName = gatewayName;
	}

	public String getProperties() {
		return properties;
	}

	public void setProperties(String properties) {
		this.properties = properties;
	}

	public String getAlertMessage() {
		return alertMessage;
	}

	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	public Integer getProfileId() {
		return profileId;
	}

	public void setProfileId(Integer profileId) {
		this.profileId = profileId;
	}

	public String getProfileName() {
		return profileName;
	}

	public void setProfileName(String profileName) {
		this.profileName = profileName;
	}

	public Long getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Long timestamp) {
		this.timestamp = timestamp;
	}

	public Integer getGrowSectionId() {
		return growSectionId;
	}

	public void setGrowSectionId(Integer growSectionId) {
		this.growSectionId = growSectionId;
	}

	public String getGrowSectionName() {
		return growSectionName;
	}

	public void setGrowSectionName(String growSectionName) {
		this.growSectionName = growSectionName;
	}

	@Override
	public String toString() {
		return "ProfileAlert [id=" + id + ", containerName=" + containerName + ", containerId=" + containerId
				+ ", facilityName=" + facilityName + ", facilityId=" + facilityId + ", gatewayId=" + gatewayId
				+ ", gatewayName=" + gatewayName + ", properties=" + properties + ", alertMessage=" + alertMessage
				+ ", profileId=" + profileId + ", profileName=" + profileName + ", growSectionId=" + growSectionId
				+ ", growSectionName=" + growSectionName + ", timestamp=" + timestamp + "]";
	}
	
	
	
}
