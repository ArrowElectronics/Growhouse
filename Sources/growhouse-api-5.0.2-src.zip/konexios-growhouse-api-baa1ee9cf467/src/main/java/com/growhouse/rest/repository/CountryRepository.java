/**
 * 
 */
package com.growhouse.rest.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.growhouse.rest.entity.Country;

/**
 * @author dharita.chokshi
 *
 */
@Repository
public interface CountryRepository extends JpaRepository<Country, Integer> {

}
