package com.growhouse.rest.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class DevicePropertyMappingDTO {

	@JsonProperty("device_hid")
    private String deviceHId;
    
    @JsonProperty("device_id") 
    private Integer deviceId;
    
    @JsonProperty("device_uid")
    private String deviceUId;
    
    @JsonProperty("device_name") 
    private String deviceName;
    
    @JsonProperty("prefix_keyword")
	private String prefixKeyword;
    
    private List<DevicePropertyDetailsDTO> properties;

    public String getDeviceHId() {
        return deviceHId;
    }

    public void setDeviceHId(String deviceHId) {
        this.deviceHId = deviceHId;
    }

    public Integer getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(Integer deviceId) {
        this.deviceId = deviceId;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

	public List<DevicePropertyDetailsDTO> getProperties() {
		return properties;
	}

	public void setProperties(List<DevicePropertyDetailsDTO> properties) {
		this.properties = properties;
	}

	public String getPrefixKeyword() {
		return prefixKeyword;
	}

	public void setPrefixKeyword(String prefixKeyword) {
		this.prefixKeyword = prefixKeyword;
	}

	public String getDeviceUId() {
		return deviceUId;
	}

	public void setDeviceUId(String deviceUId) {
		this.deviceUId = deviceUId;
	}


}
