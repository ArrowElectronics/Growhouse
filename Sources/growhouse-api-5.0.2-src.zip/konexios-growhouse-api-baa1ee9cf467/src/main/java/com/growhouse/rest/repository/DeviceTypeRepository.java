/**
 * 
 */
package com.growhouse.rest.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.growhouse.rest.entity.DeviceType;

/**
 * @author dharita.chokshi
 *
 */
@Repository
public interface DeviceTypeRepository extends JpaRepository<DeviceType, Integer> {

	public List<DeviceType> findByIsActiveTrue();

	public DeviceType findByDeviceTypeName(String deviceTypeName);
	
	public Optional<DeviceType> findByIdAndIsActiveTrue(int id);

}

