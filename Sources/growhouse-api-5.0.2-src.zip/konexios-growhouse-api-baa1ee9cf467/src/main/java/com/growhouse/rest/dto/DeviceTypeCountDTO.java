/**
 * 
 */
package com.growhouse.rest.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author dharita.chokshi
 *
 */
public class DeviceTypeCountDTO {
	@JsonProperty("scms_count")
	private int scmsCount;
	@JsonProperty("soil_nodes_count")
	private int soilNodesCount;
	@JsonProperty("light_nodes_count")
	private int lightNodesCount;
	@JsonProperty("humidity_nodes_count")
	private int humidityNodesCount;
	@JsonProperty("light_shields_count")
	private int lightShieldsCount;

	/**
	 * @return the scmsCount
	 */
	public int getScmsCount() {
		return scmsCount;
	}

	/**
	 * @param scmsCount
	 *            the scmsCount to set
	 */
	public void setScmsCount(int scmsCount) {
		this.scmsCount = scmsCount;
	}

	/**
	 * @return the soilNodesCount
	 */
	public int getSoilNodesCount() {
		return soilNodesCount;
	}

	/**
	 * @param soilNodesCount
	 *            the soilNodesCount to set
	 */
	public void setSoilNodesCount(int soilNodesCount) {
		this.soilNodesCount = soilNodesCount;
	}

	/**
	 * @return the lightNodesCount
	 */
	public int getLightNodesCount() {
		return lightNodesCount;
	}

	/**
	 * @param lightNodesCount
	 *            the lightNodesCount to set
	 */
	public void setLightNodesCount(int lightNodesCount) {
		this.lightNodesCount = lightNodesCount;
	}

	/**
	 * @return the humidityNodesCount
	 */
	public int getHumidityNodesCount() {
		return humidityNodesCount;
	}

	/**
	 * @param humidityNodesCount
	 *            the humidityNodesCount to set
	 */
	public void setHumidityNodesCount(int humidityNodesCount) {
		this.humidityNodesCount = humidityNodesCount;
	}

	/**
	 * @return the lightShieldsCount
	 */
	public int getLightShieldsCount() {
		return lightShieldsCount;
	}

	/**
	 * @param lightShieldsCount
	 *            the lightShieldsCount to set
	 */
	public void setLightShieldsCount(int lightShieldsCount) {
		this.lightShieldsCount = lightShieldsCount;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "DeviceTypeCountDTO [scmsCount=" + scmsCount + ", soilNodesCount=" + soilNodesCount
				+ ", lightNodesCount=" + lightNodesCount + ", humidityNodesCount=" + humidityNodesCount
				+ ", lightShieldsCount=" + lightShieldsCount + "]";
	}

}
