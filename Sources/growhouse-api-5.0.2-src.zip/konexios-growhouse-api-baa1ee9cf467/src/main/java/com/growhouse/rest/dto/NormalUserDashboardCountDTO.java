package com.growhouse.rest.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

public class NormalUserDashboardCountDTO {

	@JsonProperty("grow_areas_count")
	private int growAreaCount = 0;

	@JsonProperty("devices_count")
	private NormalUserDeviceTypeCount devicesCount;

	@JsonIgnore()
	private List<Integer> growAreaIds;
	
	public List<Integer> getGrowAreaIds() {
		return growAreaIds;
	}

	public void setGrowAreaIds(List<Integer> growAreaIds) {
		this.growAreaIds = growAreaIds;
	}

	public int getGrowAreaCount() {
		return growAreaCount;
	}

	public void setGrowAreaCount(int growAreaCount) {
		this.growAreaCount = growAreaCount;
	}

	public NormalUserDeviceTypeCount getDevicesCount() {
		return devicesCount;
	}

	public void setDevicesCount(NormalUserDeviceTypeCount devicesCount) {
		this.devicesCount = devicesCount;
	}

}
