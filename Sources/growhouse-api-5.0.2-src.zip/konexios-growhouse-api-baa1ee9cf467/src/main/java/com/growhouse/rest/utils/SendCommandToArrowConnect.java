package com.growhouse.rest.utils;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.growhouse.rest.KonexiosConfig;

@Component
public class SendCommandToArrowConnect {

	@Autowired
	private RestTemplate restTemplate;
	@Autowired
	private KonexiosConfig config;

	public static final Logger LOGGER = LoggerFactory.getLogger(SendCommandToArrowConnect.class);

	public void sendCommand(Map<String, Object> commandMap, String gatewayHId, String deviceHId) {
		String url = config.buildDeviceCommandUrl(gatewayHId, deviceHId);
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set(config.getAuthTokenKey(), config.getAuthToken());
			HttpEntity<Map> entity = new HttpEntity<>(commandMap, headers);
			ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
			if (response.getStatusCode() != HttpStatus.OK) {
				throw new HttpClientErrorException(response.getStatusCode(), response.getBody());
			} else {
				LOGGER.info("ArrowConnect command sent Successfully");
			}
		} catch (HttpStatusCodeException httpStatusCodeException) {
			throw new HttpClientErrorException(httpStatusCodeException.getStatusCode(),
					httpStatusCodeException.getStatusText());
		} catch (Exception exception) {
			throw new HttpClientErrorException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Unable to fetch last telemetry of device");
		}

	}

}
