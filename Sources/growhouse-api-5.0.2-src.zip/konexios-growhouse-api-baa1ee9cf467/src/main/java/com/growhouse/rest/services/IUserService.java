/**
 * 
 */
package com.growhouse.rest.services;

import java.util.List;

import com.growhouse.rest.entity.User;
import com.growhouse.rest.repository.UserRepository;

/**
 * @author dharita.chokshi
 *
 */
public interface IUserService {

	public List<User> getActiveUsers();

	public List<User> getAllUsers();

	public User getUserById(int userId);

	public User createUser(User users);

	public User updateUser(User users);

	public User deleteUser(int userId);

	public UserRepository getUserRepository();

	public User getUserByUsername(String username);
}
