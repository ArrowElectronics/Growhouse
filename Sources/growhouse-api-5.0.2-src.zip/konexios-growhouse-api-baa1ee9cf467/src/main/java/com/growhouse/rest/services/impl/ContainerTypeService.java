/**
 * 
 */
package com.growhouse.rest.services.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.growhouse.rest.entity.ContainerType;
import com.growhouse.rest.repository.ContainerTypeRepository;
import com.growhouse.rest.services.IContainerTypeService;

/**
 * @author dharita.chokshi
 *
 */
@Service
public class ContainerTypeService implements IContainerTypeService {

	@Autowired
	private ContainerTypeRepository containerTypeRepository;

	
	public List<ContainerType> getAllContainerTypes() {
		return containerTypeRepository.findByIsActiveTrue();
	}

	public ContainerType getContainerTypeById(int id) {
		Optional<ContainerType> optional = containerTypeRepository.findById(id);
		return optional.isPresent() ? optional.get() : null;
	}

}
