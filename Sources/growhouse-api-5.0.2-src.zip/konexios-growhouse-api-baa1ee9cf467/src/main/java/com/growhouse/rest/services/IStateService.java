/**
 * 
 */
package com.growhouse.rest.services;

import java.util.List;

import com.growhouse.rest.entity.State;

/**
 * @author dharita.chokshi
 *
 */
public interface IStateService {
	
	public List<State> findAll();
	
	public List<State> findByCountryId(int countryId);
}
