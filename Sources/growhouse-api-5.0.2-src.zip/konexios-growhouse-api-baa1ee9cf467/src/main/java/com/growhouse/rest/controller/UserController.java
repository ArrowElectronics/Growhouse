/**
 * 
 */
package com.growhouse.rest.controller;

import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.growhouse.rest.dto.UserDTO;
import com.growhouse.rest.dto.UserSession;
import com.growhouse.rest.dto.konexios.AuthRequest;
import com.growhouse.rest.dto.konexios.ChangePasswordRequest;
import com.growhouse.rest.entity.User;
import com.growhouse.rest.facade.UserFacade;
import com.growhouse.rest.response.ResponseMessage;
import com.growhouse.rest.utils.Constants;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author dharita.chokshi
 *
 */

@RestController
@RequestMapping("/api/users")
@Transactional
public class UserController {
	public static final Logger LOGGER = LoggerFactory.getLogger(UserController.class);

	@Autowired
	private UserFacade userFacade;

	@Autowired
	private ObjectMapper mapper;

	@Autowired
	private StringRedisTemplate redis;

	@PostMapping("/login")
	@ApiOperation("login user")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Login OK!"),
			@ApiResponse(code = 401, message = "Login FAILED!"),
			@ApiResponse(code = 409, message = "Password Change is REQUIRED") })
	public ResponseEntity<UserSession> login(@RequestBody AuthRequest request) {

		if (request == null || StringUtils.isEmpty(request.getLogin()) || StringUtils.isEmpty(request.getPassword())) {
			return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
		}

		String sessionStr = redis.opsForValue().get(request.getLogin());
		if (!StringUtils.isEmpty(sessionStr)) {
			try {
				LOGGER.info("found existing session for username: " + request.getLogin());
				return new ResponseEntity<>(mapper.readValue(sessionStr, UserSession.class), HttpStatus.OK);
			} catch (Exception e) {
				LOGGER.error("unable to parse session string: " + sessionStr);
			}
		}

		UserDTO userDTO = userFacade.authenticate(request.getLogin(), request.getPassword());
		if (userDTO == null) {
			LOGGER.info("user authenticated by Konexios but not found in the database");
			return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
		} else {
			try {
				UserSession session = new UserSession();
				session.setUserDTO(userDTO);
				session.setSessionId(RandomStringUtils.randomAlphanumeric(64));

				long timeoutHours = request.isMobileApp() ? Constants.DEFAULT_SESSION_TIMEOUT_MOBILE_APP_HOURS
						: Constants.DEFAULT_SESSION_TIMEOUT_WEB_APP_HOURS;
				session.setTimeoutHours(timeoutHours);
				LOGGER.info("timeoutHours: " + timeoutHours);

				sessionStr = mapper.writeValueAsString(session);
				LOGGER.info("sessionStr: " + sessionStr);

				redis.opsForValue().set(session.getSessionId(), sessionStr, timeoutHours, TimeUnit.HOURS);
				redis.opsForValue().set(userDTO.getUsername(), sessionStr, timeoutHours, TimeUnit.HOURS);

				return new ResponseEntity<>(session, HttpStatus.OK);
			} catch (HttpClientErrorException e) {
				throw e;
			} catch (Exception e) {
				LOGGER.error("error persisting user session", e);
				return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
	}

	@PostMapping("/logout")
	@ApiOperation("logout current user session")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Logout OK"),
			@ApiResponse(code = 400, message = "user or session not found"),
			@ApiResponse(code = 500, message = "System Error") })
	public ResponseEntity<ResponseMessage> logout() {
		ResponseEntity<ResponseMessage> responseEntity;
		try {
			Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
			if (authentication == null) {
				responseEntity = new ResponseEntity<>(new ResponseMessage().message("User not signed in"),
						HttpStatus.BAD_REQUEST);
			} else {
				User user = (User) authentication.getPrincipal();
				if (user == null) {
					responseEntity = new ResponseEntity<>(new ResponseMessage().message("User not found"),
							HttpStatus.BAD_REQUEST);
				} else {
					String sessionStr = redis.opsForValue().get(user.getUsername());
					if (!StringUtils.isEmpty(sessionStr)) {
						UserSession session = mapper.readValue(sessionStr, UserSession.class);
						redis.delete(session.getUserDTO().getUsername());
						redis.delete(session.getSessionId());
						responseEntity = new ResponseEntity<>(new ResponseMessage().message("User logged out"),
								HttpStatus.OK);
					} else {
						responseEntity = new ResponseEntity<>(new ResponseMessage().message("UserSession not found"),
								HttpStatus.BAD_REQUEST);
					}
				}
			}
		} catch (Exception exception) {
			LOGGER.error(ExceptionUtils.getFullStackTrace(exception));
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		try {
			LOGGER.info(mapper.writeValueAsString(responseEntity));
		} catch (JsonProcessingException e) {
		}
		return responseEntity;
	}

	@ApiOperation("reset user's password")
	@PostMapping("/{username}/reset-password")
	public ResponseEntity<ResponseMessage> resetPassword(@PathVariable("username") String username) {

		// clear old session
		if (redis.delete(username)) {
			LOGGER.info("removed old session for: " + username);
		}

		return new ResponseEntity<>(new ResponseMessage().message(userFacade.resetPassword(username)), HttpStatus.OK);
	}

	@ApiOperation("change user's password")
	@PostMapping("/{username}/change-password")
	public ResponseEntity<ResponseMessage> changePassword(@PathVariable("username") String username,
			@RequestBody ChangePasswordRequest request) {

		// clear old session
		if (redis.delete(username)) {
			LOGGER.info("removed old session for: " + username);
		}

		userFacade.changePassword(username, request.getCurrentPassword(), request.getNewPassword());
		return new ResponseEntity<>(new ResponseMessage().message("password has been changed successfully"),
				HttpStatus.OK);
	}

	/* Query-- Select * from user where account_id=? and is_active=true */
	@GetMapping(value = "")
	@ApiOperation(value = "View a list of active users")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "List retrieved successfully"),
			@ApiResponse(code = 204, message = "Empty list") })
	public ResponseEntity<List<UserDTO>> getUsers() {
		ResponseEntity<List<UserDTO>> responseEntity;
		try {
			List<UserDTO> users = userFacade.getUsers();
			if (users == null || users.isEmpty())
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(users, HttpStatus.OK);
		} catch (Exception exception) {
			LOGGER.error(ExceptionUtils.getFullStackTrace(exception));
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/* Query-- Select * from user where user_id=? */
	@GetMapping(value = "/{userId}")
	@ApiOperation(value = "Retrieve user based on userId")
	@ApiResponses(value = { @ApiResponse(code = 403, message = "User is inactive"),
			@ApiResponse(code = 404, message = "User not found"), })
	public ResponseEntity<?> getUserByUserId(@PathVariable("userId") Integer userId) {
		ResponseEntity<?> responseEntity;
		try {
			UserDTO users = userFacade.getUserByUserId(userId);
			if (users == null) {
				ResponseMessage responseMessage = new ResponseMessage();
				responseMessage.setMessage("User not found");
				responseEntity = new ResponseEntity<>(responseMessage, HttpStatus.NO_CONTENT);
			} else {
				responseEntity = new ResponseEntity<>(users, HttpStatus.OK);
			}
		} catch (Exception exception) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/* create user query */
	@PostMapping(value = "", consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Create new user")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "User created successfully"),
			@ApiResponse(code = 400, message = "Bad Request"),
			@ApiResponse(code = 409, message = "User with email Id already exist") })
	public ResponseEntity<?> createUser(@RequestBody UserDTO userDTO) {
		ResponseEntity<?> responseEntity = null;
		try {
			UserDTO createdUser = userFacade.createUser(userDTO);
			if (createdUser == null)
				responseEntity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			else
				responseEntity = new ResponseEntity<>(createdUser, HttpStatus.CREATED);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@PutMapping(value = "/{userId}")
	@ApiOperation(value = "Update existing user")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "User updated successfully"),
			@ApiResponse(code = 400, message = "Bad Request"), @ApiResponse(code = 403, message = "User is inactive"),
			@ApiResponse(code = 404, message = "User not found"),
			@ApiResponse(code = 406, message = "UserId in URL doesnot match with userId of User object") })
	public ResponseEntity<?> updateUser(@PathVariable("userId") Integer userId, @RequestBody UserDTO userDTO) {
		ResponseEntity<?> responseEntity;
		try {
			UserDTO updatedUser = userFacade.updateUser(userId, userDTO);
			if (updatedUser == null)
				responseEntity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			else
				responseEntity = new ResponseEntity<>(userDTO, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@GetMapping(value = "/token")
	@ApiOperation(value = "View User based on token")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "User retrived successfully"),
			@ApiResponse(code = 400, message = "Bad Request"), @ApiResponse(code = 403, message = "User is inactive"),
			@ApiResponse(code = 404, message = "User not found") })
	public ResponseEntity<?> updateUserToken() {
		ResponseEntity<?> responseEntity;
		try {
			UserDTO existingUser = userFacade.getUserByToken();
			if (existingUser == null)
				responseEntity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			else
				responseEntity = new ResponseEntity<>(existingUser, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			HashMap<String, String> invalidUser = new HashMap<>();
			invalidUser.put("user", "invalid");
			responseEntity = new ResponseEntity<>(invalidUser, HttpStatus.UNAUTHORIZED);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@GetMapping(value = "/account/admin")
	@ApiOperation(value = "View a list of admin Account users")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "List retrieved successfully"),
			@ApiResponse(code = 204, message = "Empty list") })
	public ResponseEntity<List<UserDTO>> getAdminUsersByAccountId() {
		ResponseEntity<List<UserDTO>> responseEntity;
		try {
			User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			responseEntity = new ResponseEntity<>(userFacade.getUserByAccountIdAndAdmin(user.getAccount().getId()),
					HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@DeleteMapping(value = "/{userId}")
	@ApiOperation(value = "Delete user by userId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "User deleted successfully"),
			@ApiResponse(code = 404, message = "User not found") })
	public ResponseEntity<ResponseMessage> deleteUser(@PathVariable("userId") Integer userId) {
		ResponseEntity<ResponseMessage> responseEntity;
		try {
			User deletedUser = userFacade.deleteUser(userId);
			if (deletedUser != null) {
				ResponseMessage responseMessage = new ResponseMessage();
				responseMessage.setMessage("User deleted successfully");
				responseEntity = new ResponseEntity<>(responseMessage, HttpStatus.OK);
			} else {
				responseEntity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			}
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/**
	 * @param httpClientErrorException
	 * @return
	 */
	private ResponseEntity<ResponseMessage> setResponseMessage(HttpClientErrorException httpClientErrorException) {
		ResponseMessage responseMessage = new ResponseMessage();
		responseMessage.setMessage(httpClientErrorException.getStatusText());
		return new ResponseEntity<>(responseMessage, httpClientErrorException.getStatusCode());
	}
}
