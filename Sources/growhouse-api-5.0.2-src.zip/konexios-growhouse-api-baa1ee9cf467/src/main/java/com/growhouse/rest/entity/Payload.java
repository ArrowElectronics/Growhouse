package com.growhouse.rest.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="payload")
public class Payload extends DefaultModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1182858090087889358L;

	@Column(length=1000)
	private String conditions;
	
	@Column(length=1000)
	private String monitors;
	
	private String name;
	
	@Column(name="rule_hid")
	private String ruleHid;
	
	@Column(name="time_interval")
	private String timeInterval;
	
	@OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.PERSIST)
	@JoinColumn(name="global_response_payload_id")
	private GlobalResponsePayload globalResponsePayload;
	
	
	/**
	 * @return the conditions
	 */
	public String getConditions() {
		return conditions;
	}

	/**
	 * @param conditions the conditions to set
	 */
	public void setConditions(String conditions) {
		this.conditions = conditions;
	}

	/**
	 * @return the monitors
	 */
	public String getMonitors() {
		return monitors;
	}

	/**
	 * @param monitors the monitors to set
	 */
	public void setMonitors(String monitors) {
		this.monitors = monitors;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the ruleHid
	 */
	public String getRuleHid() {
		return ruleHid;
	}

	/**
	 * @param ruleHid the ruleHid to set
	 */
	public void setRuleHid(String ruleHid) {
		this.ruleHid = ruleHid;
	}

	/**
	 * @return the timeInterval
	 */
	public String getTimeInterval() {
		return timeInterval;
	}

	/**
	 * @param timeInterval the timeInterval to set
	 */
	public void setTimeInterval(String timeInterval) {
		this.timeInterval = timeInterval;
	}

	/**
	 * @return the globalResponsePayload
	 */
	public GlobalResponsePayload getGlobalResponsePayload() {
		return globalResponsePayload;
	}

	/**
	 * @param globalResponsePayload the globalResponsePayload to set
	 */
	public void setGlobalResponsePayload(GlobalResponsePayload globalResponsePayload) {
		this.globalResponsePayload = globalResponsePayload;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Payload [conditions=" + conditions + ", monitors=" + monitors + ", name=" + name + ", ruleHid="
				+ ruleHid + ", timeInterval=" + timeInterval + ", globalResponsePayload=" + globalResponsePayload + "]";
	}
	
	
	
	
	
}
