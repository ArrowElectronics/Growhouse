/**
 * 
 */
package com.growhouse.rest.controller;

import com.growhouse.rest.response.ResponseMessage;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

/**
 * @author dharita.chokshi
 *
 */
@ControllerAdvice
public class CustomRestController extends ResponseEntityExceptionHandler {

	@ExceptionHandler(HttpClientErrorException.class)
	public final ResponseEntity<ResponseMessage> handleAllExceptions(HttpClientErrorException exception,
			WebRequest request) {
		return new ResponseEntity<>(new ResponseMessage().message(exception.getStatusText()),
				exception.getStatusCode());
	}
}
