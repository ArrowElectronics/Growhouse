/**
 * 
 */
package com.growhouse.rest.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.growhouse.rest.entity.User;

/**
 * @author dharita.chokshi
 *
 */
@Repository
public interface UserRepository extends JpaRepository<User, Integer> {

	public List<User> findByAccountIdAndIsActiveTrueOrderByCreatedTimestampDesc(int accountId);

	public List<User> findByAccountIdAndUserRoleRoleNameAndIsActiveTrue(int accountId, String userRole);

	public List<User> findByUserHidIsNullAndIsActiveTrue();

	public List<User> findByIsActiveTrueAndMigratedUsernameIsNull();

	public User findByAccountId(int accountId);

	public User findByEmailAndIsActiveTrue(String emailId);

	public Optional<User> findByIdAndIsActiveTrue(int id);

	public Optional<User> findByUsername(String username);

	@Transactional
	@Modifying
	@Query(value = "UPDATE users SET is_active = 0 WHERE account_id = ?1 ", nativeQuery = true)
	public void updateUsersByAccountId(int accountId);
}
