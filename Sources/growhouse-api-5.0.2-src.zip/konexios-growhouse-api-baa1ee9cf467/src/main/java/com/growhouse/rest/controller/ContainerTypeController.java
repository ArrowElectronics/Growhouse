/**
 * 
 */
package com.growhouse.rest.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpServerErrorException;

import com.growhouse.rest.dto.ContainerTypeDTO;
import com.growhouse.rest.facade.ContainerTypeFacade;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author dharita.chokshi
 *
 */

@RestController
@RequestMapping("/api/containertypes")
@Transactional
public class ContainerTypeController {

	public static final Logger LOGGER = LoggerFactory.getLogger(ContainerTypeController.class);

	@Autowired
	private ContainerTypeFacade containerTypeFacade;

	/* Query-- Select * from container_types where is_active=true */
	@GetMapping(value = "")
	@ApiOperation(value = "View a list of active container types")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "List retrieved successfully"),
			@ApiResponse(code = 204, message = "Empty list") })
	public ResponseEntity<List<ContainerTypeDTO>> getContainerTypes() {
		ResponseEntity<List<ContainerTypeDTO>> responseEntity;
		try {
			List<ContainerTypeDTO> containerTypeDTOs = containerTypeFacade.getContainerTypes();
			if (containerTypeDTOs == null || containerTypeDTOs.isEmpty())
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(containerTypeDTOs, HttpStatus.OK);
		} catch (Exception exception) {
			throw new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/*
	 * Query-- Select * from container_types where container_types.id=? and
	 * is_active=true
	 */
	@GetMapping(value = "/{containerTypeId}")
	@ApiOperation(value = "View container type based on containerTypeId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Container type retrieved successfully"),
			@ApiResponse(code = 403, message = "Container type is inactive") })
	public ResponseEntity<ContainerTypeDTO> getContainerTypeByContainerTypeId(
			@PathVariable("containerTypeId") Integer containerTypeId) {
		ResponseEntity<ContainerTypeDTO> responseEntity;
		try {
			ContainerTypeDTO containerTypeDTO = containerTypeFacade.getContainerTypeById(containerTypeId);
			if (containerTypeDTO == null)
				responseEntity = new ResponseEntity<>(HttpStatus.NOT_FOUND);
			else
				responseEntity = new ResponseEntity<>(containerTypeDTO, HttpStatus.OK);
		} catch (Exception exception) {
			throw new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}
}
