/**
 * 
 */
package com.growhouse.rest.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;

import com.growhouse.rest.dto.ContainerDTO;
import com.growhouse.rest.dto.FacilityDTO;
import com.growhouse.rest.entity.Facility;
import com.growhouse.rest.facade.ContainerFacade;
import com.growhouse.rest.facade.FacilityFacade;
import com.growhouse.rest.response.ResponseMessage;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author dharita.chokshi
 *
 */

@RestController
@RequestMapping("/api/facilities")
@Transactional
public class FacilityController {

	public static final Logger LOGGER = LoggerFactory.getLogger(FacilityController.class);

	@Autowired
	private FacilityFacade facilityFacade;

	@Autowired
	private ContainerFacade containerFacade;

	/*
	 * Query-Select * from facility where account_id=? and facility.is_active=true
	 */
	@GetMapping(value = "")
	@ApiOperation(value = "View list of active facilities")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "List retrieved successfully"),
			@ApiResponse(code = 204, message = "Empty list") })
	public ResponseEntity<List<FacilityDTO>> getActiveFacilities() {
		ResponseEntity<List<FacilityDTO>> responseEntity;
		try {
			List<FacilityDTO> facilities = facilityFacade.getActiveFacilitiesByAccount();
			if (facilities == null || facilities.isEmpty())
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(facilities, HttpStatus.OK);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/* Query-Select * from facility */
	@GetMapping(value = "/all")
	@ApiOperation(value = "View list of all (active and inactive) facilities")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "List retrieved successfully"),
			@ApiResponse(code = 204, message = "Empty list.") })
	public ResponseEntity<List<FacilityDTO>> getAllFacilities() {
		ResponseEntity<List<FacilityDTO>> responseEntity;
		try {
			List<FacilityDTO> facilities = facilityFacade.getAllFacilities();
			if (facilities == null || facilities.isEmpty())
				responseEntity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				responseEntity = new ResponseEntity<>(facilities, HttpStatus.OK);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/* Query-Select * from facility where facility_id=? */
	@GetMapping(value = "/{facilityId}")
	@ApiOperation(value = "View facility based on facilityId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Facility retrieved successfully"),
			@ApiResponse(code = 403, message = "User is inactive") })
	public ResponseEntity<?> getFacilityByFacilityId(@PathVariable("facilityId") Integer facilityId) {
		ResponseEntity<?> responseEntity;
		try {
			FacilityDTO facilities = facilityFacade.getFacilityById(facilityId);
			if (facilities == null)
				responseEntity = new ResponseEntity<>(HttpStatus.NOT_FOUND);
			else
				responseEntity = new ResponseEntity<>(facilities, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@PostMapping(value = "", consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Create new facility")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Facility created successfully"),
			@ApiResponse(code = 207, message = "Facility created successfully. Error saving containers"),
			@ApiResponse(code = 400, message = "Bad Request") })
	public ResponseEntity<?> createFacility(@RequestBody FacilityDTO facilityDTO) {
		ResponseEntity<?> responseEntity;
		try {
			FacilityDTO createdFacilityDTO = facilityFacade.createFacility(facilityDTO);
			if (createdFacilityDTO == null)
				responseEntity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			else {
				if (facilityDTO.getContainers() != null && !facilityDTO.getContainers().isEmpty()) {
					List<ContainerDTO> createdContainerDTOs = containerFacade
							.createContainersInBatch(facilityDTO.getContainers(), createdFacilityDTO);
					if (createdContainerDTOs == null || createdContainerDTOs.isEmpty()) {
						responseEntity = new ResponseEntity<>("Facility created successfully. Error saving containers",
								HttpStatus.MULTI_STATUS);
					} else {
						createdFacilityDTO.setContainers(createdContainerDTOs);
						responseEntity = new ResponseEntity<>(createdFacilityDTO, HttpStatus.CREATED);
					}
				} else {
					responseEntity = new ResponseEntity<>(createdFacilityDTO, HttpStatus.CREATED);
				}

			}
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@PutMapping(value = "/{facilityId}")
	@ApiOperation(value = "Update existing facility")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Facility updated successfully"),
			@ApiResponse(code = 400, message = "Bad Request"),
			@ApiResponse(code = 403, message = "Facility is inactive"),
			@ApiResponse(code = 404, message = "Facility not found"),
			@ApiResponse(code = 406, message = "FacilityId in URL doesnot match with facilityId of Facility object") })
	public ResponseEntity<?> updateFacility(@PathVariable("facilityId") Integer facilityId,
			@RequestBody FacilityDTO facilityDTO) {
		ResponseEntity<?> responseEntity;
		try {
			FacilityDTO updatedFacilities = facilityFacade.updateFacility(facilityId, facilityDTO);
			if (updatedFacilities == null)
				responseEntity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			else
				responseEntity = new ResponseEntity<>(updatedFacilities, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/*
	 * Query--Select * from facility where facility_id=? Update facility SET
	 * is_active=False where facility_id=?
	 */
	@DeleteMapping(value = "/{facilityId}")
	@ApiOperation(value = "Delete facility by facilityId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Facility deleted successfully"),
			@ApiResponse(code = 404, message = "Facility not found") })
	public ResponseEntity<ResponseMessage> deleteFacility(@PathVariable("facilityId") Integer facilityId) {
		ResponseEntity<ResponseMessage> responseEntity;
		try {
			Facility deletedFacility = facilityFacade.deleteFacility(facilityId);
			if (deletedFacility != null) {
				ResponseMessage responseMessage = new ResponseMessage();
				responseMessage.setMessage("Facility deleted successfully");
				responseEntity = new ResponseEntity<>(responseMessage, HttpStatus.OK);
			} else {
				responseEntity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			}
		} catch (HttpClientErrorException httpClientErrorException) {
			responseEntity = setResponseMessage(httpClientErrorException);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	/**
	 * @param httpClientErrorException
	 * @return
	 */
	private ResponseEntity<ResponseMessage> setResponseMessage(HttpClientErrorException httpClientErrorException) {
		ResponseMessage responseMessage = new ResponseMessage();
		responseMessage.setMessage(httpClientErrorException.getStatusText());
		return new ResponseEntity<>(responseMessage, httpClientErrorException.getStatusCode());
	}

}
