/**
 * 
 */
package com.growhouse.rest.services;

import java.util.List;

import com.growhouse.rest.entity.GrowSection;
import com.growhouse.rest.repository.GrowSectionRepository;

/**
 * @author dharita.chokshi
 *
 */
public interface IGrowSectionService {

	public List<GrowSection> getActiveGrowSections();

	public List<GrowSection> getAllGrowSections();

	public List<GrowSection> getGrowSectionsByGrowAreaId(int growAreaId);

	public List<GrowSection> getGrowSectionsByContainerId(int containerId);

	public List<GrowSection> getGrowSectionsByFacilityId(int facilityId);

	public GrowSection getGrowSectionById(int id);

	public GrowSection createGrowSection(GrowSection growSection);
	
	public List<GrowSection> createGrowSectionsInBatch(List<GrowSection> growSections);

	public GrowSection updateGrowSection(GrowSection growSection);

	public GrowSection deleteGrowSection(int id);
	
	public GrowSectionRepository getGrowSectionRepository();
	
	public List<GrowSection> getGrowSectionsByGrowAreaIdList(List<Integer> growAreaIdList);
	
	public void deleteGrowSectionByGatewayId(int gatewayId);

}
