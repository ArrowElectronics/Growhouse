package com.growhouse.rest.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.growhouse.rest.utils.TelemetryItemType;

public class TelemetryItemDTO {
	
	private String name;
	private TelemetryItemType type;
	private long timestamp;
	private Object value;
	@JsonProperty("display_property_name")
	private String displayPropertyName;
	
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public TelemetryItemType getType() {
		return type;
	}
	public void setType(TelemetryItemType type) {
		this.type = type;
	}
	public long getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}
	public Object getValue() {
		return value;
	}
	public void setValue(Object value) {
		this.value = value;
	}
	public String getDisplayPropertyName() {
		return displayPropertyName;
	}
	public void setDisplayPropertyName(String displayPropertyName) {
		this.displayPropertyName = displayPropertyName;
	}
	
	@Override
	public String toString() {
		return "TelemetryItemDTO [name=" + name + ", type=" + type + ", timestamp=" + timestamp + ", value=" + value
				+ ", displayPropertyName=" + displayPropertyName + "]";
	}

	

	
	

}
