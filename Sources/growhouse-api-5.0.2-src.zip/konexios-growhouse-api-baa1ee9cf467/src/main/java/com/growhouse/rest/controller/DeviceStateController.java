package com.growhouse.rest.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;

import com.growhouse.rest.dto.CheckDeviceStateDTO;
import com.growhouse.rest.facade.DeviceStateFacade;
import com.growhouse.rest.response.ResponseMessage;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/api/devicestate")
@Transactional
public class DeviceStateController {

	public static final Logger LOGGER = LoggerFactory.getLogger(DeviceStateController.class);

	@Autowired
	private DeviceStateFacade deviceStateFacade;

	/* call arrow connect API */
	@PostMapping(value = "/checkdevicestate", consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Check current deviceState")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Device state request sent successfully"),
			@ApiResponse(code = 400, message = "Bad Request") })
	public ResponseEntity<?> checkDeviceState(@RequestBody CheckDeviceStateDTO deviceStateDTO) {
		ResponseEntity<?> responseEntity;
		ResponseMessage responseMessage = new ResponseMessage();
		Assert.notNull(deviceStateDTO.getCommand(), "Command Must need to provide");
		Assert.notNull(deviceStateDTO.getDeviceHid(), "DeviceHId Must need to provide");
		Assert.notNull(deviceStateDTO.getGatewayHid(), "GatewayHId Must need to provide");
		try {
			deviceStateFacade.checkDeviceState(deviceStateDTO);
			responseMessage.setMessage("Request for device state sent successfully");
			responseEntity = new ResponseEntity<>(responseMessage, HttpStatus.OK);
		} catch (HttpClientErrorException httpClientErrorException) {
			responseMessage.setMessage("Not able to send devicestate request");
			responseEntity = new ResponseEntity<>(responseMessage, HttpStatus.INTERNAL_SERVER_ERROR);
		} catch (Exception e) {
			responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}
}
