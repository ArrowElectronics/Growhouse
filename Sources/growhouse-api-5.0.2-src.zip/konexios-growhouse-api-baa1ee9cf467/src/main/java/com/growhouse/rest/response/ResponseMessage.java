/**
 * 
 */
package com.growhouse.rest.response;

/**
 * @author dharita.chokshi
 *
 */
public class ResponseMessage {

	private String message;

	public ResponseMessage message(String message) {
		this.message = message;
		return this;
	}

	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}

}
