package com.growhouse.rest.dto.konexios;

public class ResetPasswordResponse extends BaseResponse {
    private String temporaryPassword;

    public String getTemporaryPassword() {
        return this.temporaryPassword;
    }

    public void setTemporaryPassword(String temporaryPassword) {
        this.temporaryPassword = temporaryPassword;
    }
}