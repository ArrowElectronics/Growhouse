package com.growhouse.rest.dto.konexios;

public class FindUserResponse extends UserResponse {
}