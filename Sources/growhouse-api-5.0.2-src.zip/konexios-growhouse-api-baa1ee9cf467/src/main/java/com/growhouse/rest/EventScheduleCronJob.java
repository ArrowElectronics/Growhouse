package com.growhouse.rest;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SchedulerFactory;
import org.quartz.SimpleScheduleBuilder;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.growhouse.rest.entity.LedNodeProfileEvent;
import com.growhouse.rest.entity.SchedulerInput;
import com.growhouse.rest.facade.LedNodeFacade;
import com.growhouse.rest.facade.SimpleJob;
import com.growhouse.rest.repository.LedNodeProfileEventRepository;
import com.growhouse.rest.services.ILedNodeService;

@Component
public class EventScheduleCronJob {

	private static final Logger LOGGER = LogManager.getLogger(EventScheduleCronJob.class);

	@Autowired
	private LedNodeProfileEventRepository repo;

	@Autowired
	private ILedNodeService ledNodeService;

	@Autowired
	private LedNodeFacade ledNodeFacade;

	@Scheduled(cron = "0 02 00 ? * *")
	public void testSchedule() throws SchedulerException, ParseException {
		HashMap<Integer, String> map = new HashMap<>();
		map.put(1, "Every Sunday");
		map.put(2, "Every Monday");
		map.put(3, "Every Tuesday");
		map.put(4, "Every Wednesday");
		map.put(5, "Every Thursday");
		map.put(6, "Every Friday");
		map.put(7, "Every Saturday");
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(new Date());
		int d = calendar.get(Calendar.DAY_OF_WEEK);
		String todayDay = map.get(d); // get current day name to match with db

		SimpleDateFormat todayformater = new SimpleDateFormat("MM/dd/yyyy");
		String todayDate = todayformater.format(new Date()); // get today date to match with db
		List<LedNodeProfileEvent> events = repo.getEventByCron(todayDay, todayDate);
		List<SchedulerInput> alreadyAdded = new ArrayList<>();
		List<SchedulerInput> cpyAdded = new ArrayList<>();

		for (LedNodeProfileEvent event : events) {

			if (alreadyAdded.isEmpty()) {
				SchedulerInput obj = new SchedulerInput();
				obj.setStartTme(event.getStartTime());
				obj.setGroupId(event.getGroupId());
				cpyAdded.add(obj);
				scheduleJob(event);
			} else {
				int flag = 0;
				for (SchedulerInput input : alreadyAdded) {
					if (input.getStartTme().equals(event.getStartTime())
							&& input.getGroupId().equals(event.getGroupId())) {
						LOGGER.info("match found");
						flag = 0;
						break;
					} else {
						flag = 1;
					}

				}
				if (flag == 1) {
					SchedulerInput obj = new SchedulerInput();
					obj.setStartTme(event.getStartTime());
					obj.setGroupId(event.getGroupId());
					cpyAdded.add(obj);
					scheduleJob(event);
				}
			}
			alreadyAdded.addAll(cpyAdded);
			cpyAdded.clear();
		}

		LOGGER.info("Final list for scheduling----" + alreadyAdded);
	}

	public void scheduleJob(LedNodeProfileEvent event) throws SchedulerException, ParseException {

		SchedulerFactory schedFact = new StdSchedulerFactory();
		Scheduler sched = schedFact.getScheduler();
		JobDetail job = JobBuilder.newJob(SimpleJob.class).withIdentity(event.getJobName(), event.getJobName()).build();
		job.getJobDataMap().put("groupId", event.getGroupId());
		job.getJobDataMap().put("profileId", event.getProfileId());
		job.getJobDataMap().put("obj", ledNodeService);
		job.getJobDataMap().put("lednodeFacade", ledNodeFacade);
		job.getJobDataMap().put("preset", event.getPreset());

		SimpleDateFormat todayformater = new SimpleDateFormat("MM/dd/yyyy");
		String startdate = todayformater.format(new Date());
		SimpleDateFormat endformatter = new SimpleDateFormat("MM/dd/yyyy HH:mm");
		String startTime = event.getStartTime();
		String finalstartdate = startdate + " " + startTime;
		Date startforonce = endformatter.parse(finalstartdate);

		Trigger trigger = TriggerBuilder.newTrigger().withIdentity("myTrigger", event.getJobName())
				.startAt(startforonce).withSchedule(SimpleScheduleBuilder.simpleSchedule()).build();
		sched.scheduleJob(job, trigger);

		sched.start();
		LOGGER.info("Today job schedule using cron..." + event.getJobName());

	}
}
