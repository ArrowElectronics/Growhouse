package com.growhouse.rest.services;

import com.growhouse.rest.entity.Payload;

public interface IPayloadService {

	public Payload createPayload(Payload payload);
}
