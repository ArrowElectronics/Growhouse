package com.growhouse.rest.dto;

public class GetProfileResponseDTO {
	
	private String property;
	private String value;
	private String operator;
	private String combinationOperator;
	public String getProperty() {
		return property;
	}
	public void setProperty(String property) {
		this.property = property;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getOperator() {
		return operator;
	}
	public void setOperator(String operator) {
		this.operator = operator;
	}
	public String getCombinationOperator() {
		return combinationOperator;
	}
	public void setCombinationOperator(String combinationOperator) {
		this.combinationOperator = combinationOperator;
	}
	
	
	

}
