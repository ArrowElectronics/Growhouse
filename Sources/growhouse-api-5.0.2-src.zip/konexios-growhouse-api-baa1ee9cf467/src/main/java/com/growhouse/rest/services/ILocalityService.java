/**
 * 
 */
package com.growhouse.rest.services;

import java.util.List;

import com.growhouse.rest.entity.Locality;

/**
 * @author dharita.chokshi
 *
 */
public interface ILocalityService {
	
	public List<Locality> findAll();
	
	public List<Locality> findByStateId(int stateId);
}
