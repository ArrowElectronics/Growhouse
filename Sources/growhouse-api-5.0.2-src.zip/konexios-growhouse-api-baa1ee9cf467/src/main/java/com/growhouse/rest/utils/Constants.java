package com.growhouse.rest.utils;

public class Constants {

	private Constants() {
		throw new IllegalStateException("Utility class");
	}

	public static final String POSTBACK_URL = "PostBackURL";
	public static final String URL = "URL";
	public static final String ALERT_POSTBACK_API_PATH = "/api/profile/alert/create";
	public static final String RULE_HID = "ruleHid";
	public static final String GROWSECTION_ID = "growSectionId";
	public static final String HEADERS = "Headers";
	public static final String REQUEST_BODY = "RequestBody";
	public static final String ALERT_REQUEST_BODY_VALUE = "{payload}";
	public static final String CONTENT_TYPE = "ContentType";
	public static final String CONTENT_TYPE_VALUE = "application/json";
	public static final String COMMAND = "command";
	public static final String DEVICE_HID = "deviceHid";
	public static final String GATEWAY_HID = "gatewayHId";
	public static final String GATEWAY_DEVICE_HID = "gatewayDeviceHid";
	public static final String MESSAGE_EXPIRATION = "messageExpiration";
	public static final String PAYLOAD = "payload";
	public static final String DELETE = "DELETE";
	public static final String TYPE = "type";
	public static final String ADMIN_USER_ROLE = "Admin";
	public static final Integer THREE_HOURS = 3 * 60 * 60 * 1000;
	public static final String EMPTY_JSON_PAYLOAD = "{}";
	public static final String PROFILE_PROPERTIES = "alertMessage,properties";
	public static final String ALERTMESSAGE = "alertMessage";
	public static final String PROPERTIES = "properties";
	public static final String CHANNEL1 = "ch1";
	public static final String CHANNEL2 = "ch2";
	public static final String CHANNEL3 = "ch3";
	public static final String CHANNEL4 = "ch4";
	public static final String CHANNEL5 = "ch5";
	public static final String CHANNEL6 = "ch6";
	public static final String GROW_AREA_NOT_ACCESSIBLE = "This user have not access of any grow area";
	public static final String DEVICE_NOT_ACCESSIBLE = "this user have not access of any devices";
	public static final String FROM_TIMESTAMP = "fromTimestamp";
	public static final String TO_TIMESTAMP = "toTimestamp";
	public static final String TELEMETRY_NAMES = "telemetryNames";
	public static final String PAGE = "_page";
	public static final String USER_INACTIVE_MESSAGE = "User is inactive";
	public static final String USER_NOT_FOUND_MESSAGE = "User not found";
	public static final String DEVICE_NOT_FOUND_MESSAGE = "Device not found";
	public static final String FACILITY_NOT_FOUND_MESSAGE = "Facility not found";
	public static final String FETCH_DEVICE_ID_ERROR_MESSAGE = "Unable to fetch Device HId";
	public static final String ACCESS_TOKEN = "access_token";
	public static final String AUTHORIZATION = "Authorization";
	public static final Boolean TRUE = true;
	public static final Boolean FALSE = false;
	public static final Integer THRITY_MINUTES = 15 * 60 * 1000;
	public static final String GROW_AREA = "growArea";
	public static final String GROW_SECTION = "growSection";
	public static final String DEVICE_NOT_EXIST = "Device does not exist on Arrow Portal";
	public static final String RELEASE_VERSION = "5.0.1";
	public static final String LEDNODE = "LedNode";
	public static final String SOILPH_KEY = "soilPh";
	public static final String BATTERYVOLTAGE_KEY = "batteryVoltage";
	public static final String SOILMOISTURE_KEY = "soilMoisture";
	public static final String SOILPH_VALUE = "Soil pH";
	public static final String BATTERYVOLTAGE_VALUE = "Battery Voltage";
	public static final String SOILMOISTURE_VALUE = "Soil Moisture";
	public static final String LED1_VALUE = "CH 1";
	public static final String LED2_VALUE = "CH 2";
	public static final String LED3_VALUE = "CH 3";
	public static final String LED4_VALUE = "CH 4";
	public static final String LED5_VALUE = "CH 5";
	public static final String LED6_VALUE = "CH 6";
	public static final String LED1_KEY = "led1";
	public static final String LED2_KEY = "led2";
	public static final String LED3_KEY = "led3";
	public static final String LED4_KEY = "led4";
	public static final String LED5_KEY = "led5";
	public static final String LED6_KEY = "led6";

	public static final long DEFAULT_SESSION_TIMEOUT_WEB_APP_HOURS = 4;
	public static final long DEFAULT_SESSION_TIMEOUT_MOBILE_APP_HOURS = 24;

	// reset password email constants
	public interface ResetPasswordEmail {
		public static final String SUBJECT = "GrowHouse Application Password Reset";
		public static final String TEMPLATE = "/templates/reset-password-email.txt";
		public static final String VAR_NAME = "<name>";
		public static final String VAR_URL = "<url>";
		public static final String VAR_USERNAME = "<username>";
		public static final String VAR_PASSWORD = "<password>";

	}
}
