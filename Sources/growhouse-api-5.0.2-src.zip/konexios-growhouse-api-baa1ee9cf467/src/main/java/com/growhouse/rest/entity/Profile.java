package com.growhouse.rest.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="profile")
public class Profile extends DefaultModel implements Serializable{	
	/**
	 * 
	 */
	private static final long serialVersionUID = -511005631464823759L;

	private String command;
	
	private String name;
	
	@Column(name="profile_name")
	private String profileName;
	
	@Column(name="device_hid")
	private String deviceHid;
	
	@Column(name="profile_hid")
	private String profileHid;
	
	@Column(name="message_expiration")
	private Integer messageExpiration=10;
	
	@OneToOne(fetch=FetchType.EAGER,cascade=CascadeType.PERSIST)
	@JoinColumn(name="payload_id")
	private Payload payload;
	
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "grow_section_id")
	private GrowSection growSection;
	

	public String getProfileHid() {
		return profileHid;
	}

	public void setProfileHid(String profileHid) {
		this.profileHid = profileHid;
	}

	public String getCommand() {
		return command;
	}

	public GrowSection getGrowSection() {
		return growSection;
	}

	public void setGrowSection(GrowSection growSection) {
		this.growSection = growSection;
	}

	public void setCommand(String command) {
		this.command = command;
	}

	public String getDeviceHid() {
		return deviceHid;
	}

	public void setDeviceHid(String deviceHid) {
		this.deviceHid = deviceHid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getMessageExpiration() {
		return messageExpiration;
	}

	public void setMessageExpiration(Integer messageExpiration) {
		this.messageExpiration = messageExpiration;
	}

	public Payload getPayload() {
		return payload;
	}

	public void setPayload(Payload payload) {
		this.payload = payload;
	}

	public String getProfileName() {
		return profileName;
	}

	public void setProfileName(String profileName) {
		this.profileName = profileName;
	}

	@Override
	public String toString() {
		return "Profile [command=" + command + ", name=" + name + ", profileName=" + profileName + ", deviceHid="
				+ deviceHid + ", profileHid=" + profileHid + ", messageExpiration=" + messageExpiration + ", payload="
				+ payload + ", growSection=" + growSection + "]";
	}

	
	
	
	

}
