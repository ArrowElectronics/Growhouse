/**
 * 
 */
package com.growhouse.rest.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

/**
 * @author dharita.chokshi
 *
 */
@Entity
@Table(name = "grow_areas")
public class GrowArea extends DefaultModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3551650341269708202L;

	@Column(name = "grow_area_name")
	@NotBlank
	private String growAreaName;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "grow_area_type_id")
	private GrowAreaType growAreaType;

	@Column(name = "mac_id")
	@NotBlank
	private String macId;

	@Column(name = "grow_area_hid")
	private String growAreaHId;

	@Column(name = "grow_area_uid")
	private String growAreaUId;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "container_id")
	private Container container;

	private String description;
	
	@Column(name = "latest_heartbeat_timestamp")
	private Long latestHeartbeat = 0L;
	
	@Column(name = "gateway_device_hid")
	private String gatewayDeviceHId;

	@Column(name = "account_id",updatable = false)
	private Integer accountId;
	
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="facility_id")
	private Facility facility;
	
	private Integer layout = 0;

	/**
	 * @return the growAreaName
	 */
	public String getGrowAreaName() {
		return growAreaName;
	}

	/**
	 * @param growAreaName
	 *            the growAreaName to set
	 */
	public void setGrowAreaName(String growAreaName) {
		this.growAreaName = growAreaName;
	}

	/**
	 * @return the growAreaType
	 */
	public GrowAreaType getGrowAreaType() {
		return growAreaType;
	}

	/**
	 * @param growAreaType
	 *            the growAreaType to set
	 */
	public void setGrowAreaType(GrowAreaType growAreaType) {
		this.growAreaType = growAreaType;
	}

	/**
	 * @return the macId
	 */
	public String getMacId() {
		return macId;
	}

	/**
	 * @param macId
	 *            the macId to set
	 */
	public void setMacId(String macId) {
		this.macId = macId;
	}

	/**
	 * @return the growAreaHid
	 */
	public String getGrowAreaHId() {
		return growAreaHId;
	}

	/**
	 * @param growAreaHid
	 *            the growAreaHid to set
	 */
	public void setGrowAreaHId(String growAreaHid) {
		this.growAreaHId = growAreaHid;
	}

	/**
	 * @return the growAreaUid
	 */
	public String getGrowAreaUId() {
		return growAreaUId;
	}

	/**
	 * @param growAreaUid
	 *            the growAreaUid to set
	 */
	public void setGrowAreaUId(String growAreaUid) {
		this.growAreaUId = growAreaUid;
	}

	/**
	 * @return the container
	 */
	public Container getContainer() {
		return container;
	}

	/**
	 * @param container
	 *            the container to set
	 */
	public void setContainer(Container container) {
		this.container = container;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description
	 *            the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the layout
	 */
	public Integer getLayout() {
		return layout;
	}

	public String getGatewayDeviceHId() {
		return gatewayDeviceHId;
	}

	public void setGatewayDeviceHId(String gatewayDeviceHId) {
		this.gatewayDeviceHId = gatewayDeviceHId;
	}

	/**
	 * @param layout
	 *            the layout to set
	 */
	public void setLayout(Integer layout) {
		this.layout = layout;
	}

	public Long getLatestHeartbeat() {
		return latestHeartbeat;
	}

	public void setLatestHeartbeat(Long latestHeartbeat) {
		this.latestHeartbeat = latestHeartbeat;
	}

	

	public Integer getAccountId() {
		return accountId;
	}

	public void setAccountId(Integer accountId) {
		this.accountId = accountId;
	}

	public Facility getFacility() {
		return facility;
	}

	public void setFacility(Facility facility) {
		this.facility = facility;
	}

	@Override
	public String toString() {
		return "GrowArea [growAreaName=" + growAreaName + ", growAreaType=" + growAreaType + ", macId=" + macId
		        + ", growAreaHId=" + growAreaHId + ", growAreaUId=" + growAreaUId + ", container=" + container
		        + ", description=" + description + ", latestHeartbeat=" + latestHeartbeat + ", gatewayDeviceHId="
		        + gatewayDeviceHId + ", accountId=" + accountId + ", facility=" + facility + ", layout=" + layout + "]";
	}

	

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	

}
