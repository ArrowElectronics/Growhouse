package com.growhouse.rest.dto.konexios;

public class UpdateUserRequest {
    private Contact contact;

    public UpdateUserRequest contact(Contact contact) {
        this.contact = contact;
        return this;
    }

    public Contact getContact() {
        return this.contact;
    }

    public void setContact(Contact contact) {
        this.contact = contact;
    }
}