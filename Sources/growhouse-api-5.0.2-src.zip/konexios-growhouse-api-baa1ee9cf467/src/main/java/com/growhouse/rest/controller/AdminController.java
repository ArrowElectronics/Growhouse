package com.growhouse.rest.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.growhouse.rest.dto.UserDTO;
import com.growhouse.rest.entity.Account;
import com.growhouse.rest.entity.User;
import com.growhouse.rest.facade.UserFacade;
import com.growhouse.rest.repository.AccountRepository;
import com.growhouse.rest.repository.UserRepository;
import com.growhouse.rest.response.ResponseMessage;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/api/admin")
@Transactional
public class AdminController extends ControllerAbstract {
	public static final Logger LOGGER = LoggerFactory.getLogger(AdminController.class);

	@Autowired
	private UserRepository userRepo;

	@Autowired
	private UserFacade userFacade;

	@Autowired
	private AccountRepository accountRepo;

	@PostMapping(value = "/migrate-users")
	@ApiOperation(value = "migrate users")
	public ResponseEntity<ResponseMessage> migrateUser() {
		ResponseEntity<ResponseMessage> responseEntity;
		if (!isSuperAdmin()) {
			responseEntity = new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
		} else {
			try {
				migrateAccounts();
				migrateUsernames();
				syncKonexios();
				responseEntity = new ResponseEntity<ResponseMessage>(HttpStatus.OK);
			} catch (Exception e) {
				LOGGER.error("error encountered", e);
				responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
		return responseEntity;
	}

	private void migrateAccounts() {
		List<Account> accounts = accountRepo.findByAdminIdIsNullAndIsActiveTrue();
		LOGGER.info("accountList: " + accounts.size());
		accounts.forEach(account -> {
			LOGGER.info("--------->> processing account: " + account.getAccountName());
			User user = userRepo.findByEmailAndIsActiveTrue(account.getEmailId());
			if (user != null) {
				account.setAdminId(user.getId());
				accountRepo.saveAndFlush(account);
				LOGGER.info("------------------>> updated admin: " + user.getEmail());
			}
		});
	}

	private void syncKonexios() {
		List<User> users = userRepo.findByUserHidIsNullAndIsActiveTrue();
		LOGGER.info("konexiosList: " + users.size());

		for (User user : users) {
			LOGGER.info("--------->> processing user: " + user.getUsername());
			UserDTO dto = userFacade.convertEntityToDTO(user);
			com.growhouse.rest.dto.konexios.User konexiosUser = userFacade.createKonexiosUser(dto);
			LOGGER.info("------------------>> konexios login: " + konexiosUser.getLogin());
			user.setUserHid(konexiosUser.getHid());
			userRepo.saveAndFlush(user);
		}
	}

	@SuppressWarnings("deprecation")
	private void migrateUsernames() {
		List<User> users = userRepo.findByIsActiveTrueAndMigratedUsernameIsNull();
		final String gmail = "@gmail.com";
		users.removeIf(user -> !user.getEmail().endsWith(gmail));
		LOGGER.info("usernameList: " + users.size());

		for (User user : users) {
			String email = user.getEmail().toLowerCase();
			LOGGER.info("processing user: " + user.getUsername() + " / " + email);
			String prefix = email.substring(0, email.length() - gmail.length());
			user.setMigratedUsername(user.getUsername());
			user.setUsername(prefix);
			LOGGER.info("------------->> updating username to " + user.getUsername());
			userRepo.saveAndFlush(user);
		}
	}
}
