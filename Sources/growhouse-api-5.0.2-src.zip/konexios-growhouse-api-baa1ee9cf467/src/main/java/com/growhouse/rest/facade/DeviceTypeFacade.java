/**
 * 
 */
package com.growhouse.rest.facade;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.growhouse.rest.dto.DeviceTypeDTO;
import com.growhouse.rest.entity.DeviceType;
import com.growhouse.rest.services.IDeviceTypeService;

/**
 * @author dharita.chokshi
 *
 */
@Component
public class DeviceTypeFacade {

	public static final Logger LOGGER = LoggerFactory.getLogger(DeviceTypeFacade.class);

	@Autowired
	private IDeviceTypeService deviceTypeService;

	@Autowired
	private ModelMapper modelMapper;

	public List<DeviceTypeDTO> getDeviceTypes() {
		List<DeviceTypeDTO> deviceTypeDTOs = new ArrayList<>();
		List<DeviceType> deviceTypes = deviceTypeService.getAllDeviceTypes();
		if (deviceTypes != null && !deviceTypes.isEmpty()) {
			deviceTypeDTOs = deviceTypes.stream().map(this::convertEntityToDTO)
					.collect(Collectors.toList());
		}
		return deviceTypeDTOs;
	}

	public DeviceTypeDTO getDeviceTypeById(int deviceTypeId) {
		DeviceTypeDTO deviceTypeDTO = null;
		DeviceType deviceType = deviceTypeService.getDeviceTypeById(deviceTypeId);
		if (deviceType != null) {
			deviceTypeDTO = convertEntityToDTO(deviceType);
		}
		return deviceTypeDTO;
	}

	private DeviceTypeDTO convertEntityToDTO(DeviceType deviceType) {
		return modelMapper.map(deviceType, DeviceTypeDTO.class);
	}

}
