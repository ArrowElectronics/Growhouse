package com.growhouse.rest.services.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SchedulerFactory;
import org.quartz.impl.StdSchedulerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.growhouse.rest.KonexiosConfig;
import com.growhouse.rest.entity.LedNodeGroupChannelConfiguration;
import com.growhouse.rest.entity.LedNodeGroupProfile;
import com.growhouse.rest.entity.LedNodeProfileEvent;
import com.growhouse.rest.repository.GroupDeviceRepository;
import com.growhouse.rest.repository.LedNodeGroupChannelConfigRepository;
import com.growhouse.rest.repository.LedNodeGroupProfileRepository;
import com.growhouse.rest.repository.LedNodeProfileEventRepository;
import com.growhouse.rest.services.ILedNodeService;

@Service
public class LedNodeService implements ILedNodeService {

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private LedNodeGroupChannelConfigRepository ledNodeGroupChannelConfigRepository;

	@Autowired
	private LedNodeGroupProfileRepository ledNodeGroupProfileRepository;

	@Autowired
	private LedNodeProfileEventRepository ledNodeProfileEventRepository;

	@Autowired
	private GroupDeviceRepository groupDeviceRepo;

	@Autowired
	private KonexiosConfig config;

	private static final Logger LOGGER = LogManager.getLogger(LedNodeService.class);

	@SuppressWarnings("unchecked")
	public Map<String, Object> getLedNodeStateProperties(String deviceHid) {

		Map<Object, Object> map;
		Map<String, Object> extraInfoMap = null;
		String url = config.buildDeviceUrl(deviceHid);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set(config.getAuthTokenKey(), config.getAuthToken());

		HttpEntity<String> entity = new HttpEntity<>(headers);
		ResponseEntity<Map> response = restTemplate.exchange(url, HttpMethod.GET, entity, Map.class);
		if (response.getStatusCode() == HttpStatus.OK) {
			map = (HashMap<Object, Object>) response.getBody().get("info");
			String extraInfo = String.valueOf(map.get("Extra-info"));
			try {
				extraInfoMap = objectMapper.readValue(extraInfo, new TypeReference<Map<String, Object>>() {
				});
			} catch (IOException ioException) {
				LOGGER.info("Error while fetching Led Node config {}" + ioException.getMessage());
			}

		}
		return extraInfoMap;
	}

	public LedNodeGroupChannelConfiguration createLedGroup(
			LedNodeGroupChannelConfiguration ledNodeGroupChannelConfiguration) {
		return ledNodeGroupChannelConfigRepository.save(ledNodeGroupChannelConfiguration);
	}

	public LedNodeGroupChannelConfiguration getGroupByGroupNameAndGateway(String groupName, int growAreaId) {
		return ledNodeGroupChannelConfigRepository.findByGrowAreaAndGroupNameAndIsActiveTrue(growAreaId, groupName);
	}

	public List<LedNodeGroupChannelConfiguration> getLedGroupByGrowareaId(Integer growAreaId) {
		return ledNodeGroupChannelConfigRepository.findByGrowAreaAndIsActiveTrueOrderByCreatedTimestampDesc(growAreaId);
	}

	public LedNodeGroupChannelConfiguration updateLedGroup(
			LedNodeGroupChannelConfiguration ledNodeGroupChannelConfiguration) {
		return ledNodeGroupChannelConfigRepository.save(ledNodeGroupChannelConfiguration);

	}

	public Optional<LedNodeGroupChannelConfiguration> getLedGroupById(Integer groupId) {
		return ledNodeGroupChannelConfigRepository.findById(groupId);
	}

	public LedNodeGroupChannelConfiguration deleteLedGroup(Integer groupId) {
		LedNodeGroupChannelConfiguration deletedLedGroup = null;
		Optional<LedNodeGroupChannelConfiguration> ledGroup = ledNodeGroupChannelConfigRepository.findById(groupId);
		if (ledGroup.isPresent() && ledGroup.get().isActive()) {
			LedNodeGroupChannelConfiguration dbLedGroup = ledGroup.get();
			dbLedGroup.setActive(false);
			deletedLedGroup = ledNodeGroupChannelConfigRepository.save(dbLedGroup);
			deleteLedNodeGroupProfilesByGroupId(groupId);
			deleteEventByGroupId(groupId);
			deleteLedNodeProfileEventByGroupId(groupId);
			groupDeviceRepo.updateGroupDevicesByGroupId(groupId);
		} else {
			throw new HttpClientErrorException(HttpStatus.NOT_FOUND, "This group id not found.");
		}
		return deletedLedGroup;
	}

	public void deleteEventByGroupId(Integer groupId) {
		List<LedNodeProfileEvent> events = ledNodeProfileEventRepository
				.findByGroupIdAndIsActiveTrueOrderByCreatedTimestampDesc(groupId);
		if (events != null && !events.isEmpty()) {
			SchedulerFactory schedFact = new StdSchedulerFactory();
			Scheduler sched;
			try {
				sched = schedFact.getScheduler();
				for (LedNodeProfileEvent event : events) {
					sched.deleteJob(new JobKey(event.getJobName(), event.getJobName()));
				}
			} catch (SchedulerException e) {
				LOGGER.info("Exception occured while deleting event.");
			}
		}
	}

	public void deleteEventByProfileId(Integer profileId) {
		List<LedNodeProfileEvent> events = ledNodeProfileEventRepository.findByProfileIdAndIsActiveTrue(profileId);
		if (events != null && !events.isEmpty()) {
			SchedulerFactory schedFact = new StdSchedulerFactory();
			Scheduler sched;
			try {
				sched = schedFact.getScheduler();
				for (LedNodeProfileEvent event : events) {
					sched.deleteJob(new JobKey(event.getJobName(), event.getJobName()));
					LOGGER.info("deleted job while delete profile-- " + event.getJobName());
					Thread.sleep(1000);
				}
			} catch (SchedulerException | InterruptedException e) {
				LOGGER.info("Exception occured while deleting event.");
				Thread.currentThread().interrupt();
			}
		}
	}

	public void deleteLedNodeProfileEventByGroupId(Integer groupId) {
		ledNodeProfileEventRepository.deleteLedNodeProfileEventByGroupId(groupId);
	}

	public void deleteLedNodeProfileEventByProfileId(Integer profileId) {
		ledNodeProfileEventRepository.deleteLedNodeProfileEventByProfileId(profileId);
	}

	public void updateEventProfileNameByProfileId(String profileName, Integer profileId) {
		ledNodeProfileEventRepository.updateEventProfileNameByProfileId(profileName, profileId);
	}

	public LedNodeGroupProfile createLedNodeGroupProfile(LedNodeGroupProfile ledNodeGroupProfile) {
		return ledNodeGroupProfileRepository.save(ledNodeGroupProfile);
	}

	public LedNodeGroupProfile getProfileByProfileNameAndGroupId(String profileName, int groupId) {
		return ledNodeGroupProfileRepository.findByLedProfileNameAndGroupIdAndIsActiveTrue(profileName, groupId);

	}

	public LedNodeGroupProfile updateLedNodeGroupProfile(LedNodeGroupProfile ledGroupProfile) {
		return ledNodeGroupProfileRepository.save(ledGroupProfile);
	}

	public List<LedNodeGroupProfile> getLedNodeGrupProfilesByGroupId(Integer groupId) {
		return ledNodeGroupProfileRepository.findByGroupIdAndIsActiveTrueOrderByCreatedTimestampDesc(groupId);
	}

	public void deleteLedNodeGroupProfilesByGroupId(Integer groupId) {
		ledNodeGroupProfileRepository.deleteLedNodeProfilesByGroupId(groupId);
	}

	public void deleteLedNodeProfileByProfileId(Integer profileId) {
		ledNodeGroupProfileRepository.deleteLedProfileById(profileId);
		deleteEventByProfileId(profileId);
		deleteLedNodeProfileEventByProfileId(profileId);

	}

	public void deleteGroupsByGatewayId(Integer gatewayId) {
		List<LedNodeGroupChannelConfiguration> groups = getLedGroupByGrowareaId(gatewayId);
		if (groups != null && !groups.isEmpty()) {
			for (LedNodeGroupChannelConfiguration group : groups) {
				deleteLedGroup(group.getId());
			}
		}

	}

	public LedNodeGroupProfile getGroupProfileByProfileId(Integer profileId) {
		return ledNodeGroupProfileRepository.findByIdAndIsActiveTrue(profileId);
	}

}
