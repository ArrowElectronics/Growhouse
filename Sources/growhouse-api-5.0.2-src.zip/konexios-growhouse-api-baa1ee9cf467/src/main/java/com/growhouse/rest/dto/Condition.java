package com.growhouse.rest.dto;

import java.util.List;

public class Condition {
	
	private String expression;
	private List<Action> actions;
	public String getExpression() {
		return expression;
	}
	public void setExpression(String expression) {
		this.expression = expression;
	}
	public List<Action> getActions() {
		return actions;
	}
	public void setActions(List<Action> actions) {
		this.actions = actions;
	}

}
