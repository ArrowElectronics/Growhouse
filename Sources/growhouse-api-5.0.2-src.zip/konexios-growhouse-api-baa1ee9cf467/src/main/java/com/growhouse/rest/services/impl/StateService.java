/**
 * 
 */
package com.growhouse.rest.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.growhouse.rest.entity.State;
import com.growhouse.rest.repository.StateRepository;
import com.growhouse.rest.services.IStateService;

/**
 * @author dharita.chokshi
 *
 */
@Service
public class StateService implements IStateService {

	@Autowired
	private StateRepository stateRepository;

	
	public List<State> findAll() {
		return stateRepository.findAll();
	}

	public List<State> findByCountryId(int countryId) {
		return stateRepository.findByCountryId(countryId);
	}

}
