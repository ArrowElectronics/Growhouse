/**
 * 
 */
package com.growhouse.rest.facade;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.growhouse.rest.dto.StateDTO;
import com.growhouse.rest.entity.State;
import com.growhouse.rest.services.impl.StateService;

/**
 * @author dharita.chokshi
 *
 */
@Component
public class StateFacade {

	public static final Logger LOGGER = LoggerFactory.getLogger(StateFacade.class);

	@Autowired
	private StateService stateService;

	@Autowired
	private ModelMapper modelMapper;

	public List<StateDTO> getAllStates() {
		List<StateDTO> stateDTOs = new ArrayList<>();
		List<State> states = stateService.findAll();
		if (states != null && !states.isEmpty()) {
			stateDTOs = states.stream().map(this::convertEntityToDTO).collect(Collectors.toList());
		}
		return stateDTOs;
	}

	public List<StateDTO> getStatesByCountryId(int countryId) {
		List<StateDTO> stateDTOs = new ArrayList<>();
		List<State> states = stateService.findByCountryId(countryId);
		if (states != null && !states.isEmpty()) {
			stateDTOs = states.stream().map(this::convertEntityToDTO).collect(Collectors.toList());
		}
		return stateDTOs;
	}

	private StateDTO convertEntityToDTO(State state) {
		return modelMapper.map(state, StateDTO.class);
	}

}
