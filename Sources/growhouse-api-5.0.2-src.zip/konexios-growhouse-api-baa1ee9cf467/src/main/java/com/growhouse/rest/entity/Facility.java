/**
 * 
 */
package com.growhouse.rest.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.security.core.context.SecurityContextHolder;

/**
 * @author dharita.chokshi
 *
 */
@Entity
@Table(name = "facilities")
public class Facility implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1848429063289828471L;

	@NotBlank
	@Column(name = "facility_name")
	private String facilityName;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "locality")
	private Locality locality;

	private String zip;

	private double longitude;

	private double latitude;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "admin")
	private User admin;

	private String description;
	
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "account_id",updatable = false)
	private Account account;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "is_active", columnDefinition = "TINYINT DEFAULT '1'")
	@NotNull
	private boolean isActive = true;

	@Column(updatable = false, name = "created_timestamp", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	@Temporal(TemporalType.TIMESTAMP)
	@CreationTimestamp
	private Date createdTimestamp;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "created_by",updatable = false)
	private User createdBy;

	@Column(name = "updated_timestamp", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
	@Temporal(TemporalType.TIMESTAMP)
	@UpdateTimestamp
	private Date updatedTimestamp;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "updated_by")
	private User updatedBy;

	@PrePersist
	protected void onCreate() {
		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();		
		createdBy = updatedBy = user;
		updatedTimestamp = createdTimestamp = new Date();
	}

	@PreUpdate
	protected void onUpdate() {
		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();		
		updatedBy = user;
		updatedTimestamp = new Date();
	}

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the isActive
	 */
	public boolean isActive() {
		return isActive;
	}

	/**
	 * @param isActive
	 *            the isActive to set
	 */
	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	/**
	 * @return the createdTimestamp
	 */
	public Date getCreatedTimestamp() {
		return createdTimestamp;
	}

	/**
	 * @param createdTimestamp
	 *            the createdTimestamp to set
	 */
	public void setCreatedTimestamp(Date createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	/**
	 * @return the createdBy
	 */
	public User getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy
	 *            the createdBy to set
	 */
	public void setCreatedBy(User createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the updatedTimestamp
	 */
	public Date getUpdatedTimestamp() {
		return updatedTimestamp;
	}

	/**
	 * @param updatedTimestamp
	 *            the updatedTimestamp to set
	 */
	public void setUpdatedTimestamp(Date updatedTimestamp) {
		this.updatedTimestamp = updatedTimestamp;
	}

	/**
	 * @return the updatedBy
	 */
	public User getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy
	 *            the updatedBy to set
	 */
	public void setUpdatedBy(User updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * @return the facilityName
	 */
	public String getFacilityName() {
		return facilityName;
	}

	/**
	 * @param facilityName
	 *            the facilityName to set
	 */
	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	/**
	 * @return the locality
	 */
	public Locality getLocality() {
		return locality;
	}

	/**
	 * @param locality
	 *            the locality to set
	 */
	public void setLocality(Locality locality) {
		this.locality = locality;
	}

	

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	/**
	 * @return the longitude
	 */
	public double getLongitude() {
		return longitude;
	}

	/**
	 * @param longitude
	 *            the longitude to set
	 */
	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	/**
	 * @return the latitude
	 */
	public double getLatitude() {
		return latitude;
	}

	/**
	 * @param latitude
	 *            the latitude to set
	 */
	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	/**
	 * @return the admin
	 */
	public User getAdmin() {
		return admin;
	}

	/**
	 * @param admin
	 *            the admin to set
	 */
	public void setAdmin(User admin) {
		this.admin = admin;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description
	 *            the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	@Override
	public String toString() {
		return "Facility [facilityName=" + facilityName + ", locality=" + locality + ", zip=" + zip + ", longitude="
		        + longitude + ", latitude=" + latitude + ", admin=" + admin + ", description=" + description
		        + ", account=" + account + ", id=" + id + ", isActive=" + isActive + ", createdTimestamp="
		        + createdTimestamp + ", createdBy=" + createdBy + ", updatedTimestamp=" + updatedTimestamp
		        + ", updatedBy=" + updatedBy + "]";
	}

}
