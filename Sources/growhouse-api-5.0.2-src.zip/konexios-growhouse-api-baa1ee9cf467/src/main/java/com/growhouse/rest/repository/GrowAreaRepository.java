/**
 * 
 */
package com.growhouse.rest.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.growhouse.rest.entity.GrowArea;

/**
 * @author dharita.chokshi
 *
 */
@Repository
public interface GrowAreaRepository extends JpaRepository<GrowArea, Integer> {

	public List<GrowArea> findByIsActiveTrue();

	public List<GrowArea> findByContainerIdAndIsActiveTrue(int containerId);
	
	@Modifying(clearAutomatically = true)
	@Transactional
	@Query(value = "update grow_areas ga set ga.latest_heartbeat_timestamp = ? where ga.grow_area_hid = ?", nativeQuery = true)
	public int updateLatestHeartbeatTimestamp(long date, String growAreaHId);

	public List<GrowArea> findByIdInAndLatestHeartbeatLessThanAndIsActiveTrue(List<Integer>growAreaIdList,long thirtyminsTime);

	public int countByIdInAndLatestHeartbeatLessThanAndIsActiveTrue(List<Integer>growAreaIdList,long thirtyminsTime);
	
	public int countByIsActiveTrue();
	
	public Optional<GrowArea> findByIdAndIsActiveTrue(int id);
	
	public int countByAccountIdInAndIsActiveTrue(List<Integer>accountIdList);
	
	public GrowArea findByGrowAreaHIdAndIsActiveTrue(String growAreaHId);
}
