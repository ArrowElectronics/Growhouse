/**
 * 
 */
package com.growhouse.rest.services;

import java.util.List;

import com.growhouse.rest.entity.Facility;
import com.growhouse.rest.repository.FacilityRepository;

/**
 * @author dharita.chokshi
 *
 */
public interface IFacilityService {

	public List<Facility> getActiveFacilities();

	public List<Facility> getAllFacilities();

	public Facility getFacilityById(int id);

	public Facility createFacility(Facility facility);

	public Facility updateFacility(Facility facility);

	public Facility deleteFacility(int id);
	
	public FacilityRepository getFacilitiRepository();
	
	public int getActiveFacilityCount();
	
	public List<Facility> getActiveFacilitiesByAccountId(int accountId);
	
	public Facility getFacilityByFacilityName(String facilityName,int accountId);
}
