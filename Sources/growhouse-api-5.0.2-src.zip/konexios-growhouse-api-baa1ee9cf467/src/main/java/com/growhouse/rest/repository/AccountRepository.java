/**
 * 
 */
package com.growhouse.rest.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.growhouse.rest.entity.Account;

/**
 * @author dharita.chokshi
 *
 */
@Repository
public interface AccountRepository extends JpaRepository<Account, Integer> {

	public List<Account> findByCreatedByIdAndIsActiveTrueOrderByCreatedTimestampDesc(int userId);

	public List<Account> findByIsActiveTrueAndAdminIdIsNotNullOrderByCreatedTimestampDesc();

	public int countByCreatedByIdAndIsActiveTrue(int userId);

	public int countByIsActiveTrueAndAdminIdIsNotNull();

	public Optional<Account> findByIdAndIsActiveTrue(int id);

	public Account findByAccountNameAndIsActiveTrue(String name);

	public Optional<Account> findByAdminId(int adminId);

	public List<Account> findByAdminIdIsNullAndIsActiveTrue();
}
