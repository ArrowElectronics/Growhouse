package com.growhouse.rest.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="led_node_group_profile")
public class LedNodeGroupProfile extends DefaultModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5415649067820703447L;

	
	@Column(name="group_id")
	private Integer groupId;
	
	
	@Column(name="led_profile_name")
	private String ledProfileName;
	
	@Column(name="channel_values")
	private String channelValues;
	
	@Column(name="channel_configuration")
	private String channelConfiguration;
	
	private String description;

	@Column(name = "status", columnDefinition = "TINYINT DEFAULT '0'")
	@NotNull
	private boolean status = false;
	
	private Integer preset;
	
	
	
	public Integer getPreset() {
		return preset;
	}

	public void setPreset(Integer preset) {
		this.preset = preset;
	}

	public Integer getGroupId() {
		return groupId;
	}

	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}

	public String getLedProfileName() {
		return ledProfileName;
	}

	public void setLedProfileName(String ledProfileName) {
		this.ledProfileName = ledProfileName;
	}

	public String getChannelValues() {
		return channelValues;
	}

	public void setChannelValues(String channelValues) {
		this.channelValues = channelValues;
	}

	public String getChannelConfiguration() {
		return channelConfiguration;
	}

	public void setChannelConfiguration(String channelConfiguration) {
		this.channelConfiguration = channelConfiguration;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	
	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "LedNodeGroupProfile [groupId=" + groupId + ", ledProfileName=" + ledProfileName + ", channelValues="
				+ channelValues + ", channelConfiguration=" + channelConfiguration + ", description=" + description
				+ ", status=" + status + ", preset=" + preset + "]";
	}

	
		
}
