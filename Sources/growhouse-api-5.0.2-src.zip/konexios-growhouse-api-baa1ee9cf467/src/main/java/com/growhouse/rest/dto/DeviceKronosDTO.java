package com.growhouse.rest.dto;

public class DeviceKronosDTO {

	private String hid;

	public String getHid() {
		return hid;
	}

	public void setHid(String hid) {
		this.hid = hid;
	}

}
